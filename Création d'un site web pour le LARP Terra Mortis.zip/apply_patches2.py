#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Trouver la ligne avec handleSubmit
for i, line in enumerate(lines):
    if 'const handleSubmit = () => {' in line:
        print(f"Trouvé handleSubmit à la ligne {i+1}")
        # Afficher les 30 prochaines lignes
        for j in range(i, min(i+30, len(lines))):
            print(f"{j+1}: {lines[j]}", end='')
        break
