import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "organizer"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Races ────────────────────────────────────────────────────────────────────
export const races = mysqlTable("races", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  faction: mysqlEnum("faction", ["Sanctum", "Légion", "Tous"]).notNull(),
  description: text("description").notNull(),
  bonuses: json("bonuses").notNull(), // array of strings
  maluses: json("maluses").notNull(), // array of strings
  abilities: json("abilities").notNull(), // array of {name, description}
  physicalDescription: text("physicalDescription").notNull(),
  startingLanguages: json("startingLanguages").notNull(), // array of strings
  pvBonus: int("pvBonus").default(0).notNull(),
  manaBonus: int("manaBonus").default(0).notNull(),
  luteBonus: int("luteBonus").default(0).notNull(),
  pvMalus: int("pvMalus").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Race = typeof races.$inferSelect;

// ─── Classes ──────────────────────────────────────────────────────────────────
export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  faction: mysqlEnum("faction", ["Sanctum", "Légion", "Tous"]).notNull(),
  description: text("description").notNull(),
  basePv: int("basePv").notNull(),
  baseMana: int("baseMana").notNull(),
  baseAbilities: json("baseAbilities").notNull(), // array of {name, description}
  specialRules: json("specialRules").notNull(), // array of strings
  requiresWeapon: boolean("requiresWeapon").default(false).notNull(), // bâton/baguette requis
  code: json("code"), // array of strings (for paladin, chevalier de la mort)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Class = typeof classes.$inferSelect;

// ─── Class Paths (Voies de classe) ────────────────────────────────────────────
export const classPaths = mysqlTable("class_paths", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ClassPath = typeof classPaths.$inferSelect;

// ─── Class Abilities (Capacités par niveau) ───────────────────────────────────
export const classAbilities = mysqlTable("class_abilities", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").notNull(),
  pathId: int("pathId"), // null = base ability
  level: int("level").notNull(),
  name: varchar("name", { length: 150 }).notNull(),
  description: text("description").notNull(),
  manaCost: int("manaCost").default(0),
  pvCost: int("pvCost").default(0),
  usesPerCombat: int("usesPerCombat"),
  usesPerHour: int("usesPerHour"),
  usesPerDay: int("usesPerDay"),
  isBuff: boolean("isBuff").default(false),
  isSign: boolean("isSign").default(false),
  isIncantation: boolean("isIncantation").default(false),
  abilityType: varchar("abilityType", { length: 50 }), // "attaque", "soin", "contrôle", "buff", etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClassAbility = typeof classAbilities.$inferSelect;

// ─── Dons ─────────────────────────────────────────────────────────────────────
export const dons = mysqlTable("dons", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description").notNull(),
  canStack: boolean("canStack").default(false).notNull(),
  maxStacks: int("maxStacks").default(1),
  pvBonus: int("pvBonus").default(0),
  manaBonus: int("manaBonus").default(0),
  luteBonus: int("luteBonus").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Don = typeof dons.$inferSelect;

// ─── Compétences ──────────────────────────────────────────────────────────────
export const competences = mysqlTable("competences", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  category: mysqlEnum("category", ["simple", "artisanat"]).default("simple").notNull(),
  description: text("description").notNull(),
  baseAdvantage: text("baseAdvantage").notNull(),
  advancedAdvantage: text("advancedAdvantage"),
  requiredMaterial: text("requiredMaterial"),
  isAdultOnly: boolean("isAdultOnly").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Competence = typeof competences.$inferSelect;

// ─── Héritage Avantages ───────────────────────────────────────────────────────
export const heritageAvantages = mysqlTable("heritage_avantages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(),
  description: text("description").notNull(),
  xpCost: int("xpCost").notNull(),
  maxTimes: int("maxTimes").default(1),
  pvBonus: int("pvBonus").default(0),
  manaBonus: int("manaBonus").default(0),
  luteBonus: int("luteBonus").default(0),
  paBonus: int("paBonus").default(0),
  poBonus: int("poBonus").default(0),
  moneyBonus: varchar("moneyBonus", { length: 50 }),
  extraAbilitiesLevel1: int("extraAbilitiesLevel1").default(0),
  extraAbilitiesLevel2: int("extraAbilitiesLevel2").default(0),
  extraCompetences: int("extraCompetences").default(0),
  extraCharacteristicPoints: int("extraCharacteristicPoints").default(0),
  extraDons: int("extraDons").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HeritageAvantage = typeof heritageAvantages.$inferSelect;

// ─── Désavantages ─────────────────────────────────────────────────────────────
export const desavantages = mysqlTable("desavantages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(),
  description: text("description").notNull(),
  xpGain: int("xpGain").notNull(),
  xpType: mysqlEnum("xpType", ["permanent", "temporaire"]).notNull(),
  forbiddenClasses: json("forbiddenClasses"), // array of class names
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Desavantage = typeof desavantages.$inferSelect;

// ─── Personnages ──────────────────────────────────────────────────────────────
export const personnages = mysqlTable("personnages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // FK → users (pour compatibilité)
  profileId: int("profileId"), // FK → family_profiles (nouveau, pour comptes familiaux)
  name: varchar("name", { length: 150 }).notNull(),
  background: text("background"),
  faction: mysqlEnum("faction", ["Sanctum", "Légion"]).notNull(),
  raceId: int("raceId").notNull(),
  classId: int("classId").notNull(),
  classPathId: int("classPathId"),
  level: int("level").default(1).notNull(),

  // Caractéristiques (3-2-1 à distribuer)
  puissance: int("puissance").default(1).notNull(),
  resistance: int("resistance").default(1).notNull(),
  esprit: int("esprit").default(1).notNull(),

  // Stats calculées (stockées pour référence)
  maxPv: int("maxPv").default(1).notNull(),
  maxMana: int("maxMana").default(0).notNull(),
  lutte: int("lutte").default(0).notNull(),
  sauvegardes: int("sauvegardes").default(0).notNull(),

  // Sélections
  competenceId: int("competenceId"),
  selectedDons: json("selectedDons"), // array of don IDs
  heritageAvantages: json("heritageAvantages"), // array of {id, times}
  selectedDesavantages: json("selectedDesavantages"), // array of desavantage IDs
  xpPermanent: int("xpPermanent").default(0).notNull(),
  xpTemporaire: int("xpTemporaire").default(0).notNull(),

  // Argent de départ
  startingMoney: json("startingMoney"), // {cuivre, argent, or}

  // Langues
  languages: json("languages"), // array of strings

  // Notes additionnelles
  notes: text("notes"),

  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Personnage = typeof personnages.$inferSelect;
export type InsertPersonnage = typeof personnages.$inferInsert;

// ─── Événements ───────────────────────────────────────────────────────────────
export const evenements = mysqlTable("evenements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 300 }).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  maxPlayers: int("maxPlayers").default(0).notNull(), // 0 = illimité
  status: mysqlEnum("status", ["draft", "published", "cancelled", "completed"]).default("draft").notNull(),
  faction: mysqlEnum("faction", ["Sanctum", "Légion", "Tous"]).default("Tous").notNull(),
  price: varchar("price", { length: 100 }), // ex: "20$"
  notes: text("notes"), // notes internes pour les organisateurs
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Evenement = typeof evenements.$inferSelect;
export type InsertEvenement = typeof evenements.$inferInsert;

// ─── Inscriptions aux événements ──────────────────────────────────────────────
export const inscriptions = mysqlTable("inscriptions", {
  id: int("id").autoincrement().primaryKey(),
  evenementId: int("evenementId").notNull(),
  userId: int("userId").notNull(),
  personnageId: int("personnageId"), // personnage joué lors de l'événement
  status: mysqlEnum("status", ["pending", "confirmed", "cancelled"]).default("pending").notNull(),
  notes: text("notes"), // notes du joueur
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Inscription = typeof inscriptions.$inferSelect;
export type InsertInscription = typeof inscriptions.$inferInsert;


// ─── Encyclopédie (Source Unique de Données) ──────────────────────────────────
export const encyclopediaEntries = mysqlTable("encyclopedia_entries", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identité
  nom: varchar("nom", { length: 255 }).notNull(),
  categorie: varchar("categorie", { length: 50 }).notNull(), // races, classes, sous_classes, capacites, dons, competences, factions, ressources, materiaux, runes, recettes_alchimie, forge, objets_magiques, regles_combat, symboles, heritage_avantages, heritage_desavantages, langues, armures, caracteristiques
  description: text("description"),
  
  // Propriétés structurées (JSON)
  proprietes: json("proprietes"), // Contient tous les champs spécifiques à la catégorie
  
  // Relations avec d'autres entrées
  relations: json("relations"), // Ex: {"prerequis": [1, 5], "incompatible": [3], "debloque": [7, 8]}
  
  // Contraintes
  factionRequise: varchar("factionRequise", { length: 50 }), // null = toutes, "Sanctum", "Légion"
  conditions: json("conditions"), // Prérequis de niveau, classe, race, etc.
  
  // Audit
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedBy: int("updatedBy"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  
  // Soft delete
  deletedAt: timestamp("deletedAt"),
});

export type EncyclopediaEntry = typeof encyclopediaEntries.$inferSelect;
export type InsertEncyclopediaEntry = typeof encyclopediaEntries.$inferInsert;

// ─── Encyclopédie Relations ───────────────────────────────────────────────────
export const encyclopediaRelations = mysqlTable("encyclopedia_relations", {
  id: int("id").autoincrement().primaryKey(),
  
  sourceId: int("sourceId").notNull(), // FK → encyclopedia_entries
  cibleId: int("cibleId").notNull(), // FK → encyclopedia_entries
  typeRelation: varchar("typeRelation", { length: 50 }).notNull(), // prerequis, incompatible, debloque, reference, etc.
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EncyclopediaRelation = typeof encyclopediaRelations.$inferSelect;
export type InsertEncyclopediaRelation = typeof encyclopediaRelations.$inferInsert;

// ─── Encyclopédie History (Audit Trail) ───────────────────────────────────────
export const encyclopediaHistory = mysqlTable("encyclopedia_history", {
  id: int("id").autoincrement().primaryKey(),
  
  entryId: int("entryId").notNull(), // FK → encyclopedia_entries
  
  // Données avant modification
  ancienContenu: json("ancienContenu"),
  nouveauContenu: json("nouveauContenu"),
  
  // Métadonnées
  action: varchar("action", { length: 20 }).notNull(), // create, update, delete
  modifiedBy: int("modifiedBy"), // FK → users
  modifiedAt: timestamp("modifiedAt").defaultNow().notNull(),
  
  // Raison du changement
  raison: varchar("raison", { length: 255 }),
});

export type EncyclopediaHistory = typeof encyclopediaHistory.$inferSelect;
export type InsertEncyclopediaHistory = typeof encyclopediaHistory.$inferInsert;

// ─── XP Permanent History (Audit Trail) ───────────────────────────────────────
export const xpPermanentHistory = mysqlTable("xp_permanent_history", {
  id: int("id").autoincrement().primaryKey(),
  
  userId: int("userId").notNull(), // FK → users
  
  montant: int("montant").notNull(), // Positif ou négatif
  soldeBefore: int("soldeBefore"), // Solde avant cette transaction
  soldeAfter: int("soldeAfter"), // Solde après cette transaction
  
  // Source
  sourceType: varchar("sourceType", { length: 50 }).notNull(), // event, admin_adjustment, etc.
  sourceId: int("sourceId"), // FK → evenements (si sourceType = event)
  
  description: varchar("description", { length: 255 }), // Ex: "Événement: Bataille de Ysgard"
  
  // Métadonnées
  createdBy: int("createdBy"), // FK → users (qui a créé cette transaction)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type XpPermanentHistory = typeof xpPermanentHistory.$inferSelect;
export type InsertXpPermanentHistory = typeof xpPermanentHistory.$inferInsert;

// ─── Personnage Dons (Junction Table) ──────────────────────────────────────────
export const personnageDons = mysqlTable("personnage_dons", {
  id: int("id").autoincrement().primaryKey(),
  
  personnageId: int("personnageId").notNull(), // FK → personnages
  donId: int("donId").notNull(), // FK → encyclopedia_entries (categorie = dons)
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PersonnageDon = typeof personnageDons.$inferSelect;
export type InsertPersonnageDon = typeof personnageDons.$inferInsert;

// ─── Personnage Compétences (Junction Table) ──────────────────────────────────
export const personnageCompetences = mysqlTable("personnage_competences", {
  id: int("id").autoincrement().primaryKey(),
  
  personnageId: int("personnageId").notNull(), // FK → personnages
  competenceId: int("competenceId").notNull(), // FK → encyclopedia_entries (categorie = competences)
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PersonnageCompetence = typeof personnageCompetences.$inferSelect;
export type InsertPersonnageCompetence = typeof personnageCompetences.$inferInsert;

// ─── Familles (Comptes familiaux) ────────────────────────────────────────────────
export const families = mysqlTable("families", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(),
  createdBy: int("createdBy").notNull(), // FK → users (parent créateur)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Family = typeof families.$inferSelect;
export type InsertFamily = typeof families.$inferInsert;

// ─── Profils de Famille (Parent/Enfant) ───────────────────────────────────────
export const familyProfiles = mysqlTable("family_profiles", {
  id: int("id").autoincrement().primaryKey(),
  familyId: int("familyId").notNull(), // FK → families
  name: varchar("name", { length: 150 }).notNull(),
  role: mysqlEnum("role", ["parent", "child"]).default("child").notNull(),
  xpPermanent: int("xpPermanent").default(0).notNull(), // XP partagé entre tous les personnages du profil
  isChild: boolean("isChild").default(false).notNull(), // Restreint les artisanats
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FamilyProfile = typeof familyProfiles.$inferSelect;
export type InsertFamilyProfile = typeof familyProfiles.$inferInsert;

// ─── Session de Famille (Profil actif) ────────────────────────────────────────
export const familySessions = mysqlTable("family_sessions", {
  id: int("id").autoincrement().primaryKey(),
  familyId: int("familyId").notNull(), // FK → families
  activeProfileId: int("activeProfileId").notNull(), // FK → family_profiles (profil actuellement actif)
  userId: int("userId").notNull(), // FK → users (pour tracer qui a changé de profil)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FamilySession = typeof familySessions.$inferSelect;
export type InsertFamilySession = typeof familySessions.$inferInsert;

// ─── Personnage Héritage (Junction Table) ──────────────────────────────────────
export const personnageHeritage = mysqlTable("personnage_heritage", {
  id: int("id").autoincrement().primaryKey(),
  
  personnageId: int("personnageId").notNull(), // FK → personnages
  heritageId: int("heritageId").notNull(), // FK → encyclopedia_entries (categorie = heritage_avantages ou heritage_desavantages)
  
  // Nombre de fois acheté (pour les avantages cumulables)
  nombre: int("nombre").default(1).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PersonnageHeritage = typeof personnageHeritage.$inferSelect;
export type InsertPersonnageHeritage = typeof personnageHeritage.$inferInsert;
