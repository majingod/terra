import { router, publicProcedure, protectedProcedure, adminProcedure } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { encyclopediaEntries, encyclopediaHistory, encyclopediaRelations } from "../../drizzle/schema";
import { eq, like, and, isNull, or } from "drizzle-orm";

/**
 * Procédures tRPC pour l'Encyclopédie
 * Source unique de données pour toutes les entrées du jeu
 */
export const encyclopediaRouter = router({
  /**
   * Récupère toutes les entrées de l'encyclopédie (publique)
   */
  getAll: publicProcedure.query(async () => {
    const db = await getDb();
    const entries = await db
      .select()
      .from(encyclopediaEntries)
      .where(isNull(encyclopediaEntries.deletedAt));

    return { entries };
  }),

  /**
   * Récupère les entrées par catégorie
   */
  getByCategory: publicProcedure
    .input(z.object({ categorie: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      const entries = await db
      .select()
      .from(encyclopediaEntries)
      .where(
        and(
          eq(encyclopediaEntries.categorie, input.categorie),
          isNull(encyclopediaEntries.deletedAt)
        )
      );

      return { entries };
    }),

  /**
   * Récupère une entrée spécifique par ID
   */
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      const entry = await db
      .select()
      .from(encyclopediaEntries)
      .where(
        and(
          eq(encyclopediaEntries.id, input.id),
          isNull(encyclopediaEntries.deletedAt)
        )
      )
      .limit(1);

      if (!entry.length) {
        throw new Error("Entrée non trouvée");
      }

      return { entry: entry[0] };
    }),

  /**
   * Recherche globale dans l'encyclopédie
   */
  search: publicProcedure
    .input(
      z.object({
        query: z.string().min(1),
        categorie: z.string().optional(),
        faction: z.string().optional(),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      let query = db
      .select()
      .from(encyclopediaEntries)
      .where(
        and(
          like(encyclopediaEntries.nom, `%${input.query}%`),
          isNull(encyclopediaEntries.deletedAt)
        )
      );

      if (input.categorie) {
        query = query.where(
          eq(encyclopediaEntries.categorie, input.categorie)
        );
      }

      if (input.faction) {
        query = query.where(
          eq(encyclopediaEntries.factionRequise, input.faction)
        );
      }

      const results = await query.limit(input.limit);

      return { results };
    }),

  /**
   * Récupère les entrées liées
   */
  getRelated: publicProcedure
    .input(z.object({ id: z.number(), type: z.string().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      const relations = await db
      .select()
      .from(encyclopediaRelations)
      .where(eq(encyclopediaRelations.sourceId, input.id));

      const relatedIds = relations.map((r: any) => r.cibleId);

      if (relatedIds.length === 0) {
        return { related: [] };
      }

      let query = db
        .select()
        .from(encyclopediaEntries)
        .where(
          and(
            eq(encyclopediaEntries.id, relatedIds[0]),
            isNull(encyclopediaEntries.deletedAt)
          )
        );

      for (let i = 1; i < relatedIds.length; i++) {
        query = query.where(
          or(
            eq(encyclopediaEntries.id, relatedIds[i]),
            isNull(encyclopediaEntries.deletedAt)
          )
        );
      }

      const related = await query;

      return { related };
    }),

  /**
   * ADMIN : Crée une nouvelle entrée
   */
  create: adminProcedure
    .input(
      z.object({
        nom: z.string(),
        categorie: z.string(),
        description: z.string().optional(),
        proprietes: z.any().optional(),
        relations: z.any().optional(),
        factionRequise: z.string().optional(),
        conditions: z.any().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      const result = await db.insert(encyclopediaEntries).values({
        nom: input.nom,
        categorie: input.categorie,
        description: input.description,
        proprietes: input.proprietes,
        relations: input.relations,
        factionRequise: input.factionRequise,
        conditions: input.conditions,
        createdBy: ctx.user.id,
        updatedBy: ctx.user.id,
      });

      // Enregistrer dans l'historique
      const entryId = (result as any).insertId || 1;
      await db.insert(encyclopediaHistory).values({
        entryId: entryId,
        action: "create",
        modifiedBy: ctx.user.id,
        nouveauContenu: {
          nom: input.nom,
          categorie: input.categorie,
          description: input.description,
          proprietes: input.proprietes,
        },
        raison: "Création initiale",
      });

      return { id: entryId };
    }),

  /**
   * ADMIN : Modifie une entrée existante
   */
  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        nom: z.string().optional(),
        description: z.string().optional(),
        proprietes: z.any().optional(),
        relations: z.any().optional(),
        factionRequise: z.string().optional(),
        conditions: z.any().optional(),
        raison: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      // Récupérer l'ancienne version
      const oldEntry = await db
        .select()
        .from(encyclopediaEntries)
        .where(eq(encyclopediaEntries.id, input.id))
        .limit(1);

      if (!oldEntry.length) {
        throw new Error("Entrée non trouvée");
      }

      // Mettre à jour
      await db
        .update(encyclopediaEntries)
        .set({
          nom: input.nom || oldEntry[0].nom,
          description: input.description || oldEntry[0].description,
          proprietes: input.proprietes || oldEntry[0].proprietes,
          relations: input.relations || oldEntry[0].relations,
          factionRequise: input.factionRequise || oldEntry[0].factionRequise,
          conditions: input.conditions || oldEntry[0].conditions,
          updatedBy: ctx.user.id,
        })
        .where(eq(encyclopediaEntries.id, input.id));

      // Enregistrer dans l'historique
      await db.insert(encyclopediaHistory).values({
        entryId: input.id,
        action: "update",
        modifiedBy: ctx.user.id,
        ancienContenu: oldEntry[0],
        nouveauContenu: {
          nom: input.nom || oldEntry[0].nom,
          description: input.description || oldEntry[0].description,
          proprietes: input.proprietes || oldEntry[0].proprietes,
        },
        raison: input.raison || "Modification",
      });

      return { success: true };
    }),

  /**
   * ADMIN : Supprime une entrée (soft delete)
   */
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      // Récupérer l'entrée
      const entry = await db
        .select()
        .from(encyclopediaEntries)
        .where(eq(encyclopediaEntries.id, input.id))
        .limit(1);

      if (!entry.length) {
        throw new Error("Entrée non trouvée");
      }

      // Soft delete
      await db
        .update(encyclopediaEntries)
        .set({
          deletedAt: new Date(),
          updatedBy: ctx.user.id,
        })
        .where(eq(encyclopediaEntries.id, input.id));

      // Enregistrer dans l'historique
      await db.insert(encyclopediaHistory).values({
        entryId: input.id,
        action: "delete",
        modifiedBy: ctx.user.id,
        ancienContenu: entry[0],
        raison: "Suppression",
      });

      return { success: true };
    }),

  /**
   * ADMIN : Récupère l'historique des modifications
   */
  getHistory: adminProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      const history = await db
        .select()
        .from(encyclopediaHistory)
        .where(eq(encyclopediaHistory.entryId, input.id));

      return { history };
    }),

  /**
   * ADMIN : Revient à une version antérieure (rollback)
   */
  rollback: adminProcedure
    .input(z.object({ id: z.number(), versionId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      // Récupérer la version historique
      const historyEntry = await db
        .select()
        .from(encyclopediaHistory)
        .where(eq(encyclopediaHistory.id, input.versionId))
        .limit(1);

      if (!historyEntry.length) {
        throw new Error("Version historique non trouvée");
      }

      const oldData = historyEntry[0].ancienContenu;

      // Restaurer les données
      await db
        .update(encyclopediaEntries)
        .set({
          nom: oldData?.nom,
          description: oldData?.description,
          proprietes: oldData?.proprietes,
          updatedBy: ctx.user.id,
        })
        .where(eq(encyclopediaEntries.id, input.id));

      // Enregistrer le rollback dans l'historique
      await db.insert(encyclopediaHistory).values({
        entryId: input.id,
        action: "update",
        modifiedBy: ctx.user.id,
        raison: `Rollback à la version ${input.versionId}`,
      });

      return { success: true };
    }),
});
