import { useState, useEffect } from "react";
import { AlertCircle } from "lucide-react";
import { useValidateCompetence } from "@/hooks/useValidateCompetence";

interface StepCompetencesProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepCompetences({ charData, onCharDataChange, heritageBonus }: StepCompetencesProps) {
  const [competences, setCompetences] = useState<any[]>([]);
  const [maxCompetences] = useState(2); // Base
  const { validateCompetence, getValidationResult } = useValidateCompetence();
  const [validatingCompetenceId, setValidatingCompetenceId] = useState<number | null>(null);

  // Calculer le nombre maximum de compétences avec bonus d'Héritage
  const totalMaxCompetences = maxCompetences + (heritageBonus?.extraCompetences || 0);
  const selectedCount = charData.selectedCompetences?.length || 0;
  const canAddMore = selectedCount < totalMaxCompetences;

  useEffect(() => {
    // TODO: Remplacer par la procédure tRPC
    setCompetences([
      { id: 1, name: "Épée", description: "Maîtrise de l'épée" },
      { id: 2, name: "Arc", description: "Maîtrise de l'arc" },
      { id: 3, name: "Magie", description: "Maîtrise de la magie" },
      { id: 4, name: "Alchimie", description: "Maîtrise de l'alchimie" },
      { id: 5, name: "Discrétion", description: "Maîtrise de la discrétion" },
      { id: 6, name: "Survie", description: "Maîtrise de la survie" },
    ]);
  }, []);

  const toggleCompetence = async (competenceId: number) => {
    const selected = charData.selectedCompetences || [];
    const isSelected = selected.includes(competenceId);

    if (isSelected) {
      // Retirer la compétence sans validation
      onCharDataChange({
        ...charData,
        selectedCompetences: selected.filter((id: number) => id !== competenceId),
      });
    } else if (canAddMore) {
      // Valider avant d'ajouter
      setValidatingCompetenceId(competenceId);
      try {
        const result = await validateCompetence(competenceId, {
          raceId: charData.raceId,
          classId: charData.classId,
          selectedCompetences: [...selected, competenceId],
          showToasts: true,
        });

        if (result.isValid) {
          onCharDataChange({
            ...charData,
            selectedCompetences: [...selected, competenceId],
          });
        }
      } finally {
        setValidatingCompetenceId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Affichage des compétences disponibles */}
      <div className="p-4 rounded-lg bg-green-50 border border-green-200">
        <div className="flex justify-between items-center">
          <span className="font-semibold text-green-900">Compétences sélectionnées</span>
          <span className="text-2xl font-bold text-green-600">
            {selectedCount} / {totalMaxCompetences}
          </span>
        </div>
        {heritageBonus?.extraCompetences > 0 && (
          <p className="text-xs text-green-700 mt-2">
            ✨ +{heritageBonus.extraCompetences} compétences bonus d'Héritage
          </p>
        )}
      </div>

      {/* Grille de compétences */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {competences.map((competence: any) => {
          const selected = charData.selectedCompetences || [];
          const isSelected = selected.includes(competence.id);

          return (
            <div
              key={competence.id}
              onClick={() => toggleCompetence(competence.id)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                isSelected
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              } ${!isSelected && !canAddMore ? "opacity-50 cursor-not-allowed" : ""} ${
                validatingCompetenceId === competence.id ? "opacity-60" : ""
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-bold mb-1">{competence.name}</h4>
                  <p className="text-xs text-muted-foreground">{competence.description}</p>
                  {getValidationResult(competence.id)?.errors.length ? (
                    <div className="flex items-center gap-1 mt-2 text-xs text-red-600">
                      <AlertCircle className="w-3 h-3" />
                      <span>{getValidationResult(competence.id)?.errors[0]}</span>
                    </div>
                  ) : null}
                </div>
                {isSelected && (
                  <div className="ml-2 w-6 h-6 rounded bg-primary flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Message si limite atteinte */}
      {!canAddMore && selectedCount > 0 && (
        <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
          <p className="text-sm text-amber-800">
            Vous avez sélectionné le nombre maximum de compétences ({totalMaxCompetences}).
          </p>
        </div>
      )}
    </div>
  );
}
