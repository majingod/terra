import { ChevronRight, Shield, Skull } from "lucide-react";
import { Link } from "wouter";

const statsTable = [
  { stat: "Points de Vie (PV)", description: "Représente la résistance physique du personnage. Quand ils tombent à 0, le personnage est à terre.", base: "Selon la classe + race + dons" },
  { stat: "Mana", description: "Énergie magique nécessaire pour utiliser des capacités spéciales et des sorts.", base: "Selon la classe + race + dons" },
  { stat: "Lutte", description: "Capacité à résister aux immobilisations et aux saisies.", base: "Selon la classe + race + dons" },
  { stat: "Sauvegardes", description: "Résistance aux effets négatifs (poisons, malédictions, etc.).", base: "Selon les dons et capacités" },
];

const combatRules = [
  {
    title: "Frappes de combat",
    content: "Chaque frappe avec une arme inflige 1 PV de dégâts par défaut, sauf indication contraire d'une capacité. Les frappes doivent être contrôlées. Les zones interdites sont : tête, cou, colonne vertébrale et entrejambe.",
  },
  {
    title: "Annonce des dégâts",
    content: "Lorsqu'une capacité inflige plus de 1 dégât, le joueur doit l'annoncer clairement. Ex: \"2 dégâts\" ou \"Poison\" lors de la frappe.",
  },
  {
    title: "Mort et résurrection",
    content: "Quand un personnage tombe à 0 PV, il est à terre et doit attendre. Un soigneur peut le stabiliser. Sans soins, après un délai déterminé par les organisateurs, le personnage meurt et doit se rendre au point de résurrection.",
  },
  {
    title: "Régénération des PV",
    content: "Les PV se régénèrent entre les combats selon les règles de l'événement. Certaines classes ont des capacités de régénération spéciales.",
  },
  {
    title: "Utilisation du mana",
    content: "Pour utiliser une capacité coûtant du mana, le joueur doit avoir suffisamment de mana disponible. Le mana se régénère selon les règles de l'événement ou via des capacités spéciales.",
  },
  {
    title: "Lutte et immobilisation",
    content: "Certaines capacités permettent d'immobiliser un adversaire. La lutte représente la résistance à ces effets. Si votre lutte est supérieure à celle de l'attaquant, vous pouvez résister.",
  },
];

const signRules = [
  { sign: "Main levée (poing fermé)", meaning: "Hors-jeu — le joueur est hors du jeu pour une raison de sécurité ou personnelle" },
  { sign: "Doigt pointé vers le bas", meaning: "Personnage à terre / inconscient" },
  { sign: "Bras croisés sur la poitrine", meaning: "Mort — le personnage est décédé" },
  { sign: "Main sur l'épaule", meaning: "Soins en cours — ne pas interrompre" },
];

export default function ReglesBase() {
  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground transition-colors">Accueil</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Règles de base</span>
        </nav>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}>
              <Shield className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            Règles de base
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Les règles fondamentales qui régissent le jeu à Terra Mortis.
          </p>
        </div>

        <div className="space-y-8">

          {/* Statistiques */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              Statistiques du personnage
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-heading text-foreground/70 uppercase tracking-wide text-xs">Statistique</th>
                    <th className="text-left py-3 px-4 font-heading text-foreground/70 uppercase tracking-wide text-xs">Description</th>
                    <th className="text-left py-3 px-4 font-heading text-foreground/70 uppercase tracking-wide text-xs">Calcul de base</th>
                  </tr>
                </thead>
                <tbody>
                  {statsTable.map((row, i) => (
                    <tr key={i} className="border-b border-border/30 hover:bg-secondary/20 transition-colors">
                      <td className="py-3 px-4 font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
                        {row.stat}
                      </td>
                      <td className="py-3 px-4 text-foreground/80">{row.description}</td>
                      <td className="py-3 px-4 text-muted-foreground text-xs">{row.base}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Caractéristiques */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              Caractéristiques (Attributs)
            </h2>
            <p className="text-foreground/80 mb-6 leading-relaxed">
              Chaque personnage possède trois caractéristiques principales qui influencent ses capacités. Lors de la création du personnage, vous disposez de <strong className="text-foreground">9 points</strong> à répartir entre ces trois caractéristiques (minimum 1, maximum 5 par caractéristique).
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                {
                  name: "Puissance",
                  abbr: "PUI",
                  desc: "Force physique et capacité de combat au corps à corps. Influence les dégâts et la résistance physique.",
                  color: "oklch(0.5 0.22 25)",
                  bonus: "+1 PV par point",
                },
                {
                  name: "Résistance",
                  abbr: "RES",
                  desc: "Endurance et capacité à encaisser les coups. Influence les points de vie et la résistance aux effets.",
                  color: "oklch(0.55 0.18 240)",
                  bonus: "+1 PV et +1 Lutte par point",
                },
                {
                  name: "Esprit",
                  abbr: "ESP",
                  desc: "Intelligence et puissance magique. Influence le mana disponible et l'efficacité des sorts.",
                  color: "oklch(0.45 0.15 140)",
                  bonus: "+1 Mana par point",
                },
              ].map(attr => (
                <div key={attr.name} className="p-4 rounded-lg border"
                  style={{ borderColor: `${attr.color}40`, background: `${attr.color}08` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-heading font-bold px-2 py-0.5 rounded"
                      style={{ background: `${attr.color}20`, color: attr.color, border: `1px solid ${attr.color}40` }}>
                      {attr.abbr}
                    </span>
                    <h3 className="font-heading font-semibold text-foreground">{attr.name}</h3>
                  </div>
                  <p className="text-xs text-foreground/70 mb-3 leading-relaxed">{attr.desc}</p>
                  <p className="text-xs font-semibold" style={{ color: attr.color }}>{attr.bonus}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 rounded-lg bg-secondary/30 text-sm text-foreground/70">
              <strong className="text-foreground">Exemple :</strong> Un guerrier avec Puissance 3, Résistance 4, Esprit 2 aura +3 PV de Puissance, +4 PV et +4 Lutte de Résistance, et +2 Mana d'Esprit.
            </div>
          </section>

          {/* Règles de combat */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              Règles de combat
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              {combatRules.map((rule, i) => (
                <div key={i} className="p-4 rounded-lg bg-secondary/20 border border-border/30">
                  <h3 className="font-heading font-semibold mb-2 text-foreground">{rule.title}</h3>
                  <p className="text-sm text-foreground/75 leading-relaxed">{rule.content}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Signes de jeu */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              Signes de jeu
            </h2>
            <p className="text-foreground/80 mb-4 leading-relaxed">
              Des gestes standardisés permettent de communiquer des états de jeu sans briser l'immersion.
            </p>
            <div className="space-y-3">
              {signRules.map((sign, i) => (
                <div key={i} className="flex items-start gap-4 p-3 rounded-lg bg-secondary/20">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-heading font-bold text-sm"
                    style={{ background: "oklch(0.65 0.18 45 / 0.2)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.4)" }}>
                    {i + 1}
                  </div>
                  <div>
                    <p className="font-heading font-semibold text-sm text-foreground">{sign.sign}</p>
                    <p className="text-sm text-foreground/70">{sign.meaning}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Monnaie */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
              Système de monnaie
            </h2>
            <p className="text-foreground/80 mb-4">
              La monnaie de Terra Mortis est divisée en trois types de pièces :
            </p>
            <div className="grid grid-cols-3 gap-4">
              {[
                { name: "Cuivre", abbr: "Cu", value: "1 Cu", color: "oklch(0.55 0.15 30)", desc: "La monnaie de base" },
                { name: "Argent", abbr: "Ag", value: "10 Cu", color: "oklch(0.7 0.02 260)", desc: "Vaut 10 pièces de cuivre" },
                { name: "Or", abbr: "Or", value: "100 Cu", color: "oklch(0.75 0.18 85)", desc: "Vaut 100 pièces de cuivre" },
              ].map(coin => (
                <div key={coin.name} className="p-4 rounded-lg text-center border"
                  style={{ borderColor: `${coin.color}40`, background: `${coin.color}08` }}>
                  <div className="w-10 h-10 rounded-full mx-auto mb-2 flex items-center justify-center font-heading font-bold"
                    style={{ background: `${coin.color}30`, color: coin.color, border: `2px solid ${coin.color}50` }}>
                    {coin.abbr}
                  </div>
                  <h3 className="font-heading font-semibold text-sm text-foreground">{coin.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{coin.desc}</p>
                  <p className="text-xs font-semibold mt-1" style={{ color: coin.color }}>{coin.value}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Navigation */}
          <div className="grid md:grid-cols-2 gap-4 pt-4">
            <Link href="/regles/races">
              <div className="p-4 rounded-lg border border-border/50 bg-card/20 hover:bg-card/40 transition-all group cursor-pointer">
                <h3 className="font-heading font-semibold text-foreground group-hover:text-primary transition-colors flex items-center gap-2">
                  Les races <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-muted-foreground mt-1">Humain, Elfe, Nain, Orc, Drow, Gobelin</p>
              </div>
            </Link>
            <Link href="/regles/classes">
              <div className="p-4 rounded-lg border border-border/50 bg-card/20 hover:bg-card/40 transition-all group cursor-pointer">
                <h3 className="font-heading font-semibold text-foreground group-hover:text-primary transition-colors flex items-center gap-2">
                  Les classes <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-muted-foreground mt-1">Guerrier, Mage, Druide, Roublard...</p>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
