import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  classAbilities,
  classPaths,
  classes,
  competences,
  desavantages,
  dons,
  evenements,
  heritageAvantages,
  inscriptions,
  InsertEvenement,
  InsertInscription,
  InsertPersonnage,
  InsertUser,
  personnages,
  races,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users);
}

export async function updateUserRole(userId: number, role: "user" | "admin" | "organizer") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ─── Races ────────────────────────────────────────────────────────────────────
export async function getAllRaces() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(races);
}

export async function getRaceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(races).where(eq(races.id, id)).limit(1);
  return result[0];
}

export async function createRace(data: Omit<typeof races.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return;
  await db.insert(races).values(data);
}

export async function updateRace(id: number, data: Partial<typeof races.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(races).set(data).where(eq(races.id, id));
}

export async function deleteRace(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(races).where(eq(races.id, id));
}

// ─── Classes ──────────────────────────────────────────────────────────────────
export async function getAllClasses() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classes);
}

export async function getClassById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  return result[0];
}

export async function getClassWithPaths(classId: number) {
  const db = await getDb();
  if (!db) return null;
  const cls = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!cls[0]) return null;
  const paths = await db.select().from(classPaths).where(eq(classPaths.classId, classId));
  const abilities = await db.select().from(classAbilities).where(eq(classAbilities.classId, classId));
  return { ...cls[0], paths, abilities };
}

export async function updateClass(id: number, data: Partial<typeof classes.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(classes).set(data).where(eq(classes.id, id));
}

// ─── Class Paths & Abilities ──────────────────────────────────────────────────
export async function getPathsByClassId(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classPaths).where(eq(classPaths.classId, classId));
}

export async function getAbilitiesByClassId(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classAbilities).where(eq(classAbilities.classId, classId));
}

export async function getAbilitiesByPathId(pathId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classAbilities).where(eq(classAbilities.pathId, pathId)).orderBy(classAbilities.level);
}

export async function getClassWithPathsAndAbilities(classId: number) {
  const db = await getDb();
  if (!db) return null;
  const cls = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (!cls[0]) return null;
  const paths = await db.select().from(classPaths).where(eq(classPaths.classId, classId));
  const pathsWithAbilities = await Promise.all(
    paths.map(async (path) => ({
      ...path,
      abilities: await db.select().from(classAbilities).where(eq(classAbilities.pathId, path.id)).orderBy(classAbilities.level),
    }))
  );
  return { ...cls[0], paths: pathsWithAbilities };
}

export async function updateAbility(id: number, data: Partial<typeof classAbilities.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(classAbilities).set(data).where(eq(classAbilities.id, id));
}

// ─── Dons ─────────────────────────────────────────────────────────────────────
export async function getAllDons() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dons);
}

export async function createDon(data: Omit<typeof dons.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return;
  await db.insert(dons).values(data);
}

export async function updateDon(id: number, data: Partial<typeof dons.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(dons).set(data).where(eq(dons.id, id));
}

export async function deleteDon(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(dons).where(eq(dons.id, id));
}

// ─── Compétences ──────────────────────────────────────────────────────────────
export async function getAllCompetences() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(competences);
}

export async function updateCompetence(id: number, data: Partial<typeof competences.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(competences).set(data).where(eq(competences.id, id));
}

// ─── Héritage Avantages ───────────────────────────────────────────────────────
export async function getAllHeritageAvantages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(heritageAvantages);
}

export async function updateHeritageAvantage(id: number, data: Partial<typeof heritageAvantages.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(heritageAvantages).set(data).where(eq(heritageAvantages.id, id));
}

// ─── Désavantages ─────────────────────────────────────────────────────────────
export async function getAllDesavantages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(desavantages);
}

export async function updateDesavantage(id: number, data: Partial<typeof desavantages.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(desavantages).set(data).where(eq(desavantages.id, id));
}

// ─── Personnages ──────────────────────────────────────────────────────────────
export async function getPersonnagesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      id: personnages.id,
      userId: personnages.userId,
      name: personnages.name,
      faction: personnages.faction,
      raceId: personnages.raceId,
      classId: personnages.classId,
      maxPv: personnages.maxPv,
      maxMana: personnages.maxMana,
      lutte: personnages.lutte,
      level: personnages.level,
      isActive: personnages.isActive,
      createdAt: personnages.createdAt,
      raceName: races.name,
      className: classes.name,
    })
    .from(personnages)
    .leftJoin(races, eq(personnages.raceId, races.id))
    .leftJoin(classes, eq(personnages.classId, classes.id))
    .where(and(eq(personnages.userId, userId), eq(personnages.isActive, true)));
  return rows;
}

export async function getPersonnageById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(personnages).where(eq(personnages.id, id)).limit(1);
  return result[0];
}

export async function createPersonnage(data: InsertPersonnage) {
  const db = await getDb();
  if (!db) return;
  const result = await db.insert(personnages).values(data);
  return result;
}

export async function updatePersonnage(id: number, data: Partial<InsertPersonnage>) {
  const db = await getDb();
  if (!db) return;
  await db.update(personnages).set(data).where(eq(personnages.id, id));
}

export async function deletePersonnage(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(personnages).set({ isActive: false }).where(eq(personnages.id, id));
}

export async function getAllPersonnages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(personnages).where(eq(personnages.isActive, true));
}

// ─── Événements ───────────────────────────────────────────────────────────────
export async function getAllEvenements(includeUnpublished = false) {
  const db = await getDb();
  if (!db) return [];
  if (includeUnpublished) {
    return db.select().from(evenements).orderBy(evenements.startDate);
  }
  return db.select().from(evenements)
    .where(eq(evenements.status, "published"))
    .orderBy(evenements.startDate);
}

export async function getEvenementById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(evenements).where(eq(evenements.id, id)).limit(1);
  return result[0];
}

export async function createEvenement(data: InsertEvenement) {
  const db = await getDb();
  if (!db) return;
  return db.insert(evenements).values(data);
}

export async function updateEvenement(id: number, data: Partial<InsertEvenement>) {
  const db = await getDb();
  if (!db) return;
  await db.update(evenements).set({ ...data, updatedAt: new Date() }).where(eq(evenements.id, id));
}

export async function deleteEvenement(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(evenements).where(eq(evenements.id, id));
}

// ─── Inscriptions ─────────────────────────────────────────────────────────────
export async function getInscriptionsByEvenement(evenementId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: inscriptions.id,
    evenementId: inscriptions.evenementId,
    userId: inscriptions.userId,
    personnageId: inscriptions.personnageId,
    status: inscriptions.status,
    notes: inscriptions.notes,
    createdAt: inscriptions.createdAt,
    userName: users.name,
  })
  .from(inscriptions)
  .leftJoin(users, eq(inscriptions.userId, users.id))
  .where(eq(inscriptions.evenementId, evenementId));
}

export async function getInscriptionsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(inscriptions).where(eq(inscriptions.userId, userId));
}

export async function getInscription(evenementId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(inscriptions)
    .where(and(eq(inscriptions.evenementId, evenementId), eq(inscriptions.userId, userId)))
    .limit(1);
  return result[0];
}

export async function createInscription(data: InsertInscription) {
  const db = await getDb();
  if (!db) return;
  return db.insert(inscriptions).values(data);
}

export async function updateInscription(id: number, data: Partial<InsertInscription>) {
  const db = await getDb();
  if (!db) return;
  await db.update(inscriptions).set({ ...data, updatedAt: new Date() }).where(eq(inscriptions.id, id));
}

export async function deleteInscription(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(inscriptions).where(eq(inscriptions.id, id));
}

export async function countInscriptions(evenementId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(inscriptions)
    .where(and(eq(inscriptions.evenementId, evenementId), eq(inscriptions.status, "confirmed")));
  return result.length;
}
