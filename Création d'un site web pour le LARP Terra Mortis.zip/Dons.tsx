import { trpc } from "@/lib/trpc";
import { ChevronRight, Loader2, Skull, Star } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

export default function Dons() {
  const { data: dons, isLoading: loadingDons } = trpc.rules.dons.useQuery();
  const [search, setSearch] = useState("");

  const filteredDons = dons?.filter(
    (d) => d.name.toLowerCase().includes(search.toLowerCase()) || d.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Dons", active: true },
      ]} />
      <div className="container max-w-5xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <Star className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Dons
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-foreground/70 max-w-2xl mx-auto mt-4">
            Les dons sont des capacités spéciales que vous pouvez acquérir pour améliorer votre personnage. Certains dons peuvent être cumulés plusieurs fois.
          </p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Rechercher un don..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 rounded-lg text-sm bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border"
          />
        </div>

        {/* Dons */}
        {loadingDons ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
          </div>
        ) : (
          <div className="space-y-4">
            {filteredDons?.map((don) => (
              <div
                key={don.id}
                className="p-5 rounded-xl border border-border/40 bg-card/30 hover:border-border/70 transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>
                    {don.name}
                  </h3>
                  <div className="flex gap-2 flex-wrap justify-end">
                    {don.canStack && (
                      <span
                        className="text-xs px-2 py-1 rounded font-heading"
                        style={{ background: "oklch(0.45 0.15 140 / 0.2)", color: "oklch(0.65 0.2 140)", border: "1px solid oklch(0.45 0.15 140 / 0.4)" }}
                      >
                        Cumulable ×{don.maxStacks}
                      </span>
                    )}
                    {don.pvBonus != null && don.pvBonus > 0 && (
                      <span className="text-xs px-2 py-1 rounded bg-green-900/30 text-green-400 border border-green-800/40">
                        +{don.pvBonus} PV
                      </span>
                    )}
                    {don.manaBonus != null && don.manaBonus > 0 && (
                      <span className="text-xs px-2 py-1 rounded bg-blue-900/30 text-blue-400 border border-blue-800/40">
                        +{don.manaBonus} Mana
                      </span>
                    )}
                    {don.luteBonus != null && don.luteBonus > 0 && (
                      <span className="text-xs px-2 py-1 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.3)" }}>
                        +{don.luteBonus} Lutte
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-foreground/80 leading-relaxed">{don.description}</p>
              </div>
            ))}
            {filteredDons?.length === 0 && (
              <p className="text-center text-muted-foreground py-8">Aucun don trouvé.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
