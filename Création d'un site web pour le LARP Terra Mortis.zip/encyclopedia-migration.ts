import { protectedProcedure, router } from "./routers";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import { races, encyclopediaEntries } from "../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * Procédures tRPC pour la migration progressive vers l'Encyclopédie
 */
export const encyclopediaMigrationRouter = router({
  /**
   * Migrer toutes les races vers encyclopedia_entries
   * Seuls les admins peuvent exécuter cette migration
   */
  migrateRaces: protectedProcedure.mutation(async ({ ctx }: any) => {
    // Vérifier que l'utilisateur est admin
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Seuls les administrateurs peuvent exécuter les migrations",
      });
    }

    try {
      // Récupérer toutes les races
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const allRaces = await db.query.races.findMany();

      if (allRaces.length === 0) {
        return {
          success: true,
          message: "Aucune race à migrer",
          migratedCount: 0,
        };
      }

      let migratedCount = 0;

      // Migrer chaque race
      for (const race of allRaces) {
        const encyclopediaEntry = {
          nom: race.name,
          categorie: "races",
          description: race.description,
          proprietes: JSON.stringify({
            faction: race.faction,
            bonuses: race.bonuses,
            maluses: race.maluses,
            abilities: race.abilities,
            physicalDescription: race.physicalDescription,
            startingLanguages: race.startingLanguages,
            pvBonus: race.pvBonus,
            manaBonus: race.manaBonus,
            luteBonus: race.luteBonus,
            pvMalus: race.pvMalus,
          }),
          relations: JSON.stringify({}),
          factionRequise: race.faction === "Tous" ? null : race.faction,
          conditions: JSON.stringify({}),
          createdBy: ctx.user.id,
          createdAt: new Date(race.createdAt),
          updatedBy: ctx.user.id,
          updatedAt: new Date(race.updatedAt),
          deletedAt: null,
        };

        // Insérer dans encyclopedia_entries
        await db.insert(encyclopediaEntries).values(encyclopediaEntry as any);
        migratedCount++;
      }

      return {
        success: true,
        message: `${migratedCount} race(s) migrée(s) avec succès`,
        migratedCount,
      };
    } catch (error) {
      console.error("Erreur lors de la migration des races :", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Erreur lors de la migration des races",
      });
    }
  }),

  /**
   * Vérifier l'état de la migration
   */
  getMigrationStatus: protectedProcedure.query(async ({ ctx }: any) => {
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Seuls les administrateurs peuvent consulter le statut",
      });
    }

    try {
      // Compter les races dans la table originale
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const racesCount = await db.query.races.findMany();

      // Compter les entrées migrées dans encyclopedia_entries
      const migratedRaces = await db.query.encyclopediaEntries.findMany({
        where: eq(encyclopediaEntries.categorie, "races"),
      });

      return {
        racesTotal: racesCount.length,
        racesMigrated: migratedRaces.length,
        racesRemaining: racesCount.length - migratedRaces.length,
        migrationComplete: racesCount.length === migratedRaces.length,
      };
    } catch (error) {
      console.error("Erreur lors de la vérification du statut :", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Erreur lors de la vérification du statut",
      });
    }
  }),

  /**
   * Rollback : supprimer toutes les races migrées
   */
  rollbackRacesMigration: protectedProcedure.mutation(async ({ ctx }: any) => {
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Seuls les administrateurs peuvent exécuter les rollbacks",
      });
    }

    try {
      // Supprimer toutes les entrées migrées
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const result = await db
        .delete(encyclopediaEntries)
        .where(eq(encyclopediaEntries.categorie, "races"));

      return {
        success: true,
        message: "Rollback des races complété",
      };
    } catch (error) {
      console.error("Erreur lors du rollback :", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Erreur lors du rollback",
      });
    }
  }),
});
