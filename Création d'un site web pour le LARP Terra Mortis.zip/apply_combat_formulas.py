#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/rules/Combat.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Remplacer les formules dans le tableau
old_formulas = '''            {[
              { label: "PV", formula: "PV base (classe) + Résistance × 2 + bonus" },
              { label: "Mana", formula: "Mana base (classe) + Esprit × 2 + bonus" },
              { label: "Lutte", formula: "Puissance × 2 + bonus raciaux + dons" },
              { label: "Sauvegardes", formula: "Esprit + bonus divers" },
            ].map((item) => ('''

new_formulas = '''            {[
              { label: "PV", formula: "PV base (classe) + Bonus Résistance + Bonus racial + Bonus capacités (Voie) + Bonus dons" },
              { label: "Mana", formula: "Mana base (classe) + Bonus Esprit + Bonus racial + Bonus capacités (Voie) + Bonus dons" },
              { label: "Lutte", formula: "Bonus Puissance + Bonus racial + Bonus capacités (Voie) + Bonus dons" },
              { label: "Sauvegardes", formula: "Bonus Résistance + Bonus capacités (Voie)" },
            ].map((item) => ('''

content = content.replace(old_formulas, new_formulas)
print("✓ Formules de calcul mises à jour")

# Remplacer le texte de PV
old_pv = '''    title: "Points de Vie (PV)",
    icon: "❤️",
    content: `Les Points de Vie représentent la résistance physique de votre personnage. Ils sont calculés selon la formule : PV = PV de base (classe) + Résistance × 2 + bonus raciaux + bonus des dons. Lorsque vos PV tombent à 0, vous êtes à terre et en état d'agonie.`,'''

new_pv = '''    title: "Points de Vie (PV)",
    icon: "❤️",
    content: `Les Points de Vie représentent la résistance physique de votre personnage. Ils sont calculés selon la formule : PV = PV de base (classe) + Bonus lié à la Résistance + Bonus racial + Bonus de capacités (Voie) + Bonus via Dons. Lorsque vos PV tombent à 0, vous êtes à terre et en état d'agonie.`,'''

content = content.replace(old_pv, new_pv)
print("✓ Texte PV mis à jour")

# Remplacer le texte de Lutte
old_lutte = '''    title: "Lutte",
    icon: "⚔️",
    content: `La Lutte représente la capacité de votre personnage à résister aux effets de contrôle (immobilisation, renversement, etc.). Elle est calculée : Lutte = Puissance × 2 + bonus raciaux + bonus des dons. Quand un effet de contrôle vous cible, vous pouvez dépenser votre Lutte pour y résister.`,'''

new_lutte = '''    title: "Lutte",
    icon: "⚔️",
    content: `La Lutte représente la capacité de votre personnage à résister aux effets de contrôle (immobilisation, renversement, etc.). Elle est calculée : Lutte = Bonus lié à la Puissance + Bonus racial + Bonus de capacités (Voie) + Bonus via Dons. Quand un effet de contrôle vous cible, vous pouvez dépenser votre Lutte pour y résister.`,'''

content = content.replace(old_lutte, new_lutte)
print("✓ Texte Lutte mis à jour")

# Remplacer le texte de Sauvegardes
old_sauvegardes = '''    title: "Sauvegardes",
    icon: "🛡️",
    content: `Les Sauvegardes permettent de résister à certains effets négatifs (poison, malédiction, etc.). Elles sont calculées : Sauvegardes = Esprit + bonus divers. Chaque sauvegarde utilisée est perdue jusqu'au prochain repos.`,'''

new_sauvegardes = '''    title: "Sauvegardes",
    icon: "🛡️",
    content: `Les Sauvegardes permettent de résister à certains effets négatifs (poison, malédiction, etc.). Elles sont calculées : Sauvegardes = Bonus lié à la Résistance + Bonus de capacités (Voie). Chaque sauvegarde utilisée est perdue jusqu'au prochain repos.`,'''

content = content.replace(old_sauvegardes, new_sauvegardes)
print("✓ Texte Sauvegardes mis à jour")

# Ajouter Mana après PV
old_agonie = '''  {
    title: "Agonie et Mort",'''

new_mana = '''  {
    title: "Points de Mana (PM)",
    icon: "✨",
    content: `Les Points de Mana représentent l'énergie magique de votre personnage. Ils sont calculés selon la formule : Mana = Mana de base (classe) + Bonus lié à l'Esprit + Bonus racial + Bonus de capacités (Voie) + Bonus via Dons. Le mana est utilisé pour lancer des sorts et des incantations.`,
  },
  {
    title: "Agonie et Mort",'''

content = content.replace(old_agonie, new_mana)
print("✓ Section Mana ajoutée")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/rules/Combat.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
