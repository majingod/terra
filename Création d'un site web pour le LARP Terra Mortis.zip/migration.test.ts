import { describe, it, expect, beforeAll, afterAll } from "vitest";
import {
  getMigrationStatus,
  migrateRaces,
  migrateClasses,
  migrateDons,
  migrateCompetences,
  migrateHeritages,
  migrateDesavantages,
} from "./migration";

describe("Migration Procedures", () => {
  describe("getMigrationStatus", () => {
    it("should return migration status with all categories", async () => {
      const status = await getMigrationStatus();

      expect(status).toHaveProperty("races");
      expect(status).toHaveProperty("classes");
      expect(status).toHaveProperty("classPaths");
      expect(status).toHaveProperty("classAbilities");
      expect(status).toHaveProperty("dons");
      expect(status).toHaveProperty("competences");
      expect(status).toHaveProperty("heritages");
      expect(status).toHaveProperty("desavantages");
      expect(status).toHaveProperty("encyclopediaTotal");
      expect(status).toHaveProperty("categories");

      // Verify categories object
      expect(status.categories).toHaveProperty("races");
      expect(status.categories).toHaveProperty("classes");
      expect(status.categories).toHaveProperty("sous_classes");
      expect(status.categories).toHaveProperty("capacites");
      expect(status.categories).toHaveProperty("dons");
      expect(status.categories).toHaveProperty("competences");
      expect(status.categories).toHaveProperty("heritage_avantages");
      expect(status.categories).toHaveProperty("heritage_desavantages");
    });

    it("should return numeric counts for all fields", async () => {
      const status = await getMigrationStatus();

      expect(typeof status.races).toBe("number");
      expect(typeof status.classes).toBe("number");
      expect(typeof status.dons).toBe("number");
      expect(typeof status.competences).toBe("number");
      expect(typeof status.heritages).toBe("number");
      expect(typeof status.desavantages).toBe("number");
      expect(typeof status.encyclopediaTotal).toBe("number");

      // All counts should be >= 0
      expect(status.races).toBeGreaterThanOrEqual(0);
      expect(status.classes).toBeGreaterThanOrEqual(0);
      expect(status.dons).toBeGreaterThanOrEqual(0);
    });
  });

  describe("migrateRaces", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateRaces();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
      expect(result.migratedCount).toBeGreaterThanOrEqual(0);
      expect(result.totalCount).toBeGreaterThanOrEqual(0);
    });
  });

  describe("migrateClasses", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateClasses();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
    });
  });

  describe("migrateDons", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateDons();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
    }, 15000);
  });

  describe("migrateCompetences", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateCompetences();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
    }, 15000);
  });

  describe("migrateHeritages", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateHeritages();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
    }, 15000);
  });

  describe("migrateDesavantages", () => {
    it("should return migration result with counts", async () => {
      const result = await migrateDesavantages();

      expect(result).toHaveProperty("migratedCount");
      expect(result).toHaveProperty("totalCount");
      expect(typeof result.migratedCount).toBe("number");
      expect(typeof result.totalCount).toBe("number");
    }, 15000);
  });

  describe("Migration idempotency", () => {
    it("should handle duplicate migrations gracefully", async () => {
      // First migration
      const result1 = await migrateRaces();
      expect(result1.migratedCount).toBeGreaterThanOrEqual(0);

      // Second migration should not fail
      const result2 = await migrateRaces();
      expect(result2.migratedCount).toBeGreaterThanOrEqual(0);

      // Status should be consistent
      const status = await getMigrationStatus();
      expect(status.races).toBeGreaterThanOrEqual(0);
    });
  });
});
