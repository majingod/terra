import { describe, it, expect } from "vitest";

describe("StepCapacitesBonus", () => {
  it("should calculate extra abilities level 1 correctly", () => {
    const heritageAvantages = [{ id: 1, times: 1 }];
    const heritageData = [{ id: 1, extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 0 }];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(1);
    expect(level2).toBe(0);
  });

  it("should calculate extra abilities level 2 correctly", () => {
    const heritageAvantages = [{ id: 2, times: 1 }];
    const heritageData = [{ id: 2, extraAbilitiesLevel1: 0, extraAbilitiesLevel2: 1 }];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(0);
    expect(level2).toBe(1);
  });

  it("should calculate both level 1 and level 2 abilities", () => {
    const heritageAvantages = [{ id: 3, times: 1 }];
    const heritageData = [{ id: 3, extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 1 }];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(1);
    expect(level2).toBe(1);
  });

  it("should handle multiple heritage advantages", () => {
    const heritageAvantages = [
      { id: 1, times: 1 },
      { id: 2, times: 1 },
    ];
    const heritageData = [
      { id: 1, extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 0 },
      { id: 2, extraAbilitiesLevel1: 0, extraAbilitiesLevel2: 1 },
    ];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(1);
    expect(level2).toBe(1);
  });

  it("should handle multiple times for same heritage", () => {
    const heritageAvantages = [{ id: 1, times: 2 }];
    const heritageData = [{ id: 1, extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 0 }];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(2);
    expect(level2).toBe(0);
  });

  it("should return 0 for no heritage advantages", () => {
    const heritageAvantages: any[] = [];
    const heritageData: any[] = [];

    let level1 = 0;
    let level2 = 0;

    heritageAvantages.forEach((h) => {
      const ha = heritageData.find((x) => x.id === h.id);
      if (ha) {
        level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
        level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
      }
    });

    expect(level1).toBe(0);
    expect(level2).toBe(0);
  });

  it("should get bonus path IDs correctly", () => {
    const classId = 1;
    const selectedPathId = 2;
    const classData = {
      id: 1,
      paths: [
        { id: 1, name: "Path 1" },
        { id: 2, name: "Path 2" },
        { id: 3, name: "Path 3" },
      ],
    };

    const bonusPathIds = classData.paths
      .filter((p: any) => p.id !== selectedPathId)
      .map((p: any) => p.id);

    expect(bonusPathIds).toEqual([1, 3]);
  });

  it("should filter selected bonus abilities correctly", () => {
    const selectedBonusAbilities = [1, 2, 3];
    const abilityId = 2;

    const isSelected = selectedBonusAbilities.includes(abilityId);
    expect(isSelected).toBe(true);

    const newSelected = selectedBonusAbilities.filter((id) => id !== abilityId);
    expect(newSelected).toEqual([1, 3]);
  });

  it("should add new bonus ability to selection", () => {
    const selectedBonusAbilities = [1, 2];
    const abilityId = 3;

    const isSelected = selectedBonusAbilities.includes(abilityId);
    expect(isSelected).toBe(false);

    const newSelected = [...selectedBonusAbilities, abilityId];
    expect(newSelected).toEqual([1, 2, 3]);
  });

  it("should respect the limit of selected abilities", () => {
    const selectedBonusAbilities = [1, 2];
    const extraAbilities = { level1: 2, level2: 0 };
    const level = 1 as const;

    const selectedCount = selectedBonusAbilities.length;
    const limit = level === 1 ? extraAbilities.level1 : extraAbilities.level2;

    expect(selectedCount).toBe(2);
    expect(limit).toBe(2);
    expect(selectedCount < limit).toBe(false);
  });

  it("should allow selection when under limit", () => {
    const selectedBonusAbilities = [1];
    const extraAbilities = { level1: 2, level2: 0 };
    const level = 1 as const;

    const selectedCount = selectedBonusAbilities.length;
    const limit = level === 1 ? extraAbilities.level1 : extraAbilities.level2;

    expect(selectedCount).toBe(1);
    expect(limit).toBe(2);
    expect(selectedCount < limit).toBe(true);
  });
});
