import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, Calendar, Users, Trophy, Trash2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function MesInscriptions() {
  const { user } = useAuth();
  
  // Récupérer les inscriptions du joueur
  const { data: inscriptions, isLoading: loadingInscriptions } =
    trpc.inscriptions.mine.useQuery(undefined, { enabled: !!user?.id });

  // Mutation pour se désinscrire
  const unsubscribeMutation = trpc.inscriptions.cancel.useMutation({
    onSuccess: () => {
      toast.success("Désinscription réussie");
      trpc.useUtils().inscriptions.mine.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de la désinscription");
    },
  });

  if (!user) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Vous devez être connecté pour voir vos inscriptions.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "confirmed":
        return "default";
      case "pending":
        return "secondary";
      case "cancelled":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmé";
      case "pending":
        return "En attente";
      case "cancelled":
        return "Annulé";
      default:
        return status;
    }
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Mes Inscriptions</h1>
        <p className="text-muted-foreground">
          Gérez vos inscriptions aux événements
        </p>
      </div>

      <div className="space-y-4">
        {loadingInscriptions ? (
          <div className="text-center py-8">Chargement des inscriptions...</div>
        ) : !inscriptions || inscriptions.length === 0 ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Vous n'êtes inscrit à aucun événement pour le moment.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="grid gap-4">
            {inscriptions.map((inscription: any) => (
              <Card key={inscription.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle>{inscription.evenements?.title || "Événement"}</CardTitle>
                      <CardDescription className="mt-2">
                        {inscription.evenements?.description}
                      </CardDescription>
                    </div>
                    <Badge variant={getStatusBadgeVariant(inscription.status)}>
                      {getStatusLabel(inscription.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    {inscription.evenements?.startDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>
                          {format(new Date(inscription.evenements.startDate), "PPP", {
                            locale: fr,
                          })}
                        </span>
                      </div>
                    )}
                    {inscription.evenements?.location && (
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>{inscription.evenements.location}</span>
                      </div>
                    )}
                  </div>

                  {inscription.notes && (
                    <div className="bg-muted p-3 rounded text-sm">
                      <p className="font-semibold mb-1">Notes:</p>
                      <p>{inscription.notes}</p>
                    </div>
                  )}

                  <div className="flex justify-end gap-2">
                    {inscription.status !== "cancelled" && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (
                            confirm(
                              "Êtes-vous sûr de vouloir vous désinscrire de cet événement ?"
                            )
                          ) {
                            unsubscribeMutation.mutate({
                              evenementId: inscription.evenementId,
                            });
                          }
                        }}
                        disabled={unsubscribeMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Se désinscrire
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
