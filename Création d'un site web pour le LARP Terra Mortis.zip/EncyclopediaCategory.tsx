import { useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Loader2, LinkIcon } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

const CATEGORY_TITLES: Record<string, string> = {
  race: "Races",
  classe: "Classes",
  don: "Dons",
  competence: "Compétences",
  heritage: "Héritages",
  desavantage: "Désavantages",
  ressource: "Ressources",
  materiau: "Matériaux",
  rune: "Runes",
  recette: "Recettes",
  forge: "Forge",
  objet_magique: "Objets Magiques",
  regle_combat: "Règles de Combat",
  symbole: "Symboles",
  langue: "Langues",
  armure: "Armures",
  caracteristique: "Caractéristiques",
  faction: "Factions",
};

export default function EncyclopediaCategory() {
  const [, params] = useRoute("/encyclopedia/:category");
  const category = params?.category || "race";
  const [page, setPage] = useState(1);
  const pageSize = 12;

  const { data: entriesData, isLoading } =
    trpc.encyclopedia.getPaginatedByCategory.useQuery(
      {
        category,
        limit: pageSize,
        offset: (page - 1) * pageSize,
      },
      { enabled: !!category }
    );

  const entries = entriesData?.items || [];
  const total = entriesData?.total || 0;
  const totalPages = Math.ceil(total / pageSize);
  const categoryTitle = CATEGORY_TITLES[category] || category;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* En-tête */}
        <div>
          <h1 className="text-3xl font-bold">Encyclopédie - {categoryTitle}</h1>
          <p className="text-muted-foreground mt-2">
            {total} entrée{total > 1 ? "s" : ""} trouvée{total > 1 ? "s" : ""}
          </p>
        </div>

        {/* Contenu */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : entries.length === 0 ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>Aucune entrée trouvée dans cette catégorie</AlertDescription>
          </Alert>
        ) : (
          <>
            {/* Grille d'entrées */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {entries.map((entry: any) => (
                <Card key={entry.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle className="line-clamp-2">{entry.nom}</CardTitle>
                    {entry.factionRequise && (
                      <Badge className="w-fit">{entry.factionRequise}</Badge>
                    )}
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {entry.description || "Pas de description"}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex gap-2 justify-center items-center pt-6">
                <Button
                  variant="outline"
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm">
                  Page {page} / {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
