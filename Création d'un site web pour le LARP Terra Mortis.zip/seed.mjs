import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

// Helper to run raw SQL with proper connection
async function rawInsert(sql, params) {
  await connection.execute(sql, params);
}

// ─── Seed Races ───────────────────────────────────────────────────────────────
const racesData = [
  {
    name: "Humain",
    faction: "Tous",
    description: "L'humain est la race la plus polyvalente qui soit. Adaptable et résilient, il peut rejoindre n'importe quelle faction et exceller dans toutes les classes.",
    bonuses: ["+1 PV OU +1 Mana (au choix)"],
    maluses: [],
    abilities: [],
    physicalDescription: "Aucune description physique spécifique requise.",
    startingLanguages: ["Commun"],
    pvBonus: 0,
    manaBonus: 0,
    luteBonus: 0,
    pvMalus: 0,
  },
  {
    name: "Elfe",
    faction: "Sanctum",
    description: "Les elfes aiment la musique, le chant et la danse. Ils ont un goût marqué pour le raffinement et les arts. On les trouve souvent dans toutes les classes, et ils sont de bons combattants, mais ils ont une affinité particulière pour l'art mystique.",
    bonuses: ["+1 Mana"],
    maluses: [],
    abilities: [
      {
        name: "Transfert",
        description: "1/heure, les elfes peuvent donner leur Mana restant à une cible consentante au contact ou prendre celui d'une cible consentante."
      }
    ],
    physicalDescription: "Oreilles pointues visibles, pas de barbe.",
    startingLanguages: ["Commun", "Elfe"],
    pvBonus: 0,
    manaBonus: 1,
    luteBonus: 0,
    pvMalus: 0,
  },
  {
    name: "Nain",
    faction: "Sanctum",
    description: "Ils sont trapus et costauds. Ils aiment la bonne cervoise et les festins. Ce sont des combattants robustes et fiers. Bien qu'ils soient grognons et orgueilleux, ils s'emportent assez facilement mais reviennent vite à leur esprit. Les nains sont matérialistes sans être cupides. Ils aiment l'or, les pierres précieuses, les belles armes et armures.",
    bonuses: ["+1 PV"],
    maluses: [],
    abilities: [
      {
        name: "Tenace",
        description: "Les nains sont immunisés aux capacités les renversant (mettre à terre) ou qui les déplacent de force (comme la bousculade par la lutte)."
      }
    ],
    physicalDescription: "Barbe longue OU symboles runiques rouges sur la peau.",
    startingLanguages: ["Commun", "Nain"],
    pvBonus: 1,
    manaBonus: 0,
    luteBonus: 0,
    pvMalus: 0,
  },
  {
    name: "Orc",
    faction: "Légion",
    description: "Les orcs sont prompts à la colère et d'un naturel grincheux. Ils préfèrent agir et combattre plutôt que de réfléchir et discuter. Ils aiment festoyer, manger, boire, se vanter, chanter et pratiquer la lutte. Les passe-temps plus raffinés tels que la danse, la poésie et la philosophie ne sont pas pour eux.",
    bonuses: ["+1 en Lutte", "+2 PV"],
    maluses: ["Cannibalisme : peut récupérer tous ses PV en mangeant un cadavre en 1 minute de RP"],
    abilities: [
      {
        name: "Cannibalisme",
        description: "Peut récupérer tous ses PV en mangeant un cadavre en 1 minute de RP."
      }
    ],
    physicalDescription: "Peau verte (avec ou sans masque d'orc).",
    startingLanguages: ["Commun", "Orc"],
    pvBonus: 2,
    manaBonus: 0,
    luteBonus: 1,
    pvMalus: 0,
  },
  {
    name: "Drow",
    faction: "Légion",
    description: "Tueurs sans pitié, meurtriers dans l'âme, leur profession est souvent liée à l'assassinat. Ils sont également de grands adeptes de la magie profane. Leur société est matriarcale, où la femme Drow a le plein pouvoir sur l'insignifiant mâle Drow.",
    bonuses: ["+2 Mana"],
    maluses: [],
    abilities: [
      {
        name: "Camouflage",
        description: "Lorsque le personnage n'est pas observé, il peut devenir invisible dans l'ombre ou la forêt, mais doit se déplacer lentement."
      }
    ],
    physicalDescription: "Oreilles pointues, peau noire et cheveux blancs.",
    startingLanguages: ["Commun", "Abyssal"],
    pvBonus: 0,
    manaBonus: 2,
    luteBonus: 0,
    pvMalus: 0,
  },
  {
    name: "Gobelin",
    faction: "Légion",
    description: "Les Gobelins tuent par plaisir toute créature faible et sans défense. Ils adorent achever les gens déjà au sol. Les Gobelins aiment torturer leurs victimes. Ils ne sont pas braves de nature, et s'ils perçoivent un danger, ils restent en général à l'écart pour mieux finir les blesser.",
    bonuses: ["Esquive : 1/heure, peut éviter une attaque infligeant des dégâts en criant 'Esquive !'"],
    maluses: ["-1 PV"],
    abilities: [
      {
        name: "Esquive",
        description: "1/heure, peut éviter une attaque infligeant des dégâts en criant 'Esquive !'"
      }
    ],
    physicalDescription: "Peau jaune ou orange.",
    startingLanguages: ["Commun", "Orc"],
    pvBonus: 0,
    manaBonus: 0,
    luteBonus: 0,
    pvMalus: 1,
  },
];

// ─── Seed Classes ─────────────────────────────────────────────────────────────
const classesData = [
  {
    name: "Druide",
    faction: "Tous",
    description: "Il existe dans la pureté des éléments et dans l'organisation de la nature un pouvoir qui dépasse les merveilles de la civilisation. Cette magie brute, discrète, mais indéniable, est protégée par des adeptes de la philosophie de l'équilibre, appelés druides. À la fois alliés des bêtes et maîtres de la nature, ces défenseurs des étendues sauvages sont souvent mal compris.",
    basePv: 4,
    baseMana: 3,
    baseAbilities: [
      { name: "Herbe de guérison", description: "Le druide peut soigner tous les PV d'une cible en 2 minutes de RP hors combat en utilisant de l'herbe sur les blessures de la cible." },
      { name: "Langage druidique", description: "Le druide connaît la langue druidique de base." }
    ],
    specialRules: ["Le druide doit avoir son bâton/baguette en main pour lancer un Signe ou incantation."],
    requiresWeapon: true,
    code: null,
  },
  {
    name: "Guerrier",
    faction: "Tous",
    description: "Certains prennent les armes en quête de gloire, de richesse, ou de vengeance. D'autres combattent pour faire leurs preuves, pour protéger des proches ou parce qu'ils ne savent rien faire d'autre. Les guerriers, ces seigneurs du champ de bataille, forment un groupe hétéroclite.",
    basePv: 6,
    baseMana: 1,
    baseAbilities: [
      { name: "Lutteur", description: "Le personnage obtient +1 en Lutte." }
    ],
    specialRules: ["Le guerrier peut toujours prendre un don au lieu d'une capacité."],
    requiresWeapon: false,
    code: null,
  },
  {
    name: "Magicien",
    faction: "Tous",
    description: "Au-delà du voile du monde quotidien se cache les mystères du pouvoir absolu. Les magiciens recherchent, collectent et convoitent les connaissances ésotériques. Ils se servent d'arts connus seulement d'une poignée de personnes pour réaliser des merveilles allant au-delà de la portée des gens normaux.",
    basePv: 3,
    baseMana: 4,
    baseAbilities: [
      { name: "Élémentaliste", description: "1/heure et par niveau, le magicien peut convertir les dégâts d'une de ses capacités en un autre élément : Feu, Froid, Foudre (magique) ou Acide (poison)." },
      { name: "Identification", description: "Le mage peut identifier au toucher les propriétés d'un effet magique sur une personne, un lieu ou un objet." }
    ],
    specialRules: ["Le mage doit avoir son bâton/baguette en main pour lancer un Signe ou incantation.", "Le mage peut toujours prendre une capacité au lieu d'un don (de niveau équivalent ou inférieur)."],
    requiresWeapon: true,
    code: null,
  },
  {
    name: "Roublard",
    faction: "Tous",
    description: "Pour ceux qui subsistent grâce à leur vivacité d'esprit, la vie est une aventure sans fin. Ces roublards qui semblent toujours sentir le danger à l'avance comptent sur leur ruse, leur habileté et leur charme pour tourner le destin à leur avantage.",
    basePv: 5,
    baseMana: 2,
    baseAbilities: [
      { name: "Bandit", description: "1/heure, peut prendre un objet (Rune/Matériel/Potion/Composante) à une cible morte ou immobilisée sans avoir à la fouiller. Si la cible n'a aucun objet, elle donne toute sa monnaie." },
      { name: "Vol à la tire", description: "Le roublard peut en 15 secondes ouvrir une porte ou voler les pièces d'une cible que le roublard a gardé la main dessus à son insu." }
    ],
    specialRules: [],
    requiresWeapon: false,
    code: null,
  },
  {
    name: "Chevalier de la mort",
    faction: "Légion",
    description: "Des entités puissantes jouent avec la mort comme les dragons jouent avec l'or. Que ce soit volontaire ou imposé, certains mortels prennent la voie du chevalier de la mort. Ces combattants manient la mort que les magiciens la magie.",
    basePv: 5,
    baseMana: 3,
    baseAbilities: [
      { name: "Poigne mortelle", description: "Signe : Mortalis, Le chevalier force une cible à se rendre à lui tant qu'il reste immobile et que la cible n'est pas attaquée." },
      { name: "Détection des morts", description: "Le chevalier de la mort peut savoir l'état de santé d'une cible à vue (si elle est vivante, morte ou morte-vivante)." },
      { name: "Armure des damnés", description: "Si le chevalier de la mort n'a pas d'armure, il obtient +1 PV. S'il porte une armure, il peut avoir jusqu'à 3 blocs d'armure sans perdre de mana." }
    ],
    specialRules: [],
    requiresWeapon: false,
    code: [
      "Le Chevalier n'attaquera jamais un mort-vivant intelligent.",
      "Le Chevalier de la mort mettra à mort les mourants à la fin d'un combat.",
      "Le Chevalier de la mort doit toujours tenir une promesse de son mieux et accepter un juste duel."
    ],
  },
  {
    name: "Sorcier",
    faction: "Légion",
    description: "Certains atteignent la puissance grâce à leurs études, d'autres par leur dévotion et d'autres encore par le sang, mais le sorcier tire ses pouvoirs de sa communion avec l'inconnu. Craint et incompris, il puise sa magie dans un pacte passé avec une puissance d'un autre monde.",
    basePv: 3,
    baseMana: 2,
    baseAbilities: [
      { name: "Mage de sang", description: "Les PV et Mana du sorcier s'additionnent et deviennent la même ressource (énergie). Son maximum de PV (donc d'énergie) devient 20." }
    ],
    specialRules: ["Le sorcier doit avoir son bâton/baguette en main pour lancer un Signe ou incantation.", "Les PV et Mana fusionnent en une seule ressource appelée Énergie (max 20)."],
    requiresWeapon: true,
    code: null,
  },
  {
    name: "Medjai",
    faction: "Sanctum",
    description: "Le pouvoir, peu importe la raison, est une grande tentation. Certains parmi les puissants des factions font des pactes avec des individus qui leur sont opposés, leur accordant des pouvoirs en espérant purifier ou corrompre leur âme. Ainsi se forment les Medjais.",
    basePv: 5,
    baseMana: 3,
    baseAbilities: [
      { name: "Immortel", description: "Le Medjai ne peut pas récupérer de PV autrement que par les potions, mais revient à la vie dès qu'il n'y a plus de combat ou d'ennemi autour de lui pendant 2 minutes." },
      { name: "Mutation", description: "Les capacités retirant 1 de mana permanent réduisent à jamais le mana maximum du Medjai. Si sa valeur tombe à 0, il ne peut plus choisir l'une de ces capacités." }
    ],
    specialRules: ["Certaines capacités coûtent -1 Mana permanent (réduction définitive du max de Mana)."],
    requiresWeapon: false,
    code: null,
  },
  {
    name: "Paladin",
    faction: "Sanctum",
    description: "À travers quelques rares et vertueux élus, on peut voir briller la puissance divine. Ces âmes nobles qu'on appelle paladins dévouent leur épée et leur vie au combat contre le mal. À la fois chevaliers, croisés et justiciers, les paladins ne cherchent pas seulement à propager la justice divine, mais également à incarner les enseignements des divinités vertueuses qu'ils servent.",
    basePv: 5,
    baseMana: 3,
    baseAbilities: [
      { name: "Détection du mensonge", description: "1/heure, Le paladin peut savoir si la dernière affirmation d'une cible est un mensonge." },
      { name: "Imposition", description: "1/heure et par cible, peut soigner la cible de 3 PV par le toucher." },
      { name: "Armure sacrée", description: "Si le paladin n'a pas d'armure, il obtient +1 PV. S'il porte une armure, il peut avoir jusqu'à 3 blocs d'armure sans perdre de mana." }
    ],
    specialRules: [],
    requiresWeapon: false,
    code: [
      "Le paladin ne peut pas mentir.",
      "Le paladin ne peut pas attaquer par surprise ou une cible au sol.",
      "Le paladin doit toujours tenir une promesse de son mieux et accepter un juste duel."
    ],
  },
];

// ─── Seed Dons ────────────────────────────────────────────────────────────────
const donsData = [
  { name: "Affinité magique", description: "Le personnage obtient +1 Mana. Peut être pris plusieurs fois.", canStack: true, maxStacks: 99, pvBonus: 0, manaBonus: 1, luteBonus: 0 },
  { name: "Agilité", description: "Immunité à ce qui met à terre ou empêche de se déplacer.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Brise bouclier", description: "1/heure, détruit un bouclier frappé par une arme de corps à corps tenue à 2 mains (pas d'arme d'hast).", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Bluff", description: "Immunité aux capacités de torture, communication avec les morts et détections du mensonge.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Courage", description: "Le personnage est immunisé aux effets de peur.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Dernière chance", description: "1/heure, permet de survivre à un coup fatal à 1 PV en criant 'dernière chance'.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Frappe Arcanique", description: "Permet de faire une attaque qui coûte 1 Mana pour rajouter 1 dégât. Perdue si ratée.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Incantation rapide", description: "Retire 2 mots aux capacités d'incantations.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Méditation", description: "Le personnage récupère 1 PV OU Mana par minute de repos.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Port armure magique", description: "Peut avoir jusqu'à 3 bloque d'armure sans perdre de Mana.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 },
  { name: "Résilient", description: "Le personnage obtient +2 PV tant qu'il ne porte ni armure ni bouclier.", canStack: false, maxStacks: 1, pvBonus: 2, manaBonus: 0, luteBonus: 0 },
  { name: "Robustesse", description: "Le personnage obtient +1 PV. Peut être pris plusieurs fois.", canStack: true, maxStacks: 99, pvBonus: 1, manaBonus: 0, luteBonus: 0 },
  { name: "Science de la lutte", description: "+1 en Lutte et gagne la Lutte en cas d'égalité.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 1 },
];

// ─── Seed Compétences ─────────────────────────────────────────────────────────
const competencesData = [
  {
    name: "Érudit",
    category: "simple",
    description: "Le personnage a été bien éduqué.",
    baseAdvantage: "Le personnage choisit 1 langue supplémentaire et apprend à lire. S'il n'est pas illettré (plus de 1 d'esprit), il obtient 2 langues supplémentaires.",
    advancedAdvantage: "Le personnage peut, à chaque GN, demander une information à un MJ.",
    requiredMaterial: null,
    isAdultOnly: false,
  },
  {
    name: "Riche",
    category: "simple",
    description: "Le personnage vient d'une famille aisée.",
    baseAdvantage: "Le personnage commence avec 1 Po comme argent de départ.",
    advancedAdvantage: "Le personnage obtient 2 Pa par GN et 2 Pa de plus chaque fois qu'il accomplit une quête.",
    requiredMaterial: null,
    isAdultOnly: false,
  },
  {
    name: "Herboriste",
    category: "simple",
    description: "Le personnage sait cultiver la végétation à son profit.",
    baseAdvantage: "Le personnage peut aller récolter jusqu'à 5 Alchimites par GN dans le jardin.",
    advancedAdvantage: "1 fois par GN, un évènement aura lieu au jardin dans lequel une créature pourra être vaincue et tout herboriste survivant peut récolter 1 Arcanite sur la créature.",
    requiredMaterial: "Serpe, Bol et Mortier",
    isAdultOnly: false,
  },
  {
    name: "Mineur",
    category: "simple",
    description: "Le personnage peut prélever les richesses de la pierre.",
    baseAdvantage: "Le personnage peut aller récolter jusqu'à 15 Pc par GN dans la mine.",
    advancedAdvantage: "1 fois par GN, un évènement aura lieu dans la mine dans lequel une créature pourra être vaincue et tout mineur survivant peut récolter 1 métal rare.",
    requiredMaterial: "Pioche et/ou pelle",
    isAdultOnly: false,
  },
  {
    name: "Marchand",
    category: "simple",
    description: "Le personnage possède des contacts à l'étranger.",
    baseAdvantage: "Poche cachée : immunisé contre la capacité de Bandit et choisit ce qu'il donne lors d'une fouille. Diplomate : peut dire 'pour-parler' pour forcer des adversaires à l'écouter 2 minutes.",
    advancedAdvantage: "Troc : peut une fois par jour échanger de la monnaie contre des ressources auprès d'un MJ.",
    requiredMaterial: null,
    isAdultOnly: false,
  },
  {
    name: "Alchimiste",
    category: "artisanat",
    description: "Le personnage peut créer des substances alchimiques consumables.",
    baseAdvantage: "Cuisinier : peut offrir jusqu'à 3 repas décorum par GN conférant +1 PV et +1 Mana pendant 1 heure. Premier-Soins : peut soigner tous les PV d'une cible en 1 minute de RP. Alchimie : peut concevoir des potions de soins, de mana et du poison avec de l'Alchimite.",
    advancedAdvantage: "Accès à l'atelier pour des recettes avancées.",
    requiredMaterial: "Beaucoup de flacons et de jus multicolore. Atelier Rang 1 (pour avancer).",
    isAdultOnly: true,
  },
  {
    name: "Forgeron",
    category: "artisanat",
    description: "Le personnage est un artisan du métal.",
    baseAdvantage: "Réparation : peut réparer armes, armures, boucliers et objets métalliques en 2 minutes de RP hors combat. Ajustement : peut conférer à 3 armures +1 bloc OU réduire de 1 le malus de mana. Forge : peut concevoir des armes, armures et boucliers en métal rare.",
    advancedAdvantage: "Accès à l'atelier pour des objets spéciaux en Adamantium, Aurorium ou Mythril.",
    requiredMaterial: "Marteau et enclume. Atelier Rang 1 (pour avancer).",
    isAdultOnly: true,
  },
  {
    name: "Runiste",
    category: "artisanat",
    description: "Le personnage est capable de créer des runes magiques enchantant les objets de leur porteur.",
    baseAdvantage: "Catalyst : peut porter plus d'une rune d'arme et d'amulette magique (mais n'en utilise qu'une à la fois). Marque : peut marquer 3 sujets volontaires par GN d'une rune conférant 1 utilisation d'une capacité de classe. Rune : peut concevoir des runes d'Armes ou Amulette magiques à partir d'Arcanite.",
    advancedAdvantage: "Accès à l'atelier pour des runes avancées.",
    requiredMaterial: "Boule de cristal. Atelier Rang 1 (pour avancer).",
    isAdultOnly: true,
  },
];

// ─── Seed Héritage Avantages ──────────────────────────────────────────────────
const heritageAvantagesData = [
  { name: "+1 PV", description: "Le personnage gagne 1 point de vie supplémentaire.", xpCost: 1, maxTimes: 99, pvBonus: 1, manaBonus: 0, luteBonus: 0, moneyBonus: null },
  { name: "+1 PM (Mana)", description: "Le personnage gagne 1 point de mana supplémentaire.", xpCost: 1, maxTimes: 99, pvBonus: 0, manaBonus: 1, luteBonus: 0, moneyBonus: null },
  { name: "+2 Pa d'argent de départ", description: "Le personnage commence avec 2 Pièces d'argent supplémentaires.", xpCost: 1, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: "2 Pa" },
  { name: "+1 de Lutte", description: "Le personnage gagne 1 point de lutte supplémentaire.", xpCost: 2, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 1, moneyBonus: null },
  { name: "+1 Po d'argent de départ", description: "Le personnage commence avec 1 Pièce d'or supplémentaire.", xpCost: 2, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: "1 Po" },
  { name: "+1 Capacité de niveau 1", description: "Le personnage obtient une capacité de niveau 1 de sa classe.", xpCost: 3, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: null },
  { name: "+2 Po d'argent de départ", description: "Le personnage commence avec 2 Pièces d'or supplémentaires.", xpCost: 3, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: "2 Po" },
  { name: "+1 Capacité de niveau 2", description: "Le personnage obtient une capacité de niveau 2 de sa classe.", xpCost: 4, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: null },
  { name: "+1 Compétence", description: "Le personnage obtient une compétence supplémentaire.", xpCost: 5, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: null },
  { name: "+1 Don", description: "Le personnage obtient un don supplémentaire. Peut être pris 3 fois. Ne peut pas être échangé contre une capacité si magicien.", xpCost: 2, maxTimes: 3, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: null },
  { name: "+1 Point de Caractéristique", description: "Le personnage obtient 1 point de caractéristique supplémentaire à distribuer. Maximum 2 fois.", xpCost: 6, maxTimes: 2, pvBonus: 0, manaBonus: 0, luteBonus: 0, moneyBonus: null },
];

// ─── Seed Désavantages ────────────────────────────────────────────────────────
const desavantagesData = [
  { name: "Amputé", description: "Vous avez un bras en moins. Seulement 1 XP si ce n'est que la main ou des doigts. Ce membre ne peut pas repousser grâce à la magie ou les potions.", xpGain: 3, xpType: "temporaire", forbiddenClasses: null },
  { name: "Asthmatique", description: "Vous avez de la difficulté à respirer correctement lors d'efforts physiques intenses. Il vous est impossible de courir ou combattre pendant plus de deux minutes sans vous effondrer à terre le souffle court.", xpGain: 1, xpType: "temporaire", forbiddenClasses: null },
  { name: "Boiteux", description: "Votre jambe manque de force et vous êtes incapable de vous déplacer correctement avec celle-ci. Cette blessure ou maladie vous empêche de courir et vous devez vous déplacer avec une cane ou bâton.", xpGain: 2, xpType: "temporaire", forbiddenClasses: null },
  { name: "Borgne ou Myope", description: "Vous avez besoin de lunettes, il vous manque 1 œil ou bien celui-ci ne fonctionne plus (doit alors porter un cache-œil).", xpGain: 1, xpType: "temporaire", forbiddenClasses: null },
  { name: "Bossu", description: "Vous êtes né bossu. Ceci n'a pas de désavantage en tant que tel autre que cela demande un élément de costume obligatoire pour votre personnage.", xpGain: 1, xpType: "temporaire", forbiddenClasses: null },
  { name: "Fragile", description: "Votre personnage n'est pas habitué à la douleur et vous ferez du RP exagéré à la moindre blessure.", xpGain: 3, xpType: "temporaire", forbiddenClasses: null },
  { name: "Honorable", description: "Votre personnage ne peut pas mentir ou combattre de manière déloyale.", xpGain: 1, xpType: "temporaire", forbiddenClasses: ["Paladin", "Chevalier de la mort"] },
  { name: "Malchance", description: "Votre personnage est né malchanceux. Vous devez porter un X rouge au visage. Les PNJ vous maltraiteront et les joueurs sont invités à faire pareil.", xpGain: 2, xpType: "temporaire", forbiddenClasses: null },
  { name: "Menteur", description: "Votre personnage aime mentir de manière crédible et le fera dès que possible.", xpGain: 1, xpType: "temporaire", forbiddenClasses: ["Paladin"] },
  { name: "Muet", description: "Vous êtes incapable de parler. Ce désavantage peut aussi bien être une perte de voix totale qu'une perte partielle qui permet uniquement quelques grognements.", xpGain: 3, xpType: "temporaire", forbiddenClasses: null },
  { name: "Naïf", description: "Votre personnage fait confiance au monde et tient pour acquis que ce que l'on lui dit est vrai. Vous êtes facile à tromper et croyez en la bonté des gens.", xpGain: 1, xpType: "temporaire", forbiddenClasses: null },
  { name: "Peureux", description: "Votre personnage évite le combat et ne participera que si le risque de ne pas participer est plus grand que de fuir.", xpGain: 2, xpType: "temporaire", forbiddenClasses: null },
  { name: "Raciste", description: "Votre personnage refuse de faire confiance, alliance ou tolérer la présence d'une race (de personnage). +1 XP si c'est une race de sa faction.", xpGain: 1, xpType: "temporaire", forbiddenClasses: null },
];

// ─── Class Paths ──────────────────────────────────────────────────────────────
const classPathsData = [
  // Druide
  { className: "Druide", name: "Chaman", description: "Maître des éléments naturels, le Chaman contrôle les forces de la nature pour entraver et détruire ses ennemis." },
  { className: "Druide", name: "Élémentaliste", description: "Le druide Élémentaliste canalise la puissance brute des éléments pour attaquer et se déplacer." },
  { className: "Druide", name: "Clerc", description: "Le Clerc druide se consacre à la guérison et au soutien de ses alliés grâce à la magie de la nature." },
  // Guerrier
  { className: "Guerrier", name: "Barbare", description: "Le Barbare entre dans une rage dévastatrice, devenant un instrument de destruction sur le champ de bataille." },
  { className: "Guerrier", name: "Ravageur", description: "Le Ravageur maîtrise les techniques de combat offensives pour briser les défenses ennemies." },
  { className: "Guerrier", name: "Gladiateur", description: "Le Gladiateur excelle dans l'art du combat spectaculaire, protégeant ses alliés et déjouant les attaques." },
  // Magicien
  { className: "Magicien", name: "Ensorceleur", description: "L'Ensorceleur maîtrise les signes magiques rapides pour harceler et contrôler ses adversaires." },
  { className: "Magicien", name: "Archimage", description: "L'Archimage lance des sorts puissants capables de dévaster des groupes d'ennemis." },
  { className: "Magicien", name: "Mystique", description: "Le Mystique utilise la magie pour manipuler la réalité, espionner et désenchanter." },
  // Roublard
  { className: "Roublard", name: "Assassin", description: "L'Assassin frappe dans l'ombre avec précision létale, éliminant ses cibles avant qu'elles ne réagissent." },
  { className: "Roublard", name: "Brigand", description: "Le Brigand est un expert de la furtivité et de l'évasion, disparaissant avant que ses ennemis ne puissent riposter." },
  { className: "Roublard", name: "Barde", description: "Le Barde utilise la musique et les mots pour inspirer ses alliés et manipuler ses ennemis." },
  // Chevalier de la mort
  { className: "Chevalier de la mort", name: "Inquisiteur", description: "L'Inquisiteur frappe avec la puissance glaciale de la mort, terrorisant ses ennemis." },
  { className: "Chevalier de la mort", name: "Immortel", description: "L'Immortel est un guerrier quasi indestructible, résistant à la mort elle-même." },
  { className: "Chevalier de la mort", name: "Faucheur", description: "Le Faucheur commande les morts-vivants et draine la vie de ses ennemis." },
  // Sorcier
  { className: "Sorcier", name: "Conjurateur", description: "Le Conjurateur drain la vie de ses ennemis et les terrifies avec des pouvoirs obscurs." },
  { className: "Sorcier", name: "Cultiste", description: "Le Cultiste manipule l'esprit et le corps de ses cibles avec une magie corrompue." },
  { className: "Sorcier", name: "Nécromancien", description: "Le Nécromancien commande les morts et les relève pour combattre à ses côtés." },
  // Medjai
  { className: "Medjai", name: "Occultiste", description: "L'Occultiste maîtrise les signes magiques pour contrôler et affaiblir ses adversaires." },
  { className: "Medjai", name: "Mutant", description: "Le Mutant sacrifie son mana pour augmenter ses capacités physiques au-delà des limites normales." },
  { className: "Medjai", name: "Sorcelier", description: "Le Sorcelier combine combat et magie pour une polyvalence redoutable." },
  // Paladin
  { className: "Paladin", name: "Croisé", description: "Le Croisé est un guerrier divin qui frappe ses ennemis avec la puissance du feu sacré." },
  { className: "Paladin", name: "Gardien", description: "Le Gardien protège ses alliés avec des boucliers divins et une vigilance surnaturelle." },
  { className: "Paladin", name: "Dévot", description: "Le Dévot se consacre à la guérison et au soutien de ses alliés par la grâce divine." },
];

// ─── Class Abilities ──────────────────────────────────────────────────────────
const classAbilitiesData = [
  // DRUIDE - Chaman
  { className: "Druide", pathName: "Chaman", level: 1, name: "Liane", description: "Signe : Vitis, empêche de se déplacer 1 min ou jusqu'à ce que la cible subisse des dégâts.", manaCost: 0, isSign: true },
  { className: "Druide", pathName: "Chaman", level: 2, name: "Sanctuaire", description: "1 Mana, Incantation, rend le druide invulnérable (mains liées), mais ne peut rien faire à part parler. Durée maximum 2 minutes.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Chaman", level: 3, name: "Peau d'écorce", description: "-1 de Mana permanent. Le druide obtient +3 PV s'il ne porte pas d'armure.", manaCost: 0 },
  { className: "Druide", pathName: "Chaman", level: 4, name: "Enchevêtrement", description: "1 Mana, Incantation, 3 cibles ne peuvent plus courir 2 minutes. Agilité ne protège pas contre ceci.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Chaman", level: 5, name: "Liberté", description: "1 Mana, Immunise la cible à la lutte et aux capacités de déplacement ou d'entrave au mouvement. Buff. Durée 1 heure.", manaCost: 1, isBuff: true },
  // DRUIDE - Élémentaliste
  { className: "Druide", pathName: "Élémentaliste", level: 1, name: "Main de feu", description: "1 Mana, Incantation, la cible fait 1 dégât de feu à main nue (augmenté par bonus de dégâts personnel). Durée 15 min.", manaCost: 1, isIncantation: true, isBuff: true },
  { className: "Druide", pathName: "Élémentaliste", level: 2, name: "Rafale", description: "1 Mana, Incantation, force la cible à reculer de 10 pas.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Élémentaliste", level: 3, name: "Appel de la foudre", description: "1 Mana, Incantation, inflige à 3 cibles 2 Dégâts magiques.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Élémentaliste", level: 4, name: "Séisme", description: "1 Mana, Incantation, 3 cibles tombent à terre.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Élémentaliste", level: 5, name: "Vol", description: "2 Mana, Incantation, permet au druide de voler (poing en l'air), ne peut être attaqué que par ceux qui volent ou à distance. Buff. Durée 1 heure.", manaCost: 2, isIncantation: true, isBuff: true },
  // DRUIDE - Clerc
  { className: "Druide", pathName: "Clerc", level: 1, name: "Guérison", description: "1 Mana, Incantation, soigne 3 PV à la cible touchée.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Clerc", level: 2, name: "Réparation (Druide)", description: "1 Mana, Incantation, peut réparer au toucher un objet, bouclier ou armure. Uniquement hors combat pour l'armure.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Clerc", level: 3, name: "Divination", description: "2 Mana, Incantation, permet de poser une question à un animateur. L'animateur peut donner des réponses énigmatiques ou incomplètes, mais toujours véridiques.", manaCost: 2, isIncantation: true },
  { className: "Druide", pathName: "Clerc", level: 4, name: "Vague de Soin", description: "1 Mana, Incantation, soigne 3 cibles différentes de 2 PV à vue.", manaCost: 1, isIncantation: true },
  { className: "Druide", pathName: "Clerc", level: 5, name: "Rappel à la vie", description: "2 Mana, Incantation, ramène 1 mort à 1 PV au toucher. Pas plus de 2 minutes après la mort.", manaCost: 2, isIncantation: true },
  // GUERRIER - Barbare
  { className: "Guerrier", pathName: "Barbare", level: 1, name: "Rage", description: "1/heure, Le guerrier tombe en rage : +3 PV, +1 de Lutte et immunisé à toutes les capacités qui le calmeraient. Durée 2 min, mais doit attaquer.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Barbare", level: 2, name: "Intimidation", description: "1/heure, La cible à vue ne peut plus attaquer le guerrier. Durée 15 secondes, sauf si le guerrier l'attaque.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Barbare", level: 3, name: "Assommage (Guerrier)", description: "1/heure, et hors combat, le personnage peut donner un (faux) coup à la tête de sa cible pour la rendre inconsciente. Durée 5 min ou jusqu'à ce qu'elle subisse des dégâts.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Barbare", level: 4, name: "Dernier souffle", description: "1/heure, lorsque le guerrier est tué, il attend 15 secondes, puis se relève plein PV au combat. S'il n'est pas tué, il meurt tout de même après 1 minute.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Barbare", level: 5, name: "Brise-Membre", description: "1/heure, une attaque de mêlée handicape le membre touché, le rendant inutilisable jusqu'à ce qu'une capacité lui retire l'effet.", usesPerHour: 1 },
  // GUERRIER - Ravageur
  { className: "Guerrier", pathName: "Ravageur", level: 1, name: "Brise bouclier (Guerrier)", description: "1/heure, détruit un bouclier frappé par une arme de corps à corps tenue à 2 mains (pas d'arme d'hast).", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Ravageur", level: 2, name: "Renversement (Guerrier)", description: "1/heure, en frappant les jambes ou bouclier de la cible, elle tombe à terre.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Ravageur", level: 3, name: "Désarmement", description: "1/heure, en frappant l'arme de la cible, celle-ci la lance au loin.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Ravageur", level: 4, name: "Brute", description: "+1 dégât avec les armes tenues à 2 mains (pas armes d'haste)." },
  { className: "Guerrier", pathName: "Ravageur", level: 5, name: "Critique", description: "1/heure, une attaque de corps à corps infligeant +3 dégâts divins. Le coup est conservé si raté.", usesPerHour: 1 },
  // GUERRIER - Gladiateur
  { className: "Guerrier", pathName: "Gladiateur", level: 1, name: "Interception", description: "3/heure, le guerrier peut rediriger une attaque ou pouvoir à proximité sur lui.", usesPerHour: 3 },
  { className: "Guerrier", pathName: "Gladiateur", level: 2, name: "Vigueur", description: "1 fois aux 30 secondes, le guerrier peut dépenser 1 Mana pour récupérer 2 PV.", manaCost: 1 },
  { className: "Guerrier", pathName: "Gladiateur", level: 3, name: "Ancrage", description: "À volonté, Le guerrier peut ancrer son pied au sol et crier 'Ancrage'. Jusqu'à ce qu'il se déplace ou attaque, toute attaque le touchant n'inflige que 1 de dégâts." },
  { className: "Guerrier", pathName: "Gladiateur", level: 4, name: "Cri de guerre", description: "1/heure, brise toute forme de contrôle mentaux (peur, confusion, charme) sur lui et ses alliés qui l'entendent.", usesPerHour: 1 },
  { className: "Guerrier", pathName: "Gladiateur", level: 5, name: "Esquive (Guerrier)", description: "1/heure, peut éviter une attaque infligeant des dégâts en criant 'Esquive !'.", usesPerHour: 1 },
  // MAGICIEN - Ensorceleur
  { className: "Magicien", pathName: "Ensorceleur", level: 1, name: "Flamme (Magicien)", description: "Signe : Ignis, Inflige 1 dégât de feu. Ne peut pas être fait 2 fois de suite sur la même cible.", isSign: true },
  { className: "Magicien", pathName: "Ensorceleur", level: 2, name: "Bourrasque", description: "Signe : Anima, force la cible à faire un tour sur elle-même.", isSign: true },
  { className: "Magicien", pathName: "Ensorceleur", level: 3, name: "Onde de choc", description: "Signe : Tremor. La cible tombe à terre. 1 fois par cible par heure.", isSign: true },
  { className: "Magicien", pathName: "Ensorceleur", level: 4, name: "Frayeur (Magicien)", description: "Signe : Anxietas. La cible doit fuir le mage. Durée 30 sec.", isSign: true },
  { className: "Magicien", pathName: "Ensorceleur", level: 5, name: "Désintégration", description: "1 Mana, Signe : Extinctio. Inflige 4 dégâts de feu.", manaCost: 1, isSign: true },
  // MAGICIEN - Archimage
  { className: "Magicien", pathName: "Archimage", level: 1, name: "Boule de feu", description: "1 Mana, Incantation, inflige 3 dégâts à une cible à environ 10m ou moins. Ne peut pas être fait 2 fois de suite sur la même cible.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Archimage", level: 2, name: "Invisibilité", description: "1 Mana, Incantation, la cible est invisible 1 minute, mais ne peut pas attaquer ou se déplacer directement vers quelqu'un.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Archimage", level: 3, name: "Appel de la foudre (Mage)", description: "1 Mana, Incantation, Inflige à 3 cibles 2 Dégâts magiques.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Archimage", level: 4, name: "Téléportation (Mage)", description: "1 Mana, Incantation, permet au mage de partir immatériel à une destination précise sans être suivi. Il revient matériel s'il arrête de se déplacer ou tourne en rond.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Archimage", level: 5, name: "Domination", description: "2 Mana, Incantation, la cible doit obéir aux ordres du mage pendant 5 minutes. Ne peut pas être utilisé 2 fois sur la même cible dans la même heure.", manaCost: 2, isIncantation: true },
  // MAGICIEN - Mystique
  { className: "Magicien", pathName: "Mystique", level: 1, name: "Fracassement (Mage)", description: "1 Mana. Détruit un objet/armure/bouclier touché par la main du mage (pas une arme tenue en main).", manaCost: 1 },
  { className: "Magicien", pathName: "Mystique", level: 2, name: "Réparation (Mage)", description: "1 Mana, Incantation, peut réparer au toucher un objet, bouclier ou armure. Uniquement hors combat pour l'armure.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Mystique", level: 3, name: "Scrutation", description: "Permet d'aller voir et espionner un lieu en hors-jeu en laissant son bâton sur place. Si le bâton a été déplacé à son retour, le mage meurt.", manaCost: 0 },
  { className: "Magicien", pathName: "Mystique", level: 4, name: "Dissipation", description: "1 Mana, Incantation. Met fin à un effet magique à vue. Les objets magiques de la cible cessent de fonctionner pour 1 heure.", manaCost: 1, isIncantation: true },
  { className: "Magicien", pathName: "Mystique", level: 5, name: "Métamorphose", description: "2 Mana, Incantation, le mage prend l'apparence d'une autre personne présente. Durée 1 heure ou jusqu'à ce qu'il subisse des dégâts.", manaCost: 2, isIncantation: true },
  // ROUBLARD - Assassin
  { className: "Roublard", pathName: "Assassin", level: 1, name: "Backstab", description: "Le premier coup avec une dague, arc ou arbalète sur une cible inflige +2 dégâts si touchés dans le dos." },
  { className: "Roublard", pathName: "Assassin", level: 2, name: "Torture", description: "À chaque 5 minutes de RP de torture sur une cible immobilisée, le roublard peut poser une question à laquelle elle devra répondre de son mieux." },
  { className: "Roublard", pathName: "Assassin", level: 3, name: "Assommage (Roublard)", description: "1/heure, et hors combat, le personnage peut donner un (faux) coup à la tête de sa cible pour la rendre inconsciente. Durée 5 min ou jusqu'à ce qu'elle subisse des dégâts.", usesPerHour: 1 },
  { className: "Roublard", pathName: "Assassin", level: 4, name: "Aveuglement", description: "1/heure, le roublard fait semblant de jeter du sable au visage d'une cible proche, l'aveuglant (doit mettre un bras devant ses yeux). Durée 15 sec.", usesPerHour: 1 },
  { className: "Roublard", pathName: "Assassin", level: 5, name: "Assassinat", description: "Le roublard doit glisser lentement une dague sous la gorge de la cible (en 3 sec), ce qui la tue. Seulement hors combat. Aucune sauvegarde, aucune esquive ne sont autorisées." },
  // ROUBLARD - Brigand
  { className: "Roublard", pathName: "Brigand", level: 1, name: "Camouflage (Roublard)", description: "Lorsque le roublard n'est pas observé, il peut devenir invisible dans l'ombre ou la végétation, mais doit se déplacer lentement." },
  { className: "Roublard", pathName: "Brigand", level: 2, name: "Évasion", description: "1/heure, le roublard peut crier 'évasion 10 sec' et s'enfuir en courant dans une direction sans ennemi sans que personne le poursuive pour 10 secondes.", usesPerHour: 1 },
  { className: "Roublard", pathName: "Brigand", level: 3, name: "Renversement (Roublard)", description: "1/heure, en frappant les jambes ou boucliers de la cible, elle tombe à terre.", usesPerHour: 1 },
  { className: "Roublard", pathName: "Brigand", level: 4, name: "Esquive (Roublard)", description: "1/heure, peut éviter une attaque infligeant des dégâts en criant 'Esquive !'.", usesPerHour: 1 },
  { className: "Roublard", pathName: "Brigand", level: 5, name: "Feinter la mort", description: "1/heure, lorsque le roublard devrait subir des dégâts fatals, il tombe au sol à 1 PV. Il peut même dire en Hors-jeu qu'il est mort. Sauf contre la capacité de détection des morts.", usesPerHour: 1 },
  // ROUBLARD - Barde
  { className: "Roublard", pathName: "Barde", level: 1, name: "Inspiration", description: "1 Mana, en chantant ou jouant de la musique en combat, ses alliés ont +1 PV pour le combat. Ceci n'est pas un buff et plusieurs bardes peuvent cumuler leurs inspirations.", manaCost: 1 },
  { className: "Roublard", pathName: "Barde", level: 2, name: "Charme", description: "1 Mana, après avoir dit 2 compliments différents à une cible, celle-ci considère le roublard comme un ami pour 5 minutes. Si résisté, ne peut être retentée avant 1 heure.", manaCost: 1 },
  { className: "Roublard", pathName: "Barde", level: 3, name: "Motivation", description: "2 Mana, faisant un discours d'encouragement à une cible, ceci lui confère +1 dégât pour 15 minutes. Ceci est un Buff.", manaCost: 2, isBuff: true },
  { className: "Roublard", pathName: "Barde", level: 4, name: "Confusion", description: "1 Mana et incantation, La cible à vue inverse alliée et ennemi pour 1 minute, 10 minutes si hors combat. Ne peut pas être lancé 2 fois sur la même cible dans la même heure.", manaCost: 1, isIncantation: true },
  { className: "Roublard", pathName: "Barde", level: 5, name: "Suggestion (Barde)", description: "1 Mana, Le roublard maintient un contact visuel et fait une suggestion convaincante à une cible, qui doit l'accomplir au mieux pendant 10 minutes.", manaCost: 1 },
  // CHEVALIER DE LA MORT - Inquisiteur
  { className: "Chevalier de la mort", pathName: "Inquisiteur", level: 1, name: "Châtiment (Chevalier)", description: "1/heure, Une attaque de corps à corps infligeant +2 dégâts de froid (perdue si raté).", usesPerHour: 1 },
  { className: "Chevalier de la mort", pathName: "Inquisiteur", level: 2, name: "Damnation", description: "1 Mana, Signe : Damnare, inflige 3 dégâts de froid.", manaCost: 1, isSign: true },
  { className: "Chevalier de la mort", pathName: "Inquisiteur", level: 3, name: "Frayeur (Chevalier)", description: "Signe : Anxietas. La cible doit fuir le chevalier. Durée 30 sec.", isSign: true },
  { className: "Chevalier de la mort", pathName: "Inquisiteur", level: 4, name: "Force du colosse (Chevalier)", description: "2 Mana, Incantation, confère à une cible +1 dégât et +1 Lutte, ceci est un Buff. Durée 15 minutes.", manaCost: 2, isIncantation: true, isBuff: true },
  { className: "Chevalier de la mort", pathName: "Inquisiteur", level: 5, name: "Arme divine (Chevalier)", description: "L'arme du chevalier de la mort inflige des dégâts divins (ignore les armures et résistances)." },
  // CHEVALIER DE LA MORT - Immortel
  { className: "Chevalier de la mort", pathName: "Immortel", level: 1, name: "Intimidation (Chevalier)", description: "1/heure, La cible à vue ne peut plus attaquer le chevalier. Durée 15 secondes, sauf si le chevalier l'attaque.", usesPerHour: 1 },
  { className: "Chevalier de la mort", pathName: "Immortel", level: 2, name: "Sauvegarde supplémentaire", description: "+1 sauvegarde." },
  { className: "Chevalier de la mort", pathName: "Immortel", level: 3, name: "Vigilance (Chevalier)", description: "Le chevalier de la mort voit les créatures invisibles (il doit dire 'vigilance' à voix haute dès qu'il voit une personne invisible)." },
  { className: "Chevalier de la mort", pathName: "Immortel", level: 4, name: "Jugement", description: "1/heure, Le chevalier amène une cible avec lui en hors-jeu pour un duel, un seul des 2 peut en ressortir vivant.", usesPerHour: 1 },
  { className: "Chevalier de la mort", pathName: "Immortel", level: 5, name: "Damné", description: "+5 PV, et immunité aux poisons et maladies (max 1 dégâts de poison par attaque), récupère 3 PV/min hors combat, mais ne peut plus être soigné par autrui." },
  // CHEVALIER DE LA MORT - Faucheur
  { className: "Chevalier de la mort", pathName: "Faucheur", level: 1, name: "Frappe de sang", description: "Une attaque de corps à corps infligeant +1 dégât, mais coûte 1 PV si réussie.", pvCost: 1 },
  { className: "Chevalier de la mort", pathName: "Faucheur", level: 2, name: "Armée des morts", description: "1 Mana, Incantation, Relève 3 morts en zombie : 5 PV, frappe de 1, ne peuvent pas courir.", manaCost: 1, isIncantation: true },
  { className: "Chevalier de la mort", pathName: "Faucheur", level: 3, name: "Frappe Vampirique", description: "1/heure, Une attaque de corps à corps soignant le chevalier du montant de dégâts infligé, récupéré si raté.", usesPerHour: 1 },
  { className: "Chevalier de la mort", pathName: "Faucheur", level: 4, name: "Gargantua (Chevalier)", description: "2 Mana, Incantation, Relève 1 mort en Zombie : 15 PV, frappe de 3, ne peut pas courir. Un seul gargantua à la fois.", manaCost: 2, isIncantation: true },
  { className: "Chevalier de la mort", pathName: "Faucheur", level: 5, name: "Extinction", description: "1/heure, Inflige 5 dégâts de froid à tous ceux près de lui (environ 10 mètres), le chevalier de la mort tombe à 1 PV.", usesPerHour: 1 },
  // SORCIER - Conjurateur
  { className: "Sorcier", pathName: "Conjurateur", level: 1, name: "Drain de vie", description: "1 fois par cible par heure. En touchant une cible, inflige 2 dégâts de froid et soigne autant le sorcier." },
  { className: "Sorcier", pathName: "Conjurateur", level: 2, name: "Damnation (Sorcier)", description: "1 Énergie, Signe : Damnare, inflige 3 dégâts de froid.", manaCost: 1, isSign: true },
  { className: "Sorcier", pathName: "Conjurateur", level: 3, name: "Frayeur (Sorcier)", description: "Signe : Anxietas. La cible doit fuir le Sorcier. Durée 30 sec.", isSign: true },
  { className: "Sorcier", pathName: "Conjurateur", level: 4, name: "Noirceur", description: "Signe : Caecitas. La cible est aveuglée (doit mettre un bras devant ses yeux). Durée 30 sec.", isSign: true },
  { className: "Sorcier", pathName: "Conjurateur", level: 5, name: "Désintégration (Sorcier)", description: "1 Énergie, Signe : Extinctio. Inflige 4 dégâts de feu.", manaCost: 1, isSign: true },
  // SORCIER - Cultiste
  { className: "Sorcier", pathName: "Cultiste", level: 1, name: "Silence", description: "1 Énergie, Incantation, la cible ne peut plus parler, incanter ou faire de sort pendant 1 minute, si hors combat, 5 minutes.", manaCost: 1, isIncantation: true },
  { className: "Sorcier", pathName: "Cultiste", level: 2, name: "Lance d'os", description: "Inflige 3 dégâts magiques à une cible à vue, chaque utilisation brise un membre du sorcier pour 1 heure. Doit attendre 5 sec entre chaque utilisation." },
  { className: "Sorcier", pathName: "Cultiste", level: 3, name: "Amnésie", description: "1 Énergie, En mettant la main sur la tête de la cible 5 secondes, fait oublier un souvenir de la cible, utilisable hors combat.", manaCost: 1 },
  { className: "Sorcier", pathName: "Cultiste", level: 4, name: "Téléportation (Sorcier)", description: "1 Énergie, Incantation, permet au sorcier de partir immatériel à une destination précise sans être suivi. Il revient matériel s'il arrête de se déplacer ou tourne en rond.", manaCost: 1, isIncantation: true },
  { className: "Sorcier", pathName: "Cultiste", level: 5, name: "Malédiction", description: "2 Énergies, Incantation, afflige une malédiction à vue que la cible ne peut plus courir OU ses dégâts sont de 1 maximum OU ne peut plus être soignée. Durée 2 heures.", manaCost: 2, isIncantation: true },
  // SORCIER - Nécromancien
  { className: "Sorcier", pathName: "Nécromancien", level: 1, name: "Réanimation", description: "Incantation, 1 fois par cible par heure. Relève 3 morts en zombie : 3 PV, frappe de 1, ne peuvent pas courir.", isIncantation: true },
  { className: "Sorcier", pathName: "Nécromancien", level: 2, name: "Bouclier d'os", description: "Incantation, utilise et détruit un cadavre pour que le sorcier obtient +3 PV, jusqu'à leur utilisation. Ceci est un Buff.", isIncantation: true, isBuff: true },
  { className: "Sorcier", pathName: "Nécromancien", level: 3, name: "Communication avec les morts", description: "Incantation, 1 fois par cadavre, Le sorcier peut poser 5 questions de oui ou non à un cadavre. Il obtient la langue des morts.", isIncantation: true },
  { className: "Sorcier", pathName: "Nécromancien", level: 4, name: "Gargantua (Sorcier)", description: "2 Énergies, Incantation, Relève 1 mort en Zombie : 15 PV, frappe de 3, ne peut pas courir. Un seul gargantua à la fois.", manaCost: 2, isIncantation: true },
  { className: "Sorcier", pathName: "Nécromancien", level: 5, name: "Goule", description: "2 Énergies, Incantation, Relève 1 mort en goule : 6 PV, frappe de 2 dégâts de poison, peuvent courir, ce que la goule tue devient également une goule.", manaCost: 2, isIncantation: true },
  // MEDJAI - Occultiste
  { className: "Medjai", pathName: "Occultiste", level: 1, name: "Flamme (Medjai)", description: "Signe : Ignis, Inflige 1 dégât de feu. Ne peut pas être fait 2 fois de suite sur la même cible.", isSign: true },
  { className: "Medjai", pathName: "Occultiste", level: 2, name: "Silence (Medjai)", description: "1 Mana, Incantation, la cible ne peut plus parler ou incanter pendant 1 minute, si hors combat 5 minutes.", manaCost: 1, isIncantation: true },
  { className: "Medjai", pathName: "Occultiste", level: 3, name: "Force (Medjai)", description: "3/heure, La cible (à environ 10 mètres ou moins) est repoussée de 3 pas.", usesPerHour: 3 },
  { className: "Medjai", pathName: "Occultiste", level: 4, name: "Force de limace", description: "1 Mana, Incantation, la cible ne fait que 1 de dégâts et a -2 de Lutte. Durée 1 minute.", manaCost: 1, isIncantation: true },
  { className: "Medjai", pathName: "Occultiste", level: 5, name: "Suggestion (Medjai)", description: "1 Mana, Le Medjai maintient un contact visuel et fait une suggestion convaincante à une cible, qui doit l'accomplir au mieux pendant 10 minutes.", manaCost: 1 },
  // MEDJAI - Mutant
  { className: "Medjai", pathName: "Mutant", level: 1, name: "Massif", description: "-1 Mana permanent, Le Medjai obtient +1 en Lutte et +2 PV." },
  { className: "Medjai", pathName: "Mutant", level: 2, name: "Costaud", description: "-1 Mana permanent, Le Medjai obtient +1 dégât s'il tient son arme à 2 mains (pas armes d'haste)." },
  { className: "Medjai", pathName: "Mutant", level: 3, name: "Vision parfaite", description: "-1 Mana permanent, Le Medjai peut voir l'invisible et est immunisé à l'aveuglement." },
  { className: "Medjai", pathName: "Mutant", level: 4, name: "Régénération", description: "-1 Mana permanent, Le Medjai peut être soigné et récupère 1 PV par minute hors combat." },
  { className: "Medjai", pathName: "Mutant", level: 5, name: "Armure de vent", description: "-2 Mana permanent, Le Medjai est immunisé aux attaques à distance infligeant des dégâts." },
  // MEDJAI - Sorcelier
  { className: "Medjai", pathName: "Sorcelier", level: 1, name: "Frappe occulte", description: "3/heure, Une attaque de corps à corps infligeant +1 dégât, réussie ou ratée.", usesPerHour: 3 },
  { className: "Medjai", pathName: "Sorcelier", level: 2, name: "Renversement (Medjai)", description: "1/heure, en frappant les jambes ou boucliers de la cible, elle tombe à terre.", usesPerHour: 1 },
  { className: "Medjai", pathName: "Sorcelier", level: 3, name: "Arme liée", description: "Le Medjai se lie à 1 arme qu'il peut toujours appeler à lui et peut 1/heure lancer son arme et se téléporter à elle.", usesPerHour: 1 },
  { className: "Medjai", pathName: "Sorcelier", level: 4, name: "Brise arcane", description: "1/heure, Le medjai peut briser une barrière ou défense magique ou retirer 4 de Mana à une cible en la frappant.", usesPerHour: 1 },
  { className: "Medjai", pathName: "Sorcelier", level: 5, name: "Esquive (Medjai)", description: "1/heure, peut éviter une attaque infligeant des dégâts en criant 'Esquive !'.", usesPerHour: 1 },
  // PALADIN - Croisé
  { className: "Paladin", pathName: "Croisé", level: 1, name: "Châtiment (Paladin)", description: "1/heure, Une attaque de corps à corps infligeant +2 dégâts de feu (perdue si raté).", usesPerHour: 1 },
  { className: "Paladin", pathName: "Croisé", level: 2, name: "Fracassement (Paladin)", description: "1 Mana. Détruit un objet/armure/bouclier touché par la main du paladin (pas une arme tenue en main).", manaCost: 1 },
  { className: "Paladin", pathName: "Croisé", level: 3, name: "Radiance", description: "1 Mana, Signe : Fulgor, inflige 3 dégâts de feu.", manaCost: 1, isSign: true },
  { className: "Paladin", pathName: "Croisé", level: 4, name: "Force du colosse (Paladin)", description: "2 Mana, Incantation, confère à une cible +1 dégât et +1 Lutte, ceci est un Buff. Durée 15 minutes.", manaCost: 2, isIncantation: true, isBuff: true },
  { className: "Paladin", pathName: "Croisé", level: 5, name: "Arme divine (Paladin)", description: "L'arme du Paladin inflige des dégâts divins (ignore les armures et résistances)." },
  // PALADIN - Gardien
  { className: "Paladin", pathName: "Gardien", level: 1, name: "Protection", description: "1 Mana, la cible touchée devient invulnérable pour 2 minutes sauf si elle sépare ses mains, se déplace ou attaque.", manaCost: 1 },
  { className: "Paladin", pathName: "Gardien", level: 2, name: "Sauvegarde (Paladin)", description: "+1 sauvegarde." },
  { className: "Paladin", pathName: "Gardien", level: 3, name: "Vigilance (Paladin)", description: "Le Paladin voit les créatures invisibles (il doit dire 'vigilance' à voix haute dès qu'il voit une personne invisible)." },
  { className: "Paladin", pathName: "Gardien", level: 4, name: "Santé divine", description: "Le paladin obtient +2 PV, et une immunité aux poisons et maladies (il ne subit que 1 dégâts maximum par attaque de poison)." },
  { className: "Paladin", pathName: "Gardien", level: 5, name: "Bouclier divin", description: "Le bouclier du paladin est indestructible, mais le paladin ne peut pas l'utiliser en duel contre un joueur n'ayant pas de bouclier ou d'arme d'hast." },
  // PALADIN - Dévot
  { className: "Paladin", pathName: "Dévot", level: 1, name: "Guérison (Paladin)", description: "1 Mana, Incantation, soigne 3 PV à la cible touchée.", manaCost: 1, isIncantation: true },
  { className: "Paladin", pathName: "Dévot", level: 2, name: "Délivrance", description: "1 Mana, Incantation, Retire tout effet négatif d'une cible sauf une malédiction.", manaCost: 1, isIncantation: true },
  { className: "Paladin", pathName: "Dévot", level: 3, name: "Vague de Soin (Paladin)", description: "1 Mana, Incantation, soigne 3 cibles différentes de 2 PV à vue.", manaCost: 1, isIncantation: true },
  { className: "Paladin", pathName: "Dévot", level: 4, name: "Aura de bravoure", description: "Le paladin et ses alliés proches sont immunisés aux effets de peur.", isBuff: true },
  { className: "Paladin", pathName: "Dévot", level: 5, name: "Rappel à la vie (Paladin)", description: "2 Mana, Incantation, ramène 1 mort à 1 PV au toucher. Pas plus de 2 minutes après la mort.", manaCost: 2, isIncantation: true },
];

// ─── Execute Seed ─────────────────────────────────────────────────────────────
console.log("🌱 Seeding Terra Mortis database...");

// Insert races
console.log("  → Inserting races...");
for (const r of racesData) {
  await rawInsert(
    `INSERT INTO races (name, faction, description, bonuses, maluses, abilities, physicalDescription, startingLanguages, pvBonus, manaBonus, luteBonus, pvMalus)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [r.name, r.faction, r.description, JSON.stringify(r.bonuses), JSON.stringify(r.maluses), JSON.stringify(r.abilities), r.physicalDescription, JSON.stringify(r.startingLanguages), r.pvBonus, r.manaBonus, r.luteBonus, r.pvMalus]
  );
}

// Insert classes
console.log("  → Inserting classes...");
for (const c of classesData) {
  await rawInsert(
    `INSERT INTO classes (name, faction, description, basePv, baseMana, baseAbilities, specialRules, requiresWeapon, code)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [c.name, c.faction, c.description, c.basePv, c.baseMana, JSON.stringify(c.baseAbilities), JSON.stringify(c.specialRules), c.requiresWeapon ? 1 : 0, c.code ? JSON.stringify(c.code) : null]
  );
}

// Insert class paths
console.log("  → Inserting class paths...");
for (const p of classPathsData) {
  const [cls] = await connection.execute(`SELECT id FROM classes WHERE name = ?`, [p.className]);
  if (cls[0]) {
    await rawInsert(
      `INSERT INTO class_paths (classId, name, description)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE name=name`,
      [cls[0].id, p.name, p.description]
    );
  }
}

// Insert class abilities
console.log("  → Inserting class abilities...");
for (const a of classAbilitiesData) {
  const [cls] = await connection.execute(`SELECT id FROM classes WHERE name = ?`, [a.className]);
  if (!cls[0]) continue;
  const [path] = await connection.execute(`SELECT id FROM class_paths WHERE classId = ? AND name = ?`, [cls[0].id, a.pathName]);
  await rawInsert(
    `INSERT INTO class_abilities (classId, pathId, level, name, description, manaCost, pvCost, usesPerHour, isBuff, isSign, isIncantation)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [cls[0].id, path[0]?.id || null, a.level, a.name, a.description, a.manaCost || 0, a.pvCost || 0, a.usesPerHour || null, a.isBuff ? 1 : 0, a.isSign ? 1 : 0, a.isIncantation ? 1 : 0]
  );
}

// Insert dons
console.log("  → Inserting dons...");
for (const d of donsData) {
  await rawInsert(
    `INSERT INTO dons (name, description, canStack, maxStacks, pvBonus, manaBonus, luteBonus)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [d.name, d.description, d.canStack ? 1 : 0, d.maxStacks, d.pvBonus, d.manaBonus, d.luteBonus]
  );
}

// Insert compétences
console.log("  → Inserting compétences...");
for (const c of competencesData) {
  await rawInsert(
    `INSERT INTO competences (name, category, description, baseAdvantage, advancedAdvantage, requiredMaterial, isAdultOnly)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [c.name, c.category, c.description, c.baseAdvantage, c.advancedAdvantage, c.requiredMaterial, c.isAdultOnly ? 1 : 0]
  );
}

// Insert heritage avantages
console.log("  → Inserting héritage avantages...");
for (const h of heritageAvantagesData) {
  await rawInsert(
    `INSERT INTO heritage_avantages (name, description, xpCost, maxTimes, pvBonus, manaBonus, luteBonus, moneyBonus)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [h.name, h.description, h.xpCost, h.maxTimes, h.pvBonus, h.manaBonus, h.luteBonus, h.moneyBonus]
  );
}

// Insert désavantages
console.log("  → Inserting désavantages...");
for (const d of desavantagesData) {
  await rawInsert(
    `INSERT INTO desavantages (name, description, xpGain, xpType, forbiddenClasses)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=name`,
    [d.name, d.description, d.xpGain, d.xpType, d.forbiddenClasses ? JSON.stringify(d.forbiddenClasses) : null]
  );
}

console.log("✅ Seed complete!");
await connection.end();
