#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/rules/Introduction.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Remplacer la section Navigation
old_section = '''          {/* Navigation vers les autres sections */}
          <div className="grid md:grid-cols-3 gap-4 pt-4">
            {[
              { href: "/regles/regles-base", label: "Règles de base", desc: "Système de combat, PV, mana..." },
              { href: "/regles/races", label: "Les races", desc: "Humain, Elfe, Nain, Orc..." },
              { href: "/regles/classes", label: "Les classes", desc: "Guerrier, Mage, Druide..." },
            ].map(link => (
              <Link key={link.href} href={link.href}>
                <div className="p-4 rounded-lg border border-border/50 bg-card/20 hover:bg-card/40 transition-all group cursor-pointer">
                  <h3 className="font-heading font-semibold text-foreground group-hover:text-primary transition-colors flex items-center gap-2">
                    {link.label}
                    <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">{link.desc}</p>
                </div>
              </Link>
            ))}
          </div>'''

new_section = '''          {/* Héritage & Désavantages */}
          <section className="pt-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Link href="/regles/heritage">
                <div className="relative p-8 rounded-xl border bg-card/30 hover:bg-card/50 transition-all group cursor-pointer h-full" style={{ borderColor: "oklch(0.5 0.18 10 / 0.5)" }}>
                  <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl" style={{ background: "linear-gradient(to right, transparent, oklch(0.5 0.18 10), transparent)" }} />
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "oklch(0.5 0.18 10)20", border: "2px solid oklch(0.5 0.18 10)50" }}>
                      <BookOpen className="w-6 h-6" style={{ color: "oklch(0.5 0.18 10)" }} />
                    </div>
                    <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.5 0.18 10)" }}>
                      Héritage
                    </h3>
                  </div>
                  <p className="text-foreground/80 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                    Définissez le passé de votre personnage avec les héritages. Gagnez des XP temporaires, débloquez des capacités bonus et améliorez vos caractéristiques.
                  </p>
                  <ChevronRight className="w-5 h-5 absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: "oklch(0.5 0.18 10)" }} />
                </div>
              </Link>
              <Link href="/regles/desavantages">
                <div className="relative p-8 rounded-xl border bg-card/30 hover:bg-card/50 transition-all group cursor-pointer h-full" style={{ borderColor: "oklch(0.45 0.15 140 / 0.5)" }}>
                  <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl" style={{ background: "linear-gradient(to right, transparent, oklch(0.45 0.15 140), transparent)" }} />
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "oklch(0.45 0.15 140)20", border: "2px solid oklch(0.45 0.15 140)50" }}>
                      <Skull className="w-6 h-6" style={{ color: "oklch(0.45 0.15 140)" }} />
                    </div>
                    <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.45 0.15 140)" }}>
                      Désavantages
                    </h3>
                  </div>
                  <p className="text-foreground/80 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                    Choisissez les désavantages de votre personnage. Gagnez des XP temporaires en échange de handicaps et de faiblesses.
                  </p>
                  <ChevronRight className="w-5 h-5 absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: "oklch(0.45 0.15 140)" }} />
                </div>
              </Link>
            </div>
          </section>'''

content = content.replace(old_section, new_section)
print("✓ Section Navigation remplacée")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/rules/Introduction.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
