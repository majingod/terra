import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import {
  Home,
  BookOpen,
  Users,
  Crown,
  Wand2,
  Skull,
  Swords,
  LogOut,
  LogIn,
  Plus,
  User,
  Menu,
  X,
  ChevronDown,
  Settings,
  Calendar,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

interface NavItem {
  href: string;
  label: string;
  icon: React.ReactNode;
  requiresAuth?: boolean;
  adminOnly?: boolean;
}

interface NavSection {
  label: string;
  icon: React.ReactNode;
  items: NavItem[];
  requiresAuth?: boolean;
}

export default function Sidebar() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    regles: true,
    evenements: true,
    personnage: true,
  });
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();

  // Déterminer si on est sur mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setIsMobileOpen(false);
      }
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [sectionId]: !prev[sectionId],
    }));
  };

  const handleNavClick = () => {
    if (isMobile) {
      setIsMobileOpen(false);
    }
  };

  const rulesItems: NavItem[] = [
    {
      href: "/regles",
      label: "Introduction",
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      href: "/regles/magie",
      label: "Magie",
      icon: <Wand2 className="w-5 h-5" />,
    },
    {
      href: "/regles/combat",
      label: "Combat",
      icon: <Swords className="w-5 h-5" />,
    },
    {
      href: "/regles/races",
      label: "Races",
      icon: <Users className="w-5 h-5" />,
    },
    {
      href: "/regles/classes",
      label: "Classes",
      icon: <Swords className="w-5 h-5" />,
    },
    {
      href: "/regles/desavantages",
      label: "Désavantages",
      icon: <Skull className="w-5 h-5" />,
    },
    {
      href: "/regles/heritage",
      label: "Héritage",
      icon: <Crown className="w-5 h-5" />,
    },
    {
      href: "/regles/competences",
      label: "Compétences",
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      href: "/regles/dons",
      label: "Dons",
      icon: <Crown className="w-5 h-5" />,
    },
  ];

  const personnageItems: NavItem[] = [
    {
      href: "/creer-personnage",
      label: "Créer Personnage",
      icon: <Plus className="w-5 h-5" />,
      requiresAuth: true,
    },
    {
      href: "/mes-personnages",
      label: "Mes Personnages",
      icon: <User className="w-5 h-5" />,
      requiresAuth: true,
    },
  ];

  const evenementItem: NavItem = {
    href: "/evenements",
    label: "Événements",
    icon: <Calendar className="w-5 h-5" />,
  };

  const adminItems: NavItem[] = [
    {
      href: "/admin",
      label: "Gestion des Races",
      icon: <Users className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Classes",
      icon: <Swords className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Désavantages",
      icon: <Skull className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Héritages",
      icon: <Crown className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Compétences",
      icon: <BookOpen className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Dons",
      icon: <Crown className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin/migration-encyclopedie",
      label: "Migration Encyclopédie",
      icon: <BookOpen className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin/evenements",
      label: "Gestion des Événements",
      icon: <Calendar className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Personnages",
      icon: <User className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
    {
      href: "/admin",
      label: "Gestion des Utilisateurs",
      icon: <Users className="w-5 h-5" />,
      requiresAuth: true,
      adminOnly: true,
    },
  ];

  const navSections: NavSection[] = [
    {
      label: "Règles",
      icon: <BookOpen className="w-5 h-5" />,
      items: rulesItems,
    },
    ...(isAuthenticated
      ? [
          {
            label: "Personnage",
            icon: <User className="w-5 h-5" />,
            items: personnageItems,
            requiresAuth: true,
          },
        ]
      : []),
    ...(user?.role === "organizer" || user?.role === "admin"
      ? [
          {
            label: "Admin",
            icon: <Settings className="w-5 h-5" />,
            items: adminItems,
            requiresAuth: true,
          },
        ]
      : []),
  ];

  const isActive = (href: string) => location === href;
  const isSectionActive = (items: NavItem[]) =>
    items.some((item) => isActive(item.href));

  // Contenu du sidebar (réutilisable pour desktop et mobile)
  const SidebarContent = () => (
    <>
      {/* Header avec toggle et auth */}
      <div className="flex items-center justify-between p-4 border-b border-border/20">
        {(isExpanded || isMobileOpen) && (
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.2)" }}
            >
              <Skull className="w-5 h-5" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
            <span
              className="font-heading font-bold text-sm"
              style={{ color: "oklch(0.82 0.2 85)" }}
            >
              Terra Mortis
            </span>
          </div>
        )}
        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <button
              onClick={() => {
                logout();
                handleNavClick();
              }}
              className="p-2 rounded-lg transition-colors hover:bg-red-900/20"
              style={{ color: "oklch(0.82 0.2 85)" }}
              title="Deconnexion"
            >
              <LogOut className="w-5 h-5" />
            </button>
          ) : (
            <a
              href={getLoginUrl()}
              onClick={handleNavClick}
              className="p-2 rounded-lg transition-colors hover:bg-green-900/20"
              style={{ color: "oklch(0.82 0.2 85)" }}
              title="Connexion"
            >
              <LogIn className="w-5 h-5" />
            </a>
          )}
          {!isMobile && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-2 rounded-lg transition-colors hover:bg-secondary/30"
              style={{ color: "oklch(0.82 0.2 85)" }}
            >
              {isExpanded ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          )}
        </div>

      </div>

      {/* Navigation items */}
      <nav className="flex flex-col gap-2 p-3 flex-1 overflow-y-auto">
        {/* Accueil */}
        <Link href="/">
          <a
            onClick={handleNavClick}
            className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group relative`}
            style={{
              background: isActive("/")
                ? "oklch(0.65 0.18 45 / 0.2)"
                : "transparent",
              color: isActive("/")
                ? "oklch(0.82 0.2 85)"
                : "oklch(0.55 0.02 60)",
            }}
            title={!isExpanded && !isMobileOpen ? "Accueil" : undefined}
          >
            <div className="flex-shrink-0">
              <Home className="w-5 h-5" />
            </div>
            {(isExpanded || isMobileOpen) && (
              <span className="text-sm font-heading flex-1">Accueil</span>
            )}
            {!isExpanded && !isMobileOpen && (
              <div
                className="absolute left-full ml-2 px-2 py-1 rounded-lg text-xs font-heading whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{
                  background: "oklch(0.2 0.05 240)",
                  border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                  color: "oklch(0.82 0.2 85)",
                }}
              >
                Accueil
              </div>
            )}
          </a>
        </Link>

        {/* Événements (lien direct) */}
        <Link href={evenementItem.href}>
          <a
            onClick={handleNavClick}
            className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group relative`}
            style={{
              background: isActive(evenementItem.href)
                ? "oklch(0.65 0.18 45 / 0.2)"
                : "transparent",
              color: isActive(evenementItem.href)
                ? "oklch(0.82 0.2 85)"
                : "oklch(0.55 0.02 60)",
            }}
            title={!isExpanded && !isMobileOpen ? evenementItem.label : undefined}
          >
            <div className="flex-shrink-0">{evenementItem.icon}</div>
            {(isExpanded || isMobileOpen) && (
              <span className="text-sm font-heading flex-1">{evenementItem.label}</span>
            )}
            {!isExpanded && !isMobileOpen && (
              <div
                className="absolute left-full ml-2 px-2 py-1 rounded-lg text-xs font-heading whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{
                  background: "oklch(0.2 0.05 240)",
                  border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                  color: "oklch(0.82 0.2 85)",
                }}
              >
                {evenementItem.label}
              </div>
            )}
          </a>
        </Link>

        {/* Sections collapsibles */}
        {navSections.map((section) => (
          <div key={section.label}>
            {/* Section header */}
            <button
              onClick={() => toggleSection(section.label.toLowerCase())}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group relative`}
              style={{
                background: isSectionActive(section.items)
                  ? "oklch(0.65 0.18 45 / 0.15)"
                  : "transparent",
                color: isSectionActive(section.items)
                  ? "oklch(0.82 0.2 85)"
                  : "oklch(0.55 0.02 60)",
              }}
              title={!isExpanded && !isMobileOpen ? section.label : undefined}
            >
              <div className="flex-shrink-0">{section.icon}</div>
              {(isExpanded || isMobileOpen) && (
                <>
                  <span className="text-sm font-heading flex-1 text-left">
                    {section.label}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform duration-200 ${
                      expandedSections[section.label.toLowerCase()]
                        ? "rotate-0"
                        : "-rotate-90"
                    }`}
                  />
                </>
              )}
              {!isExpanded && !isMobileOpen && (
                <div
                  className="absolute left-full ml-2 px-2 py-1 rounded-lg text-xs font-heading whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                  style={{
                    background: "oklch(0.2 0.05 240)",
                    border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                    color: "oklch(0.82 0.2 85)",
                  }}
                >
                  {section.label}
                </div>
              )}
            </button>

            {/* Section items */}
            {(isExpanded || isMobileOpen) && expandedSections[section.label.toLowerCase()] && (
              <div className="ml-2 border-l border-border/20 pl-2 space-y-1">
                {section.items.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <a
                      onClick={handleNavClick}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 text-sm`}
                      style={{
                        background: isActive(item.href)
                          ? "oklch(0.65 0.18 45 / 0.3)"
                          : "transparent",
                        color: isActive(item.href)
                          ? "oklch(0.82 0.2 85)"
                          : "oklch(0.55 0.02 60)",
                      }}
                    >
                      <div className="flex-shrink-0">{item.icon}</div>
                      <span className="text-xs font-heading">{item.label}</span>
                    </a>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* Footer avec auth */}
      <div className="border-t border-border/20 p-3">
        {isAuthenticated ? (
          <>
            {(isExpanded || isMobileOpen) && (
              <div className="mb-3 px-3 py-2 rounded-lg bg-secondary/20 text-xs">
                <p
                  className="font-heading font-semibold"
                  style={{ color: "oklch(0.82 0.2 85)" }}
                >
                  {user?.name || "Joueur"}
                </p>
                <p className="text-muted-foreground text-xs mt-1">
                  {user?.role === "admin"
                    ? "Administrateur"
                    : user?.role === "organizer"
                      ? "Organisateur"
                      : "Joueur"}
                </p>
              </div>
            )}
            <button
              onClick={() => {
                logout();
                handleNavClick();
              }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 hover:bg-red-900/20 group relative"
              style={{ color: "oklch(0.82 0.2 85)" }}
              title={!isExpanded && !isMobileOpen ? "Déconnexion" : undefined}
            >
              <LogOut className="w-5 h-5 flex-shrink-0" />
              {(isExpanded || isMobileOpen) && (
                <span className="text-sm font-heading">Déconnexion</span>
              )}
              {!isExpanded && !isMobileOpen && (
                <div
                  className="absolute left-full ml-2 px-2 py-1 rounded-lg text-xs font-heading whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                  style={{
                    background: "oklch(0.2 0.05 240)",
                    border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                    color: "oklch(0.82 0.2 85)",
                  }}
                >
                  Déconnexion
                </div>
              )}
            </button>
          </>
        ) : (
          <a
            href={getLoginUrl()}
            onClick={handleNavClick}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 hover:bg-green-900/20 group relative"
            style={{ color: "oklch(0.82 0.2 85)" }}
            title={!isExpanded && !isMobileOpen ? "Connexion" : undefined}
          >
            <LogIn className="w-5 h-5 flex-shrink-0" />
            {(isExpanded || isMobileOpen) && (
              <span className="text-sm font-heading">Connexion</span>
            )}
            {!isExpanded && !isMobileOpen && (
              <div
                className="absolute left-full ml-2 px-2 py-1 rounded-lg text-xs font-heading whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{
                  background: "oklch(0.2 0.05 240)",
                  border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                  color: "oklch(0.82 0.2 85)",
                }}
              >
                Connexion
              </div>
            )}
          </a>
        )}
      </div>
    </>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      {!isMobile && (
        <div
          className={`fixed left-0 top-0 h-screen transition-all duration-300 ease-in-out z-50 flex flex-col`}
          style={{
            width: isExpanded ? "250px" : "80px",
            background: "linear-gradient(180deg, oklch(0.15 0.05 240) 0%, oklch(0.12 0.04 240) 100%)",
            borderRight: "1px solid oklch(0.65 0.18 45 / 0.2)",
          }}
        >
          <SidebarContent />
        </div>
      )}

      {/* Mobile Hamburger Button */}
      {isMobile && (
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="fixed top-4 left-4 z-50 p-2 rounded-lg transition-colors hover:bg-secondary/30"
          style={{ color: "oklch(0.82 0.2 85)" }}
          title="Menu"
        >
          <Menu className="w-6 h-6" />
        </button>
      )}

      {/* Mobile Drawer Overlay */}
      {isMobile && isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 transition-opacity"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Mobile Drawer */}
      {isMobile && (
        <div
          className={`fixed left-0 top-0 h-screen w-64 transition-all duration-300 ease-in-out z-50 flex flex-col transform ${
            isMobileOpen ? "translate-x-0" : "-translate-x-full"
          }`}
          style={{
            background: "linear-gradient(180deg, oklch(0.15 0.05 240) 0%, oklch(0.12 0.04 240) 100%)",
            borderRight: "1px solid oklch(0.65 0.18 45 / 0.2)",
          }}
        >
          <SidebarContent />
        </div>
      )}

      {/* Spacer pour desktop */}
      {!isMobile && (
        <div
          style={{
            width: isExpanded ? "250px" : "80px",
            transition: "width 0.3s ease-in-out",
          }}
        />
      )}
    </>
  );
}
