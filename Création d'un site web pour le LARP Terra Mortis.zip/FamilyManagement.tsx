import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Plus, LogOut, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function FamilyManagement() {
  const { user } = useAuth();
  const [newChildName, setNewChildName] = useState("");
  const [isCreatingChild, setIsCreatingChild] = useState(false);

  // Charger les données de la famille
  const { data: familyData, isLoading } = trpc.family.getMyFamily.useQuery(undefined, {
    enabled: !!user,
  });

  // Mutations
  const addChildMutation = trpc.family.addChildProfile.useMutation({
    onSuccess: () => {
      toast.success("Profil enfant créé avec succès !");
      setNewChildName("");
      setIsCreatingChild(false);
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de la création du profil enfant");
    },
  });

  const switchProfileMutation = trpc.family.switchProfile.useMutation({
    onSuccess: () => {
      toast.success("Profil activé !");
      window.location.reload();
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors du changement de profil");
    },
  });

  if (!user) {
    return (
      <div className="container py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Gestion de Famille</h1>
        <p className="text-muted-foreground mb-6">
          Vous devez être connecté pour gérer votre famille.
        </p>
        <a
          href={getLoginUrl()}
          className="inline-block px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
        >
          Se connecter
        </a>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="container py-20 text-center">
        <p className="text-muted-foreground">Chargement...</p>
      </div>
    );
  }

  if (!familyData) {
    return (
      <div className="container py-20 text-center">
        <p className="text-muted-foreground">Aucune famille trouvée.</p>
      </div>
    );
  }

  const handleAddChild = async () => {
    if (!newChildName.trim()) {
      toast.error("Veuillez entrer un nom pour le profil enfant");
      return;
    }

    if (!familyData?.family?.id) {
      toast.error("Famille non trouvée");
      return;
    }

    await addChildMutation.mutateAsync({
      familyId: familyData.family.id,
      childName: newChildName,
    });
  };

  const handleSwitchProfile = async (profileId: number) => {
    if (!familyData?.family?.id) {
      toast.error("Famille non trouvée");
      return;
    }

    await switchProfileMutation.mutateAsync({
      familyId: familyData.family.id,
      profileId,
    });
  };

  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Gestion de Famille</h1>
          <p className="text-muted-foreground">
            Gérez les profils de votre famille et les comptes enfants
          </p>
        </div>

        {/* Profil Parent */}
        {familyData.profiles && familyData.profiles.find((p) => p.role === "parent") && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Profil Parent
              </CardTitle>
              <CardDescription>Votre compte principal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">{familyData.profiles.find((p) => p.role === "parent")?.name || "Parent"}</p>
                  <p className="text-sm text-muted-foreground">
                    XP Permanent: {familyData.profiles.find((p) => p.role === "parent")?.xpPermanent || 0}
                  </p>
                </div>
                <Button
                  onClick={() => handleSwitchProfile(familyData.profiles.find((p) => p.role === "parent")!.id)}
                  variant="outline"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Activer ce profil
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Profils Enfants */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Profils Enfants</h2>
            <Dialog open={isCreatingChild} onOpenChange={setIsCreatingChild}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un enfant
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Créer un profil enfant</DialogTitle>
                  <DialogDescription>
                    Créez un nouveau profil pour un enfant de votre famille
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Nom du profil enfant"
                    value={newChildName}
                    onChange={(e) => setNewChildName(e.target.value)}
                  />
                  <Button
                    onClick={handleAddChild}
                    disabled={addChildMutation.isPending}
                    className="w-full"
                  >
                    {addChildMutation.isPending ? "Création..." : "Créer"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {familyData.profiles && familyData.profiles.filter((p) => p.role === "child").length > 0 ? (
            <div className="grid gap-4">
              {familyData.profiles.filter((p) => p.role === "child").map((profile) => (
                <Card key={profile.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">{profile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          XP Permanent: {profile.xpPermanent}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleSwitchProfile(profile.id)}
                          variant="outline"
                          size="sm"
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Activer
                        </Button>
                        <Button variant="destructive" size="sm" disabled>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">
                  Aucun profil enfant créé. Cliquez sur "Ajouter un enfant" pour en créer un.
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Profil Actif */}
        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle>Profil Actuellement Actif</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-semibold">
              {familyData.profiles.find((p) => p.id === familyData.activeProfileId)?.name || "Aucun profil actif"}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
