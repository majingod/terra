import { Check } from "lucide-react";

type CharData = any;

/**
 * Calcule le nombre total de capacités bonus débloquées par l'héritage
 * Retourne un objet avec le nombre de capacités niveau 1 et niveau 2
 */
export function calcExtraAbilities(heritageAvantages: { id: number; times: number }[], heritageData: any[]): { level1: number; level2: number } {
  let level1 = 0;
  let level2 = 0;

  heritageAvantages.forEach((h) => {
    const ha = heritageData.find((x) => x.id === h.id);
    if (ha) {
      level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
      level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
    }
  });

  return { level1, level2 };
}

/**
 * Récupère les voies bonus (les 2 voies non choisies de la classe)
 */
export function getBonusPathIds(classId: number | null, selectedPathId: number | null, classes: any[]): number[] {
  if (!classId) return [];
  const cls = classes.find((c) => c.id === classId);
  if (!cls || !cls.paths) return [];
  
  const allPathIds = cls.paths.map((p: any) => p.id);
  return allPathIds.filter((id: number) => id !== selectedPathId);
}

/**
 * Valide si une capacité bonus peut être sélectionnée
 * Retourne true si le nombre de sélections n'a pas dépassé la limite
 */
export function canSelectBonusAbility(
  abilityId: number,
  level: 1 | 2,
  selectedBonusAbilities: number[],
  extraAbilities: { level1: number; level2: number },
  bonusAbilities: any[]
): boolean {
  const isSelected = selectedBonusAbilities.includes(abilityId);
  if (isSelected) return true; // Peut toujours décocher

  const limit = level === 1 ? extraAbilities.level1 : extraAbilities.level2;
  const selectedCount = selectedBonusAbilities.filter((id) => {
    const ability = bonusAbilities.find((a) => a.id === id);
    return ability && ability.level === level;
  }).length;

  return selectedCount < limit;
}

/**
 * Bascule la sélection d'une capacité bonus
 */
export function toggleBonusAbility(abilityId: number, selectedBonusAbilities: number[]): number[] {
  if (selectedBonusAbilities.includes(abilityId)) {
    return selectedBonusAbilities.filter((id) => id !== abilityId);
  }
  return [...selectedBonusAbilities, abilityId];
}

/**
 * Compte le nombre de capacités sélectionnées par niveau
 */
export function countSelectedByLevel(
  selectedBonusAbilities: number[],
  level: 1 | 2,
  bonusAbilities: any[]
): number {
  return selectedBonusAbilities.filter((id) => {
    const ability = bonusAbilities.find((a) => a.id === id);
    return ability && ability.level === level;
  }).length;
}

export function getBonusAbilities(bonusPathIds: number[], level: 1 | 2, classes: any[]): any[] {
  const abilities: any[] = [];
  
  bonusPathIds.forEach((pathId) => {
    classes.forEach((cls) => {
      if (cls.paths) {
        const path = cls.paths.find((p: any) => p.id === pathId);
        if (path && path.abilities) {
          const filteredAbilities = path.abilities.filter((a: any) => a.level === level);
          abilities.push(...filteredAbilities);
        }
      }
    });
  });
  
  return abilities;
}

export function calcMaxDons(data: CharData, heritageAvantages: any[]): number {
  let maxDons = 1;

  if (data.esprit >= 3) {
    maxDons += 1;
  }

  const extraDons = data.heritageAvantages.reduce((sum: number, h: any) => {
    const ha = heritageAvantages.find((x) => x.id === h.id);
    return sum + (ha ? (ha.extraDons ?? 0) * h.times : 0);
  }, 0);

  return maxDons + extraDons;
}

/**
 * Étape 9 : Sélection de la voie de classe
 * Affiche les voies disponibles avec leurs capacités par niveau
 */
export function StepVoie({
  data,
  onChange,
  classes,
}: {
  data: CharData;
  onChange: (d: Partial<CharData>) => void;
  classes: any[];
}) {
  const cls = classes.find((c) => c.id === data.classId);
  const paths = cls?.paths ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
          Choisissez une voie
        </h2>
        <p className="text-muted-foreground text-sm">Sélectionnez une des 3 voies disponibles dans votre classe (obligatoire).</p>
      </div>

      {paths.length > 0 ? (
        <div className="space-y-3">
          {paths.map((path: any) => {
            const isSelected = data.classPathId === path.id;
            const abilities = path.abilities ?? [];
            return (
              <button
                key={path.id}
                onClick={() => onChange({ classPathId: path.id })}
                className="w-full p-5 rounded-xl border text-left transition-all"
                style={{
                  background: isSelected ? "oklch(0.65 0.18 45 / 0.1)" : "oklch(0.16 0.02 260)",
                  borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.28 0.03 260)",
                  boxShadow: isSelected ? "0 0 20px oklch(0.65 0.18 45 / 0.15)" : "none",
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3
                      className="font-heading font-semibold text-lg mb-1"
                      style={{ color: "oklch(0.82 0.2 85)" }}
                    >
                      {path.name}
                    </h3>
                    {path.description && (
                      <p className="text-xs text-foreground/65 leading-relaxed">{path.description}</p>
                    )}
                  </div>
                  {isSelected && (
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center ml-3 flex-shrink-0"
                      style={{ background: "oklch(0.65 0.18 45)" }}
                    >
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>

                {abilities.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border/20 space-y-2">
                    <p className="text-xs font-heading font-semibold text-foreground/70">Capacités par niveau</p>
                    {abilities.map((ability: any) => (
                      <div key={ability.id} className="text-xs text-foreground/60 flex items-start gap-2">
                        <span
                          className="font-semibold flex-shrink-0"
                          style={{ color: "oklch(0.65 0.18 45)" }}
                        >
                          Niv {ability.level}:
                        </span>
                        <span>{ability.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="p-4 rounded-lg text-center text-muted-foreground text-sm">
          Aucune voie disponible pour cette classe.
        </div>
      )}
    </div>
  );
}

/**
 * Étape 10 : Sélection des dons et résumé final
 * Affiche les dons disponibles avec le nombre autorisé calculé
 * Affiche un résumé du personnage avec les stats finales
 */
export function StepDonsResume({
  data,
  onChange,
  dons,
  heritageAvantages,
  races,
  classes,
  competences,
  desavantages,
  calcStats,
  onCreatePersonnage,
  isCreating,
}: {
  data: CharData;
  onChange: (d: Partial<CharData>) => void;
  dons: any[];
  heritageAvantages: any[];
  races: any[];
  classes: any[];
  competences: any[];
  desavantages: any[];
  calcStats: (data: CharData, race: any, cls: any, dons: any[], heritage: any[]) => any;
  onCreatePersonnage?: () => Promise<void>;
  isCreating?: boolean;
}) {
  const maxDons = calcMaxDons(data, heritageAvantages);

  const toggleDon = (donId: number): void => {
    const current = data.selectedDons;
    if (current.includes(donId)) {
      onChange({ selectedDons: current.filter((id: number) => id !== donId) });
    } else if (current.length < maxDons) {
      onChange({ selectedDons: [...current, donId] });
    }
  };

  const race = races.find((r) => r.id === data.raceId);
  const cls = classes.find((c) => c.id === data.classId);
  const comp = competences.find((c) => c.id === data.competenceId);
  const { maxPv, maxMana, lutte, sauvegardes } = calcStats(data, race, cls, dons, heritageAvantages);

  const factionColor = data.faction === "Sanctum" ? "oklch(0.55 0.18 240)" : "oklch(0.5 0.22 25)";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
          Dons & Résumé
        </h2>
        <p className="text-muted-foreground text-sm">
          Sélectionnez vos dons ({data.selectedDons.length}/{maxDons}) et vérifiez votre personnage.
        </p>
      </div>

      {/* Dons Selection */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-foreground">Dons disponibles</h3>
          <span
            className="text-xs px-2 py-1 rounded"
            style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}
          >
            {data.selectedDons.length}/{maxDons}
          </span>
        </div>

        {maxDons === 1 && data.esprit < 3 && data.heritageAvantages.length === 0 && (
          <p className="text-xs text-muted-foreground mb-3">
            Vous avez 1 don de base. Augmentez Esprit à 3+ ou achetez des dons dans l'héritage pour en avoir plus.
          </p>
        )}

        <div className="space-y-3">
          {dons.map((don: any) => {
            const isSelected = data.selectedDons.includes(don.id);
            const isDisabled = !isSelected && data.selectedDons.length >= maxDons;
            return (
              <button
                key={don.id}
                onClick={() => toggleDon(don.id)}
                disabled={isDisabled}
                className="w-full p-4 rounded-xl border text-left transition-all disabled:opacity-40"
                style={{
                  background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                  borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4
                      className="font-heading font-semibold text-sm mb-1"
                      style={{ color: "oklch(0.82 0.2 85)" }}
                    >
                      {don.name}
                    </h4>
                    <p className="text-xs text-foreground/65 leading-relaxed">{don.description}</p>
                    <div className="flex gap-1 mt-2">
                      {(don.pvBonus ?? 0) > 0 && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/30 text-green-400">
                          +{don.pvBonus} PV
                        </span>
                      )}
                      {(don.manaBonus ?? 0) > 0 && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/30 text-blue-400">
                          +{don.manaBonus} Mana
                        </span>
                      )}
                      {(don.luteBonus ?? 0) > 0 && (
                        <span
                          className="text-xs px-1.5 py-0.5 rounded"
                          style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}
                        >
                          +{don.luteBonus} Lutte
                        </span>
                      )}
                    </div>
                  </div>
                  <div
                    className="w-5 h-5 rounded border flex items-center justify-center ml-3 flex-shrink-0"
                    style={{
                      background: isSelected ? "oklch(0.65 0.18 45)" : "transparent",
                      borderColor: isSelected ? "oklch(0.65 0.18 45)" : "oklch(0.4 0.03 260)",
                    }}
                  >
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Character Summary */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <h3 className="font-heading font-semibold mb-3 text-foreground">Résumé du personnage</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className="text-xs text-muted-foreground">Nom</span>
            <p className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
              {data.name || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Faction</span>
            <p className="font-heading font-semibold" style={{ color: factionColor }}>
              {data.faction || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Race</span>
            <p className="font-heading font-semibold text-foreground">{race?.name ?? "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Classe</span>
            <p className="font-heading font-semibold text-foreground">{cls?.name ?? "—"}</p>
          </div>
          {race?.name === "Humain" && data.humanBonusType && (
            <div>
              <span className="text-xs text-muted-foreground">Bonus racial</span>
              <p className="font-heading font-semibold text-foreground">
                +1 {data.humanBonusType === 'pv' ? 'PV' : 'PM'}
              </p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {[
            { label: "PV max", value: maxPv, color: "oklch(0.45 0.15 140)" },
            { label: "Mana max", value: maxMana, color: "oklch(0.55 0.18 240)" },
            { label: "Lutte", value: lutte, color: "oklch(0.65 0.18 45)" },
            { label: "Sauvegardes", value: sauvegardes, color: "oklch(0.55 0.22 25)" },
          ].map((stat: any) => (
            <div
              key={stat.label}
              className="p-3 rounded-lg text-center"
              style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}30` }}
            >
              <div className="text-2xl font-heading font-bold" style={{ color: stat.color }}>
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bonus Abilities Section */}
      {(() => {
        const extraAbilities = calcExtraAbilities(data.heritageAvantages, heritageAvantages);
        const bonusPathIds = getBonusPathIds(data.classId, data.classPathId, classes);
        const hasExtraAbilities = extraAbilities.level1 > 0 || extraAbilities.level2 > 0;
        
        if (!hasExtraAbilities || bonusPathIds.length === 0) return null;
        
        const level1Abilities = getBonusAbilities(bonusPathIds, 1, classes);
        const level2Abilities = getBonusAbilities(bonusPathIds, 2, classes);
        
        return (
          <div className="p-5 rounded-xl border border-border/40 bg-card/30">
            <h3 className="font-heading font-semibold mb-3 text-foreground">Capacités bonus débloquées</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Vous pouvez choisir {extraAbilities.level1} capacité(s) de niveau 1 et {extraAbilities.level2} capacité(s) de niveau 2 des autres voies.
            </p>
            
            {extraAbilities.level1 > 0 && level1Abilities.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 1 ({countSelectedByLevel(data.selectedBonusAbilities, 1, level1Abilities)}/{extraAbilities.level1})
                </h4>
                <div className="space-y-2">
                  {level1Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    const canSelect = canSelectBonusAbility(ability.id, 1, data.selectedBonusAbilities, extraAbilities, level1Abilities);
                    return (
                      <label key={ability.id} className="flex items-start gap-3 p-3 rounded-lg bg-background/50 border border-border/20 cursor-pointer hover:bg-background/70 transition-colors"
                        style={{ opacity: canSelect || isSelected ? 1 : 0.5 }}>
                        <input type="checkbox" checked={isSelected} onChange={() => {
                          if (canSelect || isSelected) {
                            data.onChange({ selectedBonusAbilities: toggleBonusAbility(ability.id, data.selectedBonusAbilities) });
                          }
                        }} disabled={!canSelect && !isSelected} className="mt-0.5 w-4 h-4 rounded cursor-pointer" />
                        <div className="flex-1">
                          <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                          <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
            
            {extraAbilities.level2 > 0 && level2Abilities.length > 0 && (
              <div>
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 2 ({countSelectedByLevel(data.selectedBonusAbilities, 2, level2Abilities)}/{extraAbilities.level2})
                </h4>
                <div className="space-y-2">
                  {level2Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    const canSelect = canSelectBonusAbility(ability.id, 2, data.selectedBonusAbilities, extraAbilities, level2Abilities);
                    return (
                      <label key={ability.id} className="flex items-start gap-3 p-3 rounded-lg bg-background/50 border border-border/20 cursor-pointer hover:bg-background/70 transition-colors"
                        style={{ opacity: canSelect || isSelected ? 1 : 0.5 }}>
                        <input type="checkbox" checked={isSelected} onChange={() => {
                          if (canSelect || isSelected) {
                            data.onChange({ selectedBonusAbilities: toggleBonusAbility(ability.id, data.selectedBonusAbilities) });
                          }
                        }} disabled={!canSelect && !isSelected} className="mt-0.5 w-4 h-4 rounded cursor-pointer" />
                        <div className="flex-1">
                          <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                          <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })()}

    </div>
  );
}

/**
 * Étape 10 : Sélection des dons
 * Affiche les dons disponibles avec le nombre autorisé calculé
 */
export function StepDons({
  data,
  onChange,
  dons,
  heritageAvantages,
}: {
  data: CharData;
  onChange: (d: Partial<CharData>) => void;
  dons: any[];
  heritageAvantages: any[];
}) {
  const maxDons = calcMaxDons(data, heritageAvantages);

  const toggleDon = (donId: number): void => {
    const current = data.selectedDons;
    if (current.includes(donId)) {
      onChange({ selectedDons: current.filter((id: number) => id !== donId) });
    } else if (current.length < maxDons) {
      onChange({ selectedDons: [...current, donId] });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
          Dons
        </h2>
        <p className="text-muted-foreground text-sm">
          Sélectionnez vos dons ({data.selectedDons.length}/{maxDons}).
        </p>
      </div>

      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-foreground">Dons disponibles</h3>
          <span
            className="text-xs px-2 py-1 rounded"
            style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}
          >
            {data.selectedDons.length}/{maxDons}
          </span>
        </div>

        {maxDons === 1 && data.esprit < 3 && data.heritageAvantages.length === 0 && (
          <p className="text-xs text-muted-foreground mb-3">
            Vous avez 1 don de base. Augmentez Esprit à 3+ ou achetez des dons dans l'héritage pour en avoir plus.
          </p>
        )}

        <div className="space-y-3">
          {dons.map((don: any) => {
            const isSelected = data.selectedDons.includes(don.id);
            const isDisabled = !isSelected && data.selectedDons.length >= maxDons;
            return (
              <button
                key={don.id}
                onClick={() => toggleDon(don.id)}
                disabled={isDisabled}
                className="w-full p-4 rounded-xl border text-left transition-all disabled:opacity-40"
                style={{
                  background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                  borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4
                      className="font-heading font-semibold text-sm mb-1"
                      style={{ color: "oklch(0.82 0.2 85)" }}
                    >
                      {don.name}
                    </h4>
                    <p className="text-xs text-foreground/65 leading-relaxed">{don.description}</p>
                    <div className="flex gap-1 mt-2">
                      {(don.pvBonus ?? 0) > 0 && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/30 text-green-400">
                          +{don.pvBonus} PV
                        </span>
                      )}
                      {(don.manaBonus ?? 0) > 0 && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/30 text-blue-400">
                          +{don.manaBonus} Mana
                        </span>
                      )}
                      {(don.luteBonus ?? 0) > 0 && (
                        <span
                          className="text-xs px-1.5 py-0.5 rounded"
                          style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}
                        >
                          +{don.luteBonus} Lutte
                        </span>
                      )}
                    </div>
                  </div>
                  <div
                    className="w-5 h-5 rounded border flex items-center justify-center ml-3 flex-shrink-0"
                    style={{
                      background: isSelected ? "oklch(0.65 0.18 45)" : "transparent",
                      borderColor: isSelected ? "oklch(0.65 0.18 45)" : "oklch(0.4 0.03 260)",
                    }}
                  >
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/**
 * Étape 11 : Résumé final
 * Affiche le résumé complet du personnage avec les stats finales
 */
export function StepResume({
  data,
  dons,
  heritageAvantages,
  races,
  classes,
  competences,
  desavantages,
  calcStats,
  onCreatePersonnage,
  isCreating,
}: {
  data: CharData;
  dons: any[];
  heritageAvantages: any[];
  races: any[];
  classes: any[];
  competences: any[];
  desavantages: any[];
  calcStats: (data: CharData, race: any, cls: any, dons: any[], heritage: any[]) => any;
  onCreatePersonnage?: () => Promise<void>;
  isCreating?: boolean;
}) {
  const race = races.find((r) => r.id === data.raceId);
  const cls = classes.find((c) => c.id === data.classId);
  const comp = competences.find((c) => c.id === data.competenceId);
  const { maxPv, maxMana, lutte, sauvegardes } = calcStats(data, race, cls, dons, heritageAvantages);

  const factionColor = data.faction === "Sanctum" ? "oklch(0.55 0.18 240)" : "oklch(0.5 0.22 25)";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
          Résumé du personnage
        </h2>
        <p className="text-muted-foreground text-sm">
          Vérifiez votre personnage avant de le créer.
        </p>
      </div>

      {/* Character Summary */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <h3 className="font-heading font-semibold mb-3 text-foreground">Informations générales</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className="text-xs text-muted-foreground">Nom</span>
            <p className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
              {data.name || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Faction</span>
            <p className="font-heading font-semibold" style={{ color: factionColor }}>
              {data.faction || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Race</span>
            <p className="font-heading font-semibold text-foreground">{race?.name ?? "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Classe</span>
            <p className="font-heading font-semibold text-foreground">{cls?.name ?? "—"}</p>
          </div>
          {race?.name === "Humain" && data.humanBonusType && (
            <div>
              <span className="text-xs text-muted-foreground">Bonus racial</span>
              <p className="font-heading font-semibold text-foreground">
                +1 {data.humanBonusType === 'pv' ? 'PV' : 'PM'}
              </p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {[
            { label: "PV max", value: maxPv, color: "oklch(0.45 0.15 140)" },
            { label: "Mana max", value: maxMana, color: "oklch(0.55 0.18 240)" },
            { label: "Lutte", value: lutte, color: "oklch(0.65 0.18 45)" },
            { label: "Sauvegardes", value: sauvegardes, color: "oklch(0.55 0.22 25)" },
          ].map((stat: any) => (
            <div
              key={stat.label}
              className="p-3 rounded-lg text-center"
              style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}30` }}
            >
              <div className="text-2xl font-heading font-bold" style={{ color: stat.color }}>
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bonus Abilities Section */}
      {(() => {
        const extraAbilities = calcExtraAbilities(data.heritageAvantages, heritageAvantages);
        const bonusPathIds = getBonusPathIds(data.classId, data.classPathId, classes);
        const hasExtraAbilities = extraAbilities.level1 > 0 || extraAbilities.level2 > 0;
        
        if (!hasExtraAbilities || bonusPathIds.length === 0) return null;
        
        const level1Abilities = getBonusAbilities(bonusPathIds, 1, classes);
        const level2Abilities = getBonusAbilities(bonusPathIds, 2, classes);
        
        return (
          <div className="p-5 rounded-xl border border-border/40 bg-card/30">
            <h3 className="font-heading font-semibold mb-3 text-foreground">Capacités bonus sélectionnées</h3>
            <p className="text-xs text-muted-foreground mb-4">
              {data.selectedBonusAbilities.length} capacité(s) bonus sélectionnée(s)
            </p>
            
            {extraAbilities.level1 > 0 && level1Abilities.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 1 ({countSelectedByLevel(data.selectedBonusAbilities, 1, level1Abilities)}/{extraAbilities.level1})
                </h4>
                <div className="space-y-2">
                  {level1Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    return isSelected ? (
                      <div key={ability.id} className="p-3 rounded-lg bg-background/50 border border-border/20">
                        <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                        <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}
            
            {extraAbilities.level2 > 0 && level2Abilities.length > 0 && (
              <div>
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 2 ({countSelectedByLevel(data.selectedBonusAbilities, 2, level2Abilities)}/{extraAbilities.level2})
                </h4>
                <div className="space-y-2">
                  {level2Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    return isSelected ? (
                      <div key={ability.id} className="p-3 rounded-lg bg-background/50 border border-border/20">
                        <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                        <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Create Character Button */}
      {onCreatePersonnage && (
        <div className="mt-8 pt-6 border-t border-border/20">
          <button
            onClick={onCreatePersonnage}
            disabled={isCreating || !data.name || !data.faction || !data.raceId || !data.classId}
            className="w-full py-3 px-4 rounded-xl font-heading font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: isCreating ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.65 0.18 45)",
              color: "oklch(0.12 0.02 260)",
            }}
          >
            {isCreating ? "Création en cours..." : "Créer le personnage"}
          </button>
          <p className="text-xs text-muted-foreground text-center mt-3">
            Votre personnage sera sauvegardé et vous pourrez le modifier ultérieurement.
          </p>
        </div>
      )}
    </div>
  );
}
