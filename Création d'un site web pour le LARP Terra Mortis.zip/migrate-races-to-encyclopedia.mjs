#!/usr/bin/env node

/**
 * Script de migration : Races → Encyclopedia Entries
 * 
 * Ce script migre toutes les races de la table `races` vers `encyclopedia_entries`
 * avec la catégorie "races" et les propriétés structurées en JSON.
 * 
 * Usage: node migrate-races-to-encyclopedia.mjs
 */

import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "terra_mortis",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function migrateRaces() {
  const connection = await pool.getConnection();

  try {
    console.log("🚀 Début de la migration des races vers l'Encyclopédie...\n");

    // Étape 1 : Récupérer toutes les races
    console.log("📖 Récupération des races...");
    const [races] = await connection.query("SELECT * FROM races");
    console.log(`✅ ${races.length} race(s) trouvée(s)\n`);

    // Étape 2 : Migrer chaque race
    let migratedCount = 0;
    for (const race of races) {
      const encyclopediaEntry = {
        nom: race.name,
        categorie: "races",
        description: race.description,
        proprietes: JSON.stringify({
          faction: race.faction,
          bonuses: race.bonuses,
          maluses: race.maluses,
          abilities: race.abilities,
          physicalDescription: race.physicalDescription,
          startingLanguages: race.startingLanguages,
          pvBonus: race.pvBonus,
          manaBonus: race.manaBonus,
          luteBonus: race.luteBonus,
          pvMalus: race.pvMalus,
        }),
        relations: JSON.stringify({}), // Pas de relations pour les races
        factionRequise: race.faction === "Tous" ? null : race.faction,
        conditions: JSON.stringify({}), // Pas de conditions pour les races
        createdBy: 1, // Admin par défaut
        createdAt: race.createdAt,
        updatedBy: 1,
        updatedAt: race.updatedAt,
        deletedAt: null,
      };

      // Insérer dans encyclopedia_entries
      const [result] = await connection.query(
        "INSERT INTO encyclopedia_entries (nom, categorie, description, proprietes, relations, factionRequise, conditions, createdBy, createdAt, updatedBy, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          encyclopediaEntry.nom,
          encyclopediaEntry.categorie,
          encyclopediaEntry.description,
          encyclopediaEntry.proprietes,
          encyclopediaEntry.relations,
          encyclopediaEntry.factionRequise,
          encyclopediaEntry.conditions,
          encyclopediaEntry.createdBy,
          encyclopediaEntry.createdAt,
          encyclopediaEntry.updatedBy,
          encyclopediaEntry.updatedAt,
        ]
      );

      console.log(`✅ Race "${race.name}" migrée (ID: ${result.insertId})`);
      migratedCount++;
    }

    console.log(`\n✨ Migration complétée : ${migratedCount} race(s) migrée(s)`);

    // Étape 3 : Vérification
    const [verifyResult] = await connection.query(
      "SELECT COUNT(*) as count FROM encyclopedia_entries WHERE categorie = 'races'"
    );
    console.log(
      `📊 Vérification : ${verifyResult[0].count} entrée(s) dans encyclopedia_entries avec categorie='races'`
    );

    console.log("\n✅ Migration des races terminée avec succès !");
  } catch (error) {
    console.error("❌ Erreur lors de la migration :", error);
    process.exit(1);
  } finally {
    await connection.release();
    await pool.end();
  }
}

migrateRaces();
