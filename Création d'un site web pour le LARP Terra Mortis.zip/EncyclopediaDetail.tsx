import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { FactionBadge } from "@/components/FactionBadge";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { TerraMortisDivider } from "@/components/TerraMortisDivider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, ChevronLeft, Link2, History } from "lucide-react";
import Breadcrumbs from "@/components/Breadcrumbs";

interface EncyclopediaEntry {
  id: number;
  nom: string;
  categorie: string;
  description: string;
  proprietes: Record<string, any>;
  factionRequise?: string;
  relations?: Record<string, any>;
}

const CATEGORIES = [
  { id: "races", label: "Races", icon: "👑" },
  { id: "classes", label: "Classes", icon: "⚔️" },
  { id: "sous_classes", label: "Sous-classes", icon: "🗡️" },
  { id: "capacites", label: "Capacités", icon: "✨" },
  { id: "dons", label: "Dons", icon: "🔥" },
  { id: "competences", label: "Compétences", icon: "📜" },
  { id: "heritage_avantages", label: "Héritage (Avantages)", icon: "💎" },
  { id: "heritage_desavantages", label: "Héritage (Désavantages)", icon: "💔" },
  { id: "factions", label: "Factions", icon: "🏰" },
  { id: "ressources", label: "Ressources", icon: "⛏️" },
  { id: "materiaux", label: "Matériaux", icon: "🪨" },
  { id: "runes", label: "Runes", icon: "📿" },
  { id: "recettes_alchimie", label: "Recettes d'Alchimie", icon: "🧪" },
  { id: "forge", label: "Forge", icon: "🔨" },
  { id: "objets_magiques", label: "Objets Magiques", icon: "🪄" },
  { id: "regles_combat", label: "Règles de Combat", icon: "⚡" },
  { id: "symboles", label: "Symboles", icon: "🔮" },
];

const FACTIONS = [
  { id: "Sanctum", label: "Le Sanctum" },
  { id: "Légion", label: "La Légion" },
  { id: "Tous", label: "Tous" },
];

export default function EncyclopediaDetail() {
  const [, navigate] = useLocation();
  const [entries, setEntries] = useState<EncyclopediaEntry[]>([]);
  const [filteredEntries, setFilteredEntries] = useState<EncyclopediaEntry[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<EncyclopediaEntry | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("races");
  const [selectedFaction, setSelectedFaction] = useState<string>("Tous");
  const [isLoading, setIsLoading] = useState(true);

  // Charger les données depuis l'API (simulé pour l'instant)
  useEffect(() => {
    const loadEntries = async () => {
      try {
        setIsLoading(true);
        // TODO: Remplacer par l'appel tRPC réel
        // const data = await trpc.encyclopedia.getByCategory.useQuery({ categorie: selectedCategory });
        // Pour l'instant, on utilise des données de test
        const mockData: EncyclopediaEntry[] = [
          {
            id: 1,
            nom: "Humain",
            categorie: "races",
            description: "Les humains sont les créatures les plus adaptables de Terra Mortis.",
            proprietes: {
              pv_bonus: 1,
              mana_bonus: 0,
              faction: "Tous",
            },
            factionRequise: "Tous",
          },
          {
            id: 2,
            nom: "Elfe",
            categorie: "races",
            description: "Les elfes sont gracieux et doués pour la magie.",
            proprietes: {
              pv_bonus: 0,
              mana_bonus: 1,
              faction: "Tous",
            },
            factionRequise: "Tous",
          },
        ];
        setEntries(mockData);
      } catch (error) {
        console.error("Erreur lors du chargement des entrées:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadEntries();
  }, [selectedCategory]);

  // Filtrer les entrées
  useEffect(() => {
    let filtered = entries;

    // Filtre par recherche
    if (searchQuery) {
      filtered = filtered.filter((entry) =>
        entry.nom.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filtre par faction
    if (selectedFaction !== "Tous") {
      filtered = filtered.filter(
        (entry) =>
          entry.factionRequise === "Tous" ||
          entry.factionRequise === selectedFaction
      );
    }

    setFilteredEntries(filtered);
  }, [entries, searchQuery, selectedFaction]);

  const currentCategory = CATEGORIES.find((c) => c.id === selectedCategory);
  const categoryLabel = currentCategory?.label || "Encyclopédie";

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900">
      <Breadcrumbs
        items={[
          { label: "Règles", href: "/regles", active: false },
          { label: categoryLabel, href: "#", active: true },
        ]}
      />

      <div className="container mx-auto px-4 py-8">
        {/* ─── Header ────────────────────────────────────────────────────────── */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/regles")}
              className="hover:bg-slate-800"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <TerraMortisHeading level={1} gradient="gold" className="text-4xl">
              {categoryLabel}
            </TerraMortisHeading>
          </div>
          <p className="text-slate-400">
            Explorez les entrées de {categoryLabel.toLowerCase()} dans l'encyclopédie de Terra Mortis
          </p>
        </div>

        {/* ─── Filtres ────────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {/* Recherche */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Rechercher..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          {/* Filtre Faction */}
          <Select value={selectedFaction} onValueChange={setSelectedFaction}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="Faction" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              {FACTIONS.map((faction) => (
                <SelectItem key={faction.id} value={faction.id}>
                  {faction.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Filtre Catégorie */}
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="Catégorie" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              {CATEGORIES.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  {cat.icon} {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* ─── Contenu Principal ────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* ─── Liste des Entrées ────────────────────────────────────────── */}
          <div className="lg:col-span-1">
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {isLoading ? (
                <div className="text-center text-slate-400 py-8">
                  Chargement...
                </div>
              ) : filteredEntries.length === 0 ? (
                <div className="text-center text-slate-400 py-8">
                  Aucune entrée trouvée
                </div>
              ) : (
                filteredEntries.map((entry) => (
                  <Card
                    key={entry.id}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedEntry?.id === entry.id
                        ? "bg-amber-500/20 border-amber-500 ring-1 ring-amber-500"
                        : "bg-slate-800 border-slate-700 hover:border-amber-500/50"
                    }`}
                    onClick={() => setSelectedEntry(entry)}
                  >
                    <h3 className="font-semibold text-white">{entry.nom}</h3>
                    {entry.factionRequise && entry.factionRequise !== "Tous" && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        {entry.factionRequise}
                      </Badge>
                    )}
                  </Card>
                ))
              )}
            </div>
          </div>

          {/* ─── Détail de l'Entrée ────────────────────────────────────────── */}
          <div className="lg:col-span-2">
            {selectedEntry ? (
              <Card className="bg-slate-800 border-slate-700 p-8">
                {/* Header */}
                <div className="mb-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <TerraMortisHeading level={2} gradient="gold" className="text-3xl mb-2">
                        {selectedEntry.nom}
                      </TerraMortisHeading>
                      <div className="flex gap-2 flex-wrap">
                        <Badge variant="secondary">
                          {selectedEntry.categorie}
                        </Badge>
                        {selectedEntry.factionRequise && selectedEntry.factionRequise !== "Tous" && (
                          <FactionBadge faction={selectedEntry.factionRequise as "Sanctum" | "Légion"} size="sm" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <TerraMortisHeading level={3} className="text-lg mb-3">
                    Description
                  </TerraMortisHeading>
                  <p className="text-slate-300 leading-relaxed">
                    {selectedEntry.description}
                  </p>
                </div>

                {/* Propriétés */}
                {Object.keys(selectedEntry.proprietes || {}).length > 0 && (
                  <div className="mb-6">
                    <TerraMortisHeading level={3} className="text-lg mb-3">
                      Caractéristiques
                    </TerraMortisHeading>
                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(selectedEntry.proprietes).map(
                        ([key, value]) => (
                          <div
                            key={key}
                            className="bg-slate-700/50 p-3 rounded border border-slate-600"
                          >
                            <p className="text-sm text-slate-400 capitalize">
                              {key.replace(/_/g, " ")}
                            </p>
                            <p className="text-white font-semibold">
                              {typeof value === "object"
                                ? JSON.stringify(value)
                                : String(value)}
                            </p>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                )}

                {/* Relations */}
                {selectedEntry.relations &&
                  Object.keys(selectedEntry.relations).length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                        <Link2 className="w-5 h-5" />
                        Entrées Liées
                      </h3>
                      <div className="space-y-2">
                        {Object.entries(selectedEntry.relations).map(
                          ([type, ids]: [string, any]) => (
                            <div key={type}>
                              <p className="text-sm text-slate-400 capitalize mb-2">
                                {type}
                              </p>
                              <div className="flex flex-wrap gap-2">
                                {Array.isArray(ids) &&
                                  ids.map((id: number) => (
                                    <Badge
                                      key={id}
                                      variant="outline"
                                      className="cursor-pointer hover:bg-amber-500/20"
                                    >
                                      ID: {id}
                                    </Badge>
                                  ))}
                              </div>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  )}

                {/* Actions */}
                <div className="flex gap-3 pt-6 border-t border-slate-700">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => navigate(`/regles/${selectedEntry.categorie}`)}
                  >
                    Voir la catégorie
                  </Button>
                  <Button
                    variant="default"
                    className="flex-1 bg-amber-600 hover:bg-amber-700"
                  >
                    Utiliser dans un personnage
                  </Button>
                </div>
              </Card>
            ) : (
              <Card className="bg-slate-800 border-slate-700 p-8 text-center">
                <History className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">
                  Sélectionnez une entrée pour voir les détails
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
