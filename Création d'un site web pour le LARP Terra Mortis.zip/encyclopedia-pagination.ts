import { getDb } from "./db";
import { encyclopediaEntries } from "../drizzle/schema";
import { eq, like, desc, sql } from "drizzle-orm";

/**
 * Procédures pour la pagination et l'optimisation des requêtes d'Encyclopédie
 */

export interface PaginationParams {
  limit: number;
  offset: number;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  hasMore: boolean;
  limit: number;
  offset: number;
}

export async function getPaginatedEntries(
  params: PaginationParams
): Promise<PaginatedResult<typeof encyclopediaEntries.$inferSelect>> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer le nombre total d'entrées
  const countResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(encyclopediaEntries);
  const total = countResult[0]?.count || 0;

  // Récupérer les entrées paginées
  const items = await db
    .select()
    .from(encyclopediaEntries)
    .orderBy(desc(encyclopediaEntries.createdAt))
    .limit(params.limit)
    .offset(params.offset);

  return {
    items,
    total,
    hasMore: params.offset + params.limit < total,
    limit: params.limit,
    offset: params.offset,
  };
}

export async function getPaginatedByCategory(
  category: string,
  params: PaginationParams
): Promise<PaginatedResult<typeof encyclopediaEntries.$inferSelect>> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer le nombre total d'entrées dans la catégorie
  const countResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(encyclopediaEntries)
    .where(eq(encyclopediaEntries.categorie, category));
  const total = countResult[0]?.count || 0;

  // Récupérer les entrées paginées
  const items = await db
    .select()
    .from(encyclopediaEntries)
    .where(eq(encyclopediaEntries.categorie, category))
    .orderBy(desc(encyclopediaEntries.createdAt))
    .limit(params.limit)
    .offset(params.offset);

  return {
    items,
    total,
    hasMore: params.offset + params.limit < total,
    limit: params.limit,
    offset: params.offset,
  };
}

export async function searchPaginated(
  query: string,
  params: PaginationParams
): Promise<PaginatedResult<typeof encyclopediaEntries.$inferSelect>> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const searchPattern = `%${query}%`;

  // Récupérer le nombre total de résultats
  const countResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(encyclopediaEntries)
    .where(like(encyclopediaEntries.nom, searchPattern));
  const total = countResult[0]?.count || 0;

  // Récupérer les résultats paginés
  const items = await db
    .select()
    .from(encyclopediaEntries)
    .where(like(encyclopediaEntries.nom, searchPattern))
    .orderBy(desc(encyclopediaEntries.createdAt))
    .limit(params.limit)
    .offset(params.offset);

  return {
    items,
    total,
    hasMore: params.offset + params.limit < total,
    limit: params.limit,
    offset: params.offset,
  };
}

export async function getCategoryCounts(): Promise<Record<string, number>> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const results = await db
    .select({
      categorie: encyclopediaEntries.categorie,
      count: sql<number>`COUNT(*)`,
    })
    .from(encyclopediaEntries)
    .groupBy(encyclopediaEntries.categorie);

  const counts: Record<string, number> = {};
  results.forEach((result) => {
    counts[result.categorie] = result.count;
  });

  return counts;
}

export async function getRecentEntries(
  limit: number = 10
): Promise<typeof encyclopediaEntries.$inferSelect[]> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaEntries)
    .orderBy(desc(encyclopediaEntries.createdAt))
    .limit(limit);
}

export async function getMostViewedEntries(
  limit: number = 10
): Promise<typeof encyclopediaEntries.$inferSelect[]> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaEntries)
    .orderBy(desc(encyclopediaEntries.updatedAt))
    .limit(limit);
}
