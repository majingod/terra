import { getDb } from "./db";
import { encyclopediaEntries, races, classes, classPaths, classAbilities, dons, competences, heritageAvantages, desavantages } from "../drizzle/schema";

/**
 * Script de migration des données existantes vers la table encyclopediaEntries
 * À exécuter une seule fois après la création de la table encyclopediaEntries
 */

export async function migrateRaces() {
  console.log("🔄 Migration des races...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allRaces = await db.select().from(races);

    for (const race of allRaces) {
      const proprietes = {
        faction: race.faction,
        description: race.description,
        bonuses: race.bonuses,
        maluses: race.maluses,
        abilities: race.abilities,
        physicalDescription: race.physicalDescription,
        startingLanguages: race.startingLanguages,
        pvBonus: race.pvBonus,
        manaBonus: race.manaBonus,
        luteBonus: race.luteBonus,
        pvMalus: race.pvMalus,
      };

      await db.insert(encyclopediaEntries).values({
        nom: race.name,
        categorie: "races",
        description: race.description,
        proprietes: proprietes as any,
        factionRequise: race.faction,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allRaces.length} races migrées`);
    return allRaces.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des races :", error);
    throw error;
  }
}

export async function migrateClasses() {
  console.log("🔄 Migration des classes...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allClasses = await db.select().from(classes);

    for (const cls of allClasses) {
      const proprietes = {
        faction: cls.faction,
        description: cls.description,
        basePv: cls.basePv,
        baseMana: cls.baseMana,
        baseAbilities: cls.baseAbilities,
        specialRules: cls.specialRules,
        requiresWeapon: cls.requiresWeapon,
        code: cls.code,
      };

      await db.insert(encyclopediaEntries).values({
        nom: cls.name,
        categorie: "classes",
        description: cls.description,
        proprietes: proprietes as any,
        factionRequise: cls.faction,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allClasses.length} classes migrées`);
    return allClasses.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des classes :", error);
    throw error;
  }
}

export async function migrateClassPaths() {
  console.log("🔄 Migration des voies de classe...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allPaths = await db.select().from(classPaths);

    for (const path of allPaths) {
      const proprietes = {
        classId: path.classId,
        description: path.description,
      };

      await db.insert(encyclopediaEntries).values({
        nom: path.name,
        categorie: "sous_classes",
        description: path.description,
        proprietes: proprietes as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allPaths.length} voies de classe migrées`);
    return allPaths.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des voies de classe :", error);
    throw error;
  }
}

export async function migrateClassAbilities() {
  console.log("🔄 Migration des capacités de classe...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allAbilities = await db.select().from(classAbilities);

    for (const ability of allAbilities) {
      const proprietes = {
        classId: ability.classId,
        pathId: ability.pathId,
        level: ability.level,
        manaCost: ability.manaCost,
        pvCost: ability.pvCost,
        usesPerCombat: ability.usesPerCombat,
        usesPerHour: ability.usesPerHour,
        usesPerDay: ability.usesPerDay,
        isBuff: ability.isBuff,
        isSign: ability.isSign,
        isIncantation: ability.isIncantation,
        abilityType: ability.abilityType,
      };

      const conditions = {
        level: ability.level,
      };

      await db.insert(encyclopediaEntries).values({
        nom: ability.name,
        categorie: "capacites",
        description: ability.description,
        proprietes: proprietes as any,
        conditions: conditions as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allAbilities.length} capacités de classe migrées`);
    return allAbilities.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des capacités de classe :", error);
    throw error;
  }
}

export async function migrateDons() {
  console.log("🔄 Migration des dons...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allDons = await db.select().from(dons);

    for (const don of allDons) {
      const proprietes = {
        canStack: don.canStack,
        maxStacks: don.maxStacks,
        pvBonus: don.pvBonus,
        manaBonus: don.manaBonus,
        luteBonus: don.luteBonus,
      };

      await db.insert(encyclopediaEntries).values({
        nom: don.name,
        categorie: "dons",
        description: don.description,
        proprietes: proprietes as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allDons.length} dons migrés`);
    return allDons.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des dons :", error);
    throw error;
  }
}

export async function migrateCompetences() {
  console.log("🔄 Migration des compétences...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allCompetences = await db.select().from(competences);

    for (const comp of allCompetences) {
      const proprietes = {
        category: comp.category,
        baseAdvantage: comp.baseAdvantage,
        advancedAdvantage: comp.advancedAdvantage,
        requiredMaterial: comp.requiredMaterial,
        isAdultOnly: comp.isAdultOnly,
      };

      const conditions = {
        isAdultOnly: comp.isAdultOnly,
      };

      await db.insert(encyclopediaEntries).values({
        nom: comp.name,
        categorie: "competences",
        description: comp.description,
        proprietes: proprietes as any,
        conditions: conditions as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allCompetences.length} compétences migrées`);
    return allCompetences.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des compétences :", error);
    throw error;
  }
}

export async function migrateHeritageAvantages() {
  console.log("🔄 Migration des héritages (avantages...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allHeritages = await db.select().from(heritageAvantages);

    for (const heritage of allHeritages) {
      const proprietes = {
        xpCost: heritage.xpCost,
        maxTimes: heritage.maxTimes,
        pvBonus: heritage.pvBonus,
        manaBonus: heritage.manaBonus,
        luteBonus: heritage.luteBonus,
        paBonus: heritage.paBonus,
        poBonus: heritage.poBonus,
        moneyBonus: heritage.moneyBonus,
        extraAbilitiesLevel1: heritage.extraAbilitiesLevel1,
        extraAbilitiesLevel2: heritage.extraAbilitiesLevel2,
        extraCompetences: heritage.extraCompetences,
        extraCharacteristicPoints: heritage.extraCharacteristicPoints,
        extraDons: heritage.extraDons,
      };

      await db.insert(encyclopediaEntries).values({
        nom: heritage.name,
        categorie: "heritage_avantages",
        description: heritage.description,
        proprietes: proprietes as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allHeritages.length} héritages (avantages) migrés`);
    return allHeritages.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des héritages (avantages) :", error);
    throw error;
  }
}

export async function migrateDesavantages() {
  console.log("🔄 Migration des désavantages...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const allDesavantages = await db.select().from(desavantages);

    for (const desav of allDesavantages) {
      const proprietes = {
        xpGain: desav.xpGain,
        xpType: desav.xpType,
        forbiddenClasses: desav.forbiddenClasses,
      };

      const conditions = {
        forbiddenClasses: desav.forbiddenClasses,
      };

      await db.insert(encyclopediaEntries).values({
        nom: desav.name,
        categorie: "heritage_desavantages",
        description: desav.description,
        proprietes: proprietes as any,
        conditions: conditions as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${allDesavantages.length} désavantages migrés`);
    return allDesavantages.length;
  } catch (error) {
    console.error("❌ Erreur lors de la migration des désavantages :", error);
    throw error;
  }
}

export async function addNewCategories() {
  console.log("🔄 Ajout des nouvelles catégories...");
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");
    const newCategories = [
      {
        nom: "Ressources",
        categorie: "ressources",
        description: "Ressources naturelles et matériaux bruts",
        proprietes: { type: "ressource", rareté: "commune" },
      },
      {
        nom: "Matériaux",
        categorie: "materiaux",
        description: "Matériaux de craft et de forge",
        proprietes: { type: "matériau", utilisations: [] },
      },
      {
        nom: "Runes",
        categorie: "runes",
        description: "Runes magiques et enchantements",
        proprietes: { type: "rune", pouvoir: "" },
      },
      {
        nom: "Recettes d'Alchimie",
        categorie: "recettes_alchimie",
        description: "Recettes pour la création de potions et élixirs",
        proprietes: { type: "recette", ingredients: [], resultat: "" },
      },
      {
        nom: "Forge",
        categorie: "forge",
        description: "Techniques et recettes de forge",
        proprietes: { type: "forge", niveau: 1 },
      },
      {
        nom: "Objets Magiques",
        categorie: "objets_magiques",
        description: "Objets enchantés et artefacts",
        proprietes: { type: "objet_magique", rareté: "commune", pouvoir: "" },
      },
      {
        nom: "Règles de Combat",
        categorie: "regles_combat",
        description: "Règles spéciales et mécaniques de combat",
        proprietes: { type: "règle", domaine: "combat" },
      },
      {
        nom: "Symboles",
        categorie: "symboles",
        description: "Symboles et signes mystiques",
        proprietes: { type: "symbole", signification: "" },
      },
      {
        nom: "Langues",
        categorie: "langues",
        description: "Langues parlées dans le monde",
        proprietes: { type: "langue", locuteurs: [] },
      },
      {
        nom: "Armures",
        categorie: "armures",
        description: "Types d'armures et équipements de protection",
        proprietes: { type: "armure", niveau_protection: 0 },
      },
      {
        nom: "Caractéristiques",
        categorie: "caracteristiques",
        description: "Caractéristiques principales des personnages",
        proprietes: { type: "caracteristique", valeur_base: 0 },
      },
      {
        nom: "Factions",
        categorie: "factions",
        description: "Factions principales du monde",
        proprietes: { type: "faction", alignement: "" },
      },
    ];

    for (const category of newCategories) {
      await db.insert(encyclopediaEntries).values({
        nom: category.nom,
        categorie: category.categorie,
        description: category.description,
        proprietes: category.proprietes as any,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`✅ ${newCategories.length} nouvelles catégories ajoutées`);
    return newCategories.length;
  } catch (error) {
    console.error("❌ Erreur lors de l'ajout des nouvelles catégories :", error);
    throw error;
  }
}

export async function runMigration() {
  try {
    console.log("🚀 Début de la migration des données...\n");

    let totalMigrated = 0;
    totalMigrated += await migrateRaces();
    totalMigrated += await migrateClasses();
    totalMigrated += await migrateClassPaths();
    totalMigrated += await migrateClassAbilities();
    totalMigrated += await migrateDons();
    totalMigrated += await migrateCompetences();
    totalMigrated += await migrateHeritageAvantages();
    totalMigrated += await migrateDesavantages();
    totalMigrated += await addNewCategories();

    console.log(`\n✅ Migration complétée ! ${totalMigrated} entrées créées au total`);
    return totalMigrated;
  } catch (error) {
    console.error("❌ Erreur lors de la migration :", error);
    throw error;
  }
}
