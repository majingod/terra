import { Button } from "@/components/ui/button";
import { Plus, Minus } from "lucide-react";

interface StepStatsProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepStats({ charData, onCharDataChange, heritageBonus }: StepStatsProps) {
  // Points de base + bonus d'Héritage
  const totalPoints = 6 + (heritageBonus?.extraStatsPoints || 0);
  const usedPoints = charData.puissance + charData.resistance + charData.esprit;
  const remainingPoints = totalPoints - usedPoints;

  const stats = [
    { key: "puissance", label: "Puissance", color: "oklch(0.5 0.22 25)" },
    { key: "resistance", label: "Résistance", color: "oklch(0.55 0.18 240)" },
    { key: "esprit", label: "Esprit", color: "oklch(0.45 0.15 140)" },
  ];

  const addStat = (stat: string) => {
    if (remainingPoints > 0) {
      onCharDataChange({
        ...charData,
        [stat]: charData[stat] + 1,
      });
    }
  };

  const removeStat = (stat: string) => {
    if (charData[stat] > 0) {
      onCharDataChange({
        ...charData,
        [stat]: charData[stat] - 1,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Affichage des points disponibles */}
      <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
        <div className="flex justify-between items-center">
          <span className="font-semibold text-blue-900">Points disponibles</span>
          <span className="text-2xl font-bold text-blue-600">
            {remainingPoints} / {totalPoints}
          </span>
        </div>
        {heritageBonus?.extraStatsPoints > 0 && (
          <p className="text-xs text-blue-700 mt-2">
            ✨ +{heritageBonus.extraStatsPoints} points bonus d'Héritage
          </p>
        )}
      </div>

      {/* Distribution des stats */}
      <div className="space-y-4">
        {stats.map((stat) => (
          <div
            key={stat.key}
            className="p-4 rounded-lg border border-border flex items-center justify-between"
          >
            <div className="flex-1">
              <h4 className="font-semibold">{stat.label}</h4>
              <p className="text-xs text-muted-foreground">
                {charData[stat.key]} / {totalPoints}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => removeStat(stat.key)}
                disabled={charData[stat.key] === 0}
              >
                <Minus className="w-4 h-4" />
              </Button>

              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center font-bold text-white"
                style={{ background: stat.color }}
              >
                {charData[stat.key]}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => addStat(stat.key)}
                disabled={remainingPoints === 0}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Règle de distribution */}
      <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
        <h4 className="font-semibold text-amber-900 mb-2">Règle de distribution :</h4>
        <p className="text-sm text-amber-800">
          Distribuez {totalPoints} points entre Puissance, Résistance et Esprit.
          La règle 3-2-1 est recommandée (3 points dans une stat, 2 dans une autre, 1 dans la dernière).
        </p>
      </div>
    </div>
  );
}
