import { getDb } from "./db";
import {
  races,
  classes,
  classPaths,
  classAbilities,
  dons,
  competences,
  heritageAvantages,
  desavantages,
  encyclopediaEntries,
} from "../drizzle/schema";
import { eq, isNull } from "drizzle-orm";

/**
 * Obtenir le statut de la migration
 * Retourne le nombre d'entrées dans chaque table
 */
export async function getMigrationStatus() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const raceCount = await db.select().from(races);
  const classCount = await db.select().from(classes);
  const classPathCount = await db.select().from(classPaths);
  const classAbilityCount = await db.select().from(classAbilities);
  const donCount = await db.select().from(dons);
  const competenceCount = await db.select().from(competences);
  const heritageCount = await db.select().from(heritageAvantages);
  const desavantageCount = await db.select().from(desavantages);
  const encyclopediaCount = await db
    .select()
    .from(encyclopediaEntries)
    .where(isNull(encyclopediaEntries.deletedAt));

  return {
    races: raceCount.length,
    classes: classCount.length,
    classPaths: classPathCount.length,
    classAbilities: classAbilityCount.length,
    dons: donCount.length,
    competences: competenceCount.length,
    heritages: heritageCount.length,
    desavantages: desavantageCount.length,
    encyclopediaTotal: encyclopediaCount.length,
    categories: {
      races: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) => e.categorie === "races"
      ).length,
      classes: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) => e.categorie === "classes"
      ).length,
      sous_classes: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) =>
          e.categorie === "sous_classes"
      ).length,
      capacites: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) => e.categorie === "capacites"
      ).length,
      dons: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) => e.categorie === "dons"
      ).length,
      competences: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) =>
          e.categorie === "competences"
      ).length,
      heritage_avantages: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) =>
          e.categorie === "heritage_avantages"
      ).length,
      heritage_desavantages: encyclopediaCount.filter(
        (e: typeof encyclopediaEntries.$inferSelect) =>
          e.categorie === "heritage_desavantages"
      ).length,
    },
  };
}

/**
 * Migrer les races vers encyclopediaEntries
 */
export async function migrateRaces() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allRaces = await db.select().from(races);
  let migratedCount = 0;

  for (const race of allRaces) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, race.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: race.name,
        categorie: "races",
        description: race.description,
        proprietes: {
          faction: race.faction,
          bonuses: race.bonuses,
          maluses: race.maluses,
          abilities: race.abilities,
          physicalDescription: race.physicalDescription,
          startingLanguages: race.startingLanguages,
          pvBonus: race.pvBonus,
          manaBonus: race.manaBonus,
          luteBonus: race.luteBonus,
          pvMalus: race.pvMalus,
        },
        factionRequise: race.faction === "Tous" ? null : race.faction,
        createdAt: race.createdAt,
        updatedAt: race.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allRaces.length };
}

/**
 * Migrer les classes vers encyclopediaEntries
 */
export async function migrateClasses() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allClasses = await db.select().from(classes);
  let migratedCount = 0;

  for (const cls of allClasses) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, cls.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: cls.name,
        categorie: "classes",
        description: cls.description,
        proprietes: {
          faction: cls.faction,
          basePv: cls.basePv,
          baseMana: cls.baseMana,
          baseAbilities: cls.baseAbilities,
          specialRules: cls.specialRules,
          requiresWeapon: cls.requiresWeapon,
          code: cls.code,
        },
        factionRequise: cls.faction === "Tous" ? null : cls.faction,
        createdAt: cls.createdAt,
        updatedAt: cls.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allClasses.length };
}

/**
 * Migrer les dons vers encyclopediaEntries
 */
export async function migrateDons() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allDons = await db.select().from(dons);
  let migratedCount = 0;

  for (const don of allDons) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, don.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: don.name,
        categorie: "dons",
        description: don.description,
        proprietes: {
          canStack: don.canStack,
          maxStacks: don.maxStacks,
          pvBonus: don.pvBonus,
          manaBonus: don.manaBonus,
          luteBonus: don.luteBonus,
        },
        createdAt: don.createdAt,
        updatedAt: don.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allDons.length };
}

/**
 * Migrer les compétences vers encyclopediaEntries
 */
export async function migrateCompetences() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allCompetences = await db.select().from(competences);
  let migratedCount = 0;

  for (const comp of allCompetences) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, comp.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: comp.name,
        categorie: "competences",
        description: comp.description,
        proprietes: {
          category: comp.category,
          baseAdvantage: comp.baseAdvantage,
          advancedAdvantage: comp.advancedAdvantage,
          requiredMaterial: comp.requiredMaterial,
          isAdultOnly: comp.isAdultOnly,
        },
        createdAt: comp.createdAt,
        updatedAt: comp.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allCompetences.length };
}

/**
 * Migrer les héritages vers encyclopediaEntries
 */
export async function migrateHeritages() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allHeritages = await db.select().from(heritageAvantages);
  let migratedCount = 0;

  for (const heritage of allHeritages) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, heritage.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: heritage.name,
        categorie: "heritage_avantages",
        description: heritage.description,
        proprietes: {
          xpCost: heritage.xpCost,
          maxTimes: heritage.maxTimes,
          pvBonus: heritage.pvBonus,
          manaBonus: heritage.manaBonus,
          luteBonus: heritage.luteBonus,
          paBonus: heritage.paBonus,
          poBonus: heritage.poBonus,
          moneyBonus: heritage.moneyBonus,
          extraAbilitiesLevel1: heritage.extraAbilitiesLevel1,
          extraAbilitiesLevel2: heritage.extraAbilitiesLevel2,
          extraCompetences: heritage.extraCompetences,
          extraCharacteristicPoints: heritage.extraCharacteristicPoints,
          extraDons: heritage.extraDons,
        },
        createdAt: heritage.createdAt,
        updatedAt: heritage.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allHeritages.length };
}

/**
 * Migrer les désavantages vers encyclopediaEntries
 */
export async function migrateDesavantages() {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const allDesavantages = await db.select().from(desavantages);
  let migratedCount = 0;

  for (const desav of allDesavantages) {
    const existing = await db
      .select()
      .from(encyclopediaEntries)
      .where(eq(encyclopediaEntries.nom, desav.name));

    if (existing.length === 0) {
      await db!.insert(encyclopediaEntries).values({
        nom: desav.name,
        categorie: "heritage_desavantages",
        description: desav.description,
        proprietes: {
          xpGain: desav.xpGain,
          xpType: desav.xpType,
          forbiddenClasses: desav.forbiddenClasses,
        },
        createdAt: desav.createdAt,
        updatedAt: desav.updatedAt,
      });
      migratedCount++;
    }
  }

  return { migratedCount, totalCount: allDesavantages.length };
}
