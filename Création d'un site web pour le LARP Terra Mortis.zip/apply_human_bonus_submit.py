#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Trouver handleSubmit et ajouter humanBonusType
old_submit = '''      selectedBonusAbilities: charData.selectedBonusAbilities,
      xpTemporaire: xpTempo,
      xpPermanent: xpPerma,
    });'''

new_submit = '''      selectedBonusAbilities: charData.selectedBonusAbilities,
      humanBonusType: charData.humanBonusType,
      xpTemporaire: xpTempo,
      xpPermanent: xpPerma,
    });'''

content = content.replace(old_submit, new_submit)
print("✓ humanBonusType ajouté à handleSubmit")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
