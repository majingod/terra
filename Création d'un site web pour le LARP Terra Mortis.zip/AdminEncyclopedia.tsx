import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { TerraMortisCard } from "@/components/TerraMortisCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  BookOpen,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  History,
  Check,
  X,
  Loader2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type Category =
  | "races"
  | "classes"
  | "competences"
  | "dons"
  | "heritage"
  | "desavantages"
  | "magie"
  | "combat"
  | "ressources"
  | "materiaux"
  | "runes"
  | "recettes"
  | "regles";

const CATEGORIES: { value: Category; label: string; icon: string }[] = [
  { value: "races", label: "Races", icon: "👥" },
  { value: "classes", label: "Classes", icon: "⚔️" },
  { value: "competences", label: "Compétences", icon: "📚" },
  { value: "dons", label: "Dons", icon: "✨" },
  { value: "heritage", label: "Héritage", icon: "👑" },
  { value: "desavantages", label: "Désavantages", icon: "💀" },
  { value: "magie", label: "Magie", icon: "🔮" },
  { value: "combat", label: "Combat", icon: "⚡" },
  { value: "ressources", label: "Ressources", icon: "💎" },
  { value: "materiaux", label: "Matériaux", icon: "🔨" },
  { value: "runes", label: "Runes", icon: "📜" },
  { value: "recettes", label: "Recettes", icon: "🍲" },
  { value: "regles", label: "Règles", icon: "📖" },
];

interface EncyclopediaEntry {
  id: number;
  name: string;
  category: Category;
  faction: string;
  description: string;
  properties: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

interface EditForm {
  id?: number;
  name: string;
  category: Category;
  faction: string;
  description: string;
  properties: string;
}

export function AdminEncyclopedia() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<Category>("races");
  const [searchQuery, setSearchQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [form, setForm] = useState<EditForm>({
    name: "",
    category: "races",
    faction: "Tous",
    description: "",
    properties: "{}",
  });

  // Récupérer les entrées via tRPC selon la catégorie sélectionnée
  const { data: racesData } = trpc.rules.races.useQuery(undefined, { enabled: selectedCategory === "races" });
  const { data: classesData } = trpc.rules.classes.useQuery(undefined, { enabled: selectedCategory === "classes" });
  const { data: donsData } = trpc.rules.dons.useQuery(undefined, { enabled: selectedCategory === "dons" });
  const { data: competencesData } = trpc.rules.competences.useQuery(undefined, { enabled: selectedCategory === "competences" });
  const { data: heritageData } = trpc.rules.heritageAvantages.useQuery(undefined, { enabled: selectedCategory === "heritage" });
  const { data: desavantagesData } = trpc.rules.desavantages.useQuery(undefined, { enabled: selectedCategory === "desavantages" });

  // Mapper les données selon la catégorie
  const getEntriesForCategory = (): EncyclopediaEntry[] => {
    switch (selectedCategory) {
      case "races":
        return (racesData || []).map((r: any) => ({
          id: r.id,
          name: r.name,
          category: "races",
          faction: r.faction,
          description: r.description,
          properties: { pvBonus: r.pvBonus, manaBonus: r.manaBonus },
          createdAt: r.createdAt,
          updatedAt: r.updatedAt,
        }));
      case "classes":
        return (classesData || []).map((c: any) => ({
          id: c.id,
          name: c.name,
          category: "classes",
          faction: c.faction,
          description: c.description,
          properties: { maxPv: c.maxPv, maxMana: c.maxMana },
          createdAt: c.createdAt,
          updatedAt: c.updatedAt,
        }));
      case "dons":
        return (donsData || []).map((d: any) => ({
          id: d.id,
          name: d.name,
          category: "dons",
          faction: d.faction,
          description: d.description,
          properties: { level: d.level },
          createdAt: d.createdAt,
          updatedAt: d.updatedAt,
        }));
      case "competences":
        return (competencesData || []).map((c: any) => ({
          id: c.id,
          name: c.name,
          category: "competences",
          faction: c.faction,
          description: c.description,
          properties: { type: c.type },
          createdAt: c.createdAt,
          updatedAt: c.updatedAt,
        }));
      case "heritage":
        return (heritageData || []).map((h: any) => ({
          id: h.id,
          name: h.name,
          category: "heritage",
          faction: h.faction,
          description: h.description,
          properties: { cost: h.cost },
          createdAt: h.createdAt,
          updatedAt: h.updatedAt,
        }));
      case "desavantages":
        return (desavantagesData || []).map((d: any) => ({
          id: d.id,
          name: d.name,
          category: "desavantages",
          faction: d.faction,
          description: d.description,
          properties: { malus: d.malus },
          createdAt: d.createdAt,
          updatedAt: d.updatedAt,
        }));
      default:
        return [];
    }
  };

  const entries = getEntriesForCategory();

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <TerraMortisHeading level={1} gradient="gold" className="text-3xl mb-4">
            Accès refusé
          </TerraMortisHeading>
          <p className="text-muted-foreground">
            Vous n'avez pas les permissions pour accéder à cette page.
          </p>
        </div>
      </div>
    );
  }

  const filteredEntries = entries.filter(
    (entry) =>
      entry.category === selectedCategory &&
      entry.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Mutations tRPC
  const createRaceMutation = trpc.admin.createRace.useMutation();
  const updateRaceMutation = trpc.admin.updateRace.useMutation();
  const deleteRaceMutation = trpc.admin.deleteRace.useMutation();
  const createClassMutation = trpc.admin.createClass.useMutation();
  const updateClassMutation = trpc.admin.updateClass.useMutation();
  const deleteClassMutation = trpc.admin.deleteClass.useMutation();
  const createDonMutation = trpc.admin.createDon.useMutation();
  const updateDonMutation = trpc.admin.updateDon.useMutation();
  const deleteDonMutation = trpc.admin.deleteDon.useMutation();
  const createCompetenceMutation = trpc.admin.createCompetence.useMutation();
  const updateCompetenceMutation = trpc.admin.updateCompetence.useMutation();
  const deleteCompetenceMutation = trpc.admin.deleteCompetence.useMutation();
  // Note: Les mutations pour créer/modifier/supprimer les entrées d'Encyclopédie
  // seront implémentées dans les prochaines phases
  // Pour l'instant, on utilise les procédures existantes

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast.error("Le nom est obligatoire.");
      return;
    }

    try {
      JSON.parse(form.properties);
      // Les mutations seront appelées ici une fois implémentées
    } catch {
      toast.error("Les propriétés doivent être du JSON valide.");
      return;
    }

    try {
      const properties = JSON.parse(form.properties);

      switch (selectedCategory) {
        case "races":
          if (editingId) {
            await updateRaceMutation.mutateAsync({
              id: editingId,
              data: {
                name: form.name,
                faction: form.faction as "Sanctum" | "Légion" | "Tous",
                description: form.description,
                ...properties,
              },
            });
            toast.success("Race mise à jour !");
          } else {
            await createRaceMutation.mutateAsync({
              name: form.name,
              faction: form.faction as "Sanctum" | "Légion" | "Tous",
              description: form.description,
              bonuses: properties.bonuses || [],
              maluses: properties.maluses || [],
              abilities: properties.abilities || [],
              physicalDescription: properties.physicalDescription || "",
              startingLanguages: properties.startingLanguages || [],
              pvBonus: properties.pvBonus || 0,
              manaBonus: properties.manaBonus || 0,
              luteBonus: properties.luteBonus || 0,
              pvMalus: properties.pvMalus || 0,
            });
            toast.success("Race créée !");
          }
          break;
        case "classes":
          if (editingId) {
            await updateClassMutation.mutateAsync({
              id: editingId,
              data: {
                name: form.name,
                description: form.description,
                ...properties,
              },
            });
            toast.success("Classe mise à jour !");
          } else {
            await createClassMutation.mutateAsync({
              name: form.name,
              faction: form.faction as "Sanctum" | "Legion" | "Tous",
              description: form.description,
              basePv: properties.basePv || 10,
              baseMana: properties.baseMana || 0,
              baseAbilities: properties.baseAbilities || [],
              specialRules: properties.specialRules || [],
              requiresWeapon: properties.requiresWeapon || false,
            });
            toast.success("Classe créée !");
          }
          break;
        case "dons":
          if (editingId) {
            await updateDonMutation.mutateAsync({
              id: editingId,
              data: {
                name: form.name,
                description: form.description,
                ...properties,
              },
            });
            toast.success("Don mis à jour !");
          } else {
            await createDonMutation.mutateAsync({
              name: form.name,
              description: form.description,
              canStack: properties.canStack || false,
              maxStacks: properties.maxStacks || 1,
              pvBonus: properties.pvBonus || 0,
              manaBonus: properties.manaBonus || 0,
              luteBonus: properties.luteBonus || 0,
            });
            toast.success("Don créé !");
          }
          break;
        case "competences":
          if (editingId) {
            await updateCompetenceMutation.mutateAsync({
              id: editingId,
              data: {
                name: form.name,
                description: form.description,
                ...properties,
              },
            });
            toast.success("Compétence mise à jour !");
          } else {
            await createCompetenceMutation.mutateAsync({
              name: form.name,
              category: properties.category || "simple",
              description: form.description,
              baseAdvantage: properties.baseAdvantage || "",
              advancedAdvantage: properties.advancedAdvantage || undefined,
              requiredMaterial: properties.requiredMaterial || undefined,
              isAdultOnly: properties.isAdultOnly || false,
            });
            toast.success("Compétence créée !");
          }
          break;
        case "heritage":
          toast.info("Les mutations pour les héritages seront implémentées dans les prochaines phases.");
          break;
        case "desavantages":
          toast.info("Les mutations pour les désavantages seront implémentées dans les prochaines phases.");
          break;
        default:
          toast.info("Catégorie non encore implémentée. Mutations tRPC à ajouter.");
      }

      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de la sauvegarde");
    }
  };

  const resetForm = () => {
    setForm({
      name: "",
      category: "races",
      faction: "Tous",
      description: "",
      properties: "{}",
    });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/30 py-8">
        <div className="container">
          <div className="flex items-center justify-between mb-4">
            <TerraMortisHeading level={1} gradient="gold" className="text-4xl">
              Gestion de l'Encyclopédie
            </TerraMortisHeading>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowHistory(!showHistory)}
                className="font-heading"
              >
                <History className="w-4 h-4 mr-2" />
                Historique
              </Button>
              <Button
                onClick={() => {
                  resetForm();
                  setShowForm(!showForm);
                }}
                className="font-heading"
                style={{
                  background: "oklch(0.65 0.18 45)",
                  color: "oklch(0.1 0.01 260)",
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle entrée
              </Button>
            </div>
          </div>
          <p className="text-muted-foreground">
            Gérez toutes les entrées de l'Encyclopédie : races, classes,
            compétences, dons, héritage, et bien plus.
          </p>
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="border-b border-border/30 py-8">
          <div className="container">
            <TerraMortisCard>
              <div className="space-y-4">
                <TerraMortisHeading level={2} className="text-2xl">
                  {editingId ? "Modifier l'entrée" : "Créer une nouvelle entrée"}
                </TerraMortisHeading>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Nom *
                    </label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) =>
                        setForm({ ...form, name: e.target.value })
                      }
                      placeholder="Nom de l'entrée"
                      className="w-full px-3 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Catégorie *
                    </label>
                    <select
                      value={form.category}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          category: e.target.value as Category,
                        })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground"
                    >
                      {CATEGORIES.map((cat) => (
                        <option key={cat.value} value={cat.value}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Faction
                    </label>
                    <select
                      value={form.faction}
                      onChange={(e) =>
                        setForm({ ...form, faction: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground"
                    >
                      <option value="Tous">Toutes les factions</option>
                      <option value="Sanctum">Sanctum</option>
                      <option value="Légion">Légion</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    Description
                  </label>
                  <textarea
                    value={form.description}
                    onChange={(e) =>
                      setForm({ ...form, description: e.target.value })
                    }
                    placeholder="Description détaillée"
                    rows={4}
                    className="w-full px-3 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    Propriétés (JSON)
                  </label>
                  <textarea
                    value={form.properties}
                    onChange={(e) =>
                      setForm({ ...form, properties: e.target.value })
                    }
                    placeholder='{"key": "value"}'
                    rows={4}
                    className="w-full px-3 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground font-mono text-sm"
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={handleSave}
                    className="font-heading"
                    style={{
                      background: "oklch(0.65 0.18 45)",
                      color: "oklch(0.1 0.01 260)",
                    }}
                  >
                    {editingId ? "Mettre à jour" : "Créer"}
                  </Button>
                  <Button
                    onClick={resetForm}
                    variant="outline"
                    className="font-heading"
                  >
                    Annuler
                  </Button>
                </div>
              </div>
            </TerraMortisCard>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar - Categories */}
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4">
                Catégories
              </h3>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.value}
                  onClick={() => {
                    setSelectedCategory(cat.value);
                    setSearchQuery("");
                  }}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                    selectedCategory === cat.value
                      ? "bg-foreground/10 border border-foreground/20"
                      : "hover:bg-foreground/5"
                  }`}
                >
                  <span className="text-lg mr-2">{cat.icon}</span>
                  <span className="text-sm">{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Main Area */}
            <div className="lg:col-span-3 space-y-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Rechercher..."
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-border/30 bg-background/50 text-foreground"
                />
              </div>

              {/* Entries List */}
              {filteredEntries.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground/30" />
                  <p className="text-muted-foreground">
                    Aucune entrée dans cette catégorie.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredEntries.map((entry) => (
                    <TerraMortisCard key={entry.id}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <TerraMortisHeading level={3} className="text-lg mb-2">
                            {entry.name}
                          </TerraMortisHeading>
                          <p className="text-sm text-foreground/60 mb-3">
                            {entry.description}
                          </p>
                          <div className="flex gap-2">
                            <Badge
                              style={{
                                background:
                                  entry.faction === "Sanctum"
                                    ? "oklch(0.45 0.15 240 / 0.2)"
                                    : entry.faction === "Légion"
                                      ? "oklch(0.65 0.18 45 / 0.2)"
                                      : "oklch(0.4 0.04 60 / 0.2)",
                                color:
                                  entry.faction === "Sanctum"
                                    ? "oklch(0.45 0.15 240)"
                                    : entry.faction === "Légion"
                                      ? "oklch(0.65 0.18 45)"
                                      : "oklch(0.4 0.04 60)",
                              }}
                            >
                              {entry.faction}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              Modifié{" "}
                              {new Date(entry.updatedAt).toLocaleDateString(
                                "fr-FR"
                              )}
                            </span>
                          </div>
                        </div>

                        <div className="flex gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setForm({
                                id: entry.id,
                                name: entry.name,
                                category: entry.category,
                                faction: entry.faction,
                                description: entry.description,
                                properties: JSON.stringify(
                                  entry.properties,
                                  null,
                                  2
                                ),
                              });
                              setEditingId(entry.id);
                              setShowForm(true);
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-400 border-red-400/30 hover:bg-red-400/10"
                            onClick={async () => {
                              if (!confirm("Êtes-vous sûr de vouloir supprimer cette entrée ?")) return;
                              try {
                                switch (selectedCategory) {
                                  case "races":
                                    await deleteRaceMutation.mutateAsync({ id: entry.id });
                                    break;
                                  case "classes":
                                    await deleteClassMutation.mutateAsync({ id: entry.id });
                                    break;
                                  case "dons":
                                    await deleteDonMutation.mutateAsync({ id: entry.id });
                                    break;
                                  case "competences":
                                    await deleteCompetenceMutation.mutateAsync({ id: entry.id });
                                    break;
                                  case "heritage":
                                    toast.info("La suppression des héritages sera implémentée dans les prochaines phases.");
                                    break;
                                  case "desavantages":
                                    toast.info("La suppression des désavantages sera implémentée dans les prochaines phases.");
                                    break;
                                }
                                toast.success("Entrée supprimée !");
                              } catch (error: any) {
                                toast.error(error.message || "Erreur lors de la suppression");
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </TerraMortisCard>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
