import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface UseValidateDonOptions {
  raceId?: number;
  classId?: number;
  level?: number;
  selectedDons?: number[];
  showToasts?: boolean;
}

export function useValidateDon() {
  const [validationResults, setValidationResults] = useState<Map<number, ValidationResult>>(new Map());
  const [isValidating, setIsValidating] = useState(false);

  // Utiliser la procédure tRPC de validation
  const validateDonMutation = trpc.validation.validateDon.useQuery;

  const validateDon = useCallback(
    async (donId: number, options: UseValidateDonOptions = {}) => {
      const { showToasts = true } = options;
      setIsValidating(true);

      try {
        // Appeler la procédure tRPC de validation
        const result = await new Promise<ValidationResult>((resolve) => {
          // Utiliser fetch directement pour éviter les problèmes de cache
          fetch("/api/trpc/validation.validateDon", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              donId,
              raceId: options.raceId,
              classId: options.classId,
              level: options.level,
              selectedDons: options.selectedDons,
            }),
          })
            .then((res) => res.json())
            .then((data) => {
              const result = data.result || { isValid: true, errors: [], warnings: [] };
              resolve(result);
            })
            .catch(() => {
              resolve({ isValid: true, errors: [], warnings: [] });
            });
        });

        // Stocker le résultat
        setValidationResults((prev) => new Map(prev).set(donId, result));

        // Afficher les toasts si demandé
        if (showToasts) {
          if (!result.isValid && result.errors.length > 0) {
            result.errors.forEach((error) => {
              toast.error(error);
            });
          }
          if (result.warnings.length > 0) {
            result.warnings.forEach((warning) => {
              toast.warning(warning);
            });
          }
        }

        return result;
      } catch (error) {
        console.error("Erreur lors de la validation du don:", error);
        const errorResult: ValidationResult = {
          isValid: false,
          errors: ["Erreur lors de la validation"],
          warnings: [],
        };
        setValidationResults((prev) => new Map(prev).set(donId, errorResult));
        if (showToasts) {
          toast.error("Erreur lors de la validation du don");
        }
        return errorResult;
      } finally {
        setIsValidating(false);
      }
    },
    []
  );

  const getValidationResult = useCallback(
    (donId: number): ValidationResult | undefined => {
      return validationResults.get(donId);
    },
    [validationResults]
  );

  const clearValidation = useCallback((donId?: number) => {
    if (donId) {
      setValidationResults((prev) => {
        const newMap = new Map(prev);
        newMap.delete(donId);
        return newMap;
      });
    } else {
      setValidationResults(new Map());
    }
  }, []);

  return {
    validateDon,
    getValidationResult,
    clearValidation,
    isValidating,
    validationResults,
  };
}
