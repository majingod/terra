# Findings - Héritages et Capacités Bonus

## Problème identifié
Les héritages "+1 Capacité de niveau 1" et "+1 Capacité de niveau 2" existent en base de données et sont affichés dans l'interface Admin, mais les champs `extraAbilitiesLevel1` et `extraAbilitiesLevel2` ne sont **PAS affichés** dans l'interface Admin.

## Champs visibles dans l'interface Admin
Pour chaque héritage, on voit :
- XP (Coût en XP)
- PV Bonus
- Mana Bonus
- Lutte Bonus

## Champs manquants
Les champs suivants ne sont **PAS affichés** dans l'interface Admin :
- `extraAbilitiesLevel1`
- `extraAbilitiesLevel2`
- `extraCompetences`
- `extraCharacteristicPoints` (celui-ci fonctionne, donc il doit être affichable)
- `extraDons`

## Solution
Il faut soit :
1. Ajouter ces champs à l'interface Admin
2. Utiliser une requête SQL directe pour mettre à jour les valeurs

## Requête SQL à exécuter
```sql
UPDATE heritage_avantages SET extraAbilitiesLevel1 = 1 WHERE id IN (SELECT id FROM heritage_avantages WHERE name LIKE '%+1 Capacité de niveau 1%');
UPDATE heritage_avantages SET extraAbilitiesLevel2 = 1 WHERE id IN (SELECT id FROM heritage_avantages WHERE name LIKE '%+1 Capacité de niveau 2%');
```

Ou avec les IDs directs si connus.
