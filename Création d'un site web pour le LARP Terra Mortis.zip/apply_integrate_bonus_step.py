#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Ajouter l'import de StepCapacitesBonus
old_imports = '''import StepVoieEtDons from "./StepVoieEtDons";'''

new_imports = '''import StepVoieEtDons from "./StepVoieEtDons";
import { StepCapacitesBonus } from "./StepCapacitesBonus";'''

content = content.replace(old_imports, new_imports)
print("✓ Import de StepCapacitesBonus ajouté")

# Trouver la section stepContent et ajouter StepCapacitesBonus
# Chercher le cas 9 (Voie) et le remplacer par StepCapacitesBonus avec logique conditionnelle
old_case_9 = '''        case 9:
          return (
            <StepVoie
              data={charData}
              onChange={updateData}
              classData={classInfo}
              pathsData={paths}
              abilitiesData={abilities}
            />
          );'''

new_case_9 = '''        case 9:
          // Vérifier si le joueur a acheté des capacités bonus
          const hasExtraAbilities = charData.heritageAvantages.some((h) => {
            const heritage = heritageData?.find((ha) => ha.id === h.id);
            return heritage && (heritage.extraAbilitiesLevel1 > 0 || heritage.extraAbilitiesLevel2 > 0);
          });
          
          if (!hasExtraAbilities) {
            // Sauter à l'étape 10 si pas de capacités bonus
            return (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
                    Capacités bonus
                  </h2>
                  <p className="text-muted-foreground text-sm">
                    Vous n'avez pas acheté de capacités bonus dans l'héritage.
                  </p>
                </div>
                <div className="p-6 rounded-xl border text-center" style={{ borderColor: "oklch(0.28 0.03 260)", background: "oklch(0.16 0.02 260)" }}>
                  <p className="text-foreground/60">
                    Pour débloquer des capacités bonus, achetez "+1 Capacité de niveau 1" ou "+1 Capacité de niveau 2" dans l'étape Héritage.
                  </p>
                </div>
              </div>
            );
          }
          
          return (
            <StepCapacitesBonus
              data={charData}
              onChange={updateData}
              heritageData={heritageData || []}
              classData={classInfo}
              pathsData={paths}
              abilitiesData={abilities}
            />
          );'''

content = content.replace(old_case_9, new_case_9)
print("✓ Cas 9 (Capacités bonus) modifié avec logique conditionnelle")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
