import { useMemo } from "react";

/**
 * Hook pour calculer les bonus d'Héritage et leur propagation
 * dans le générateur de personnage
 */
export interface HeritageBonusCalculation {
  // Bonus de caractéristiques
  extraStatsPoints: number;
  
  // Bonus de dons
  extraDons: number;
  
  // Bonus de compétences
  extraCompetences: number;
  
  // Bonus de capacités
  extraAbilities: number;
  extraAbilitiesLevel1: number;
  extraAbilitiesLevel2: number;
  
  // Bonus de PV/PM
  extraPv: number;
  extraPm: number;
  
  // Autres bonus
  extraLute: number;
}

export interface HeritageData {
  id: number;
  name: string;
  xpCost: number;
  extraStatsPoints?: number;
  extraDons?: number;
  extraCompetences?: number;
  extraAbilities?: number;
  extraAbilitiesLevel1?: number;
  extraAbilitiesLevel2?: number;
  extraPv?: number;
  extraPm?: number;
  extraLute?: number;
}

/**
 * Calcule les bonus totaux d'Héritage en fonction des héritages sélectionnés
 */
export function useHeritageBonus(
  selectedHeritages: { id: number; times: number }[],
  heritageDatabase: HeritageData[]
): HeritageBonusCalculation {
  return useMemo(() => {
    const totals: HeritageBonusCalculation = {
      extraStatsPoints: 0,
      extraDons: 0,
      extraCompetences: 0,
      extraAbilities: 0,
      extraAbilitiesLevel1: 0,
      extraAbilitiesLevel2: 0,
      extraPv: 0,
      extraPm: 0,
      extraLute: 0,
    };

    for (const selected of selectedHeritages) {
      const heritage = heritageDatabase.find((h) => h.id === selected.id);
      if (!heritage) continue;

      const multiplier = selected.times;

      totals.extraStatsPoints += (heritage.extraStatsPoints ?? 0) * multiplier;
      totals.extraDons += (heritage.extraDons ?? 0) * multiplier;
      totals.extraCompetences += (heritage.extraCompetences ?? 0) * multiplier;
      totals.extraAbilities += (heritage.extraAbilities ?? 0) * multiplier;
      totals.extraAbilitiesLevel1 += (heritage.extraAbilitiesLevel1 ?? 0) * multiplier;
      totals.extraAbilitiesLevel2 += (heritage.extraAbilitiesLevel2 ?? 0) * multiplier;
      totals.extraPv += (heritage.extraPv ?? 0) * multiplier;
      totals.extraPm += (heritage.extraPm ?? 0) * multiplier;
      totals.extraLute += (heritage.extraLute ?? 0) * multiplier;
    }

    return totals;
  }, [selectedHeritages, heritageDatabase]);
}

/**
 * Hook pour valider les limites de sélection en fonction des bonus d'Héritage
 */
export function useHeritageValidation(
  bonus: HeritageBonusCalculation,
  selectedCount: number,
  maxAllowed: number
): {
  canAdd: boolean;
  canRemove: boolean;
  reason?: string;
} {
  return useMemo(() => {
    const totalAllowed = maxAllowed + bonus.extraDons;

    if (selectedCount >= totalAllowed) {
      return {
        canAdd: false,
        canRemove: selectedCount > 0,
        reason: `Limite atteinte (${selectedCount}/${totalAllowed})`,
      };
    }

    return {
      canAdd: true,
      canRemove: selectedCount > 0,
    };
  }, [bonus.extraDons, selectedCount, maxAllowed]);
}
