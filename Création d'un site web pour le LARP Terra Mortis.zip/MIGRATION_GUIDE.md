# Guide de Migration vers l'Encyclopédie

## Vue d'ensemble

Ce guide explique comment migrer progressivement les données de Terra Mortis vers le nouveau système d'Encyclopédie centralisé.

## Stratégie de Migration Progressive

La migration est conçue pour être **progressive et non-destructive** :

- Les anciennes tables restent intactes pendant la migration
- Chaque catégorie peut être migrée indépendamment
- Les données migrées sont validées avant suppression des anciennes tables
- Vous pouvez revenir en arrière à tout moment

## Interface de Migration

### Accès

1. Connectez-vous en tant qu'**Organisateur** (rôle admin)
2. Allez dans le menu **Admin** > **Migration Encyclopédie**
3. Vous verrez le tableau de bord de migration

### Tableau de Bord

Le tableau de bord affiche :

- **Progression globale** : Pourcentage de données migrées (barre de progression)
- **Cartes par catégorie** : État de migration pour chaque type de données
- **Boutons de migration** : Migrer chaque catégorie individuellement

### Catégories Migrables

| Catégorie | Description | Statut |
|-----------|-------------|--------|
| **Races** | Toutes les races disponibles | Migrables |
| **Classes** | Classes et voies de classe | Migrables |
| **Dons** | Tous les dons disponibles | Migrables |
| **Compétences** | Compétences et artisanats | Migrables |
| **Héritages** | Avantages héréditaires | Migrables |
| **Désavantages** | Désavantages héréditaires | Migrables |

## Processus de Migration

### Étape 1 : Vérifier l'État

1. Ouvrez le tableau de bord de migration
2. Cliquez sur **Rafraîchir** pour voir l'état actuel
3. Vérifiez le nombre d'entrées à migrer pour chaque catégorie

### Étape 2 : Migrer par Catégorie

**Recommandation** : Migrez dans cet ordre :

1. **Races** (fondation)
2. **Classes** (dépend des races)
3. **Dons** (dépend des classes)
4. **Compétences** (indépendant)
5. **Héritages** (dépend des races/classes)
6. **Désavantages** (indépendant)

### Étape 3 : Valider la Migration

Après chaque migration :

1. Vérifiez que le nombre d'entrées a augmenté
2. Consultez l'Encyclopédie pour vérifier les données
3. Testez les dépendances (ex : race → classe)

### Étape 4 : Rafraîchir et Répéter

1. Cliquez sur **Rafraîchir** pour voir la progression
2. Continuez avec la catégorie suivante
3. Répétez jusqu'à 100% de migration

## Dépannage

### Problème : La migration échoue

**Solution** :
- Vérifiez que vous êtes connecté en tant qu'Organisateur
- Attendez quelques secondes et réessayez
- Consultez les logs du serveur pour les détails

### Problème : Les données ne s'affichent pas après migration

**Solution** :
- Cliquez sur **Rafraîchir** pour recharger les données
- Videz le cache du navigateur (Ctrl+Shift+Delete)
- Rechargez la page (F5)

### Problème : Certaines entrées ne sont pas migrées

**Solution** :
- Vérifiez que toutes les dépendances sont migrées
- Certaines entrées peuvent avoir des relations complexes
- Consultez les logs pour les entrées ignorées

## Après la Migration

### Vérification Complète

1. Consultez l'Encyclopédie (Règles > Encyclopédie)
2. Testez les filtres par catégorie et faction
3. Vérifiez les relations entre entrées

### Nettoyage des Anciennes Tables

**⚠️ ATTENTION** : Ne supprimez les anciennes tables que lorsque vous êtes certain que la migration est complète et validée.

Une fois la migration 100% complète :
1. Sauvegardez la base de données
2. Créez un checkpoint
3. Les anciennes tables peuvent être archivées ou supprimées

### Mise à Jour des Interfaces

Les interfaces suivantes utiliseront automatiquement les données de l'Encyclopédie :

- Créateur de personnage
- Pages de règles
- Recherche globale
- Filtres par faction

## Support

Pour toute question ou problème :

1. Consultez les logs du serveur (`.manus-logs/devserver.log`)
2. Vérifiez que toutes les dépendances sont satisfaites
3. Contactez l'équipe de développement

## Références Techniques

### Procédures tRPC Utilisées

- `migration.getMigrationStatus()` : Récupère l'état de la migration
- `migration.migrateRaces()` : Migre les races
- `migration.migrateClasses()` : Migre les classes
- `migration.migrateDons()` : Migre les dons
- `migration.migrateCompetences()` : Migre les compétences
- `migration.migrateHeritages()` : Migre les héritages
- `migration.migrateDesavantages()` : Migre les désavantages

### Structure de Données

Chaque entrée de l'Encyclopédie contient :

- **id** : Identifiant unique
- **title** : Titre de l'entrée
- **category** : Catégorie (races, classes, dons, etc.)
- **faction** : Faction (Sanctum, Légion, Neutre)
- **description** : Description détaillée
- **properties** : Propriétés spécifiques (JSON)
- **relations** : Relations avec d'autres entrées

## Historique des Modifications

Chaque migration est enregistrée dans l'historique :

- Qui a migré les données
- Quand la migration a eu lieu
- Combien d'entrées ont été migrées
- Détails de chaque entrée migrée

Vous pouvez consulter cet historique pour auditer la migration.

---

**Version** : 1.0  
**Dernière mise à jour** : 2026-06-14  
**Auteur** : Équipe Terra Mortis
