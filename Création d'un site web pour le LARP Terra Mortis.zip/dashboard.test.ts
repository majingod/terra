import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock des fonctions de base de données
vi.mock("./db", () => ({
  getAllEvenements: vi.fn(),
  getAllUsers: vi.fn(),
}));

describe("Dashboard Organisateur - Procédures tRPC", () => {
  let mockGetAllEvenements: any;
  let mockGetAllUsers: any;

  beforeEach(async () => {
    const { getAllEvenements, getAllUsers } = await import("./db");
    mockGetAllEvenements = getAllEvenements as any;
    mockGetAllUsers = getAllUsers as any;
    vi.clearAllMocks();
  });

  describe("getUpcomingEvents", () => {
    it("devrait retourner les événements à venir dans les 30 prochains jours", async () => {
      const now = new Date();
      const futureDate = new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000); // 10 jours
      const pastDate = new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000); // -10 jours
      const tooFarDate = new Date(now.getTime() + 40 * 24 * 60 * 60 * 1000); // 40 jours

      const mockEvents = [
        { id: 1, title: "Event 1", startDate: futureDate, status: "published", endDate: new Date() },
        { id: 2, title: "Event 2", startDate: pastDate, status: "published", endDate: new Date() },
        { id: 3, title: "Event 3", startDate: tooFarDate, status: "published", endDate: new Date() },
        { id: 4, title: "Event 4", startDate: futureDate, status: "draft", endDate: new Date() },
      ];

      mockGetAllEvenements.mockResolvedValue(mockEvents);

      // Simuler la logique de filtrage
      const allEvents = await mockGetAllEvenements();
      const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      
      const upcomingEvents = allEvents
        .filter((e: any) => e.status === "published" && 
                new Date(e.startDate) >= now && 
                new Date(e.startDate) <= thirtyDaysLater)
        .sort((a: any, b: any) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
        .slice(0, 10);

      expect(upcomingEvents).toHaveLength(1);
      expect(upcomingEvents[0].id).toBe(1);
    });

    it("devrait retourner un array vide si aucun événement à venir", async () => {
      mockGetAllEvenements.mockResolvedValue([]);

      const allEvents = await mockGetAllEvenements();
      const now = new Date();
      const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      
      const upcomingEvents = allEvents
        .filter((e: any) => e.status === "published" && 
                new Date(e.startDate) >= now && 
                new Date(e.startDate) <= thirtyDaysLater)
        .slice(0, 10);

      expect(upcomingEvents).toHaveLength(0);
    });

    it("devrait limiter les résultats à 10 événements", async () => {
      const now = new Date();
      const mockEvents = Array.from({ length: 15 }, (_, i) => ({
        id: i + 1,
        title: `Event ${i + 1}`,
        startDate: new Date(now.getTime() + (i + 1) * 24 * 60 * 60 * 1000),
        status: "published",
        endDate: new Date(),
      }));

      mockGetAllEvenements.mockResolvedValue(mockEvents);

      const allEvents = await mockGetAllEvenements();
      const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      
      const upcomingEvents = allEvents
        .filter((e: any) => e.status === "published" && 
                new Date(e.startDate) >= now && 
                new Date(e.startDate) <= thirtyDaysLater)
        .sort((a: any, b: any) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
        .slice(0, 10);

      expect(upcomingEvents.length).toBeLessThanOrEqual(10);
    });
  });

  describe("getActiveUsers", () => {
    it("devrait retourner les 10 utilisateurs les plus actifs", async () => {
      const mockUsers = Array.from({ length: 15 }, (_, i) => ({
        id: i + 1,
        name: `User ${i + 1}`,
        email: `user${i + 1}@example.com`,
        role: "user",
        xp: 100 - i * 5,
      }));

      mockGetAllUsers.mockResolvedValue(mockUsers);

      const allUsers = await mockGetAllUsers();
      const activeUsers = allUsers.slice(0, 10);

      expect(activeUsers).toHaveLength(10);
      expect(activeUsers[0].id).toBe(1);
    });

    it("devrait retourner tous les utilisateurs s'il y en a moins de 10", async () => {
      const mockUsers = [
        { id: 1, name: "User 1", email: "user1@example.com", role: "user", xp: 100 },
        { id: 2, name: "User 2", email: "user2@example.com", role: "user", xp: 90 },
      ];

      mockGetAllUsers.mockResolvedValue(mockUsers);

      const allUsers = await mockGetAllUsers();
      const activeUsers = allUsers.slice(0, 10);

      expect(activeUsers).toHaveLength(2);
    });
  });

  describe("getXPToDistribute", () => {
    it("devrait retourner les événements terminés sans XP attribué", async () => {
      const now = new Date();
      const pastDate = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000); // -5 jours
      const futureDate = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000); // +5 jours

      const mockEvents = [
        { id: 1, title: "Event 1", endDate: pastDate, status: "completed", startDate: new Date() },
        { id: 2, title: "Event 2", endDate: futureDate, status: "completed", startDate: new Date() },
        { id: 3, title: "Event 3", endDate: pastDate, status: "published", startDate: new Date() },
      ];

      mockGetAllEvenements.mockResolvedValue(mockEvents);

      const allEvents = await mockGetAllEvenements();
      const xpToDistribute = allEvents
        .filter((e: any) => e.status === "completed" && new Date(e.endDate) < now)
        .sort((a: any, b: any) => new Date(b.endDate).getTime() - new Date(a.endDate).getTime())
        .slice(0, 10);

      expect(xpToDistribute).toHaveLength(1);
      expect(xpToDistribute[0].id).toBe(1);
    });

    it("devrait trier par date décroissante (plus récents en premier)", async () => {
      const now = new Date();
      const date1 = new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000); // -1 jour
      const date2 = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000); // -5 jours

      const mockEvents = [
        { id: 1, title: "Event 1", endDate: date2, status: "completed", startDate: new Date() },
        { id: 2, title: "Event 2", endDate: date1, status: "completed", startDate: new Date() },
      ];

      mockGetAllEvenements.mockResolvedValue(mockEvents);

      const allEvents = await mockGetAllEvenements();
      const xpToDistribute = allEvents
        .filter((e: any) => e.status === "completed" && new Date(e.endDate) < now)
        .sort((a: any, b: any) => new Date(b.endDate).getTime() - new Date(a.endDate).getTime())
        .slice(0, 10);

      expect(xpToDistribute[0].id).toBe(2); // Event 2 est plus récent
      expect(xpToDistribute[1].id).toBe(1);
    });
  });

  describe("getStats", () => {
    it("devrait retourner les statistiques globales correctes", async () => {
      const mockEvents = [
        { id: 1, status: "published" },
        { id: 2, status: "published" },
        { id: 3, status: "draft" },
        { id: 4, status: "completed" },
      ];

      const mockUsers = [
        { id: 1, name: "User 1" },
        { id: 2, name: "User 2" },
      ];

      mockGetAllEvenements.mockResolvedValue(mockEvents);
      mockGetAllUsers.mockResolvedValue(mockUsers);

      const allEvents = await mockGetAllEvenements();
      const allUsers = await mockGetAllUsers();

      const stats = {
        totalEvents: allEvents.filter((e: any) => e.status === "published").length,
        totalUsers: allUsers.length,
        totalInscriptions: 0,
        totalXPDistributed: 0,
      };

      expect(stats.totalEvents).toBe(2);
      expect(stats.totalUsers).toBe(2);
      expect(stats.totalInscriptions).toBe(0);
      expect(stats.totalXPDistributed).toBe(0);
    });

    it("devrait compter uniquement les événements publiés", async () => {
      const mockEvents = [
        { id: 1, status: "published" },
        { id: 2, status: "draft" },
        { id: 3, status: "cancelled" },
        { id: 4, status: "completed" },
      ];

      mockGetAllEvenements.mockResolvedValue(mockEvents);

      const allEvents = await mockGetAllEvenements();
      const publishedCount = allEvents.filter((e: any) => e.status === "published").length;

      expect(publishedCount).toBe(1);
    });
  });
});
