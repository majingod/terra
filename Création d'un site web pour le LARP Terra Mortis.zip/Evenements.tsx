import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import Breadcrumbs from "@/components/Breadcrumbs";
import { Calendar, MapPin, Users, Clock, Skull, Shield, Swords, ChevronRight, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

function formatDate(date: string | Date) {
  return format(new Date(date), "d MMMM yyyy", { locale: fr });
}

function formatDateTime(date: string | Date) {
  return format(new Date(date), "d MMMM yyyy 'à' HH:mm", { locale: fr });
}

function getStatusBadge(status: string) {
  switch (status) {
    case "published":
      return { label: "Ouvert", bg: "oklch(0.35 0.12 145)", border: "oklch(0.45 0.15 145)" };
    case "completed":
      return { label: "Terminé", bg: "oklch(0.25 0.05 240)", border: "oklch(0.35 0.08 240)" };
    case "cancelled":
      return { label: "Annulé", bg: "oklch(0.3 0.12 25)", border: "oklch(0.4 0.15 25)" };
    default:
      return { label: "Brouillon", bg: "oklch(0.25 0.02 60)", border: "oklch(0.35 0.04 60)" };
  }
}

function getFactionIcon(faction: string) {
  if (faction === "Sanctum") return <Shield className="w-4 h-4" />;
  if (faction === "Légion") return <Skull className="w-4 h-4" />;
  return <Swords className="w-4 h-4" />;
}

export default function Evenements() {
  const { isAuthenticated } = useAuth();
  const { data: evenements, isLoading } = trpc.evenements.list.useQuery();

  const upcomingEvents = evenements?.filter(
    (e: any) => new Date(e.startDate) >= new Date()
  ) ?? [];
  const pastEvents = evenements?.filter(
    (e: any) => new Date(e.startDate) < new Date()
  ) ?? [];

  return (
    <div className="min-h-screen">
      {/* ─── Hero Section ────────────────────────────────────────────────────── */}
      <section className="relative min-h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0"
            style={{
              background: "radial-gradient(ellipse at center, oklch(0.2 0.04 270 / 0.4) 0%, transparent 70%)",
            }} />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.65 0.18 45)" }} />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.5 0.22 25)" }} />
          <div className="absolute top-10 left-10 text-6xl opacity-5 font-heading select-none">ᚠ</div>
          <div className="absolute bottom-10 right-10 text-7xl opacity-5 font-heading select-none">ᚨ</div>
        </div>

        <div className="container relative z-10 text-center py-16">
          <Breadcrumbs items={[{ label: "Événements" }]} />

          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.2), oklch(0.45 0.15 30 / 0.1))",
                border: "2px solid oklch(0.65 0.18 45 / 0.4)",
                boxShadow: "0 0 40px oklch(0.65 0.18 45 / 0.2)",
              }}>
              <Calendar className="w-10 h-10" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-heading font-black mb-4 leading-tight"
            style={{
              background: "linear-gradient(135deg, oklch(0.82 0.2 85), oklch(0.65 0.18 45), oklch(0.82 0.2 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
            ÉVÉNEMENTS
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Découvrez les prochaines parties de Terra Mortis et inscrivez-vous pour participer aux aventures.
          </p>

          <div className="flex items-center justify-center gap-4 my-8">
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Calendar className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
        </div>
      </section>

      {/* ─── Événements à venir ──────────────────────────────────────────────── */}
      <section className="container py-16">
        <h2 className="text-3xl font-heading font-bold mb-8 flex items-center gap-3">
          <Swords className="w-7 h-7" style={{ color: "oklch(0.82 0.2 85)" }} />
          <span style={{ color: "oklch(0.82 0.2 85)" }}>Prochains événements</span>
        </h2>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : upcomingEvents.length === 0 ? (
          <div className="text-center py-20 rounded-xl border border-border/40"
            style={{ background: "oklch(0.18 0.01 270 / 0.5)" }}>
            <Calendar className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-40" />
            <p className="text-xl text-muted-foreground mb-2">Aucun événement à venir pour le moment</p>
            <p className="text-sm text-muted-foreground/60">Revenez bientôt pour découvrir les prochaines parties !</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {upcomingEvents.map((evt: any) => {
              const statusBadge = getStatusBadge(evt.status);
              return (
                <Link key={evt.id} href={`/evenements/${evt.id}`}>
                  <div className="group relative rounded-xl border border-border/40 p-6 transition-all duration-300 hover:border-border/60 cursor-pointer"
                    style={{
                      background: "linear-gradient(135deg, oklch(0.18 0.01 270 / 0.8), oklch(0.15 0.02 30 / 0.5))",
                    }}>
                    <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.05), transparent)" }} />

                    <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
                      {/* Date badge */}
                      <div className="flex-shrink-0 w-20 h-20 rounded-lg flex flex-col items-center justify-center"
                        style={{
                          background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.2), oklch(0.45 0.15 30 / 0.1))",
                          border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                        }}>
                        <span className="text-2xl font-heading font-black" style={{ color: "oklch(0.82 0.2 85)" }}>
                          {format(new Date(evt.startDate), "d")}
                        </span>
                        <span className="text-xs uppercase tracking-wider text-muted-foreground">
                          {format(new Date(evt.startDate), "MMM", { locale: fr })}
                        </span>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2 flex-wrap">
                          <h3 className="text-xl font-heading font-bold text-foreground group-hover:text-amber-200 transition-colors">
                            {evt.title}
                          </h3>
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                            style={{ background: statusBadge.bg, border: `1px solid ${statusBadge.border}`, color: "oklch(0.85 0.05 85)" }}>
                            {statusBadge.label}
                          </span>
                          {evt.faction !== "Tous" && (
                            <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                              style={{
                                background: evt.faction === "Sanctum" ? "oklch(0.25 0.08 240)" : "oklch(0.25 0.08 25)",
                                border: `1px solid ${evt.faction === "Sanctum" ? "oklch(0.35 0.12 240)" : "oklch(0.35 0.12 25)"}`,
                              }}>
                              {getFactionIcon(evt.faction)}
                              {evt.faction}
                            </span>
                          )}
                        </div>

                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                          {evt.description}
                        </p>

                        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5" style={{ color: "oklch(0.65 0.18 45)" }} />
                            {evt.location}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5" style={{ color: "oklch(0.65 0.18 45)" }} />
                            {formatDateTime(evt.startDate)}
                          </span>
                          {evt.maxPlayers > 0 && (
                            <span className="flex items-center gap-1.5">
                              <Users className="w-3.5 h-3.5" style={{ color: "oklch(0.65 0.18 45)" }} />
                              {evt.maxPlayers} places max
                            </span>
                          )}
                          {evt.price && (
                            <span className="flex items-center gap-1.5 font-medium" style={{ color: "oklch(0.82 0.2 85)" }}>
                              {evt.price}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Arrow */}
                      <div className="flex-shrink-0">
                        <ChevronRight className="w-6 h-6 text-muted-foreground group-hover:text-amber-200 transition-colors" />
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* ─── Événements passés ───────────────────────────────────────────────── */}
      {pastEvents.length > 0 && (
        <section className="container py-16 border-t border-border/20">
          <h2 className="text-2xl font-heading font-bold mb-8 flex items-center gap-3 text-muted-foreground">
            <Clock className="w-6 h-6" />
            Événements passés
          </h2>

          <div className="grid gap-4">
            {pastEvents.map((evt: any) => (
              <div key={evt.id} className="rounded-lg border border-border/20 p-4 opacity-60"
                style={{ background: "oklch(0.15 0.005 270 / 0.5)" }}>
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex-shrink-0 w-14 h-14 rounded-lg flex flex-col items-center justify-center"
                    style={{ background: "oklch(0.2 0.01 270 / 0.5)", border: "1px solid oklch(0.3 0.02 270 / 0.3)" }}>
                    <span className="text-lg font-heading font-bold text-muted-foreground">
                      {format(new Date(evt.startDate), "d")}
                    </span>
                    <span className="text-[10px] uppercase text-muted-foreground/60">
                      {format(new Date(evt.startDate), "MMM", { locale: fr })}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-heading font-bold text-muted-foreground">{evt.title}</h3>
                    <p className="text-xs text-muted-foreground/60 flex items-center gap-2 mt-1">
                      <MapPin className="w-3 h-3" /> {evt.location}
                      <span>•</span>
                      {formatDate(evt.startDate)}
                    </p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">Terminé</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ─── CTA ─────────────────────────────────────────────────────────────── */}
      {!isAuthenticated && (
        <section className="container py-16 text-center">
          <div className="rounded-xl p-8 border border-border/40"
            style={{
              background: "linear-gradient(135deg, oklch(0.18 0.02 45 / 0.5), oklch(0.15 0.01 270 / 0.5))",
            }}>
            <h3 className="text-2xl font-heading font-bold mb-3" style={{ color: "oklch(0.82 0.2 85)" }}>
              Prêt à rejoindre l'aventure ?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
              Connectez-vous pour vous inscrire aux événements et créer votre personnage.
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="font-heading text-lg px-8"
                style={{
                  background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.5 0.22 25))",
                  color: "oklch(0.98 0 0)",
                }}>
                Se connecter
              </Button>
            </a>
          </div>
        </section>
      )}
    </div>
  );
}
