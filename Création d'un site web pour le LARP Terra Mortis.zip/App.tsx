import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Sidebar from "./components/Sidebar";
import Home from "./pages/Home";
import Races from "./pages/rules/Races";
import Classes from "./pages/rules/Classes";
import Competences from "./pages/rules/Competences";
import Dons from "./pages/rules/Dons";
import Heritage from "./pages/rules/Heritage";
import Desavantages from "./pages/rules/Desavantages";
import Magie from "./pages/rules/Magie";
import Combat from "./pages/rules/Combat";
import CreatePersonnage from "./pages/CreatePersonnage";
import CreatePersonnageV2 from "./pages/CreatePersonnageV2";
import MesPersonnages from "./pages/MesPersonnages";
import PersonnageDetail from "./pages/PersonnageDetail";
import PersonnageSheet from "./pages/PersonnageSheet";
import Admin from "./pages/Admin";
import AdminEvenements from "./pages/AdminEvenements";
import RulesHub from "./pages/RulesHub";
import Evenements from "./pages/Evenements";
import EvenementDetail from "./pages/EvenementDetail";
import EncyclopediaDetail from "./pages/EncyclopediaDetail";
import { ListEvenements } from "./pages/ListEvenements";
import { XPPermanent } from "./pages/XPPermanent";
import { AdminEncyclopedia } from "./pages/AdminEncyclopedia";
import AdminMigration from "./pages/AdminMigration";
import AdminEncyclopediaMigration from "./pages/AdminEncyclopediaMigration";
import EncyclopediaCategory from "./pages/EncyclopediaCategory";
import MesInscriptions from "./pages/MesInscriptions";
import AdminXPManagement from "./pages/AdminXPManagement";
import AdminDashboard from "./pages/AdminDashboard";
import EncyclopediaHistory from "./pages/EncyclopediaHistory";

function Router() {
  return (
    <div className="min-h-screen flex" style={{ background: "oklch(0.13 0.02 260)" }}>
      <Sidebar />
      <div className="flex-1">
        <Switch>
        <Route path="/" component={Home} />
        <Route path="/regles" component={RulesHub} />
        <Route path="/regles/introduction" component={RulesHub} />
        <Route path="/regles/races" component={Races} />
        <Route path="/regles/classes" component={Classes} />
        <Route path="/regles/competences" component={Competences} />
        <Route path="/regles/dons" component={Dons} />
        <Route path="/regles/heritage" component={Heritage} />
        <Route path="/regles/desavantages" component={Desavantages} />
        <Route path="/regles/magie" component={Magie} />
        <Route path="/regles/combat" component={Combat} />
        <Route path="/creer-personnage" component={CreatePersonnage} />
        <Route path="/creer-personnage-v2" component={CreatePersonnageV2} />
        <Route path="/mes-personnages" component={MesPersonnages} />
        <Route path="/personnage/:id" component={PersonnageDetail} />
        <Route path="/personnage-sheet/:id" component={PersonnageSheet} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin/encyclopedie" component={AdminEncyclopedia} />
        <Route path="/admin/migration" component={AdminMigration} />
        <Route path="/admin/migration-encyclopedie" component={AdminEncyclopediaMigration} />
        <Route path="/admin/evenements" component={AdminEvenements} />
        <Route path="/admin/xp" component={AdminXPManagement} />
        <Route path="/evenements" component={Evenements} />
        <Route path="/evenements/:id" component={EvenementDetail} />
        <Route path="/xp-permanent" component={XPPermanent} />
        <Route path="/mes-inscriptions" component={MesInscriptions} />
        <Route path="/encyclopedie/historique" component={EncyclopediaHistory} />
        <Route path="/encyclopedie/:category" component={EncyclopediaCategory} />
        <Route path="/encyclopedie/:categorie" component={EncyclopediaDetail} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
