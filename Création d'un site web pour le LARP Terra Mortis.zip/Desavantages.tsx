import { trpc } from "@/lib/trpc";
import { ChevronRight, Loader2, Skull, TrendingDown } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

export default function Desavantages() {
  const { data: desavantages, isLoading } = trpc.rules.desavantages.useQuery();
  const [search, setSearch] = useState("");

  const filtered = desavantages?.filter(
    (d) => d.name.toLowerCase().includes(search.toLowerCase()) || d.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Désavantages", active: true },
      ]} />
      <div className="container max-w-5xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.45 0.15 140 / 0.15)", border: "2px solid oklch(0.45 0.15 140 / 0.4)" }}
            >
              <TrendingDown className="w-8 h-8" style={{ color: "oklch(0.45 0.15 140)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Désavantages
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.45 0.15 140 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.45 0.15 140)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.45 0.15 140 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Les désavantages offrent des XP supplémentaires en échange de limitations ou de handicaps pour votre personnage.
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <input
            type="text"
            placeholder="Rechercher un désavantage..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border"
            style={{ background: "oklch(0.16 0.02 260)", borderColor: "oklch(0.28 0.03 260)" }}
          />
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
          </div>
        ) : (
          <div className="space-y-4">
            {filtered && filtered.length > 0 ? (
              filtered.map((desavantage) => (
                <div
                  key={desavantage.id}
                  className="p-6 rounded-xl border transition-all hover:border-opacity-100"
                  style={{
                    background: "oklch(0.16 0.02 260)",
                    borderColor: "oklch(0.28 0.03 260 / 0.5)",
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-lg font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
                        {desavantage.name}
                      </h3>
                      {desavantage.xpGain && (
                        <p className="text-xs text-foreground/60 mt-1">
                          XP Gagné: <span style={{ color: "oklch(0.45 0.15 140)" }}>{desavantage.xpGain} XP</span>
                        </p>
                      )}
                    </div>
                    <ChevronRight className="w-5 h-5 text-foreground/40 flex-shrink-0" />
                  </div>
                  <p className="text-sm text-foreground/70 mb-3">{desavantage.description}</p>

                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <p className="text-foreground/60">Aucun désavantage trouvé.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
