import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Plus, Trash2, Trophy } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState } from "react";
import { toast } from "sonner";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function AdminXPManagement() {
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<string>("");
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [xpAmount, setXpAmount] = useState<string>("");
  const [reason, setReason] = useState<string>("");

  const awardXPMutation = trpc.xp.awardForInscription.useMutation({
    onSuccess: (result) => {
      toast.success(`${result.montant} XP attribué avec succès`);
      setSelectedUserId("");
      setXpAmount("");
      setReason("");
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast.error(error.message || "Impossible d'attribuer l'XP");
    },
  });

  // Récupérer les événements
  const { data: events, isLoading: loadingEvents } =
    trpc.evenements.listAll.useQuery(undefined, { enabled: !!user?.id });

  // Récupérer les inscriptions pour l'événement sélectionné
  const { data: inscriptions, isLoading: loadingInscriptions } =
    trpc.evenements.inscriptions.useQuery(
      { evenementId: parseInt(selectedEventId) },
      { enabled: !!selectedEventId && !!user?.id }
    );

  if (!user || (user.role !== "admin" && user.role !== "organizer")) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Accès réservé aux administrateurs.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const handleAttributeXP = () => {
    if (!selectedEventId || !selectedUserId || !xpAmount) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }

    const xpValue = Number.parseInt(xpAmount, 10);
    if (!Number.isInteger(xpValue) || xpValue <= 0) {
      toast.error("Le montant d'XP doit être un nombre entier positif");
      return;
    }

    awardXPMutation.mutate({
      inscriptionId: Number.parseInt(selectedUserId, 10),
      amount: xpValue,
      reason: reason.trim() || undefined,
    });
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Gestion de l'XP</h1>
        <p className="text-muted-foreground">
          Attribuez l'XP aux joueurs après les événements
        </p>
      </div>

      {/* Sélection d'événement */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Sélectionner un événement</CardTitle>
          <CardDescription>
            Choisissez l'événement pour lequel vous souhaitez attribuer l'XP
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedEventId}
            onValueChange={(value) => {
              setSelectedEventId(value);
              setSelectedUserId("");
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Sélectionner un événement" />
            </SelectTrigger>
            <SelectContent>
              {loadingEvents ? (
                <div className="px-2 py-1.5 text-sm text-muted-foreground">Chargement...</div>
              ) : events && events.length > 0 ? (
                events.map((event: any) => (
                  <SelectItem key={event.id} value={event.id.toString()}>
                    {event.title} ({format(new Date(event.startDate), "PPP", { locale: fr })})
                  </SelectItem>
                ))
              ) : (
                <div className="px-2 py-1.5 text-sm text-muted-foreground">Aucun événement disponible</div>
              )}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Liste des inscriptions */}
      {selectedEventId && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Inscriptions</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Attribuer XP
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Attribuer XP à un joueur</DialogTitle>
                  <DialogDescription>
                    Sélectionnez un joueur et entrez le montant d'XP à attribuer
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Joueur
                    </label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner un joueur" />
                      </SelectTrigger>
                      <SelectContent>
                        {loadingInscriptions ? (
                          <div className="px-2 py-1.5 text-sm text-muted-foreground">Chargement...</div>
                        ) : inscriptions && inscriptions.length > 0 ? (
                          inscriptions.map((inscription: any) => (
                            <SelectItem
                              key={inscription.id}
                              value={inscription.id.toString()}
                            >
                              {inscription.userName || "Utilisateur inconnu"}
                            </SelectItem>
                          ))
                        ) : (
                          <div className="px-2 py-1.5 text-sm text-muted-foreground">Aucun joueur inscrit</div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Montant d'XP
                    </label>
                    <Input
                      type="number"
                      min="1"
                      value={xpAmount}
                      onChange={(e) => setXpAmount(e.target.value)}
                      placeholder="Entrez le montant d'XP"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Raison (optionnel)
                    </label>
                    <Textarea
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder="Entrez la raison de l'attribution d'XP"
                      rows={3}
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Annuler
                    </Button>
                    <Button onClick={handleAttributeXP} disabled={awardXPMutation.isPending}>
                      {awardXPMutation.isPending ? "Attribution..." : null}
                      <Trophy className="h-4 w-4 mr-2" />
                      Attribuer XP
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {loadingInscriptions ? (
            <div className="text-center py-8">Chargement des inscriptions...</div>
          ) : !inscriptions || inscriptions.length === 0 ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Aucune inscription pour cet événement.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="grid gap-4">
              {inscriptions.map((inscription: any) => (
                <Card key={inscription.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>
                          {inscription.userName || "Utilisateur inconnu"}
                        </CardTitle>
                        <CardDescription>
                          Inscription #{inscription.id}
                        </CardDescription>
                      </div>
                      <Badge
                        variant={
                          inscription.status === "confirmed"
                            ? "default"
                            : "secondary"
                        }
                      >
                        {inscription.status === "confirmed"
                          ? "Confirmé"
                          : "En attente"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {inscription.personnageId && (
                      <div className="text-sm">
                        <p className="font-semibold mb-1">Personnage:</p>
                        <p className="text-muted-foreground">
                          ID: {inscription.personnageId}
                        </p>
                      </div>
                    )}

                    {inscription.notes && (
                      <div className="bg-muted p-3 rounded text-sm">
                        <p className="font-semibold mb-1">Notes:</p>
                        <p>{inscription.notes}</p>
                      </div>
                    )}

                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedUserId(inscription.id.toString());
                          setIsDialogOpen(true);
                        }}
                      >
                        <Trophy className="h-4 w-4 mr-2" />
                        Attribuer XP
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
