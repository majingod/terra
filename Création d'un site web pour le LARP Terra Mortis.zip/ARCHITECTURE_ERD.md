# Architecture ERD — Terra Mortis Modulaire

## Diagramme Entité-Relation Complet

```mermaid
erDiagram
    USERS ||--o{ PERSONNAGES : crée
    USERS ||--o{ EVENT_INSCRIPTIONS : inscrit
    USERS ||--o{ XP_PERMANENT_HISTORY : accumule
    
    PERSONNAGES ||--o{ EVENT_INSCRIPTIONS : participe
    PERSONNAGES ||--o{ PERSONNAGE_DONS : possede
    PERSONNAGES ||--o{ PERSONNAGE_COMPETENCES : possede
    PERSONNAGES ||--o{ PERSONNAGE_HERITAGE : possede
    
    EVENTS ||--o{ EVENT_INSCRIPTIONS : contient
    
    ENCYCLOPEDIE_ENTRIES ||--o{ ENCYCLOPEDIE_RELATIONS : source
    ENCYCLOPEDIE_ENTRIES ||--o{ ENCYCLOPEDIE_RELATIONS : cible
    ENCYCLOPEDIE_ENTRIES ||--o{ ENCYCLOPEDIE_HISTORY : modifie
    
    PERSONNAGE_DONS ||--o{ ENCYCLOPEDIE_ENTRIES : reference
    PERSONNAGE_COMPETENCES ||--o{ ENCYCLOPEDIE_ENTRIES : reference
    PERSONNAGE_HERITAGE ||--o{ ENCYCLOPEDIE_ENTRIES : reference
```

---

## Tables Existantes (à conserver)

### users
- `id` (PK)
- `email` (unique)
- `name`
- `role` (user, admin)
- `created_at`
- `updated_at`
- **NEW:** `xp_permanent_total` (nombre total d'XP permanent accumulé)

### personnages
- `id` (PK)
- `user_id` (FK → users)
- `name`
- `race_id` (FK → encyclopedie_entries)
- `class_id` (FK → encyclopedie_entries)
- `subclass_id` (FK → encyclopedie_entries)
- `faction` (Sanctum, Légion)
- `puissance`, `resistance`, `esprit` (caractéristiques)
- `background`, `notes`
- **NEW:** `xp_permanent_depense` (XP dépensé sur ce personnage)
- `created_at`, `updated_at`

---

## Nouvelles Tables à Créer

### encyclopedie_entries
Table centrale contenant TOUTES les données du jeu (races, classes, dons, compétences, etc.)

```sql
CREATE TABLE encyclopedie_entries (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  -- Identité
  nom VARCHAR(255) NOT NULL,
  categorie VARCHAR(50) NOT NULL,  -- races, classes, sous_classes, capacites, dons, competences, factions, ressources, materiaux, runes, recettes_alchimie, forge, objets_magiques, regles_combat, symboles, heritage_avantages, heritage_desavantages, langues, armures, caracteristiques
  description LONGTEXT,
  
  -- Propriétés structurées (JSON)
  proprietes JSON,  -- Contient tous les champs spécifiques à la catégorie
  
  -- Relations avec d'autres entrées
  relations JSON,  -- Ex: {"prerequis": [1, 5], "incompatible": [3], "debloque": [7, 8]}
  
  -- Contraintes
  faction_requise VARCHAR(50),  -- null = toutes, "Sanctum", "Légion"
  conditions JSON,  -- Prérequis de niveau, classe, race, etc.
  
  -- Audit
  created_by BIGINT,  -- FK → users
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_by BIGINT,  -- FK → users
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Soft delete
  deleted_at TIMESTAMP NULL,
  
  -- Indices
  INDEX idx_categorie (categorie),
  INDEX idx_faction (faction_requise),
  INDEX idx_nom (nom)
);
```

### encyclopedie_relations
Table pour tracer les relations complexes entre entrées

```sql
CREATE TABLE encyclopedie_relations (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  source_id BIGINT NOT NULL,  -- FK → encyclopedie_entries
  cible_id BIGINT NOT NULL,   -- FK → encyclopedie_entries
  type_relation VARCHAR(50),  -- prerequis, incompatible, debloque, reference, etc.
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX idx_source (source_id),
  INDEX idx_cible (cible_id),
  INDEX idx_type (type_relation)
);
```

### encyclopedie_history
Historique complet des modifications avec possibilité de rollback

```sql
CREATE TABLE encyclopedie_history (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  entry_id BIGINT NOT NULL,  -- FK → encyclopedie_entries
  
  -- Données avant modification
  ancien_contenu JSON,
  nouveau_contenu JSON,
  
  -- Métadonnées
  action VARCHAR(20),  -- create, update, delete
  modified_by BIGINT,  -- FK → users
  modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Raison du changement
  raison VARCHAR(255),
  
  INDEX idx_entry (entry_id),
  INDEX idx_date (modified_at)
);
```

### events
Gestion des événements du LARP

```sql
CREATE TABLE events (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  titre VARCHAR(255) NOT NULL,
  description LONGTEXT,
  date_event DATE NOT NULL,
  lieu VARCHAR(255),
  
  -- Factions concernées (JSON array)
  factions_concernees JSON,  -- ["Sanctum", "Légion"] ou null = toutes
  
  -- Statut
  status VARCHAR(20),  -- a_venir, en_cours, termine, annule
  
  -- Métadonnées
  created_by BIGINT,  -- FK → users (organisateur)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  INDEX idx_date (date_event),
  INDEX idx_status (status)
);
```

### event_inscriptions
Inscriptions des personnages aux événements

```sql
CREATE TABLE event_inscriptions (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  event_id BIGINT NOT NULL,  -- FK → events
  personnage_id BIGINT NOT NULL,  -- FK → personnages
  user_id BIGINT NOT NULL,  -- FK → users (pour faciliter les requêtes)
  
  -- Présence
  present BOOLEAN DEFAULT NULL,  -- null = non validé, true = présent, false = absent
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_inscription (event_id, personnage_id),
  INDEX idx_event (event_id),
  INDEX idx_user (user_id)
);
```

### xp_permanent_history
Historique complet de l'XP permanent avec audit trail

```sql
CREATE TABLE xp_permanent_history (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  user_id BIGINT NOT NULL,  -- FK → users
  
  montant INT NOT NULL,  -- Positif ou négatif
  solde_avant INT,  -- Solde avant cette transaction
  solde_apres INT,  -- Solde après cette transaction
  
  -- Source
  source_type VARCHAR(50),  -- event, admin_adjustment, etc.
  source_id BIGINT,  -- FK → events (si source_type = event)
  
  description VARCHAR(255),  -- Ex: "Événement: Bataille de Ysgard"
  
  -- Métadonnées
  created_by BIGINT,  -- FK → users (qui a créé cette transaction)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX idx_user (user_id),
  INDEX idx_date (created_at),
  INDEX idx_source (source_type)
);
```

### personnage_dons (junction table)
Lien entre personnages et dons

```sql
CREATE TABLE personnage_dons (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  personnage_id BIGINT NOT NULL,  -- FK → personnages
  don_id BIGINT NOT NULL,  -- FK → encyclopedie_entries (categorie = dons)
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_don (personnage_id, don_id),
  INDEX idx_personnage (personnage_id)
);
```

### personnage_competences (junction table)
Lien entre personnages et compétences

```sql
CREATE TABLE personnage_competences (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  personnage_id BIGINT NOT NULL,  -- FK → personnages
  competence_id BIGINT NOT NULL,  -- FK → encyclopedie_entries (categorie = competences)
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_competence (personnage_id, competence_id),
  INDEX idx_personnage (personnage_id)
);
```

### personnage_heritage (junction table)
Lien entre personnages et avantages/désavantages d'héritage

```sql
CREATE TABLE personnage_heritage (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  
  personnage_id BIGINT NOT NULL,  -- FK → personnages
  heritage_id BIGINT NOT NULL,  -- FK → encyclopedie_entries (categorie = heritage_avantages ou heritage_desavantages)
  
  -- Nombre de fois acheté (pour les avantages cumulables)
  nombre INT DEFAULT 1,
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_heritage (personnage_id, heritage_id),
  INDEX idx_personnage (personnage_id)
);
```

---

## Schéma JSON pour les Propriétés

### Races (categorie = races)
```json
{
  "faction": "Sanctum",
  "pv_bonus": 1,
  "mana_bonus": 0,
  "lutte_bonus": 0,
  "capacites_raciales": ["Transfert de Mana 1/heure"],
  "description_physique": "Oreilles pointues, pas de barbe",
  "langues": ["Commun", "Elfe"]
}
```

### Classes (categorie = classes)
```json
{
  "faction": "Toutes",
  "pv_base": 6,
  "mana_base": 1,
  "sous_specialisations": [1, 2, 3],  -- IDs des sous-classes
  "code_conduite": null
}
```

### Sous-classes (categorie = sous_classes)
```json
{
  "classe_parent_id": 1,
  "description": "Maître du combat rapproché",
  "capacites_par_niveau": {
    "1": [10, 11],  -- IDs des capacités niveau 1
    "2": [12, 13],
    "3": [14],
    "4": [15],
    "5": [16]
  }
}
```

### Capacités (categorie = capacites)
```json
{
  "niveau": 1,
  "sous_classe_id": 1,
  "description": "Augmente la puissance de 1",
  "effet": "+1 Lutte"
}
```

### Dons (categorie = dons)
```json
{
  "effet": "+1 Mana (cumulable)",
  "cumulable": true,
  "max_fois": null
}
```

### Compétences (categorie = competences)
```json
{
  "type": "Simple",  -- ou "Artisanat"
  "avantage_base": "+1-2 langue(s), apprend à lire",
  "avantage_avance": "1 information par GN auprès d'un MJ",
  "interdit_enfants": false
}
```

### Héritage Avantages (categorie = heritage_avantages)
```json
{
  "xp_cost": 3,
  "max_times": 1,
  "effet": "+1 Capacité de niveau 1",
  "debloque": "capacites_bonus_niveau_1",
  "extraAbilitiesLevel1": 1,
  "extraAbilitiesLevel2": 0
}
```

### Héritage Désavantages (categorie = heritage_desavantages)
```json
{
  "xp_gain": 3,
  "description": "Manque un bras ou une jambe",
  "restrictions": ["Paladin", "CdM"],  -- Classes interdites
  "effet": "Perte d'une main"
}
```

---

## Flux de Données Principaux

### 1. Création d'un Personnage
```
User → Générateur → encyclopedie_entries (races, classes, dons, etc.)
                  ↓
              personnages (insert)
              personnage_dons (insert)
              personnage_competences (insert)
              personnage_heritage (insert)
              xp_permanent_history (insert si XP dépensé)
```

### 2. Modification de l'Encyclopédie (Admin)
```
Admin → Modification → encyclopedie_entries (update)
                    ↓
                encyclopedie_history (insert audit)
                ↓
            Tous les générateurs rechargent les données
            Toutes les fiches de personnages se mettent à jour automatiquement
```

### 3. Événement avec Attribution d'XP
```
Admin → Crée événement → events (insert)
                      ↓
                Joueurs s'inscrivent → event_inscriptions (insert)
                      ↓
                Admin clôt l'événement → event_inscriptions (update present)
                                      ↓
                                  xp_permanent_history (insert)
                                  users.xp_permanent_total (update)
```

---

## Stratégie de Migration

### Étape 1 : Préparation
1. Créer les nouvelles tables dans la base de données
2. Créer les indices pour la performance
3. Sauvegarder les données existantes

### Étape 2 : Migration des Données
1. Migrer les races existantes vers `encyclopedie_entries`
2. Migrer les classes et sous-classes
3. Migrer les capacités avec leurs relations
4. Migrer les dons, compétences, héritage
5. Ajouter les nouvelles catégories (ressources, matériaux, runes, etc.)

### Étape 3 : Validation
1. Vérifier l'intégrité des données migrées
2. Tester les relations croisées
3. Valider les contraintes de faction/race/classe
4. Tester la performance des requêtes

### Étape 4 : Rollback Plan
- Garder les anciennes tables pendant 2 semaines
- Créer des vues pour la compatibilité rétroactive
- Pouvoir revenir rapidement si problème

---

## Performance et Indices

| Table | Indices | Raison |
|-------|---------|--------|
| encyclopedie_entries | categorie, faction_requise, nom | Recherche et filtrage fréquents |
| encyclopedie_relations | source_id, cible_id, type_relation | Traversée de graphe |
| encyclopedie_history | entry_id, modified_at | Audit trail et rollback |
| events | date_event, status | Filtrage des événements |
| event_inscriptions | event_id, user_id | Requêtes d'inscription |
| xp_permanent_history | user_id, created_at, source_type | Historique et audit |

---

## Dépendances Entre Modules

```
encyclopedie_entries (source unique)
    ↓
    ├─→ Générateur de Personnage (charge races, classes, dons, etc.)
    ├─→ Pages de Règles (affiche les entrées)
    ├─→ Fiches de Personnage (affiche les données du perso)
    └─→ Admin (CRUD sur les entrées)

events + event_inscriptions
    ↓
    ├─→ Page Événements (affiche les événements)
    ├─→ Profil Joueur (affiche les inscriptions)
    └─→ Admin Événements (gère les événements)

xp_permanent_history
    ↓
    ├─→ Profil Joueur (affiche le solde et l'historique)
    └─→ Générateur (utilise l'XP pour acheter des avantages)
```

