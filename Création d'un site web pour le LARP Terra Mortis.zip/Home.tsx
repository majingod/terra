import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { TerraMortisDivider } from "@/components/TerraMortisDivider";
import { BookOpen, ChevronRight, Shield, Skull, Swords, Users, Wand2 } from "lucide-react";
import { Link } from "wouter";

const features = [
  {
    icon: BookOpen,
    title: "Règles complètes",
    description: "Consultez toutes les règles du GN : races, classes, dons, compétences, magie et héritage.",
    href: "/regles",
    color: "oklch(0.65 0.18 45)",
  },
  {
    icon: Users,
    title: "6 Races jouables",
    description: "Humain, Elfe, Nain, Orc, Drow, Gobelin — chacune avec ses capacités uniques et sa faction.",
    href: "/regles/races",
    color: "oklch(0.55 0.18 240)",
  },
  {
    icon: Swords,
    title: "8 Classes de combat",
    description: "Druide, Guerrier, Magicien, Roublard, Chevalier de la mort, Sorcier, Medjai, Paladin.",
    href: "/regles/classes",
    color: "oklch(0.5 0.22 25)",
  },
  {
    icon: Wand2,
    title: "Créateur de personnage",
    description: "Créez votre personnage étape par étape avec un guide détaillé et un résumé complet.",
    href: "/creer-personnage",
    color: "oklch(0.45 0.15 140)",
    requiresAuth: true,
  },
];

const factions = [
  {
    name: "Sanctum",
    description: "Les races et individus de Sanctum proviennent de civilisations avancées. Leur force réside dans l'union, la persévérance et l'organisation. En général, les membres de cette faction sont bienveillants, ayant tendance à penser aux besoins des autres avant les leurs.",
    races: ["Humain", "Elfe", "Nain"],
    classes: ["Druide", "Guerrier", "Magicien", "Roublard", "Medjai", "Paladin"],
    color: "oklch(0.55 0.18 240)",
    borderColor: "oklch(0.55 0.18 240)",
    icon: Shield,
  },
  {
    name: "Légion",
    description: "La Légion regroupe les races et individus souillés par une forme de corruption. Leur force réside dans le nombre, la brutalité et la volonté de tout faire pour l'emporter. En général, les membres de cette faction sont malveillants, ayant tendance à penser à leurs besoins avant ceux des autres.",
    races: ["Humain", "Orc", "Drow", "Gobelin"],
    classes: ["Druide", "Guerrier", "Magicien", "Roublard", "Chevalier de la Mort", "Sorcier"],
    color: "oklch(0.5 0.22 25)",
    borderColor: "oklch(0.5 0.22 25)",
    icon: Skull,
  },
];

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen">
      {/* ─── Hero Section ────────────────────────────────────────────────────── */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0"
            style={{
              background: "radial-gradient(ellipse at center, oklch(0.2 0.04 270 / 0.4) 0%, transparent 70%)",
            }} />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.65 0.18 45)" }} />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.5 0.22 25)" }} />
          {/* Decorative runes */}
          <div className="absolute top-10 left-10 text-6xl opacity-5 font-heading select-none">ᚠ</div>
          <div className="absolute top-20 right-20 text-4xl opacity-5 font-heading select-none">ᚢ</div>
          <div className="absolute bottom-20 left-20 text-5xl opacity-5 font-heading select-none">ᚦ</div>
          <div className="absolute bottom-10 right-10 text-7xl opacity-5 font-heading select-none">ᚨ</div>
        </div>

        <div className="container relative z-10 text-center py-20">
          {/* Skull icon */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="w-24 h-24 rounded-full flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.2), oklch(0.45 0.15 30 / 0.1))",
                  border: "2px solid oklch(0.65 0.18 45 / 0.4)",
                  boxShadow: "0 0 40px oklch(0.65 0.18 45 / 0.2)",
                }}>
                <Skull className="w-12 h-12" style={{ color: "oklch(0.82 0.2 85)" }} />
              </div>
            </div>
          </div>

          {/* Title */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-black mb-4 leading-tight"
            style={{
              background: "linear-gradient(135deg, oklch(0.82 0.2 85), oklch(0.65 0.18 45), oklch(0.82 0.2 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              textShadow: "none",
            }}>
            TERRA MORTIS
          </h1>

          <p className="text-xl md:text-2xl font-heading text-muted-foreground mb-2 tracking-widest uppercase">
            Grandeur Nature — Stukely-Sud
          </p>

          {/* Decorative divider */}
          <div className="flex items-center justify-center gap-4 my-8">
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>

          {/* Lore intro */}
          <p className="text-lg md:text-xl max-w-3xl mx-auto text-foreground/80 mb-10 leading-relaxed"
            style={{ fontFamily: "'Crimson Text', serif", fontStyle: "italic" }}>
            Vous êtes mort. L'après-vie est extrêmement chaotique depuis la destruction de la balance.
            Deux factions s'affrontent pour le droit d'accéder à Ysgard, le paradis des guerriers.
            Quelle sera votre destinée dans les plaines de Terra Mortis ?
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/regles">
              <Button size="lg" className="font-heading tracking-wide text-base px-8 py-6"
                style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}>
                <BookOpen className="w-5 h-5 mr-2" />
                Consulter les règles
              </Button>
            </Link>
            {isAuthenticated ? (
              <Link href="/creer-personnage">
                <Button size="lg" variant="outline" className="font-heading tracking-wide text-base px-8 py-6 border-2"
                  style={{ borderColor: "oklch(0.65 0.18 45 / 0.5)", color: "oklch(0.82 0.2 85)" }}>
                  <Swords className="w-5 h-5 mr-2" />
                  Créer mon personnage
                </Button>
              </Link>
            ) : (
              <Button size="lg" variant="outline" className="font-heading tracking-wide text-base px-8 py-6 border-2"
                style={{ borderColor: "oklch(0.65 0.18 45 / 0.5)", color: "oklch(0.82 0.2 85)" }}
                onClick={() => window.location.href = getLoginUrl()}>
                <Swords className="w-5 h-5 mr-2" />
                Créer mon personnage
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* ─── Features Grid ───────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <TerraMortisHeading level={2} gradient="gold" className="text-3xl md:text-4xl text-center mb-4">
            Tout ce dont vous avez besoin
          </TerraMortisHeading>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Le site officiel de Terra Mortis vous offre toutes les ressources pour préparer votre aventure.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Link key={feature.href} href={feature.requiresAuth && !isAuthenticated ? "#" : feature.href}>
                <div className="group relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300 cursor-pointer h-full"
                  style={{
                    boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLDivElement).style.boxShadow = `0 0 30px ${feature.color}30, 0 4px 20px oklch(0 0 0 / 0.4)`;
                    (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)";
                    (e.currentTarget as HTMLDivElement).style.borderColor = `${feature.color}60`;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLDivElement).style.boxShadow = "0 2px 20px oklch(0 0 0 / 0.3)";
                    (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
                    (e.currentTarget as HTMLDivElement).style.borderColor = "";
                  }}>
                  <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                    style={{ background: `${feature.color}20`, border: `1px solid ${feature.color}40` }}>
                    <feature.icon className="w-6 h-6" style={{ color: feature.color }} />
                  </div>
                  <TerraMortisHeading level={3} className="text-lg mb-2">
                    {feature.title}
                  </TerraMortisHeading>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                  {feature.requiresAuth && !isAuthenticated && (
                    <p className="text-xs mt-3" style={{ color: "oklch(0.65 0.18 45)" }}>
                      Connexion requise
                    </p>
                  )}
                  <ChevronRight className="w-4 h-4 absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ color: feature.color }} />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Factions ────────────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <TerraMortisHeading level={2} gradient="gold" className="text-3xl md:text-4xl text-center mb-4">
            Les deux factions
          </TerraMortisHeading>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Chaque personnage appartient à l'une des deux factions qui s'affrontent pour la victoire.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {factions.map((faction) => (
              <div key={faction.name} className="relative p-8 rounded-xl border bg-card/30"
                style={{ borderColor: `${faction.color}50` }}>
                <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl"
                  style={{ background: `linear-gradient(to right, transparent, ${faction.color}, transparent)` }} />

                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{ background: `${faction.color}20`, border: `2px solid ${faction.color}50` }}>
                    <faction.icon className="w-6 h-6" style={{ color: faction.color }} />
                  </div>
                  <div style={{ color: faction.color }}>
                    <TerraMortisHeading level={3} className="text-2xl">
                      {faction.name}
                    </TerraMortisHeading>
                  </div>
                </div>

                <p className="text-foreground/80 mb-6 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                  {faction.description}
                </p>

                <div className="space-y-4">
                  {/* Races */}
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">
                      Races disponibles
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {faction.races.map((race) => (
                        <span key={race} className="px-2 py-1 rounded text-xs font-heading"
                          style={{
                            background: `${faction.color}15`,
                            border: `1px solid ${faction.color}30`,
                            color: faction.color,
                          }}>
                          {race}
                        </span>
                      ))}
                    </div>
                  </div>
                  {/* Classes */}
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">
                      Classes disponibles
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {faction.classes.map((cls) => (
                        <span key={cls} className="px-2 py-1 rounded text-xs font-heading"
                          style={{
                            background: `${faction.color}08`,
                            border: `1px dashed ${faction.color}40`,
                            color: `${faction.color}`,
                          }}>
                          {cls}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA Section ─────────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container text-center">
          <div className="max-w-2xl mx-auto p-10 rounded-2xl border border-border/50 bg-card/20"
            style={{ boxShadow: "0 0 60px oklch(0.65 0.18 45 / 0.05)" }}>
            <Skull className="w-12 h-12 mx-auto mb-4" style={{ color: "oklch(0.82 0.2 85)" }} />
            <h2 className="text-3xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
              Prêt à rejoindre l'aventure ?
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Connectez-vous pour créer votre personnage, gérer votre fiche et préparer votre prochain événement Terra Mortis à Stukely-Sud.
            </p>
            {!isAuthenticated ? (
              <Button size="lg" className="font-heading tracking-wide text-base px-10 py-6"
                style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}
                onClick={() => window.location.href = getLoginUrl()}>
                Se connecter maintenant
              </Button>
            ) : (
              <Link href="/creer-personnage">
                <Button size="lg" className="font-heading tracking-wide text-base px-10 py-6"
                  style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}>
                  <Swords className="w-5 h-5 mr-2" />
                  Créer mon personnage
                </Button>
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* ─── Footer ──────────────────────────────────────────────────────────── */}
      <footer className="border-t border-border/30 py-8">
        <div className="container text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <span className="font-heading text-sm" style={{ color: "oklch(0.65 0.18 45)" }}>
              Terra Mortis
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            Grandeur Nature — Stukely-Sud, Québec · Tome des règles V1.2
          </p>
        </div>
      </footer>
    </div>
  );
}
