import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import Breadcrumbs from "@/components/Breadcrumbs";
import { Calendar, MapPin, Users, Clock, Skull, Shield, Swords, ArrowLeft, Check, X, Loader2 } from "lucide-react";
import { Link, useParams } from "wouter";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useState, useMemo } from "react";
import { toast } from "sonner";

export default function EvenementDetail() {
  const params = useParams<{ id: string }>();
  const eventId = parseInt(params.id || "0");
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const { data: evt, isLoading } = trpc.evenements.getById.useQuery({ id: eventId }, { enabled: eventId > 0 });
  const { data: inscription } = trpc.inscriptions.check.useQuery({ evenementId: eventId }, { enabled: isAuthenticated && eventId > 0 });
  const { data: mesPersonnages } = trpc.personnages.myPersonnages.useQuery(undefined, { enabled: isAuthenticated });

  const [selectedPersonnageId, setSelectedPersonnageId] = useState<number | undefined>();
  const [notes, setNotes] = useState("");

  const registerMutation = trpc.inscriptions.register.useMutation({
    onSuccess: () => {
      toast.success("Inscription confirmée !");
      utils.inscriptions.check.invalidate({ evenementId: eventId });
      utils.evenements.getById.invalidate({ id: eventId });
    },
    onError: (err) => toast.error(err.message),
  });

  const cancelMutation = trpc.inscriptions.cancel.useMutation({
    onSuccess: () => {
      toast.success("Inscription annulée.");
      utils.inscriptions.check.invalidate({ evenementId: eventId });
      utils.evenements.getById.invalidate({ id: eventId });
    },
    onError: (err) => toast.error(err.message),
  });

  const isRegistered = inscription && inscription.status !== "cancelled";
  const isFull = evt && evt.maxPlayers > 0 && evt.inscriptionCount >= evt.maxPlayers;
  const isPast = evt && new Date(evt.endDate) < new Date();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!evt) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Skull className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-40" />
          <h2 className="text-2xl font-heading font-bold mb-2">Événement introuvable</h2>
          <Link href="/evenements">
            <Button variant="outline" className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" /> Retour aux événements
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* ─── Hero ─────────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0"
            style={{ background: "radial-gradient(ellipse at center, oklch(0.2 0.04 270 / 0.4) 0%, transparent 70%)" }} />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.65 0.18 45)" }} />
        </div>

        <div className="container relative z-10 py-12">
          <Breadcrumbs items={[
            { label: "Événements", href: "/evenements" },
            { label: evt.title },
          ]} />

          <Link href="/evenements">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4 mr-2" /> Retour aux événements
            </Button>
          </Link>

          <div className="flex flex-wrap items-center gap-3 mb-4">
            {evt.status === "published" && !isPast && (
              <span className="text-xs px-3 py-1 rounded-full font-medium"
                style={{ background: "oklch(0.35 0.12 145)", border: "1px solid oklch(0.45 0.15 145)", color: "oklch(0.85 0.05 85)" }}>
                Ouvert aux inscriptions
              </span>
            )}
            {isPast && (
              <span className="text-xs px-3 py-1 rounded-full font-medium bg-muted text-muted-foreground">
                Événement terminé
              </span>
            )}
            {evt.faction !== "Tous" && (
              <span className="flex items-center gap-1.5 text-xs px-3 py-1 rounded-full"
                style={{
                  background: evt.faction === "Sanctum" ? "oklch(0.25 0.08 240)" : "oklch(0.25 0.08 25)",
                  border: `1px solid ${evt.faction === "Sanctum" ? "oklch(0.35 0.12 240)" : "oklch(0.35 0.12 25)"}`,
                }}>
                {evt.faction === "Sanctum" ? <Shield className="w-3.5 h-3.5" /> : <Skull className="w-3.5 h-3.5" />}
                {evt.faction}
              </span>
            )}
          </div>

          <h1 className="text-3xl md:text-5xl font-heading font-black mb-6"
            style={{
              background: "linear-gradient(135deg, oklch(0.82 0.2 85), oklch(0.65 0.18 45))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
            {evt.title}
          </h1>
        </div>
      </section>

      {/* ─── Content ──────────────────────────────────────────────────────────── */}
      <section className="container py-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="md:col-span-2 space-y-8">
            {/* Description */}
            <div className="rounded-xl border border-border/40 p-6"
              style={{ background: "linear-gradient(135deg, oklch(0.18 0.01 270 / 0.8), oklch(0.15 0.02 30 / 0.5))" }}>
              <h2 className="text-xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
                Description
              </h2>
              <div className="text-foreground/80 whitespace-pre-wrap leading-relaxed">
                {evt.description}
              </div>
            </div>

            {/* Inscription section */}
            {isAuthenticated && !isPast && evt.status === "published" && (
              <div className="rounded-xl border border-border/40 p-6"
                style={{ background: "linear-gradient(135deg, oklch(0.18 0.02 45 / 0.5), oklch(0.15 0.01 270 / 0.5))" }}>
                <h2 className="text-xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
                  {isRegistered ? "Vous êtes inscrit !" : "Inscription"}
                </h2>

                {isRegistered ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 rounded-lg"
                      style={{ background: "oklch(0.25 0.08 145 / 0.3)", border: "1px solid oklch(0.35 0.12 145 / 0.4)" }}>
                      <Check className="w-6 h-6" style={{ color: "oklch(0.65 0.18 145)" }} />
                      <div>
                        <p className="font-medium text-foreground">Inscription confirmée</p>
                        <p className="text-sm text-muted-foreground">Vous êtes inscrit à cet événement.</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm"
                      onClick={() => cancelMutation.mutate({ evenementId: eventId })}
                      disabled={cancelMutation.isPending}
                      className="text-red-400 border-red-400/30 hover:bg-red-400/10">
                      {cancelMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <X className="w-4 h-4 mr-2" />}
                      Annuler mon inscription
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {isFull ? (
                      <div className="p-4 rounded-lg text-center"
                        style={{ background: "oklch(0.25 0.08 25 / 0.3)", border: "1px solid oklch(0.35 0.12 25 / 0.4)" }}>
                        <p className="font-medium text-red-400">Événement complet</p>
                        <p className="text-sm text-muted-foreground mt-1">Toutes les places sont prises.</p>
                      </div>
                    ) : (
                      <>
                        {mesPersonnages && mesPersonnages.length > 0 && (
                          <div>
                            <label className="block text-sm font-medium text-muted-foreground mb-2">
                              Personnage (optionnel)
                            </label>
                            <select
                              className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                              value={selectedPersonnageId || ""}
                              onChange={(e) => setSelectedPersonnageId(e.target.value ? parseInt(e.target.value) : undefined)}
                            >
                              <option value="">Aucun personnage sélectionné</option>
                              {mesPersonnages.map((p: any) => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                              ))}
                            </select>
                          </div>
                        )}

                        <div>
                          <label className="block text-sm font-medium text-muted-foreground mb-2">
                            Notes (optionnel)
                          </label>
                          <textarea
                            className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground resize-none"
                            rows={3}
                            placeholder="Allergies, besoins spéciaux, questions..."
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                          />
                        </div>

                        <Button
                          onClick={() => registerMutation.mutate({
                            evenementId: eventId,
                            personnageId: selectedPersonnageId,
                            notes: notes || undefined,
                          })}
                          disabled={registerMutation.isPending}
                          className="w-full font-heading text-lg py-3"
                          style={{
                            background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.5 0.22 25))",
                            color: "oklch(0.98 0 0)",
                          }}>
                          {registerMutation.isPending ? (
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          ) : (
                            <Check className="w-5 h-5 mr-2" />
                          )}
                          S'inscrire à l'événement
                        </Button>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}

            {!isAuthenticated && !isPast && (
              <div className="rounded-xl border border-border/40 p-6 text-center"
                style={{ background: "linear-gradient(135deg, oklch(0.18 0.02 45 / 0.5), oklch(0.15 0.01 270 / 0.5))" }}>
                <p className="text-muted-foreground mb-4">Connectez-vous pour vous inscrire à cet événement.</p>
                <a href={getLoginUrl()}>
                  <Button className="font-heading"
                    style={{
                      background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.5 0.22 25))",
                      color: "oklch(0.98 0 0)",
                    }}>
                    Se connecter
                  </Button>
                </a>
              </div>
            )}
          </div>

          {/* Sidebar info */}
          <div className="space-y-6">
            <div className="rounded-xl border border-border/40 p-6"
              style={{ background: "linear-gradient(135deg, oklch(0.18 0.01 270 / 0.8), oklch(0.15 0.02 30 / 0.5))" }}>
              <h3 className="text-lg font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
                Informations
              </h3>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: "oklch(0.65 0.18 45)" }} />
                  <div>
                    <p className="text-sm font-medium text-foreground">Date de début</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(evt.startDate), "EEEE d MMMM yyyy 'à' HH:mm", { locale: fr })}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: "oklch(0.65 0.18 45)" }} />
                  <div>
                    <p className="text-sm font-medium text-foreground">Date de fin</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(evt.endDate), "EEEE d MMMM yyyy 'à' HH:mm", { locale: fr })}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: "oklch(0.65 0.18 45)" }} />
                  <div>
                    <p className="text-sm font-medium text-foreground">Lieu</p>
                    <p className="text-sm text-muted-foreground">{evt.location}</p>
                  </div>
                </div>

                {evt.maxPlayers > 0 && (
                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: "oklch(0.65 0.18 45)" }} />
                    <div>
                      <p className="text-sm font-medium text-foreground">Places</p>
                      <p className="text-sm text-muted-foreground">
                        {evt.inscriptionCount} / {evt.maxPlayers} inscrits
                      </p>
                      {/* Progress bar */}
                      <div className="w-full h-2 rounded-full mt-2" style={{ background: "oklch(0.2 0.01 270)" }}>
                        <div className="h-full rounded-full transition-all"
                          style={{
                            width: `${Math.min(100, (evt.inscriptionCount / evt.maxPlayers) * 100)}%`,
                            background: isFull
                              ? "oklch(0.5 0.22 25)"
                              : "linear-gradient(90deg, oklch(0.65 0.18 45), oklch(0.82 0.2 85))",
                          }} />
                      </div>
                    </div>
                  </div>
                )}

                {evt.price && (
                  <div className="flex items-start gap-3">
                    <span className="w-5 h-5 mt-0.5 flex-shrink-0 text-center font-bold" style={{ color: "oklch(0.65 0.18 45)" }}>$</span>
                    <div>
                      <p className="text-sm font-medium text-foreground">Prix</p>
                      <p className="text-sm text-muted-foreground">{evt.price}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
