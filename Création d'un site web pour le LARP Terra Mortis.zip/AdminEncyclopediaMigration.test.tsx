import { describe, it, expect, vi, beforeEach } from "vitest";
import AdminEncyclopediaMigration from "./AdminEncyclopediaMigration";

// Mock tRPC
vi.mock("@/lib/trpc", () => ({
  trpc: {
    migration: {
      getStatus: {
        useQuery: vi.fn(),
      },
      migrateRaces: {
        useMutation: vi.fn(),
      },
      migrateClasses: {
        useMutation: vi.fn(),
      },
      migrateDons: {
        useMutation: vi.fn(),
      },
      migrateCompetences: {
        useMutation: vi.fn(),
      },
      migrateHeritages: {
        useMutation: vi.fn(),
      },
      migrateDesavantages: {
        useMutation: vi.fn(),
      },
    },
  },
}));

const mockStatus = {
  races: 10,
  classes: 5,
  classPaths: 0,
  classAbilities: 0,
  dons: 20,
  competences: 15,
  heritages: 8,
  desavantages: 12,
  encyclopediaTotal: 70,
  categories: {
    races: 10,
    classes: 5,
    sous_classes: 0,
    capacites: 0,
    dons: 20,
    competences: 15,
    heritage_avantages: 8,
    heritage_desavantages: 12,
  },
};

const mockStatusPartial = {
  races: 10,
  classes: 5,
  classPaths: 0,
  classAbilities: 0,
  dons: 20,
  competences: 15,
  heritages: 8,
  desavantages: 12,
  encyclopediaTotal: 70,
  categories: {
    races: 5,
    classes: 2,
    sous_classes: 0,
    capacites: 0,
    dons: 10,
    competences: 7,
    heritage_avantages: 4,
    heritage_desavantages: 6,
  },
};

describe("AdminEncyclopediaMigration Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should be importable", () => {
    expect(AdminEncyclopediaMigration).toBeDefined();
    expect(typeof AdminEncyclopediaMigration).toBe("function");
  });

  it("should have correct component structure", () => {
    const component = AdminEncyclopediaMigration;
    expect(component).toHaveProperty("$$typeof");
  });

  it("should render without errors", () => {
    // Component should be a valid React component
    expect(AdminEncyclopediaMigration.length).toBeGreaterThanOrEqual(0);
  });

  it("should have correct display name", () => {
    expect(AdminEncyclopediaMigration.name).toBe("AdminEncyclopediaMigration");
  });

  it("should accept no props", () => {
    // Component is a functional component with no required props
    expect(AdminEncyclopediaMigration).toBeDefined();
  });

  it("should have migration status structure", () => {
    // Verify the mock status structure
    expect(mockStatus).toHaveProperty("races");
    expect(mockStatus).toHaveProperty("classes");
    expect(mockStatus).toHaveProperty("dons");
    expect(mockStatus).toHaveProperty("competences");
    expect(mockStatus).toHaveProperty("heritages");
    expect(mockStatus).toHaveProperty("desavantages");
    expect(mockStatus).toHaveProperty("categories");
  });

  it("should have correct category counts in mock status", () => {
    expect(mockStatus.categories.races).toBe(10);
    expect(mockStatus.categories.classes).toBe(5);
    expect(mockStatus.categories.dons).toBe(20);
    expect(mockStatus.categories.competences).toBe(15);
    expect(mockStatus.categories.heritage_avantages).toBe(8);
    expect(mockStatus.categories.heritage_desavantages).toBe(12);
  });

  it("should calculate partial migration progress correctly", () => {
    const totalLegacy =
      mockStatusPartial.races +
      mockStatusPartial.classes +
      mockStatusPartial.dons +
      mockStatusPartial.competences +
      mockStatusPartial.heritages +
      mockStatusPartial.desavantages;

    const totalMigrated =
      mockStatusPartial.categories.races +
      mockStatusPartial.categories.classes +
      mockStatusPartial.categories.dons +
      mockStatusPartial.categories.competences +
      mockStatusPartial.categories.heritage_avantages +
      mockStatusPartial.categories.heritage_desavantages;

    expect(totalLegacy).toBe(70);
    expect(totalMigrated).toBe(34);
    expect(Math.round((totalMigrated / totalLegacy) * 100)).toBe(49);
  });
});
