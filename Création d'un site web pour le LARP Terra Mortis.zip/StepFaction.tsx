import { Shield, Skull } from "lucide-react";

interface StepFactionProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepFaction({ charData, onCharDataChange }: StepFactionProps) {
  const factions = [
    {
      id: "Sanctum",
      name: "Sanctum",
      description: "Les races et individus de Sanctum proviennent de civilisations avancées.",
      icon: Shield,
      color: "oklch(0.55 0.18 240)",
    },
    {
      id: "Légion",
      name: "Légion",
      description: "La Légion regroupe les races et individus souillés par une forme de corruption.",
      icon: Skull,
      color: "oklch(0.5 0.22 25)",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {factions.map((faction) => {
        const IconComponent = faction.icon;
        const isSelected = charData.faction === faction.id;

        return (
          <div
            key={faction.id}
            onClick={() => onCharDataChange({ ...charData, faction: faction.id })}
            className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
              isSelected
                ? "border-primary bg-primary/10"
                : "border-border hover:border-primary/50"
            }`}
            style={isSelected ? { borderColor: faction.color } : {}}
          >
            <div className="flex items-center gap-4 mb-4">
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center"
                style={{ background: `${faction.color}20` }}
              >
                <IconComponent className="w-6 h-6" style={{ color: faction.color }} />
              </div>
              <h3 className="text-xl font-bold">{faction.name}</h3>
            </div>
            <p className="text-sm text-muted-foreground">{faction.description}</p>
          </div>
        );
      })}
    </div>
  );
}
