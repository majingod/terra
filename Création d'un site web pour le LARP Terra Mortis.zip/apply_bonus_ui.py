#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/StepVoieEtDons.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Remplacer la section niveau 1
old_level1 = '''            {extraAbilities.level1 > 0 && level1Abilities.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>Niveau 1 ({level1Abilities.length} disponibles)</h4>
                <div className="space-y-2">
                  {level1Abilities.map((ability) => (
                    <div key={ability.id} className="p-3 rounded-lg bg-background/50 border border-border/20">
                      <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                      <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}'''

new_level1 = '''            {extraAbilities.level1 > 0 && level1Abilities.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 1 ({countSelectedByLevel(data.selectedBonusAbilities, 1, level1Abilities)}/{extraAbilities.level1})
                </h4>
                <div className="space-y-2">
                  {level1Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    const canSelect = canSelectBonusAbility(ability.id, 1, data.selectedBonusAbilities, extraAbilities, level1Abilities);
                    return (
                      <label key={ability.id} className="flex items-start gap-3 p-3 rounded-lg bg-background/50 border border-border/20 cursor-pointer hover:bg-background/70 transition-colors"
                        style={{ opacity: canSelect || isSelected ? 1 : 0.5 }}>
                        <input type="checkbox" checked={isSelected} onChange={() => {
                          if (canSelect || isSelected) {
                            data.onChange({ selectedBonusAbilities: toggleBonusAbility(ability.id, data.selectedBonusAbilities) });
                          }
                        }} disabled={!canSelect && !isSelected} className="mt-0.5 w-4 h-4 rounded cursor-pointer" />
                        <div className="flex-1">
                          <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                          <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}'''

content = content.replace(old_level1, new_level1)
print("✓ Niveau 1 modifié")

# Remplacer la section niveau 2
old_level2 = '''            {extraAbilities.level2 > 0 && level2Abilities.length > 0 && (
              <div>
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>Niveau 2 ({level2Abilities.length} disponibles)</h4>
                <div className="space-y-2">
                  {level2Abilities.map((ability) => (
                    <div key={ability.id} className="p-3 rounded-lg bg-background/50 border border-border/20">
                      <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                      <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}'''

new_level2 = '''            {extraAbilities.level2 > 0 && level2Abilities.length > 0 && (
              <div>
                <h4 className="text-sm font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
                  Niveau 2 ({countSelectedByLevel(data.selectedBonusAbilities, 2, level2Abilities)}/{extraAbilities.level2})
                </h4>
                <div className="space-y-2">
                  {level2Abilities.map((ability) => {
                    const isSelected = data.selectedBonusAbilities.includes(ability.id);
                    const canSelect = canSelectBonusAbility(ability.id, 2, data.selectedBonusAbilities, extraAbilities, level2Abilities);
                    return (
                      <label key={ability.id} className="flex items-start gap-3 p-3 rounded-lg bg-background/50 border border-border/20 cursor-pointer hover:bg-background/70 transition-colors"
                        style={{ opacity: canSelect || isSelected ? 1 : 0.5 }}>
                        <input type="checkbox" checked={isSelected} onChange={() => {
                          if (canSelect || isSelected) {
                            data.onChange({ selectedBonusAbilities: toggleBonusAbility(ability.id, data.selectedBonusAbilities) });
                          }
                        }} disabled={!canSelect && !isSelected} className="mt-0.5 w-4 h-4 rounded cursor-pointer" />
                        <div className="flex-1">
                          <p className="text-xs font-heading font-semibold text-foreground">{ability.name}</p>
                          <p className="text-xs text-foreground/65 mt-1">{ability.description}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}'''

content = content.replace(old_level2, new_level2)
print("✓ Niveau 2 modifié")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/StepVoieEtDons.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
