import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface UseValidateHeritageOptions {
  raceId?: number;
  classId?: number;
  level?: number;
  selectedHeritages?: number[];
  showToasts?: boolean;
}

export function useValidateHeritage() {
  const [validationResults, setValidationResults] = useState<Map<number, ValidationResult>>(new Map());
  const [isValidating, setIsValidating] = useState(false);

  const validateHeritage = useCallback(
    async (heritageId: number, options: UseValidateHeritageOptions = {}) => {
      const { showToasts = true } = options;
      setIsValidating(true);

      try {
        // Appeler la procédure tRPC de validation
        const result = await new Promise<ValidationResult>((resolve) => {
          fetch("/api/trpc/validation.validateHeritage", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              heritageId,
              raceId: options.raceId,
              classId: options.classId,
              level: options.level,
              selectedHeritages: options.selectedHeritages,
            }),
          })
            .then((res) => res.json())
            .then((data) => {
              const result = data.result || { isValid: true, errors: [], warnings: [] };
              resolve(result);
            })
            .catch(() => {
              resolve({ isValid: true, errors: [], warnings: [] });
            });
        });

        // Stocker le résultat
        setValidationResults((prev) => new Map(prev).set(heritageId, result));

        // Afficher les toasts si demandé
        if (showToasts) {
          if (!result.isValid && result.errors.length > 0) {
            result.errors.forEach((error) => {
              toast.error(error);
            });
          }
          if (result.warnings.length > 0) {
            result.warnings.forEach((warning) => {
              toast.warning(warning);
            });
          }
        }

        return result;
      } catch (error) {
        console.error("Erreur lors de la validation de l'héritage:", error);
        const errorResult: ValidationResult = {
          isValid: false,
          errors: ["Erreur lors de la validation"],
          warnings: [],
        };
        setValidationResults((prev) => new Map(prev).set(heritageId, errorResult));
        if (showToasts) {
          toast.error("Erreur lors de la validation de l'héritage");
        }
        return errorResult;
      } finally {
        setIsValidating(false);
      }
    },
    []
  );

  const getValidationResult = useCallback(
    (heritageId: number): ValidationResult | undefined => {
      return validationResults.get(heritageId);
    },
    [validationResults]
  );

  const clearValidation = useCallback((heritageId?: number) => {
    if (heritageId) {
      setValidationResults((prev) => {
        const newMap = new Map(prev);
        newMap.delete(heritageId);
        return newMap;
      });
    } else {
      setValidationResults(new Map());
    }
  }, []);

  return {
    validateHeritage,
    getValidationResult,
    clearValidation,
    isValidating,
    validationResults,
  };
}
