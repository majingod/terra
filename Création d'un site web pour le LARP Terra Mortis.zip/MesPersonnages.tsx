import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { FactionBadge } from "@/components/FactionBadge";
import { TerraMortisCard } from "@/components/TerraMortisCard";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { toast } from "sonner";
import { useState } from "react";
import { Link } from "wouter";
import {
  Loader2, Lock, Plus, User, Sword, Shield, Trash2, Eye, ChevronRight, Skull
} from "lucide-react";

export default function MesPersonnages() {
  const { isAuthenticated, loading } = useAuth();
  const { data: personnages, isLoading, refetch } = trpc.personnages.myPersonnages.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const deleteMutation = trpc.personnages.delete.useMutation({
    onSuccess: () => { toast.success("Personnage supprimé."); refetch(); },
    onError: (err) => toast.error("Erreur : " + err.message),
  });
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}>
            <Lock className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
          </div>
          <h2 className="text-2xl font-heading font-bold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
            Connexion requise
          </h2>
          <p className="text-muted-foreground mb-6">Vous devez être connecté pour voir vos personnages.</p>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            className="font-heading"
            style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}
          >
            Se connecter
          </Button>
        </div>
      </div>
    );
  }

  const factionColor = (faction: string) => {
    if (faction === "Sanctum") return "oklch(0.55 0.18 240)";
    if (faction === "Légion") return "oklch(0.5 0.22 25)";
    return "oklch(0.65 0.18 45)";
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-5xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground transition-colors">Accueil</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Mes personnages</span>
        </nav>

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <TerraMortisHeading level={1} gradient="gold" className="text-3xl mb-2">
              Mes personnages
            </TerraMortisHeading>
            <p className="text-muted-foreground text-sm mt-1">Gérez vos personnages Terra Mortis</p>
          </div>
          <Link href="/creer-personnage">
            <Button
              className="font-heading"
              style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nouveau personnage
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
          </div>
        ) : personnages && personnages.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {personnages.map((p) => {
              const factionType = p.faction as "Sanctum" | "Légion";
              return (
                <TerraMortisCard key={p.id} faction={factionType} hover elevated>
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <TerraMortisHeading level={3} className="text-lg mb-2">
                        {p.name}
                      </TerraMortisHeading>
                      <FactionBadge faction={factionType} size="sm" />
                    </div>
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 glow-gold"
                      style={{ background: "oklch(0.65 0.18 45 / 0.15)" }}
                    >
                      <User className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />
                    </div>
                  </div>

                  {/* Info */}
                  <div className="space-y-1 mb-4">
                    <div className="flex items-center gap-2 text-sm text-foreground/70">
                      <Shield className="w-3.5 h-3.5" />
                      <span>{p.raceName ?? "Race inconnue"}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-foreground/70">
                      <Sword className="w-3.5 h-3.5" />
                      <span>{p.className ?? "Classe inconnue"}</span>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="text-center p-2 rounded-lg" style={{ background: "oklch(0.45 0.15 140 / 0.15)" }}>
                      <div className="text-sm font-heading font-bold text-green-400">{p.maxPv}</div>
                      <div className="text-xs text-muted-foreground">PV</div>
                    </div>
                    <div className="text-center p-2 rounded-lg" style={{ background: "oklch(0.55 0.18 240 / 0.15)" }}>
                      <div className="text-sm font-heading font-bold text-blue-400">{p.maxMana}</div>
                      <div className="text-xs text-muted-foreground">Mana</div>
                    </div>
                    <div className="text-center p-2 rounded-lg" style={{ background: "oklch(0.65 0.18 45 / 0.15)" }}>
                      <div className="text-sm font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>{p.lutte}</div>
                      <div className="text-xs text-muted-foreground">Lutte</div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Link href={`/personnage/${p.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full font-heading text-xs">
                        <Eye className="w-3.5 h-3.5 mr-1" />
                        Voir
                      </Button>
                    </Link>
                    {confirmDelete === p.id ? (
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs font-heading"
                          onClick={() => setConfirmDelete(null)}
                        >
                          Annuler
                        </Button>
                        <Button
                          size="sm"
                          className="text-xs font-heading bg-red-900/50 text-red-300 hover:bg-red-900"
                          onClick={() => { deleteMutation.mutate({ id: p.id }); setConfirmDelete(null); }}
                          disabled={deleteMutation.isPending}
                        >
                          Confirmer
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        className="font-heading text-xs"
                        onClick={() => setConfirmDelete(p.id)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </TerraMortisCard>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6"
              style={{ background: "oklch(0.65 0.18 45 / 0.1)", border: "2px dashed oklch(0.65 0.18 45 / 0.3)" }}
            >
              <Skull className="w-10 h-10 text-muted-foreground/30" />
            </div>
            <h3 className="text-xl font-heading font-semibold mb-2 text-foreground">Aucun personnage</h3>
            <p className="text-muted-foreground mb-6">Vous n'avez pas encore créé de personnage.</p>
            <Link href="/creer-personnage">
              <Button
                className="font-heading"
                style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Créer mon premier personnage
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
