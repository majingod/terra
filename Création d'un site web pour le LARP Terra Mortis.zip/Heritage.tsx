import { trpc } from "@/lib/trpc";
import { ChevronRight, Gem, Loader2, Skull, TrendingDown } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

export default function Heritage() {
  const { data: heritageAvantages, isLoading } = trpc.rules.heritageAvantages.useQuery();
  const [search, setSearch] = useState("");

  const filtered = heritageAvantages?.filter(
    (h) => h.name.toLowerCase().includes(search.toLowerCase()) || h.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Héritage", active: true },
      ]} />
      <div className="container max-w-5xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <Gem className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Héritage
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Les avantages d'héritage permettent de personnaliser votre personnage avec des bonus XP.
          </p>
        </div>



        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Rechercher..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 rounded-lg text-sm bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border"
          />
        </div>

        {/* Heritage */}
        <div>
          {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Les avantages d'héritage sont achetés avec des XP permanents lors de la création du personnage.
                  Certains peuvent être pris plusieurs fois (indiqué par "×N").
                </p>
                {filtered?.map((h) => (
                  <div
                    key={h.id}
                    className="p-5 rounded-xl border border-border/40 bg-card/30 hover:border-border/70 transition-all"
                  >
                    <div className="flex items-start justify-between mb-2 gap-4">
                      <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>
                        {h.name}
                      </h3>
                      <div className="flex gap-2 flex-wrap justify-end flex-shrink-0">
                        <span
                          className="text-xs px-2 py-1 rounded font-heading font-bold"
                          style={{ background: "oklch(0.65 0.18 45 / 0.2)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.4)" }}
                        >
                          {h.xpCost} XP
                        </span>
                        {(h.maxTimes ?? 1) > 1 && (
                          <span
                            className="text-xs px-2 py-1 rounded font-heading"
                            style={{ background: "oklch(0.55 0.18 240 / 0.15)", color: "oklch(0.65 0.2 240)", border: "1px solid oklch(0.55 0.18 240 / 0.3)" }}
                          >
                            ×{h.maxTimes} max
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-foreground/80 leading-relaxed mb-3">{h.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {(h.pvBonus ?? 0) > 0 && (
                        <span className="text-xs px-2 py-1 rounded bg-green-900/30 text-green-400 border border-green-800/40">+{h.pvBonus} PV</span>
                      )}
                      {(h.manaBonus ?? 0) > 0 && (
                        <span className="text-xs px-2 py-1 rounded bg-blue-900/30 text-blue-400 border border-blue-800/40">+{h.manaBonus} Mana</span>
                      )}
                      {(h.luteBonus ?? 0) > 0 && (
                        <span className="text-xs px-2 py-1 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.3)" }}>
                          +{h.luteBonus} Lutte
                        </span>
                      )}
                      {h.moneyBonus && (
                        <span className="text-xs px-2 py-1 rounded bg-yellow-900/30 text-yellow-400 border border-yellow-800/40">{h.moneyBonus}</span>
                      )}
                    </div>
                  </div>
                ))}
                {filtered?.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">Aucun avantage trouvé.</p>
                )}
              </div>
            )}
        </div>
      </div>
    </div>
  );
}
