import { getDb } from "./db";
import { encyclopediaHistory, encyclopediaEntries } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

/**
 * Procédures pour la gestion de l'historique des modifications d'Encyclopédie
 */

export async function getEntryHistory(entryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaHistory)
    .where(eq(encyclopediaHistory.entryId, entryId))
    .orderBy(desc(encyclopediaHistory.modifiedAt));
}

export async function getRecentChanges(limit: number = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaHistory)
    .orderBy(desc(encyclopediaHistory.modifiedAt))
    .limit(limit);
}

export async function getChangesByUser(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaHistory)
    .where(eq(encyclopediaHistory.modifiedBy, userId))
    .orderBy(desc(encyclopediaHistory.modifiedAt))
    .limit(limit);
}

export async function recordChange(
  entryId: number,
  action: "create" | "update" | "delete",
  ancienContenu: any,
  nouveauContenu: any,
  modifiedBy: number,
  raison?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db.insert(encyclopediaHistory).values({
    entryId,
    action,
    ancienContenu,
    nouveauContenu,
    modifiedBy,
    raison,
  });
}

export async function restoreVersion(historyId: number, restoredBy: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer l'historique
  const history = await db
    .select()
    .from(encyclopediaHistory)
    .where(eq(encyclopediaHistory.id, historyId));

  if (!history || history.length === 0) {
    throw new Error("History entry not found");
  }

  const historyEntry = history[0];

  // Restaurer le contenu
  await db
    .update(encyclopediaEntries)
    .set({
      nom: (historyEntry.ancienContenu as any)?.nom,
      description: (historyEntry.ancienContenu as any)?.description,
      proprietes: (historyEntry.ancienContenu as any)?.proprietes,
      relations: (historyEntry.ancienContenu as any)?.relations,
      conditions: (historyEntry.ancienContenu as any)?.conditions,
      updatedBy: restoredBy,
      updatedAt: new Date(),
    })
    .where(eq(encyclopediaEntries.id, historyEntry.entryId));

  // Enregistrer la restauration
  return recordChange(
    historyEntry.entryId,
    "update",
    historyEntry.nouveauContenu,
    historyEntry.ancienContenu,
    restoredBy,
    `Restauration de la version du ${historyEntry.modifiedAt}`
  );
}

export async function getChangeStats(days: number = 30) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  const changes = await db
    .select()
    .from(encyclopediaHistory)
    .where(eq(encyclopediaHistory.modifiedAt, cutoffDate));

  const stats = {
    totalChanges: changes.length,
    creates: changes.filter((c) => c.action === "create").length,
    updates: changes.filter((c) => c.action === "update").length,
    deletes: changes.filter((c) => c.action === "delete").length,
  };

  return stats;
}
