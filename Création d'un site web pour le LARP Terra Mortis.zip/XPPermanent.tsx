import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { TerraMortisCard } from "@/components/TerraMortisCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp, Calendar, Award } from "lucide-react";

export function XPPermanent() {
  const { user, isAuthenticated } = useAuth();

  // TODO: Récupérer l'XP permanent via tRPC
  const xpPermanent = {
    total: 450,
    maxLevel: 5,
    currentLevel: 3,
    xpForNextLevel: 500,
    xpInCurrentLevel: 450,
  };

  // TODO: Récupérer l'historique d'XP via tRPC
  const historique = [
    {
      id: 1,
      date: new Date(2026, 2, 28),
      evenement: "Tournoi d'Armes",
      xp: 100,
      personnage: "Aldric le Sombre",
    },
    {
      id: 2,
      date: new Date(2026, 2, 25),
      evenement: "Expédition Sanctum",
      xp: 150,
      personnage: "Elara Lumineuse",
    },
    {
      id: 3,
      date: new Date(2026, 2, 20),
      evenement: "Bataille de la Légion",
      xp: 200,
      personnage: "Thorgrim Marteau",
    },
  ];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <TerraMortisHeading level={1} gradient="gold" className="text-3xl mb-4">
            Connectez-vous
          </TerraMortisHeading>
          <p className="text-muted-foreground mb-6">
            Vous devez être connecté pour voir votre XP permanent.
          </p>
          <Button className="font-heading">Se connecter</Button>
        </div>
      </div>
    );
  }

  const progressPercentage = (xpPermanent.xpInCurrentLevel / xpPermanent.xpForNextLevel) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/30 py-8">
        <div className="container">
          <TerraMortisHeading level={1} gradient="gold" className="text-4xl mb-2">
            XP Permanent
          </TerraMortisHeading>
          <p className="text-muted-foreground">
            Votre XP permanent est partagé entre tous vos personnages. Gagnez de
            l'XP en participant à des événements Terra Mortis.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="py-12">
        <div className="container grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - XP Progress */}
          <div className="lg:col-span-2 space-y-8">
            {/* XP Card */}
            <TerraMortisCard>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <TerraMortisHeading level={2} className="text-2xl">
                    Progression
                  </TerraMortisHeading>
                  <div className="flex items-center gap-2">
                    <Zap
                      className="w-5 h-5"
                      style={{ color: "oklch(0.65 0.18 45)" }}
                    />
                    <span className="font-semibold">Niveau {xpPermanent.currentLevel}</span>
                  </div>
                </div>

                {/* Level Display */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground/70">
                      Niveau {xpPermanent.currentLevel}
                    </span>
                    <span className="text-sm text-foreground/70">
                      Niveau {xpPermanent.currentLevel + 1}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="relative h-8 rounded-lg overflow-hidden border border-border/30">
                    <div
                      className="h-full transition-all duration-500 flex items-center justify-center"
                      style={{
                        width: `${progressPercentage}%`,
                        background: "linear-gradient(90deg, oklch(0.65 0.18 45), oklch(0.82 0.2 85))",
                      }}
                    >
                      {progressPercentage > 20 && (
                        <span className="text-xs font-bold text-background">
                          {Math.round(progressPercentage)}%
                        </span>
                      )}
                    </div>
                    {progressPercentage <= 20 && (
                      <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">
                        {Math.round(progressPercentage)}%
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-foreground/70">
                      {xpPermanent.xpInCurrentLevel} / {xpPermanent.xpForNextLevel} XP
                    </span>
                    <span className="text-foreground/70">
                      +{xpPermanent.xpForNextLevel - xpPermanent.xpInCurrentLevel} XP restants
                    </span>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border/30">
                  <div>
                    <p className="text-sm text-foreground/60 mb-1">Total XP</p>
                    <p className="text-2xl font-bold">
                      <span style={{ color: "oklch(0.65 0.18 45)" }}>
                        {xpPermanent.total}
                      </span>
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-foreground/60 mb-1">Niveau Max</p>
                    <p className="text-2xl font-bold">
                      <span style={{ color: "oklch(0.65 0.18 45)" }}>
                        {xpPermanent.maxLevel}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </TerraMortisCard>

            {/* Historique */}
            <TerraMortisCard>
              <div className="space-y-4">
                <TerraMortisHeading level={2} className="text-2xl">
                  Historique d'XP
                </TerraMortisHeading>

                <div className="space-y-3">
                  {historique.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-border/30 hover:border-border/60 transition-colors"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{
                            background: "oklch(0.65 0.18 45 / 0.1)",
                            border: "1px solid oklch(0.65 0.18 45 / 0.3)",
                          }}
                        >
                          <TrendingUp
                            className="w-5 h-5"
                            style={{ color: "oklch(0.65 0.18 45)" }}
                          />
                        </div>

                        <div className="flex-1">
                          <p className="font-semibold">{entry.evenement}</p>
                          <div className="flex items-center gap-2 text-sm text-foreground/60">
                            <Calendar className="w-3 h-3" />
                            <span>
                              {entry.date.toLocaleDateString("fr-FR", {
                                day: "numeric",
                                month: "long",
                                year: "numeric",
                              })}
                            </span>
                            <span>•</span>
                            <span>{entry.personnage}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <p
                          className="text-lg font-bold"
                          style={{ color: "oklch(0.65 0.18 45)" }}
                        >
                          +{entry.xp}
                        </p>
                        <p className="text-xs text-foreground/60">XP</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TerraMortisCard>
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Info Card */}
            <TerraMortisCard>
              <div className="space-y-4">
                <TerraMortisHeading level={3} className="text-lg">
                  À propos
                </TerraMortisHeading>

                <div className="space-y-3 text-sm text-foreground/70">
                  <p>
                    Votre XP permanent augmente chaque fois que vous participez
                    à un événement Terra Mortis.
                  </p>
                  <p>
                    Cet XP est partagé entre tous vos personnages et peut être
                    utilisé pour débloquer de nouvelles capacités.
                  </p>
                  <p>
                    Chaque niveau vous rapproche de récompenses exclusives et
                    d'avantages spéciaux.
                  </p>
                </div>
              </div>
            </TerraMortisCard>

            {/* Rewards Card */}
            <TerraMortisCard>
              <div className="space-y-4">
                <TerraMortisHeading level={3} className="text-lg">
                  Récompenses
                </TerraMortisHeading>

                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <div
                      key={level}
                      className="flex items-center justify-between p-3 rounded-lg border border-border/30"
                      style={{
                        background:
                          level <= xpPermanent.currentLevel
                            ? "oklch(0.65 0.18 45 / 0.1)"
                            : "oklch(0.2 0.01 270 / 0.3)",
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <Award
                          className="w-4 h-4"
                          style={{
                            color:
                              level <= xpPermanent.currentLevel
                                ? "oklch(0.65 0.18 45)"
                                : "oklch(0.5 0.1 270)",
                          }}
                        />
                        <span className="text-sm font-semibold">
                          Niveau {level}
                        </span>
                      </div>
                      {level <= xpPermanent.currentLevel && (
                        <Badge
                          style={{
                            background: "oklch(0.65 0.18 45 / 0.2)",
                            color: "oklch(0.65 0.18 45)",
                            border: "1px solid oklch(0.65 0.18 45 / 0.5)",
                          }}
                        >
                          Débloqué
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </TerraMortisCard>
          </div>
        </div>
      </div>
    </div>
  );
}
