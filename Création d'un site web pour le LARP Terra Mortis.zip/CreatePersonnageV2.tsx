import { useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useHeritageBonus } from "@/hooks/useHeritageBonus";
import { StepOrchestrator } from "@/components/CreatePersonnageV2/StepOrchestrator";
import { StepIdentity } from "@/components/CreatePersonnageV2/StepIdentity";
import { StepFaction } from "@/components/CreatePersonnageV2/StepFaction";
import { StepRace } from "@/components/CreatePersonnageV2/StepRace";
import { StepHeritage } from "@/components/CreatePersonnageV2/StepHeritage";
import { StepClass } from "@/components/CreatePersonnageV2/StepClass";
import { StepStats } from "@/components/CreatePersonnageV2/StepStats";
import { StepDons } from "@/components/CreatePersonnageV2/StepDons";
import { StepCompetences } from "@/components/CreatePersonnageV2/StepCompetences";
import { StepCapacitesBonus } from "@/components/CreatePersonnageV2/StepCapacitesBonus";
import { StepResume } from "@/components/CreatePersonnageV2/StepResume";
import { User, Shield, Crown, Gem, Sword, Star, Check } from "lucide-react";
import { toast } from "sonner";

interface CharData {
  name: string;
  background: string;
  faction: "Sanctum" | "Légion" | null;
  raceId: number | null;
  classId: number | null;
  classPathId: number | null;
  puissance: number;
  resistance: number;
  esprit: number;
  competenceId: number | null;
  selectedDons: number[];
  selectedCompetences?: number[];
  heritageAvantages: { id: number; times: number }[];
  selectedDesavantages: number[];
  selectedBonusAbilities: number[];
  humanBonusType: "pv" | "pm" | null;
  notes: string;
  profileId?: number;
}

const INITIAL_CHAR_DATA: CharData = {
  name: "",
  background: "",
  faction: null,
  raceId: null,
  classId: null,
  classPathId: null,
  puissance: 0,
  resistance: 0,
  esprit: 0,
  competenceId: null,
  selectedDons: [],
  heritageAvantages: [],
  selectedDesavantages: [],
  selectedBonusAbilities: [],
  humanBonusType: null,
  notes: "",
};

// Données temporaires pour les héritages (à remplacer par tRPC)
const MOCK_HERITAGES = [
  { id: 1, name: "+1 Dons", xpCost: 10, extraDons: 1 },
  { id: 2, name: "+1 Compétence", xpCost: 10, extraCompetences: 1 },
  { id: 3, name: "+1 Capacité bonus", xpCost: 15, extraAbilitiesLevel1: 1 },
  { id: 4, name: "+2 Points de caractéristiques", xpCost: 20, extraStatsPoints: 2 },
];

export default function CreatePersonnageV2() {
  const { user } = useAuth();
  const [charData, setCharData] = useState<CharData>(INITIAL_CHAR_DATA);

  // Calculer les bonus d'Héritage
  const heritageBonus = useHeritageBonus(charData.heritageAvantages, MOCK_HERITAGES);

  // Configuration des étapes
  const steps = useMemo(
    () => [
      {
        id: 1,
        label: "Identité",
        icon: User,
        component: StepIdentity,
      },
      {
        id: 2,
        label: "Faction",
        icon: Shield,
        component: StepFaction,
      },
      {
        id: 3,
        label: "Race",
        icon: Crown,
        component: StepRace,
      },
      {
        id: 4,
        label: "Héritage",
        icon: Gem,
        component: StepHeritage,
      },
      {
        id: 5,
        label: "Classe",
        icon: Sword,
        component: StepClass,
      },
      {
        id: 6,
        label: "Caractéristiques",
        icon: Star,
        component: StepStats,
      },
      {
        id: 7,
        label: "Dons",
        icon: Check,
        component: StepDons,
      },
      {
        id: 8,
        label: "Compétences",
        icon: Sword,
        component: StepCompetences,
      },
      {
        id: 9,
        label: "Capacités bonus",
        icon: Star,
        component: StepCapacitesBonus,
      },
      {
        id: 10,
        label: "Résumé",
        icon: Check,
        component: StepResume,
      },
    ],
    []
  );

  const handleStepChange = () => {
    // Logique de validation avant de passer à l'étape suivante
    console.log("Étape complétée");
  };

  const handleComplete = async () => {
    if (!user) {
      window.location.href = getLoginUrl();
      return;
    }

    try {
      // TODO: Appeler la procédure tRPC pour créer le personnage
      toast.success("Personnage créé avec succès !");
      console.log("Données du personnage :", charData);
    } catch (error) {
      toast.error("Erreur lors de la création du personnage");
      console.error(error);
    }
  };

  if (!user) {
    return (
      <div className="container py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Créer un Personnage</h1>
        <p className="text-muted-foreground mb-6">
          Vous devez être connecté pour créer un personnage.
        </p>
        <a
          href={getLoginUrl()}
          className="inline-block px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
        >
          Se connecter
        </a>
      </div>
    );
  }

  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-2">Créer un Personnage</h1>
        <p className="text-muted-foreground mb-8">
          Nouvelle architecture avec propagation de bonus d'Héritage
        </p>

        <StepOrchestrator
          steps={steps}
          onStepChange={() => handleStepChange()}
          onComplete={handleComplete}
          charData={charData}
          onCharDataChange={setCharData}
          heritageBonus={heritageBonus}
        />
      </div>
    </div>
  );
}
