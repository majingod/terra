import { getDb } from "./db";
import { eq } from "drizzle-orm";
import { dons, competences, heritageAvantages, desavantages, races, classes } from "../drizzle/schema";

/**
 * Validation des prérequis pour les dons, compétences et héritages
 * Retourne { isValid: boolean, errors: string[] }
 */

export interface PrerequisiteCheck {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface SelectionContext {
  raceId?: number;
  classId?: number;
  level?: number;
  faction?: "Sanctum" | "Légion";
  selectedDons?: number[];
  selectedCompetences?: number[];
  selectedHeritages?: number[];
  selectedDesavantages?: number[];
}

/**
 * Valide la sélection d'un don
 */
export async function validateDon(
  donId: number,
  context: SelectionContext
): Promise<PrerequisiteCheck> {
  const db = await getDb();
  if (!db) return { isValid: false, errors: ["Database not available"], warnings: [] };

  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const don = await db.select().from(dons).where(eq(dons.id, donId));
    if (!don.length) {
      errors.push(`Don avec l'ID ${donId} non trouvé`);
      return { isValid: false, errors, warnings };
    }

    // Vérifier si le don peut être stacké
    if (context.selectedDons?.includes(donId)) {
      const donData = don[0];
      if (!donData.canStack) {
        errors.push(`Le don "${donData.name}" ne peut pas être sélectionné plusieurs fois`);
      } else if (donData.maxStacks && context.selectedDons.filter(d => d === donId).length >= donData.maxStacks) {
        errors.push(`Le don "${donData.name}" a atteint le nombre maximum de sélections (${donData.maxStacks})`);
      }
    }

    // Ajouter d'autres validations de prérequis si nécessaire
    // (classe requise, race requise, niveau minimum, etc.)

    return { isValid: errors.length === 0, errors, warnings };
  } catch (error: any) {
    errors.push(`Erreur lors de la validation du don: ${error.message}`);
    return { isValid: false, errors, warnings };
  }
}

/**
 * Valide la sélection d'une compétence
 */
export async function validateCompetence(
  competenceId: number,
  context: SelectionContext
): Promise<PrerequisiteCheck> {
  const db = await getDb();
  if (!db) return { isValid: false, errors: ["Database not available"], warnings: [] };

  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const competence = await db.select().from(competences).where(eq(competences.id, competenceId));
    if (!competence.length) {
      errors.push(`Compétence avec l'ID ${competenceId} non trouvée`);
      return { isValid: false, errors, warnings };
    }

    const competenceData = competence[0];

    // Vérifier si la compétence est réservée aux adultes
    if (competenceData.isAdultOnly) {
      warnings.push(`La compétence "${competenceData.name}" est réservée aux adultes`);
    }

    // Vérifier les doublons
    if (context.selectedCompetences?.includes(competenceId)) {
      errors.push(`La compétence "${competenceData.name}" est déjà sélectionnée`);
    }

    // Ajouter d'autres validations de prérequis si nécessaire
    // (classe requise, race requise, niveau minimum, etc.)

    return { isValid: errors.length === 0, errors, warnings };
  } catch (error: any) {
    errors.push(`Erreur lors de la validation de la compétence: ${error.message}`);
    return { isValid: false, errors, warnings };
  }
}

/**
 * Valide la sélection d'un héritage
 */
export async function validateHeritage(
  heritageId: number,
  context: SelectionContext
): Promise<PrerequisiteCheck> {
  const db = await getDb();
  if (!db) return { isValid: false, errors: ["Database not available"], warnings: [] };

  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const heritage = await db.select().from(heritageAvantages).where(eq(heritageAvantages.id, heritageId));
    if (!heritage.length) {
      errors.push(`Héritage avec l'ID ${heritageId} non trouvé`);
      return { isValid: false, errors, warnings };
    }

    const heritageData = heritage[0];

    // Vérifier si l'héritage peut être pris plusieurs fois
    if (context.selectedHeritages?.includes(heritageId)) {
      if (heritageData.maxTimes && heritageData.maxTimes === 1) {
        errors.push(`L'héritage "${heritageData.name}" ne peut être sélectionné qu'une seule fois`);
      } else if (heritageData.maxTimes && context.selectedHeritages.filter(h => h === heritageId).length >= heritageData.maxTimes) {
        errors.push(`L'héritage "${heritageData.name}" a atteint le nombre maximum de sélections (${heritageData.maxTimes})`);
      }
    }

    // Ajouter d'autres validations de prérequis si nécessaire
    // (classe requise, race requise, niveau minimum, etc.)

    return { isValid: errors.length === 0, errors, warnings };
  } catch (error: any) {
    errors.push(`Erreur lors de la validation de l'héritage: ${error.message}`);
    return { isValid: false, errors, warnings };
  }
}

/**
 * Valide la sélection d'un désavantage
 */
export async function validateDesavantage(
  desavantageId: number,
  context: SelectionContext
): Promise<PrerequisiteCheck> {
  const db = await getDb();
  if (!db) return { isValid: false, errors: ["Database not available"], warnings: [] };

  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const desavantage = await db.select().from(desavantages).where(eq(desavantages.id, desavantageId));
    if (!desavantage.length) {
      errors.push(`Désavantage avec l'ID ${desavantageId} non trouvé`);
      return { isValid: false, errors, warnings };
    }

    const desavantageData = desavantage[0];

    // Vérifier si la classe est interdite pour ce désavantage
    if (context.classId && desavantageData.forbiddenClasses) {
      const forbiddenClasses = Array.isArray(desavantageData.forbiddenClasses)
        ? desavantageData.forbiddenClasses
        : JSON.parse(desavantageData.forbiddenClasses as any);

      const classData = await db.select().from(classes).where(eq(classes.id, context.classId));
      if (classData.length && forbiddenClasses.includes(classData[0].name)) {
        errors.push(`Le désavantage "${desavantageData.name}" est interdit pour la classe ${classData[0].name}`);
      }
    }

    // Vérifier les doublons
    if (context.selectedDesavantages?.includes(desavantageId)) {
      errors.push(`Le désavantage "${desavantageData.name}" est déjà sélectionné`);
    }

    return { isValid: errors.length === 0, errors, warnings };
  } catch (error: any) {
    errors.push(`Erreur lors de la validation du désavantage: ${error.message}`);
    return { isValid: false, errors, warnings };
  }
}

/**
 * Valide une sélection complète de personnage
 */
export async function validateCompleteSelection(
  context: SelectionContext
): Promise<PrerequisiteCheck> {
  const db = await getDb();
  if (!db) return { isValid: false, errors: ["Database not available"], warnings: [] };

  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    // Valider tous les dons sélectionnés
    if (context.selectedDons) {
      for (const donId of context.selectedDons) {
        const donCheck = await validateDon(donId, context);
        errors.push(...donCheck.errors);
        warnings.push(...donCheck.warnings);
      }
    }

    // Valider toutes les compétences sélectionnées
    if (context.selectedCompetences) {
      for (const competenceId of context.selectedCompetences) {
        const competenceCheck = await validateCompetence(competenceId, context);
        errors.push(...competenceCheck.errors);
        warnings.push(...competenceCheck.warnings);
      }
    }

    // Valider tous les héritages sélectionnés
    if (context.selectedHeritages) {
      for (const heritageId of context.selectedHeritages) {
        const heritageCheck = await validateHeritage(heritageId, context);
        errors.push(...heritageCheck.errors);
        warnings.push(...heritageCheck.warnings);
      }
    }

    // Valider tous les désavantages sélectionnés
    if (context.selectedDesavantages) {
      for (const desavantageId of context.selectedDesavantages) {
        const desavantageCheck = await validateDesavantage(desavantageId, context);
        errors.push(...desavantageCheck.errors);
        warnings.push(...desavantageCheck.warnings);
      }
    }

    return { isValid: errors.length === 0, errors, warnings };
  } catch (error: any) {
    errors.push(`Erreur lors de la validation complète: ${error.message}`);
    return { isValid: false, errors, warnings };
  }
}
