import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle2, Loader2, RefreshCw } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface MigrationStatus {
  races: number;
  classes: number;
  classPaths: number;
  classAbilities: number;
  dons: number;
  competences: number;
  heritages: number;
  desavantages: number;
  encyclopediaTotal: number;
  categories: {
    races: number;
    classes: number;
    sous_classes: number;
    capacites: number;
    dons: number;
    competences: number;
    heritage_avantages: number;
    heritage_desavantages: number;
  };
}

interface MigrationResult {
  migratedCount: number;
  totalCount: number;
}

export default function AdminEncyclopediaMigration() {
  const [status, setStatus] = useState<MigrationStatus | null>(null);
  const [migrationResults, setMigrationResults] = useState<Record<string, MigrationResult>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isMigrating, setIsMigrating] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Procédures tRPC
  const getStatusQuery = trpc.migration.getStatus.useQuery();
  const migrateRacesMutation = trpc.migration.migrateRaces.useMutation();
  const migrateClassesMutation = trpc.migration.migrateClasses.useMutation();
  const migrateDonsMutation = trpc.migration.migrateDons.useMutation();
  const migrateCompetencesMutation = trpc.migration.migrateCompetences.useMutation();
  const migrateHeritagesMutation = trpc.migration.migrateHeritages.useMutation();
  const migrateDesavantagesMutation = trpc.migration.migrateDesavantages.useMutation();

  // Charger le statut initial
  useEffect(() => {
    if (getStatusQuery.data) {
      setStatus(getStatusQuery.data);
      setIsLoading(false);
    }
  }, [getStatusQuery.data]);

  // Rafraîchir le statut
  const refreshStatus = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await getStatusQuery.refetch();
    } catch (err) {
      setError("Erreur lors du chargement du statut");
    }
  };

  // Migrer une catégorie
  const handleMigrate = async (category: string) => {
    setIsMigrating(category);
    setError(null);
    try {
      let result: MigrationResult;

      switch (category) {
        case "races":
          result = await migrateRacesMutation.mutateAsync();
          break;
        case "classes":
          result = await migrateClassesMutation.mutateAsync();
          break;
        case "dons":
          result = await migrateDonsMutation.mutateAsync();
          break;
        case "competences":
          result = await migrateCompetencesMutation.mutateAsync();
          break;
        case "heritages":
          result = await migrateHeritagesMutation.mutateAsync();
          break;
        case "desavantages":
          result = await migrateDesavantagesMutation.mutateAsync();
          break;
        default:
          throw new Error("Catégorie inconnue");
      }

      setMigrationResults((prev) => ({
        ...prev,
        [category]: result,
      }));

      // Rafraîchir le statut après la migration
      await refreshStatus();
    } catch (err) {
      setError(`Erreur lors de la migration de ${category}`);
    } finally {
      setIsMigrating(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!status) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Impossible de charger le statut de la migration</AlertDescription>
        </Alert>
      </div>
    );
  }

  // Calculer le pourcentage de migration
  const totalLegacy =
    status.races +
    status.classes +
    status.dons +
    status.competences +
    status.heritages +
    status.desavantages;
  const totalMigrated =
    status.categories.races +
    status.categories.classes +
    status.categories.dons +
    status.categories.competences +
    status.categories.heritage_avantages +
    status.categories.heritage_desavantages;
  const migrationPercentage = totalLegacy > 0 ? (totalMigrated / totalLegacy) * 100 : 0;

  const categories = [
    { key: "races", label: "Races", legacy: status.races, migrated: status.categories.races },
    { key: "classes", label: "Classes", legacy: status.classes, migrated: status.categories.classes },
    { key: "dons", label: "Dons", legacy: status.dons, migrated: status.categories.dons },
    {
      key: "competences",
      label: "Compétences",
      legacy: status.competences,
      migrated: status.categories.competences,
    },
    {
      key: "heritages",
      label: "Héritages",
      legacy: status.heritages,
      migrated: status.categories.heritage_avantages,
    },
    {
      key: "desavantages",
      label: "Désavantages",
      legacy: status.desavantages,
      migrated: status.categories.heritage_desavantages,
    },
  ];

  return (
    <div className="space-y-6 p-6">
      {/* En-tête */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Migration vers l'Encyclopédie</h1>
        <p className="text-gray-600">
          Migrez progressivement les données des tables existantes vers la table centralisée encyclopediaEntries
        </p>
      </div>

      {/* Erreur */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Progression globale */}
      <Card>
        <CardHeader>
          <CardTitle>Progression globale</CardTitle>
          <CardDescription>
            {totalMigrated} / {totalLegacy} entrées migrées
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progression</span>
              <span className="font-semibold">{Math.round(migrationPercentage)}%</span>
            </div>
            <Progress value={migrationPercentage} className="h-2" />
          </div>
          <Button onClick={refreshStatus} variant="outline" className="w-full">
            <RefreshCw className="mr-2 h-4 w-4" />
            Rafraîchir
          </Button>
        </CardContent>
      </Card>

      {/* Catégories */}
      <div className="grid gap-4 md:grid-cols-2">
        {categories.map((category) => {
          const isMigrationDone = category.migrated >= category.legacy;
          const categoryPercentage = category.legacy > 0 ? (category.migrated / category.legacy) * 100 : 0;
          const result = migrationResults[category.key];

          return (
            <Card key={category.key}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">{category.label}</CardTitle>
                    {isMigrationDone && <CheckCircle2 className="h-5 w-5 text-green-600" />}
                  </div>
                </div>
                <CardDescription>
                  {category.migrated} / {category.legacy} entrées
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Progress value={categoryPercentage} className="h-2" />
                  <p className="text-sm text-gray-600">{Math.round(categoryPercentage)}% migré</p>
                </div>

                {result && (
                  <div className="rounded-md bg-blue-50 p-3 text-sm">
                    <p className="text-blue-900">
                      Dernière migration : {result.migratedCount} entrée(s) ajoutée(s)
                    </p>
                  </div>
                )}

                <Button
                  onClick={() => handleMigrate(category.key)}
                  disabled={isMigrationDone || isMigrating === category.key}
                  className="w-full"
                  variant={isMigrationDone ? "outline" : "default"}
                >
                  {isMigrating === category.key ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Migration en cours...
                    </>
                  ) : isMigrationDone ? (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Migré
                    </>
                  ) : (
                    `Migrer ${category.label}`
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Informations */}
      <Card className="bg-blue-50">
        <CardHeader>
          <CardTitle className="text-base">À propos de cette migration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>
            Cette interface permet de migrer progressivement les données des tables existantes (races, classes, dons,
            etc.) vers la table centralisée <code className="bg-white px-2 py-1 rounded">encyclopediaEntries</code>.
          </p>
          <p>
            Chaque catégorie peut être migrée indépendamment. Les migrations sont idempotentes : relancer une migration
            n'ajoutera pas de doublons.
          </p>
          <p>
            Une fois la migration terminée pour toutes les catégories, vous pourrez basculer l'application pour utiliser
            l'Encyclopédie comme source unique de données.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
