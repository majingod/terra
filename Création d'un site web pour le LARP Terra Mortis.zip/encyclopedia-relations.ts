import { getDb } from "./db";
import { encyclopediaRelations, encyclopediaEntries } from "../drizzle/schema";
import { eq, and, isNull } from "drizzle-orm";

/**
 * Procédures pour gérer les relations entre entrées d'Encyclopédie
 * Types de relations : "prerequis", "incompatible", "debloque", "liee"
 */

export async function createRelation(
  sourceId: number,
  cibleId: number,
  typeRelation: string,
  description?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Vérifier que les deux entrées existent
  const [source, cible] = await Promise.all([
    db.select().from(encyclopediaEntries).where(eq(encyclopediaEntries.id, sourceId)).limit(1),
    db.select().from(encyclopediaEntries).where(eq(encyclopediaEntries.id, cibleId)).limit(1),
  ]);

  if (!source.length || !cible.length) {
    throw new Error("Une ou les deux entrées n'existent pas");
  }

  // Vérifier qu'une relation similaire n'existe pas déjà
  const existing = await db
    .select()
    .from(encyclopediaRelations)
    .where(
      and(
        eq(encyclopediaRelations.sourceId, sourceId),
        eq(encyclopediaRelations.cibleId, cibleId),
        eq(encyclopediaRelations.typeRelation, typeRelation)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Cette relation existe déjà");
  }

  const result = await db.insert(encyclopediaRelations).values({
    sourceId,
    cibleId,
    typeRelation,
  });

  return result;
}

export async function deleteRelation(sourceId: number, cibleId: number, typeRelation: string) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .delete(encyclopediaRelations)
    .where(
      and(
        eq(encyclopediaRelations.sourceId, sourceId),
        eq(encyclopediaRelations.cibleId, cibleId),
        eq(encyclopediaRelations.typeRelation, typeRelation)
      )
    );
}

export async function getRelationsByType(typeRelation: string, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaRelations)
    .where(eq(encyclopediaRelations.typeRelation, typeRelation))
    .limit(limit)
    .offset(offset);
}

export async function getPrerequisites(entryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.sourceId, encyclopediaEntries.id))
    .where(
      and(
        eq(encyclopediaRelations.cibleId, entryId),
        eq(encyclopediaRelations.typeRelation, "prerequis")
      )
    );
}

export async function getIncompatibilities(entryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.cibleId, encyclopediaEntries.id))
    .where(
      and(
        eq(encyclopediaRelations.sourceId, entryId),
        eq(encyclopediaRelations.typeRelation, "incompatible")
      )
    );
}

export async function getUnlocks(entryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.cibleId, encyclopediaEntries.id))
    .where(
      and(
        eq(encyclopediaRelations.sourceId, entryId),
        eq(encyclopediaRelations.typeRelation, "debloque")
      )
    );
}

export async function getRelatedEntries(entryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.cibleId, encyclopediaEntries.id))
    .where(
      and(
        eq(encyclopediaRelations.sourceId, entryId),
        eq(encyclopediaRelations.typeRelation, "liee")
      )
    );
}

export async function validatePrerequisites(entryId: number, selectedEntries: number[]): Promise<{
  valid: boolean;
  missingPrerequisites: number[];
  incompatibilities: number[];
}> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer les prérequis
  const prerequisites = await db
    .select({ sourceId: encyclopediaRelations.sourceId })
    .from(encyclopediaRelations)
    .where(
      and(
        eq(encyclopediaRelations.cibleId, entryId),
        eq(encyclopediaRelations.typeRelation, "prerequis")
      )
    );

  const missingPrerequisites = prerequisites
    .map((p) => p.sourceId)
    .filter((id) => !selectedEntries.includes(id));

  // Récupérer les incompatibilités
  const incompatibilities = await db
    .select({ cibleId: encyclopediaRelations.cibleId })
    .from(encyclopediaRelations)
    .where(
      and(
        eq(encyclopediaRelations.sourceId, entryId),
        eq(encyclopediaRelations.typeRelation, "incompatible")
      )
    );

  const foundIncompatibilities = incompatibilities
    .map((i) => i.cibleId)
    .filter((id) => selectedEntries.includes(id));

  return {
    valid: missingPrerequisites.length === 0 && foundIncompatibilities.length === 0,
    missingPrerequisites,
    incompatibilities: foundIncompatibilities,
  };
}
