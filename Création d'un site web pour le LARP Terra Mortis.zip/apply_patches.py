#!/usr/bin/env python3
import re

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Modifier handleSubmit pour ajouter la validation 3-2-1 et xpTemporaire/xpPermanent
old_handleSubmit = '''  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez completer toutes les etapes obligatoires.");
      return;
    }
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      notes: charData.notes || undefined,
    });
  };'''

new_handleSubmit = '''  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez completer toutes les etapes obligatoires.");
      return;
    }
    const values = [charData.puissance, charData.resistance, charData.esprit].sort((a, b) => b - a);
    if (values[0] !== 3 || values[1] !== 2 || values[2] !== 1) {
      toast.error("Les caracteristiques doivent suivre 3-2-1");
      return;
    }
    const xpTemp = charData.selectedDesavantages.reduce((sum, id) => {
      const d = desavantages.find((x) => x.id === id);
      return sum + (d?.xpGain ?? 0);
    }, 0);
    const xpPerm = charData.heritageAvantages.reduce((sum, h) => {
      const ha = heritageAvantages.find((x) => x.id === h.id);
      return sum + (ha ? ha.xpCost * h.times : 0);
    }, 0);
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      xpTemporaire: xpTemp,
      xpPermanent: xpPerm,
      notes: charData.notes || undefined,
    });
  };'''

content = content.replace(old_handleSubmit, new_handleSubmit)

# 2. Modifier l'appel à StepDonsResume pour ajouter onCreatePersonnage et isCreating
old_step10 = '''      case 10: return <StepDonsResume data={charData} onChange={updateData} dons={dons} heritageAvantages={heritageAvantages} races={races} classes={classes} competences={competences} desavantages={desavantages} calcStats={calcStats} />;'''

new_step10 = '''      case 10: return <StepDonsResume data={charData} onChange={updateData} dons={dons} heritageAvantages={heritageAvantages} races={races} classes={classes} competences={competences} desavantages={desavantages} calcStats={calcStats} onCreatePersonnage={handleSubmit} isCreating={createMutation.isPending} />;'''

content = content.replace(old_step10, new_step10)

# Écrire le fichier modifié
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Modifications appliquées avec succès")
