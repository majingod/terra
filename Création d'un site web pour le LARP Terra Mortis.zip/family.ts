import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { families, familyProfiles, familySessions } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

/**
 * Procédures tRPC pour la gestion des comptes familiaux
 * - Créer une famille
 * - Ajouter un profil enfant
 * - Basculer vers un profil
 * - Récupérer les profils de la famille
 */

export const familyRouter = router({
  /**
   * Créer une nouvelle famille (appelé lors de la première connexion)
   */
  createFamily: protectedProcedure
    .input(z.object({ familyName: z.string().min(1).max(150) }))
    .mutation(async ({ input, ctx }) => {
      const { familyName } = input;
      const userId = ctx.user.id;

      // Créer la famille
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");
      
      const family = await db.insert(families).values({
        name: familyName,
        createdBy: userId,
      });

      const familyId = family[0].insertId;

      // Créer le profil parent principal
      const profile = await db.insert(familyProfiles).values({
        familyId: familyId as number,
        name: ctx.user.name || "Parent",
        role: "parent",
        isChild: false,
        xpPermanent: 0,
      });

      const profileId = profile[0].insertId;

      // Créer la session (profil actif)
      await db.insert(familySessions).values({
        familyId: familyId as number,
        activeProfileId: profileId as number,
        userId: userId,
      });

      return {
        familyId: familyId as number,
        profileId: profileId as number,
      };
    }),

  /**
   * Ajouter un profil enfant à la famille
   */
  addChildProfile: protectedProcedure
    .input(
      z.object({
        familyId: z.number(),
        childName: z.string().min(1).max(150),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { familyId, childName } = input;
      const userId = ctx.user.id;
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");

      // Vérifier que l'utilisateur est parent de cette famille
      const family = await db
        .select()
        .from(families)
        .where(and(eq(families.id, familyId), eq(families.createdBy, userId)))
        .limit(1);

      if (family.length === 0) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Vous n'êtes pas le parent de cette famille",
        });
      }

      // Créer le profil enfant
      const profile = await db.insert(familyProfiles).values({
        familyId: familyId,
        name: childName,
        role: "child",
        isChild: true,
        xpPermanent: 0,
      });

      return {
        profileId: profile[0].insertId,
        familyId: familyId,
      };
    }),

  /**
   * Basculer vers un profil (changer le profil actif)
   */
  switchProfile: protectedProcedure
    .input(
      z.object({
        familyId: z.number(),
        profileId: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { familyId, profileId } = input;
      const userId = ctx.user.id;
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");

      // Vérifier que le profil appartient à la famille
      const profile = await db
        .select()
        .from(familyProfiles)
        .where(
          and(
            eq(familyProfiles.id, profileId),
            eq(familyProfiles.familyId, familyId)
          )
        )
        .limit(1);

      if (profile.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Profil non trouvé",
        });
      }

      // Vérifier que l'utilisateur est parent de cette famille
      const family = await db
        .select()
        .from(families)
        .where(and(eq(families.id, familyId), eq(families.createdBy, userId)))
        .limit(1);

      if (family.length === 0) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Vous n'êtes pas le parent de cette famille",
        });
      }

      // Mettre à jour la session (profil actif)
      const session = await db
        .select()
        .from(familySessions)
        .where(eq(familySessions.familyId, familyId))
        .limit(1);

      if (session.length === 0) {
        // Créer une nouvelle session si elle n'existe pas
        await db.insert(familySessions).values({
          familyId: familyId,
          activeProfileId: profileId,
          userId: userId,
        });
      } else {
        // Mettre à jour la session existante
        await db
          .update(familySessions)
          .set({
            activeProfileId: profileId,
            updatedAt: new Date(),
          })
          .where(eq(familySessions.familyId, familyId));
      }

      return { success: true, profileId };
    }),

  /**
   * Récupérer tous les profils de la famille
   */
  getFamilyProfiles: protectedProcedure
    .input(z.object({ familyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const { familyId } = input;
      const userId = ctx.user.id;
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");

      // Vérifier que l'utilisateur est parent de cette famille
      const family = await db
        .select()
        .from(families)
        .where(and(eq(families.id, familyId), eq(families.createdBy, userId)))
        .limit(1);

      if (family.length === 0) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Vous n'êtes pas le parent de cette famille",
        });
      }

      // Récupérer tous les profils
      const profiles = await db
        .select()
        .from(familyProfiles)
        .where(eq(familyProfiles.familyId, familyId));

      // Récupérer le profil actif
      const session = await db
        .select()
        .from(familySessions)
        .where(eq(familySessions.familyId, familyId))
        .limit(1);

      const activeProfileId = session.length > 0 ? session[0].activeProfileId : null;

      return {
        profiles,
        activeProfileId,
      };
    }),

  /**
   * Récupérer la famille de l'utilisateur connecté
   */
  getMyFamily: protectedProcedure.query(async ({ ctx }) => {
    const userId = ctx.user.id;
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Récupérer la famille créée par cet utilisateur
    const family = await db
      .select()
      .from(families)
      .where(eq(families.createdBy, userId))
      .limit(1);

    if (family.length === 0) {
      return null;
    }

    // Récupérer les profils
    const profiles = await db
      .select()
      .from(familyProfiles)
      .where(eq(familyProfiles.familyId, family[0].id));

    // Récupérer la session
    const session = await db
      .select()
      .from(familySessions)
      .where(eq(familySessions.familyId, family[0].id))
      .limit(1);

    return {
      family: family[0],
      profiles,
      activeProfileId: session.length > 0 ? session[0].activeProfileId : null,
    };
  }),

  /**
   * Récupérer le profil actif de l'utilisateur
   */
  getActiveProfile: protectedProcedure.query(async ({ ctx }) => {
    const userId = ctx.user.id;
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Récupérer la famille
    const family = await db
      .select()
      .from(families)
      .where(eq(families.createdBy, userId))
      .limit(1);

    if (family.length === 0) {
      return null;
    }

    // Récupérer la session
    const session = await db
      .select()
      .from(familySessions)
      .where(eq(familySessions.familyId, family[0].id))
      .limit(1);

    if (session.length === 0) {
      return null;
    }

    // Récupérer le profil actif
    const profile = await db
      .select()
      .from(familyProfiles)
      .where(eq(familyProfiles.id, session[0].activeProfileId))
      .limit(1);

    return profile.length > 0 ? profile[0] : null;
  }),
});
