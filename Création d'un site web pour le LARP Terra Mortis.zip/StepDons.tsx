import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Plus, Minus, AlertCircle } from "lucide-react";
import { useValidateDon } from "@/hooks/useValidateDon";

interface StepDonsProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepDons({ charData, onCharDataChange, heritageBonus }: StepDonsProps) {
  const [dons, setDons] = useState<any[]>([]);
  const [maxDons] = useState(3); // Base
  const { validateDon, getValidationResult } = useValidateDon();
  const [validatingDonId, setValidatingDonId] = useState<number | null>(null);

  // Calculer le nombre maximum de dons avec bonus d'Héritage
  const totalMaxDons = maxDons + (heritageBonus?.extraDons || 0);
  const selectedCount = charData.selectedDons.length;
  const canAddMore = selectedCount < totalMaxDons;

  useEffect(() => {
    // TODO: Remplacer par la procédure tRPC
    setDons([
      { id: 1, name: "Force", description: "+1 Puissance" },
      { id: 2, name: "Agilité", description: "+1 Agilité" },
      { id: 3, name: "Sagesse", description: "+1 Sagesse" },
      { id: 4, name: "Charisme", description: "+1 Charisme" },
      { id: 5, name: "Vitalité", description: "+5 PV" },
      { id: 6, name: "Mana", description: "+5 PM" },
    ]);
  }, []);

  const toggleDon = async (donId: number) => {
    const isSelected = charData.selectedDons.includes(donId);

    if (isSelected) {
      // Retirer le don sans validation
      onCharDataChange({
        ...charData,
        selectedDons: charData.selectedDons.filter((id: number) => id !== donId),
      });
    } else if (canAddMore) {
      // Valider avant d'ajouter
      setValidatingDonId(donId);
      try {
        const result = await validateDon(donId, {
          raceId: charData.raceId,
          classId: charData.classId,
          selectedDons: [...charData.selectedDons, donId],
          showToasts: true,
        });

        if (result.isValid) {
          onCharDataChange({
            ...charData,
            selectedDons: [...charData.selectedDons, donId],
          });
        }
      } finally {
        setValidatingDonId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Affichage des dons disponibles */}
      <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
        <div className="flex justify-between items-center">
          <span className="font-semibold text-blue-900">Dons sélectionnés</span>
          <span className="text-2xl font-bold text-blue-600">
            {selectedCount} / {totalMaxDons}
          </span>
        </div>
        {heritageBonus?.extraDons > 0 && (
          <p className="text-xs text-blue-700 mt-2">
            ✨ +{heritageBonus.extraDons} dons bonus d'Héritage
          </p>
        )}
      </div>

      {/* Grille de dons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {dons.map((don: any) => {
          const isSelected = charData.selectedDons.includes(don.id);

          return (
            <div
              key={don.id}
              onClick={() => toggleDon(don.id)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                isSelected
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              } ${!isSelected && !canAddMore ? "opacity-50 cursor-not-allowed" : ""} ${
                validatingDonId === don.id ? "opacity-60" : ""
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-bold mb-1">{don.name}</h4>
                  <p className="text-xs text-muted-foreground">{don.description}</p>
                  {getValidationResult(don.id)?.errors.length ? (
                    <div className="flex items-center gap-1 mt-2 text-xs text-red-600">
                      <AlertCircle className="w-3 h-3" />
                      <span>{getValidationResult(don.id)?.errors[0]}</span>
                    </div>
                  ) : null}
                </div>
                {isSelected && (
                  <div className="ml-2 w-6 h-6 rounded bg-primary flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Message si limite atteinte */}
      {!canAddMore && selectedCount > 0 && (
        <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
          <p className="text-sm text-amber-800">
            Vous avez sélectionné le nombre maximum de dons ({totalMaxDons}).
          </p>
        </div>
      )}
    </div>
  );
}
