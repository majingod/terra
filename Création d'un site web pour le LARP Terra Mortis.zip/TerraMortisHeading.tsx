import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface TerraMortisHeadingProps {
  children: ReactNode;
  level?: 1 | 2 | 3 | 4 | 5 | 6;
  className?: string;
  gradient?: "gold" | "faction" | "none";
}

export function TerraMortisHeading({
  children,
  level = 1,
  className,
  gradient = "none",
}: TerraMortisHeadingProps) {
  const baseClasses = "terra-heading";
  const gradientClasses = {
    gold: "text-gradient-gold",
    faction: "text-gradient-faction",
    none: "",
  };

  const Tag = `h${level}` as const;

  return (
    <Tag className={cn(baseClasses, gradientClasses[gradient], className)}>
      {children}
    </Tag>
  );
}
