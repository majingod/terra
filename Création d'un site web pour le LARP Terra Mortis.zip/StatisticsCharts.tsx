import { useMemo } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface StatisticsChartsProps {
  events?: any[];
  inscriptions?: any[];
  xpDistributions?: any[];
}

export default function StatisticsCharts({
  events = [],
  inscriptions = [],
  xpDistributions = [],
}: StatisticsChartsProps) {
  // Préparer les données pour le graphique des événements
  const eventsByMonth = useMemo(() => {
    const data: Record<string, number> = {};
    events.forEach((event) => {
      const date = new Date(event.createdAt);
      const month = date.toLocaleDateString("fr-FR", { month: "short", year: "numeric" });
      data[month] = (data[month] || 0) + 1;
    });
    return Object.entries(data).map(([month, count]) => ({ month, count }));
  }, [events]);

  // Préparer les données pour le graphique des inscriptions
  const inscriptionsByStatus = useMemo(() => {
    const data: Record<string, number> = {};
    inscriptions.forEach((insc) => {
      const status = insc.status || "unknown";
      data[status] = (data[status] || 0) + 1;
    });
    return Object.entries(data).map(([status, count]) => ({
      name: status === "approved" ? "Approuvée" : status === "pending" ? "En attente" : "Rejetée",
      value: count,
    }));
  }, [inscriptions]);

  // Préparer les données pour le graphique XP
  const xpByMonth = useMemo(() => {
    const data: Record<string, number> = {};
    xpDistributions.forEach((xp) => {
      const date = new Date(xp.createdAt);
      const month = date.toLocaleDateString("fr-FR", { month: "short", year: "numeric" });
      data[month] = (data[month] || 0) + (xp.amount || 0);
    });
    return Object.entries(data).map(([month, total]) => ({ month, total }));
  }, [xpDistributions]);

  const COLORS = ["#f97316", "#06b6d4", "#ec4899", "#8b5cf6", "#14b8a6"];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Graphique des événements */}
      <Card>
        <CardHeader>
          <CardTitle>Événements par Mois</CardTitle>
          <CardDescription>Nombre d'événements créés par mois</CardDescription>
        </CardHeader>
        <CardContent>
          {eventsByMonth.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={eventsByMonth}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="#f97316"
                  name="Événements"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              Aucune donnée disponible
            </div>
          )}
        </CardContent>
      </Card>

      {/* Graphique des inscriptions */}
      <Card>
        <CardHeader>
          <CardTitle>Inscriptions par Statut</CardTitle>
          <CardDescription>Distribution des inscriptions</CardDescription>
        </CardHeader>
        <CardContent>
          {inscriptionsByStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={inscriptionsByStatus}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {inscriptionsByStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              Aucune donnée disponible
            </div>
          )}
        </CardContent>
      </Card>

      {/* Graphique XP distribué */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>XP Distribué par Mois</CardTitle>
          <CardDescription>Total de l'XP attribué aux personnages</CardDescription>
        </CardHeader>
        <CardContent>
          {xpByMonth.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={xpByMonth}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="total" fill="#06b6d4" name="XP Distribué" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              Aucune donnée disponible
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
