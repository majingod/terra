# PLAN D'IMPLÉMENTATION — Terra Mortis Transformation
## Brief de transformation : Comptes familiaux + Builder refondé + Parcours organisateur

---

## ANALYSE DE L'ARCHITECTURE ACTUELLE

**État du code** :
- ✅ Builder de personnage en 8 étapes (StepFaction → StepResume)
- ✅ Schéma DB complet (races, classes, voies, capacités, dons, désavantages, compétences)
- ✅ Système d'XP (xpPermanent, xpTemporaire) déjà dans le schéma
- ✅ Dashboard organisateur avec filtres (faction, statut)
- ⚠️ Pas de table "Profil" ou "Famille" — les personnages sont directement liés à `userId`
- ⚠️ Pas de gestion des comptes familiaux (parent-enfant)
- ⚠️ Pas de notifications email
- ⚠️ Pas d'export PDF

**Contrainte clé** : Le GN est 80% parents-enfants → comptes familiaux OBLIGATOIRE

---

## DEUX APPROCHES STRATÉGIQUES

### **APPROCHE 1 : Incrémentale (Refonte légère)**

**Philosophie** : Améliorer progressivement sans refonte majeure de la DB

**Étapes** :
1. Ajouter une table `Family` et `FamilyProfile` (parent/enfant)
2. Modifier `users.userId` → lier à `FamilyProfile` au lieu de `User`
3. Améliorer le builder UI (validation temps réel, infobulles, résumé latéral)
4. Ajouter l'export PDF
5. Ajouter les notifications email
6. Refondre l'écran "Attribuer XP" avec actions en masse

**Avantages** :
- ✅ Moins de risque de régression (code existant préservé)
- ✅ Peut être livré par étapes (MVP rapide possible)
- ✅ Données existantes restent intactes
- ✅ Équipe solo peut itérer sans refonte massive

**Inconvénients** :
- ❌ La table `users` reste confuse (mélange User + FamilyProfile)
- ❌ Migrations DB complexes (refactoring des FKs)
- ❌ Risque de dette technique (deux modèles coexistent)
- ❌ Logique métier dispersée (certains checks en DB, d'autres en code)

**Risque concret** : Après 6 mois, la logique de "quel profil est actif" sera éparpillée entre 5 fichiers différents.

---

### **APPROCHE 2 : Refonte structurelle (Clean slate)**

**Philosophie** : Restructurer le modèle de données pour aligner DB + métier + UI

**Étapes** :
1. Créer une table `Family` (id, name, createdBy, createdAt)
2. Créer une table `FamilyProfile` (id, familyId, name, role, xpPermanent, isChild, createdAt)
3. Créer une table `FamilySession` (id, familyId, activeProfileId, userId, createdAt) — pour tracker le profil actif
4. Migrer tous les `personnages.userId` → `personnages.profileId`
5. Refondre le builder UI complètement (wizard moderne, validation temps réel, infobulles, résumé latéral)
6. Ajouter export PDF + notifications email
7. Refondre l'écran "Attribuer XP" avec actions en masse
8. Ajouter un écran "Gestion de famille" (ajouter enfants, gérer rôles)

**Avantages** :
- ✅ Modèle de données clair et scalable
- ✅ Logique métier centralisée (un seul endroit pour "quel profil est actif")
- ✅ Pas de dette technique (structure cohérente)
- ✅ Facile à ajouter des rôles futurs (tuteur, invité, etc.)
- ✅ Séparation claire User (authentification) vs FamilyProfile (jeu)

**Inconvénients** :
- ❌ Refonte DB majeure (migrations complexes)
- ❌ Risque de régression élevé (beaucoup de code à modifier)
- ❌ Temps de développement plus long (2-3 semaines vs 1 semaine)
- ❌ Nécessite des tests exhaustifs avant déploiement

**Risque concret** : Si la migration échoue, la plateforme est down. Nécessite un plan de rollback solide.

---

## CRITIQUE DE CHAQUE APPROCHE

### Approche 1 : Incrémentale

| Critère | Évaluation |
|---------|-----------|
| **Force principale** | Livrable rapide (1-2 semaines), risque faible, peut être itérative |
| **Faiblesse principale** | Modèle de données reste confus, dette technique, logique métier dispersée |
| **Risque dans votre contexte** | Après 3-4 mois, ajouter une nouvelle feature (ex: tuteur) sera compliqué |

### Approche 2 : Refonte structurelle

| Critère | Évaluation |
|---------|-----------|
| **Force principale** | Architecture propre, scalable, logique métier centralisée, pas de dette technique |
| **Faiblesse principale** | Refonte majeure, risque de régression, temps long, nécessite tests exhaustifs |
| **Risque dans votre contexte** | Si migration échoue, plateforme down. Nécessite 2-3 jours de tests avant déploiement |

---

## 🏆 RECOMMANDATION FINALE

**Je recommande l'Approche 2 : Refonte structurelle**, mais avec une **stratégie de déploiement prudente** (déploiement progressif, tests exhaustifs, rollback plan).

**Pourquoi** :
1. **Comptes familiaux sont une contrainte métier forte** (80% du public) → méritent une structure DB propre
2. **Vous êtes solo dev** → mieux vaut une architecture claire que de naviguer dans une dette technique croissante
3. **La plateforme est jeune** (pas de millions de données) → c'est le moment idéal pour refondre
4. **Scalabilité future** : ajouter des rôles (tuteur, invité), des permissions granulaires sera facile après
5. **Qualité du code** : une structure propre rend les futures features 50% plus rapides à implémenter

**Stratégie de déploiement** :
- Phase 1 (Semaine 1-2) : Refonte DB + migrations + tests
- Phase 2 (Semaine 2-3) : Refondre builder UI + tests
- Phase 3 (Semaine 3-4) : Ajouter export PDF + notifications email + écran gestion famille
- Phase 4 (Semaine 4) : Tests exhaustifs + déploiement progressif (10% → 50% → 100%)

---

## 5 À 8 SUGGESTIONS CONCRÈTES (Alignées avec Approche 2)

### 1. Refondre le modèle de données — Comptes familiaux
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur la contrainte métier (80% parents-enfants)  
**Description** :
- Créer table `Family` (id, name, createdBy, createdAt, updatedAt)
- Créer table `FamilyProfile` (id, familyId, name, role: "parent"|"child", xpPermanent, isChild, createdAt)
- Créer table `FamilySession` (id, familyId, activeProfileId, userId, createdAt) — pour tracker le profil actif
- Migrer `personnages.userId` → `personnages.profileId`
- Ajouter check : enfants ne peuvent pas choisir artisanats (Alchimiste, Forgeron, Runiste)

**Valeur** : Pour qui : organisateurs (gestion simplifiée), joueurs (un compte = toute la famille). Pourquoi : structure scalable, logique métier centralisée  
**Effort** : **GROS** (3-4 jours)

---

### 2. Builder de personnage refondé — Wizard moderne + validation temps réel
**Étiquette** : [META]  
**Pourquoi** : UX/ergonomie, agnostique au système de jeu  
**Description** :
- Remplacer les 8 étapes actuelles par un wizard moderne avec stepper visible
- Ajouter validation temps réel (pas d'erreurs après validation finale)
- Ajouter panneau de résumé latéral persistant : PV, Mana, Lutte, Sauvegardes, Capacités, Langues, équipement magique
- Chaque ligne du résumé a une infobulle expliquant son calcul (ex: "PV = 5 (base Guerrier) + 2 (Résistance 3) + 1 (Don Robuste)")
- Ajouter infobulles sur les termes de règles (race, don, capacité) avec court extrait du lore + effet mécanique
- Mode "Build assisté" : questionnaire 4 questions → 3 propositions de builds valides

**Valeur** : Pour qui : joueurs (expérience fluide, moins d'erreurs). Pourquoi : réduction des erreurs de création, meilleure compréhension des règles  
**Effort** : **GROS** (4-5 jours)

---

### 3. Étape Héritage refondée — XP permanent vs temporaire visible
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur les règles d'XP (permanent vs temporaire)  
**Description** :
- Afficher solde d'XP permanent du joueur (global, partagé entre tous ses personnages)
- Afficher solde d'XP temporaire calculé à partir des désavantages cochés
- Permettre de cocher des désavantages et d'acheter des avantages en temps réel
- Vérifier les restrictions (ex: Paladin interdit Menteur/Honorable, Chevalier de la Mort interdit Honorable)
- Afficher un récapitulatif : "Vous avez 5 XP permanent + 3 XP temporaire (désavantages) = 8 XP total pour l'héritage"

**Valeur** : Pour qui : joueurs (compréhension claire du système d'XP). Pourquoi : éviter les erreurs d'héritage, meilleure transparence  
**Effort** : **MOYEN** (2-3 jours)

---

### 4. Export PDF — Fiche imprimable
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur le besoin métier (fiche en jeu)  
**Description** :
- Générer PDF avec : nom, race, classe, voie, stats, capacités, dons, compétences, langues, équipement magique
- Ajouter QR code pointant vers le profil du personnage (pour vérification rapide en jeu)
- Ajouter section "Incantations" pré-remplie (liste des capacités avec incantations)
- Ajouter section "Notes du joueur" (background, notes personnelles)
- Design imprimable (noir/blanc, lisible en petit)

**Valeur** : Pour qui : joueurs (fiche de référence en jeu), organisateurs (vérification rapide). Pourquoi : expérience LARP améliorée, moins de disputes  
**Effort** : **PETIT** (1-2 jours, utiliser `pdfkit` ou `jsPDF`)

---

### 5. Notifications email — Post-GN XP attribution
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur le workflow post-GN  
**Description** :
- Après attribution d'XP, envoyer email au joueur avec :
  - XP gagnée (ex: 1 XP)
  - XP total du personnage (ex: 5 XP)
  - Niveau débloqué ou non
  - Message optionnel de l'orga
  - Lien vers le journal du personnage
- Utiliser SendGrid ou Mailjet (gratuit pour <100 emails/jour)
- Template email responsive, branded Terra Mortis

**Valeur** : Pour qui : joueurs (engagement, transparence). Pourquoi : meilleure communication, joueurs informés en temps réel  
**Effort** : **PETIT** (1-2 jours)

---

### 6. Écran "Attribuer XP" refondé — Actions en masse
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur le workflow post-GN  
**Description** :
- Afficher liste des personnages inscrits avec cases à cocher pour marquer les présents
- Pour chaque présent : champ "XP gagné" (valeur par défaut configurable) + case "Quête réussie" (niveau débloqué)
- Actions en masse :
  - "Donner 1 XP à tous les présents"
  - "Ajouter 1 XP à la sélection"
  - "Marquer tous comme présents"
- Champ "Notes de l'orga" optionnel (visible dans email du joueur)
- Validation en deux étapes avec récapitulatif avant confirmation

**Valeur** : Pour qui : organisateurs (gain de temps, moins d'erreurs). Pourquoi : réduire le temps post-GN de 30 min à 5 min  
**Effort** : **MOYEN** (2-3 jours)

---

### 7. Écran "Gestion de famille" — Ajouter enfants, gérer rôles
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur la contrainte métier (comptes familiaux)  
**Description** :
- Page accessible depuis le profil du parent
- Afficher tous les profils de la famille (parent, enfants)
- Bouton "Ajouter un enfant" → créer nouveau profil (nom, âge, email optionnel)
- Afficher solde d'XP permanent de chaque profil
- Bouton "Basculer vers ce profil" (change le profil actif)
- Afficher les restrictions pour les enfants (pas d'artisanats, etc.)

**Valeur** : Pour qui : parents (gestion centralisée), enfants (accès facile). Pourquoi : expérience familiale fluide  
**Effort** : **MOYEN** (2-3 jours)

---

### 8. Journal de personnage — Historique XP + participations
**Étiquette** : [ANCRÉ]  
**Pourquoi** : S'appuie directement sur les règles (progression de niveau)  
**Description** :
- Page accessible depuis le profil du joueur
- Liste chronologique des participations : date événement, XP gagnée, niveau débloqué ou non
- Afficher solde d'XP permanent du joueur (global)
- Aucun classement public (pas de "top 10 joueurs")
- Afficher les niveaux atteints et dates

**Valeur** : Pour qui : joueurs (suivi de progression). Pourquoi : transparence, motivation, traçabilité  
**Effort** : **PETIT** (1-2 jours)

---

## SOUS-DÉCISION : Modèle de données pour FamilySession

**Problème** : Comment tracker le "profil actif" d'une famille ?

### Option A : Colonne dans `users`
```sql
users.activeProfileId (FK → FamilyProfile)
```
- ✅ Simple, une seule requête
- ❌ Mélange User (auth) et FamilyProfile (jeu)

### Option B : Table `FamilySession`
```sql
FamilySession (id, familyId, activeProfileId, userId, createdAt)
```
- ✅ Séparation claire, historique possible
- ❌ Une requête supplémentaire

### Option C : JWT claim
- Stocker `activeProfileId` dans le JWT
- ✅ Pas de requête DB
- ❌ Risque de stale data (JWT refresh lent)

**Recommandation** : **Option B (FamilySession)**
- Raison : Séparation claire, historique possible, pas de mélange User/Profile

---

## ROADMAP DE DÉPLOIEMENT

**Semaine 1** :
- [ ] Créer tables `Family`, `FamilyProfile`, `FamilySession`
- [ ] Migrer `personnages.userId` → `personnages.profileId`
- [ ] Écrire tests de migration
- [ ] Déployer en staging, tester

**Semaine 2** :
- [ ] Refondre builder UI (wizard, validation temps réel, résumé latéral)
- [ ] Ajouter infobulles
- [ ] Ajouter mode "Build assisté"
- [ ] Tests exhaustifs

**Semaine 3** :
- [ ] Ajouter export PDF
- [ ] Ajouter notifications email
- [ ] Refondre écran "Attribuer XP"
- [ ] Tests

**Semaine 4** :
- [ ] Ajouter écran "Gestion de famille"
- [ ] Ajouter journal de personnage
- [ ] Tests exhaustifs
- [ ] Déploiement progressif (10% → 50% → 100%)

---

## CHECKLIST DE VALIDATION AVANT DÉPLOIEMENT

- [ ] Toutes les migrations DB testées (forward + rollback)
- [ ] Tous les tests vitest passent (161+ tests)
- [ ] Aucune erreur TypeScript
- [ ] Export PDF fonctionne sur mobile et desktop
- [ ] Notifications email reçues correctement
- [ ] Comptes familiaux : parent peut basculer vers enfant et vice-versa
- [ ] Enfants ne peuvent pas choisir artisanats
- [ ] Builder validation temps réel fonctionne
- [ ] Infobulles affichent correctement
- [ ] Actions en masse "Attribuer XP" fonctionnent
- [ ] Rollback plan testé (peut revenir à version précédente en <5 min)

---

## QUESTIONS OUVERTES

1. **Email service** : Préférez-vous SendGrid, Mailjet, ou un autre ?
2. **PDF design** : Voulez-vous un design spécifique (couleurs Terra Mortis, logo, etc.) ?
3. **Déploiement progressif** : Êtes-vous à l'aise avec un déploiement 10% → 50% → 100% ?
4. **Rollback plan** : Avez-vous une stratégie de backup/restore de la DB ?
