import { trpc } from "@/lib/trpc";
import type { Race } from "../../../../drizzle/schema";
import { ChevronRight, Loader2, Skull, Users } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const factionColor = (faction: string) => {
  if (faction === "Sanctum") return "oklch(0.55 0.18 240)";
  if (faction === "Légion") return "oklch(0.5 0.22 25)";
  return "oklch(0.65 0.18 45)";
};

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);
const asAbilities = (v: unknown): { name: string; description: string }[] =>
  Array.isArray(v) ? (v as { name: string; description: string }[]) : [];

function RaceDetail({ race }: { race: Race }) {
  const physDesc = String(race.physicalDescription ?? "");
  const bonuses = asStrArr(race.bonuses);
  const maluses = asStrArr(race.maluses);
  const abilities = asAbilities(race.abilities);
  const languages = asStrArr(race.startingLanguages);

  return (
    <div className="p-6 rounded-xl border border-border/50 bg-card/30 sticky top-20 overflow-y-auto max-h-[80vh]">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-3xl font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>
            {race.name}
          </h2>
          <span
            className="text-sm px-3 py-1 rounded-full mt-2 inline-block font-heading"
            style={{
              background: `${factionColor(race.faction)}20`,
              color: factionColor(race.faction),
              border: `1px solid ${factionColor(race.faction)}40`,
            }}
          >
            {race.faction}
          </span>
        </div>
      </div>

      {/* Stat bonuses */}
      <div className="flex flex-wrap gap-2 mb-6">
        {race.pvBonus > 0 && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.45 0.15 140 / 0.2)", color: "oklch(0.65 0.2 140)", border: "1px solid oklch(0.45 0.15 140 / 0.4)" }}
          >
            +{race.pvBonus} PV
          </div>
        )}
        {race.manaBonus > 0 && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.55 0.18 240 / 0.2)", color: "oklch(0.65 0.2 240)", border: "1px solid oklch(0.55 0.18 240 / 0.4)" }}
          >
            +{race.manaBonus} Mana
          </div>
        )}
        {race.luteBonus > 0 && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.65 0.18 45 / 0.2)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.4)" }}
          >
            +{race.luteBonus} Lutte
          </div>
        )}
        {race.pvMalus > 0 && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.55 0.22 25 / 0.2)", color: "oklch(0.65 0.22 25)", border: "1px solid oklch(0.55 0.22 25 / 0.4)" }}
          >
            -{race.pvMalus} PV
          </div>
        )}
      </div>

      {/* Description */}
      <div className="mb-6">
        <h3 className="font-heading font-semibold mb-2 text-foreground">Description</h3>
        <p className="text-foreground/80 leading-relaxed text-sm">{race.description}</p>
      </div>

      {/* Physical description */}
      {physDesc.length > 0 && (
        <div className="mb-6">
          <h3 className="font-heading font-semibold mb-2 text-foreground">Description physique & costume</h3>
          <p className="text-foreground/80 leading-relaxed text-sm">{physDesc}</p>
        </div>
      )}

      {/* Bonuses */}
      {bonuses.length > 0 && (
        <div className="mb-4">
          <h3 className="font-heading font-semibold mb-2 text-foreground">Avantages raciaux</h3>
          <ul className="space-y-1">
            {bonuses.map((b, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "oklch(0.45 0.15 140)" }} />
                {b}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Maluses */}
      {maluses.length > 0 && (
        <div className="mb-4">
          <h3 className="font-heading font-semibold mb-2 text-foreground">Désavantages raciaux</h3>
          <ul className="space-y-1">
            {maluses.map((m, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "oklch(0.55 0.22 25)" }} />
                {m}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Abilities */}
      {abilities.length > 0 && (
        <div className="mb-4">
          <h3 className="font-heading font-semibold mb-3 text-foreground">Capacités raciales</h3>
          <div className="space-y-3">
            {abilities.map((ability, i) => (
              <div key={i} className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
                  {ability.name}
                </h4>
                <p className="text-xs text-foreground/75 leading-relaxed">{ability.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Languages */}
      {languages.length > 0 && (
        <div>
          <h3 className="font-heading font-semibold mb-2 text-foreground">Langues de départ</h3>
          <div className="flex flex-wrap gap-2">
            {languages.map((lang, i) => (
              <span
                key={i}
                className="px-2 py-1 rounded text-xs font-heading"
                style={{ background: "oklch(0.22 0.025 260)", color: "oklch(0.7 0.02 60)", border: "1px solid oklch(0.28 0.03 260)" }}
              >
                {lang}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Races() {
  const { data: races, isLoading } = trpc.rules.races.useQuery();
  const [selectedRace, setSelectedRace] = useState<number | null>(null);
  const [filterFaction, setFilterFaction] = useState<string>("Tous");

  const filtered = races?.filter(
    (r) => filterFaction === "Tous" || r.faction === filterFaction || r.faction === "Tous"
  );
  const selected = races?.find((r) => r.id === selectedRace);

  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Races", active: true },
      ]} />
      <div className="container max-w-6xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <Users className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Les Races
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Choisissez la race de votre personnage. Chaque race appartient à une faction et possède des capacités uniques.
          </p>
        </div>

        {/* Faction filter */}
        <div className="flex justify-center gap-3 mb-8">
          {["Tous", "Sanctum", "Légion"].map((f) => (
            <button
              key={f}
              onClick={() => setFilterFaction(f)}
              className="px-4 py-2 rounded-full text-sm font-heading transition-all"
              style={{
                background:
                  filterFaction === f
                    ? f === "Sanctum"
                      ? "oklch(0.55 0.18 240)"
                      : f === "Légion"
                        ? "oklch(0.5 0.22 25)"
                        : "oklch(0.65 0.18 45)"
                    : "oklch(0.22 0.025 260)",
                color: filterFaction === f ? "oklch(0.95 0.01 60)" : "oklch(0.6 0.02 60)",
                border: `1px solid ${filterFaction === f ? "transparent" : "oklch(0.28 0.03 260)"}`,
              }}
            >
              {f}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Race list */}
            <div className="lg:col-span-1 space-y-3">
              {filtered?.map((race) => {
                const color = factionColor(race.faction);
                const isSelected = selectedRace === race.id;
                return (
                  <button
                    key={race.id}
                    onClick={() => setSelectedRace(isSelected ? null : race.id)}
                    className="w-full text-left p-4 rounded-xl border transition-all"
                    style={{
                      background: isSelected ? `${color}15` : "oklch(0.16 0.02 260)",
                      borderColor: isSelected ? `${color}60` : "oklch(0.28 0.03 260)",
                      boxShadow: isSelected ? `0 0 20px ${color}20` : "none",
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-heading font-semibold text-foreground">{race.name}</h3>
                        <span
                          className="text-xs px-2 py-0.5 rounded mt-1 inline-block"
                          style={{ background: `${color}20`, color, border: `1px solid ${color}30` }}
                        >
                          {race.faction}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div className="flex gap-2 mt-2">
                      {race.pvBonus > 0 && <span className="text-xs text-green-400">+{race.pvBonus} PV</span>}
                      {race.manaBonus > 0 && <span className="text-xs text-blue-400">+{race.manaBonus} Mana</span>}
                      {race.luteBonus > 0 && <span className="text-xs text-yellow-400">+{race.luteBonus} Lutte</span>}
                      {race.pvMalus > 0 && <span className="text-xs text-red-400">-{race.pvMalus} PV</span>}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Race detail */}
            <div className="lg:col-span-2">
              {selected ? (
                <RaceDetail race={selected} />
              ) : (
                <div className="h-full flex items-center justify-center p-12 rounded-xl border border-dashed border-border/30">
                  <div className="text-center">
                    <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
                    <p className="text-muted-foreground font-heading">Sélectionnez une race pour voir ses détails</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
