import { Check, Zap, Shield, Wand2, Sword, BookOpen, Eye, Wind } from "lucide-react";

type CharData = any;

/**
 * Composant pour sélectionner les capacités bonus de niveau 1 et 2
 * Affiche les capacités des 2 voies non choisies de la classe
 */
export function StepCapacitesBonus({
  data,
  onChange,
  heritageData = [],
  classData,
  pathsData = [],
  abilitiesData = [],
}: {
  data: CharData;
  onChange: (d: Partial<CharData>) => void;
  heritageData: any[];
  classData: any;
  pathsData: any[];
  abilitiesData: any[];
}) {
  // Calculer le nombre de capacités bonus débloquées
  const extraAbilities = calcExtraAbilitiesForStep(data.heritageAvantages, heritageData);

  // Récupérer les voies bonus (les 2 voies non choisies)
  const bonusPathIds = getBonusPathIdsForStep(data.classId, data.classPathId, classData);

  // Récupérer les capacités des voies bonus
  const bonusAbilitiesLevel1 = getAbilitiesByLevel(bonusPathIds, 1, pathsData, abilitiesData);
  const bonusAbilitiesLevel2 = getAbilitiesByLevel(bonusPathIds, 2, pathsData, abilitiesData);

  const toggleAbility = (abilityId: number) => {
    const newSelected = data.selectedBonusAbilities.includes(abilityId)
      ? data.selectedBonusAbilities.filter((id: number) => id !== abilityId)
      : [...data.selectedBonusAbilities, abilityId];
    onChange({ selectedBonusAbilities: newSelected });
  };

  // Si aucune capacité bonus n'est débloquée, afficher un message
  if (extraAbilities.level1 === 0 && extraAbilities.level2 === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
            Capacités bonus
          </h2>
          <p className="text-muted-foreground text-sm">
            Vous n'avez pas acheté de capacités bonus dans l'héritage.
          </p>
        </div>
        <div className="p-6 rounded-xl border text-center" style={{ borderColor: "oklch(0.28 0.03 260)", background: "oklch(0.16 0.02 260)" }}>
          <p className="text-foreground/60">
            Pour débloquer des capacités bonus, achetez "+1 Capacité de niveau 1" ou "+1 Capacité de niveau 2" dans l'étape Héritage.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
          Capacités bonus
        </h2>
        <p className="text-muted-foreground text-sm">
          Choisissez vos capacités bonus parmi les autres voies de votre classe.
        </p>
      </div>

      {/* Capacités bonus niveau 1 */}
      {extraAbilities.level1 > 0 && bonusAbilitiesLevel1.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1 h-6 rounded-full" style={{ background: "oklch(0.65 0.18 45)" }}></div>
            <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>
              Capacités de niveau 1
            </h3>
            <span className="text-sm font-medium px-2 py-1 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.65 0.18 45)" }}>
              {getSelectedCount(bonusAbilitiesLevel1, data.selectedBonusAbilities)}/{extraAbilities.level1}
            </span>
          </div>
          <div className="grid gap-3">
            {bonusAbilitiesLevel1.map((ability: any) => {
              const isSelected = data.selectedBonusAbilities.includes(ability.id);
              const canSelect = canSelectAbility(ability, 1, data.selectedBonusAbilities, extraAbilities, bonusAbilitiesLevel1);
              const icon = getAbilityIcon(ability.name);
              return (
                <button
                  key={ability.id}
                  onClick={() => canSelect && toggleAbility(ability.id)}
                  disabled={!canSelect && !isSelected}
                  className="p-4 rounded-lg border text-left transition-all hover:shadow-md"
                  style={{
                    background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                    borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
                    opacity: !canSelect && !isSelected ? 0.5 : 1,
                    cursor: canSelect ? "pointer" : "not-allowed",
                    boxShadow: isSelected ? "0 0 15px oklch(0.65 0.18 45 / 0.15)" : "none",
                  }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "oklch(0.65 0.18 45 / 0.2)" }}>
                        {icon}
                      </div>
                      <div className="flex-1">
                        <div className="font-heading font-semibold text-foreground mb-1">{ability.name}</div>
                        <div className="text-xs text-foreground/60 leading-relaxed">{ability.description}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "oklch(0.65 0.18 45)" }}>
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Capacités bonus niveau 2 */}
      {extraAbilities.level2 > 0 && bonusAbilitiesLevel2.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1 h-6 rounded-full" style={{ background: "oklch(0.45 0.15 140)" }}></div>
            <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>
              Capacités de niveau 2
            </h3>
            <span className="text-sm font-medium px-2 py-1 rounded" style={{ background: "oklch(0.45 0.15 140 / 0.15)", color: "oklch(0.45 0.15 140)" }}>
              {getSelectedCount(bonusAbilitiesLevel2, data.selectedBonusAbilities)}/{extraAbilities.level2}
            </span>
          </div>
          <div className="grid gap-3">
            {bonusAbilitiesLevel2.map((ability: any) => {
              const isSelected = data.selectedBonusAbilities.includes(ability.id);
              const canSelect = canSelectAbility(ability, 2, data.selectedBonusAbilities, extraAbilities, bonusAbilitiesLevel2);
              const icon = getAbilityIcon(ability.name);
              return (
                <button
                  key={ability.id}
                  onClick={() => canSelect && toggleAbility(ability.id)}
                  disabled={!canSelect && !isSelected}
                  className="p-4 rounded-lg border text-left transition-all hover:shadow-md"
                  style={{
                    background: isSelected ? "oklch(0.45 0.15 140 / 0.12)" : "oklch(0.16 0.02 260)",
                    borderColor: isSelected ? "oklch(0.45 0.15 140 / 0.6)" : "oklch(0.28 0.03 260)",
                    opacity: !canSelect && !isSelected ? 0.5 : 1,
                    cursor: canSelect ? "pointer" : "not-allowed",
                    boxShadow: isSelected ? "0 0 15px oklch(0.45 0.15 140 / 0.15)" : "none",
                  }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "oklch(0.45 0.15 140 / 0.2)" }}>
                        {icon}
                      </div>
                      <div className="flex-1">
                        <div className="font-heading font-semibold text-foreground mb-1">{ability.name}</div>
                        <div className="text-xs text-foreground/60 leading-relaxed">{ability.description}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-1" style={{ background: "oklch(0.45 0.15 140)" }}>
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Fonctions utilitaires ───────────────────────────────────────────────────

function calcExtraAbilitiesForStep(heritageAvantages: { id: number; times: number }[], heritageData: any[]): { level1: number; level2: number } {
  let level1 = 0;
  let level2 = 0;

  heritageAvantages.forEach((h) => {
    const ha = heritageData.find((x) => x.id === h.id);
    if (ha) {
      level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
      level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
    }
  });

  return { level1, level2 };
}

function getBonusPathIdsForStep(classId: number | null, selectedPathId: number | null, classData: any): number[] {
  if (!classId || !classData) return [];
  const paths = classData.paths || [];
  return paths.filter((p: any) => p.id !== selectedPathId).map((p: any) => p.id);
}

function getAbilitiesByLevel(pathIds: number[], level: 1 | 2, pathsData: any[], abilitiesData: any[]): any[] {
  const abilities: any[] = [];

  pathIds.forEach((pathId) => {
    const path = pathsData.find((p) => p.id === pathId);
    if (path) {
      const levelKey = level === 1 ? "level1Abilities" : "level2Abilities";
      const pathAbilities = path[levelKey] || [];
      pathAbilities.forEach((abilityId: number) => {
        const ability = abilitiesData.find((a) => a.id === abilityId);
        if (ability) {
          abilities.push(ability);
        }
      });
    }
  });

  return abilities;
}

function getSelectedCount(abilities: any[], selectedIds: number[]): number {
  return abilities.filter((a) => selectedIds.includes(a.id)).length;
}

function canSelectAbility(ability: any, level: 1 | 2, selectedIds: number[], extraAbilities: { level1: number; level2: number }, levelAbilities: any[]): boolean {
  const isSelected = selectedIds.includes(ability.id);
  if (isSelected) return true;

  const limit = level === 1 ? extraAbilities.level1 : extraAbilities.level2;
  const selectedCount = getSelectedCount(levelAbilities, selectedIds);

  return selectedCount < limit;
}

/**
 * Retourne une icône appropriée basée sur le nom de la capacité
 */
function getAbilityIcon(name: string) {
  const lowerName = name.toLowerCase();
  
  if (lowerName.includes("magie") || lowerName.includes("arcane") || lowerName.includes("sort")) {
    return <Wand2 className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />;
  }
  if (lowerName.includes("armure") || lowerName.includes("protection") || lowerName.includes("résist")) {
    return <Shield className="w-5 h-5" style={{ color: "oklch(0.45 0.15 140)" }} />;
  }
  if (lowerName.includes("épée") || lowerName.includes("arme") || lowerName.includes("combat") || lowerName.includes("frappe")) {
    return <Sword className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />;
  }
  if (lowerName.includes("vitesse") || lowerName.includes("agilité") || lowerName.includes("rapide")) {
    return <Wind className="w-5 h-5" style={{ color: "oklch(0.55 0.18 240)" }} />;
  }
  if (lowerName.includes("vision") || lowerName.includes("regard") || lowerName.includes("voir")) {
    return <Eye className="w-5 h-5" style={{ color: "oklch(0.55 0.18 240)" }} />;
  }
  if (lowerName.includes("savoir") || lowerName.includes("connaissance") || lowerName.includes("étude")) {
    return <BookOpen className="w-5 h-5" style={{ color: "oklch(0.55 0.18 240)" }} />;
  }
  if (lowerName.includes("pouvoir") || lowerName.includes("énergie") || lowerName.includes("force")) {
    return <Zap className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />;
  }
  
  // Icône par défaut
  return <Zap className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />;
}
