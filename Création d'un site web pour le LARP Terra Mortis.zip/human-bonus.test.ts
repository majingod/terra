import { describe, it, expect } from "vitest";

describe("Human Bonus Type", () => {
  it("should allow human to choose PV bonus", () => {
    const humanBonusType = "pv" as const;
    expect(humanBonusType).toBe("pv");
  });

  it("should allow human to choose PM bonus", () => {
    const humanBonusType = "pm" as const;
    expect(humanBonusType).toBe("pm");
  });

  it("should allow human bonus to be null", () => {
    const humanBonusType: "pv" | "pm" | null = null;
    expect(humanBonusType).toBeNull();
  });

  it("should validate human bonus type values", () => {
    const validTypes = ["pv", "pm"];
    const testType = "pv";
    expect(validTypes).toContain(testType);
  });

  it("should not allow invalid bonus types", () => {
    const validTypes = ["pv", "pm"];
    const invalidType = "hp";
    expect(validTypes).not.toContain(invalidType);
  });

  it("should handle bonus type changes", () => {
    let humanBonusType: "pv" | "pm" | null = null;
    expect(humanBonusType).toBeNull();
    
    humanBonusType = "pv";
    expect(humanBonusType).toBe("pv");
    
    humanBonusType = "pm";
    expect(humanBonusType).toBe("pm");
    
    humanBonusType = null;
    expect(humanBonusType).toBeNull();
  });

  it("should calculate PV bonus correctly", () => {
    const basePV = 10;
    const humanBonusType = "pv" as const;
    const pvBonus = humanBonusType === "pv" ? 1 : 0;
    const totalPV = basePV + pvBonus;
    
    expect(totalPV).toBe(11);
  });

  it("should calculate PM bonus correctly", () => {
    const basePM = 5;
    const humanBonusType = "pm" as const;
    const pmBonus = humanBonusType === "pm" ? 1 : 0;
    const totalPM = basePM + pmBonus;
    
    expect(totalPM).toBe(6);
  });

  it("should not apply bonus when type is null", () => {
    const basePV = 10;
    const basePM = 5;
    const humanBonusType: "pv" | "pm" | null = null;
    
    const pvBonus = humanBonusType === "pv" ? 1 : 0;
    const pmBonus = humanBonusType === "pm" ? 1 : 0;
    
    expect(basePV + pvBonus).toBe(10);
    expect(basePM + pmBonus).toBe(5);
  });

  it("should apply only one bonus at a time", () => {
    const basePV = 10;
    const basePM = 5;
    const humanBonusType = "pv" as const;
    
    const pvBonus = humanBonusType === "pv" ? 1 : 0;
    const pmBonus = humanBonusType === "pm" ? 1 : 0;
    
    expect(basePV + pvBonus).toBe(11);
    expect(basePM + pmBonus).toBe(5);
  });

  it("should handle switching between bonus types", () => {
    const basePV = 10;
    const basePM = 5;
    
    // Start with PV bonus
    let humanBonusType: "pv" | "pm" = "pv";
    let totalPV = basePV + (humanBonusType === "pv" ? 1 : 0);
    let totalPM = basePM + (humanBonusType === "pm" ? 1 : 0);
    
    expect(totalPV).toBe(11);
    expect(totalPM).toBe(5);
    
    // Switch to PM bonus
    humanBonusType = "pm";
    totalPV = basePV + (humanBonusType === "pv" ? 1 : 0);
    totalPM = basePM + (humanBonusType === "pm" ? 1 : 0);
    
    expect(totalPV).toBe(10);
    expect(totalPM).toBe(6);
  });
});
