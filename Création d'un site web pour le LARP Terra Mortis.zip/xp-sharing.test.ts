import { describe, it, expect, beforeAll, afterAll } from "vitest";
import {
  getFamilyProfilePermanentXP,
  getUserCharacters,
  addFamilyProfilePermanentXP,
  transferCharacterXP,
  getUserXPHistory,
  validateXPLimits,
  getFamilyProfileXPStats,
  awardXPForInscription,
} from "./xp-sharing";
import { getDb } from "./db";
import { users, familyProfiles, personnages, families, evenements, inscriptions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("XP Sharing Procedures", () => {
  let testUserId: number;
  let testFamilyId: number;
  let testProfileId: number;
  let testCharacterId1: number;
  let testCharacterId2: number;
  let testEventId: number;
  let testInscriptionId: number;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Créer un utilisateur de test
    const userResult = await db.insert(users).values({
      openId: `test-xp-sharing-${Date.now()}`,
      name: "Test XP Sharing",
      role: "user",
    });
    testUserId = userResult[0].insertId as number;

    // Créer une famille
    const familyResult = await db.insert(families).values({
      userId: testUserId,
      name: "Test Family",
      createdBy: testUserId,
    });
    testFamilyId = familyResult[0].insertId as number;

    // Créer un profil de famille
    const profileResult = await db.insert(familyProfiles).values({
      familyId: testFamilyId,
      name: "Test Profile",
      role: "parent",
      xpPermanent: 0,
    });
    testProfileId = profileResult[0].insertId as number;

    // Créer des personnages de test
    const char1Result = await db.insert(personnages).values({
      userId: testUserId,
      name: "Character 1",
      background: "Test",
      faction: "Sanctum",
      raceId: 1,
      classId: 1,
      level: 1,
      xpPermanent: 100,
      xpTemporaire: 50,
    });
    testCharacterId1 = char1Result[0].insertId as number;

    const char2Result = await db.insert(personnages).values({
      userId: testUserId,
      name: "Character 2",
      background: "Test",
      faction: "Légion",
      raceId: 1,
      classId: 1,
      level: 1,
      xpPermanent: 80,
      xpTemporaire: 30,
    });
    testCharacterId2 = char2Result[0].insertId as number;

    const eventResult = await db.insert(evenements).values({
      title: "Test Event XP",
      description: "Event for XP award tests",
      location: "Stukely-Sud",
      startDate: new Date("2026-09-01T10:00:00Z"),
      endDate: new Date("2026-09-01T18:00:00Z"),
      maxPlayers: 0,
      status: "completed",
      faction: "Tous",
      createdBy: testUserId,
    });
    testEventId = eventResult[0].insertId as number;

    const inscriptionResult = await db.insert(inscriptions).values({
      evenementId: testEventId,
      userId: testUserId,
      personnageId: testCharacterId1,
      status: "confirmed",
    });
    testInscriptionId = inscriptionResult[0].insertId as number;
  });

  afterAll(async () => {
    const db = await getDb();
    if (!db) return;

    // Nettoyer les données de test
    await db.delete(inscriptions).where(eq(inscriptions.id, testInscriptionId));
    await db.delete(evenements).where(eq(evenements.id, testEventId));
    await db.delete(personnages).where(eq(personnages.userId, testUserId));
    await db.delete(familyProfiles).where(eq(familyProfiles.familyId, testFamilyId));
    await db.delete(families).where(eq(families.id, testFamilyId));
    await db.delete(users).where(eq(users.id, testUserId));
  });

  describe("getFamilyProfilePermanentXP", () => {
    it("should return the permanent XP of a family profile", async () => {
      const xp = await getFamilyProfilePermanentXP(testProfileId);
      expect(xp).toBe(0);
    });

    it("should return 0 for non-existent profile", async () => {
      const xp = await getFamilyProfilePermanentXP(99999);
      expect(xp).toBe(0);
    });
  });

  describe("getUserCharacters", () => {
    it("should return all characters of a user", async () => {
      const characters = await getUserCharacters(testUserId);
      expect(characters.length).toBeGreaterThanOrEqual(2);
      expect(characters[0]).toHaveProperty("id");
      expect(characters[0]).toHaveProperty("name");
      expect(characters[0]).toHaveProperty("xpPermanent");
      expect(characters[0]).toHaveProperty("xpTemporaire");
      expect(characters[0]).toHaveProperty("level");
    });

    it("should return empty array for non-existent user", async () => {
      const characters = await getUserCharacters(99999);
      expect(characters).toEqual([]);
    });
  });

  describe("addFamilyProfilePermanentXP", () => {
    it("should add XP to family profile", async () => {
      const result = await addFamilyProfilePermanentXP(
        testProfileId,
        testUserId,
        100,
        "test",
        undefined,
        "Test XP addition"
      );

      expect(result.soldeBefore).toBe(0);
      expect(result.soldeAfter).toBe(100);
      expect(result.montant).toBe(100);

      // Vérifier que l'XP a été mis à jour
      const xp = await getFamilyProfilePermanentXP(testProfileId);
      expect(xp).toBe(100);
    });

    it("should not allow negative XP", async () => {
      const result = await addFamilyProfilePermanentXP(
        testProfileId,
        testUserId,
        -200,
        "test",
        undefined,
        "Test negative XP"
      );

      expect(result.soldeAfter).toBe(0); // Math.max(0, 100 - 200) = 0
    });
  });

  describe("transferCharacterXP", () => {
    it("should transfer XP between characters", async () => {
      const result = await transferCharacterXP(
        testCharacterId1,
        testCharacterId2,
        20,
        testUserId,
        "Test transfer"
      );

      expect(result.fromCharacter.xpAfter).toBe(30); // 50 - 20
      expect(result.toCharacter.xpAfter).toBe(50); // 30 + 20
      expect(result.amount).toBe(20);
    });

    it("should fail if source character has insufficient XP", async () => {
      try {
        await transferCharacterXP(
          testCharacterId1,
          testCharacterId2,
          1000,
          testUserId,
          "Test insufficient XP"
        );
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("Insufficient XP");
      }
    });

    it("should fail if character does not belong to user", async () => {
      try {
        await transferCharacterXP(
          testCharacterId1,
          99999,
          10,
          testUserId,
          "Test invalid character"
        );
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("not found or does not belong");
      }
    });
  });

  describe("validateXPLimits", () => {
    it("should validate XP within limits", () => {
      const result = validateXPLimits(1, 50);
      expect(result.isValid).toBe(true);
      expect(result.maxXP).toBe(100);
    });

    it("should invalidate XP exceeding limits", () => {
      const result = validateXPLimits(1, 150);
      expect(result.isValid).toBe(false);
      expect(result.maxXP).toBe(100);
      expect(result.message).toContain("dépasse la limite");
    });

    it("should use default limit for high levels", () => {
      const result = validateXPLimits(15, 2000);
      expect(result.isValid).toBe(true);
      expect(result.maxXP).toBe(3250);
    });
  });

  describe("getUserXPHistory", () => {
    it("should return XP history for user", async () => {
      const history = await getUserXPHistory(testUserId, 10);
      expect(Array.isArray(history)).toBe(true);
      if (history.length > 0) {
        expect(history[0]).toHaveProperty("userId");
        expect(history[0]).toHaveProperty("montant");
        expect(history[0]).toHaveProperty("createdAt");
      }
    });

    it("should respect limit parameter", async () => {
      const history = await getUserXPHistory(testUserId, 1);
      expect(history.length).toBeLessThanOrEqual(1);
    });
  });

  describe("awardXPForInscription", () => {
    it("should award XP to the registered character and record the event", async () => {
      const result = await awardXPForInscription(
        testInscriptionId,
        25,
        "Participation au GN",
        testUserId,
      );

      expect(result.inscriptionId).toBe(testInscriptionId);
      expect(result.targetType).toBe("character");
      expect(result.characterId).toBe(testCharacterId1);
      expect(result.soldeBefore).toBe(100);
      expect(result.soldeAfter).toBe(125);
      expect(result.montant).toBe(25);
      expect(result.description).toBe("Participation au GN");
    });

    it("should reject an unknown inscription", async () => {
      await expect(
        awardXPForInscription(999999, 10, undefined, testUserId),
      ).rejects.toThrow("Inscription not found");
    });
  });

  describe("getFamilyProfileXPStats", () => {
    it("should return XP statistics for profile", async () => {
      const stats = await getFamilyProfileXPStats(testProfileId, testUserId);

      expect(stats).toHaveProperty("profilePermanentXP");
      expect(stats).toHaveProperty("characterCount");
      expect(stats).toHaveProperty("totalCharacterXP");
      expect(stats).toHaveProperty("totalEarned");
      expect(stats).toHaveProperty("totalSpent");
      expect(stats).toHaveProperty("transactionCount");

      expect(typeof stats.profilePermanentXP).toBe("number");
      expect(typeof stats.characterCount).toBe("number");
    });

    it("should calculate totals correctly", async () => {
      const stats = await getFamilyProfileXPStats(testProfileId, testUserId);

      expect(stats.characterCount).toBeGreaterThanOrEqual(2);
      expect(stats.totalCharacterXP).toBeGreaterThanOrEqual(0);
    });
  });
});
