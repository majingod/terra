# Architecture Détaillée — Terra Mortis Modulaire

## 1. Principes Fondamentaux

### Source Unique de Données
L'**Encyclopédie** (`encyclopedie_entries`) est la source unique de vérité pour toutes les données du jeu. Aucune donnée ne doit être codée en dur dans le générateur de personnage ou les pages de règles.

### Propagation Automatique
Quand une entrée de l'Encyclopédie est modifiée, tous les systèmes qui l'utilisent doivent se mettre à jour automatiquement :
- Générateur de personnage
- Pages de règles
- Fiches de personnage
- Calculs de statistiques

### Audit Trail Complet
Chaque modification de l'Encyclopédie est enregistrée dans `encyclopedie_history` avec :
- Ancien contenu
- Nouveau contenu
- Qui a modifié
- Quand
- Raison du changement
- Possibilité de rollback

---

## 2. Catégories de l'Encyclopédie

| Catégorie | Exemples | Propriétés Clés | Relations |
|-----------|----------|-----------------|-----------|
| **races** | Humain, Elfe, Nain, Orc, Drow, Gobelin | faction, pv_bonus, mana_bonus, capacites_raciales, langues | Aucune |
| **factions** | Sanctum, Légion | description, couleurs, races_disponibles | races (1:N) |
| **classes** | Druide, Guerrier, Magicien, Roublard, CdM, Sorcier, Medjai, Paladin | pv_base, mana_base, sous_specialisations, code_conduite | sous_classes (1:N) |
| **sous_classes** | Chaman, Élémentaliste, Clerc, etc. | classe_parent_id, capacites_par_niveau | classes (N:1), capacites (1:N) |
| **capacites** | Toutes les capacités par niveau | niveau, sous_classe_id, description, effet | sous_classes (N:1) |
| **dons** | Affinité magique, Agilité, Brise bouclier, etc. | effet, cumulable, max_fois | Aucune |
| **competences** | Érudit, Riche, Herboriste, Alchimiste, Forgeron, Runiste | type (Simple/Artisanat), avantage_base, avantage_avance, interdit_enfants | Aucune |
| **heritage_avantages** | +1 PV, +1 Mana, +1 Don, +1 Capacité, etc. | xp_cost, max_times, effet, debloque, extraAbilitiesLevel1/2 | Aucune |
| **heritage_desavantages** | Amputé, Asthmatique, Boiteux, etc. | xp_gain, restrictions (classes interdites) | Aucune |
| **ressources** | Alchimite, Arcanite, Adamantium, Aurorium, Mythril | valeur, source | Aucune |
| **recettes_alchimie** | Potion de soins, Potion de Mana, Poison | composition, effet, couleur | ressources (N:N) |
| **forge** | Objets en matériaux rares | materiau, effet_arme, effet_armure, effet_bouclier | ressources (N:1) |
| **runes** | Runes d'arme, Runes d'amulette | type, effet, description | Aucune |
| **objets_magiques** | Objets spéciaux cartonné | description, effet, restrictions | Aucune |
| **regles_combat** | PV, Mana, Lutte, Sauvegardes, types de dégâts | formule, description, exemple | Aucune |
| **symboles** | Invisibilité, Vol, Immatériel, Invulnérable | geste, effet, description | Aucune |
| **langues** | Commun, Elfe, Nain, Orc, Runique, Abyssal, Druidique, Langue des morts | description, races_disponibles, classes_exclusives | Aucune |
| **armures** | Plastron métal, cuir, casque, bouclier, etc. | type, protection, malus_mana, description | Aucune |
| **caracteristiques** | Puissance, Résistance, Esprit | valeurs (1-5), bonus_par_valeur | Aucune |

---

## 3. Schémas JSON Détaillés

### 3.1 Races
```json
{
  "faction": "Sanctum",
  "pv_bonus": 1,
  "pv_malus": 0,
  "mana_bonus": 0,
  "lutte_bonus": 0,
  "capacites_raciales": [
    {
      "nom": "Transfert de Mana",
      "description": "Donner ou recevoir Mana d'une cible consentante",
      "cooldown": "1/heure"
    }
  ],
  "description_physique": "Oreilles pointues, pas de barbe",
  "langues": ["Commun", "Elfe"],
  "restrictions": {
    "classes_interdites": [],
    "factions": ["Sanctum"]
  }
}
```

### 3.2 Classes
```json
{
  "faction": "Toutes",
  "pv_base": 6,
  "mana_base": 1,
  "sous_specialisations": [
    {
      "id": 1,
      "nom": "Barbare",
      "description": "Maître du combat rapproché"
    },
    {
      "id": 2,
      "nom": "Ravageur",
      "description": "Destructeur de défenses"
    },
    {
      "id": 3,
      "nom": "Gladiateur",
      "description": "Combattant d'arène"
    }
  ],
  "code_conduite": null,
  "systeme_special": null
}
```

### 3.3 Sous-classes
```json
{
  "classe_parent_id": 1,
  "classe_parent_nom": "Guerrier",
  "description": "Maître du combat rapproché",
  "capacites_par_niveau": {
    "1": [
      {
        "id": 10,
        "nom": "Coup puissant",
        "description": "Augmente la puissance de 1",
        "effet": "+1 Lutte"
      }
    ],
    "2": [
      {
        "id": 12,
        "nom": "Frappe écrasante",
        "description": "Coup dévastateur",
        "effet": "+2 dégâts"
      }
    ]
  }
}
```

### 3.4 Héritage Avantages
```json
{
  "xp_cost": 3,
  "max_times": 1,
  "effet": "+1 Capacité de niveau 1",
  "description": "Débloque une capacité supplémentaire de niveau 1 d'une voie non choisie",
  "debloque": "capacites_bonus_niveau_1",
  "extraAbilitiesLevel1": 1,
  "extraAbilitiesLevel2": 0,
  "restrictions": {
    "classes_exclusives": [],
    "classes_interdites": []
  }
}
```

### 3.5 Héritage Désavantages
```json
{
  "xp_gain": 3,
  "description": "Manque un bras ou une jambe",
  "effet": "Perte d'une main",
  "restrictions": {
    "classes_interdites": ["Paladin", "CdM"],
    "max_par_personnage": 1
  },
  "roleplay_requirements": "Doit jouer avec un bras/jambe manquant"
}
```

---

## 4. Procédures tRPC Principales

### 4.1 Encyclopédie (Lecture Publique)

#### `encyclopedia.getAll()`
Retourne toutes les entrées de l'encyclopédie

```typescript
// Response
{
  entries: [
    {
      id: 1,
      nom: "Humain",
      categorie: "races",
      description: "...",
      proprietes: { faction: "Toutes", pv_bonus: 1, ... },
      relations: { ... }
    },
    ...
  ]
}
```

#### `encyclopedia.getByCategory(category: string)`
Retourne toutes les entrées d'une catégorie

```typescript
// Input
{ category: "races" }

// Response
{
  entries: [
    { id: 1, nom: "Humain", ... },
    { id: 2, nom: "Elfe", ... },
    ...
  ]
}
```

#### `encyclopedia.getById(id: number)`
Retourne une entrée spécifique avec ses relations

```typescript
// Input
{ id: 1 }

// Response
{
  entry: {
    id: 1,
    nom: "Humain",
    categorie: "races",
    description: "...",
    proprietes: { ... },
    relations: {
      prerequis: [],
      incompatible: [],
      debloque: [5, 6, 7]
    },
    related_entries: [
      { id: 5, nom: "Guerrier", categorie: "classes" },
      { id: 6, nom: "Magicien", categorie: "classes" },
      ...
    ]
  }
}
```

#### `encyclopedia.search(query: string, filters?: object)`
Recherche globale dans l'encyclopédie

```typescript
// Input
{
  query: "mana",
  filters: {
    categorie: "dons",
    faction: "Sanctum"
  }
}

// Response
{
  results: [
    {
      id: 5,
      nom: "Affinité magique",
      categorie: "dons",
      description: "+1 Mana (cumulable)",
      score: 0.95  // Score de pertinence
    },
    ...
  ]
}
```

#### `encyclopedia.getRelated(id: number, type?: string)`
Retourne les entrées liées

```typescript
// Input
{
  id: 1,  // Humain (race)
  type: "classes"  // Optionnel : filtrer par type
}

// Response
{
  related: [
    { id: 5, nom: "Guerrier", categorie: "classes", relation: "compatible" },
    { id: 6, nom: "Magicien", categorie: "classes", relation: "compatible" },
    ...
  ]
}
```

### 4.2 Encyclopédie (Admin - CRUD)

#### `admin.encyclopedia.create(data: object)`
Crée une nouvelle entrée

```typescript
// Input
{
  nom: "Nouvelle capacité",
  categorie: "capacites",
  description: "...",
  proprietes: { niveau: 1, sous_classe_id: 1, ... },
  faction_requise: null
}

// Response
{
  id: 100,
  nom: "Nouvelle capacité",
  ...
}
```

#### `admin.encyclopedia.update(id: number, data: object)`
Modifie une entrée existante

```typescript
// Input
{
  id: 1,
  nom: "Humain (modifié)",
  proprietes: { pv_bonus: 2, ... }
}

// Response
{
  id: 1,
  nom: "Humain (modifié)",
  ...
}
```

#### `admin.encyclopedia.delete(id: number)`
Supprime une entrée (soft delete)

```typescript
// Input
{ id: 1 }

// Response
{ success: true }
```

#### `admin.encyclopedia.getHistory(id: number)`
Retourne l'historique des modifications

```typescript
// Input
{ id: 1 }

// Response
{
  history: [
    {
      id: 100,
      ancien_contenu: { ... },
      nouveau_contenu: { ... },
      action: "update",
      modified_by: 5,
      modified_at: "2026-03-10T10:30:00Z",
      raison: "Correction du bonus PV"
    },
    ...
  ]
}
```

#### `admin.encyclopedia.rollback(id: number, versionId: number)`
Revient à une version antérieure

```typescript
// Input
{
  id: 1,
  versionId: 100
}

// Response
{
  entry: { ... },
  message: "Rollback effectué avec succès"
}
```

### 4.3 Événements

#### `events.getUpcoming()`
Retourne les événements à venir

```typescript
// Response
{
  events: [
    {
      id: 1,
      titre: "Bataille de Ysgard",
      date_event: "2026-04-15",
      lieu: "Parc Lafontaine",
      description: "...",
      factions_concernees: ["Sanctum", "Légion"],
      inscriptions_count: 45
    },
    ...
  ]
}
```

#### `events.register(eventId: number, characterId: number)`
Inscrit un personnage à un événement

```typescript
// Input
{
  eventId: 1,
  characterId: 5
}

// Response
{
  inscription: {
    id: 100,
    event_id: 1,
    personnage_id: 5,
    created_at: "2026-03-10T10:30:00Z"
  }
}
```

#### `events.getMyRegistrations()`
Retourne les événements auxquels le joueur est inscrit

```typescript
// Response
{
  registrations: [
    {
      event_id: 1,
      event_titre: "Bataille de Ysgard",
      event_date: "2026-04-15",
      personnage_id: 5,
      personnage_nom: "Aldric le Sombre",
      present: null
    },
    ...
  ]
}
```

### 4.4 XP Permanent

#### `xp.getBalance()`
Retourne le solde d'XP permanent du joueur

```typescript
// Response
{
  total: 15,
  depense: 3,
  disponible: 12,
  historique: [
    {
      montant: 1,
      source: "Événement: Bataille de Ysgard",
      date: "2026-03-10T10:30:00Z"
    },
    ...
  ]
}
```

#### `xp.getHistory()`
Retourne l'historique complet de l'XP

```typescript
// Response
{
  history: [
    {
      id: 1,
      montant: 1,
      solde_avant: 0,
      solde_apres: 1,
      source_type: "event",
      source_id: 1,
      description: "Événement: Bataille de Ysgard",
      created_at: "2026-03-10T10:30:00Z"
    },
    ...
  ]
}
```

---

## 5. Flux de Données Détaillés

### 5.1 Création d'un Personnage

```
1. Utilisateur accède au générateur
   ↓
2. Générateur charge les données depuis l'Encyclopédie
   - Factions
   - Races (filtrées par faction)
   - Classes (filtrées par faction)
   - Sous-classes
   - Capacités
   - Dons
   - Compétences
   - Héritage (avantages + désavantages)
   ↓
3. Utilisateur remplit le formulaire étape par étape
   ↓
4. À chaque étape, les données sont validées contre l'Encyclopédie
   - Vérification des restrictions de faction/race/classe
   - Vérification des prérequis
   - Calcul des statistiques
   ↓
5. Utilisateur clique "Sauvegarder"
   ↓
6. Données insérées en base de données
   - personnages (insert)
   - personnage_dons (insert)
   - personnage_competences (insert)
   - personnage_heritage (insert)
   - xp_permanent_history (insert si XP dépensé)
   ↓
7. Fiche de personnage générée et affichée
```

### 5.2 Modification de l'Encyclopédie

```
1. Admin accède au panneau administrateur
   ↓
2. Admin modifie une entrée (ex: augmenter le bonus PV des Orcs)
   ↓
3. Modification enregistrée
   - encyclopedie_entries (update)
   - encyclopedie_history (insert audit)
   ↓
4. Tous les systèmes se mettent à jour automatiquement
   - Générateur recharge les données
   - Pages de règles se rafraîchissent
   - Fiches de personnages existants se recalculent
   ↓
5. Les joueurs voient les changements en temps réel
```

### 5.3 Événement avec Attribution d'XP

```
1. Admin crée un événement
   - events (insert)
   ↓
2. Joueurs consultent les événements
   - events.getUpcoming()
   ↓
3. Joueurs s'inscrivent avec leurs personnages
   - event_inscriptions (insert)
   ↓
4. Événement se déroule
   ↓
5. Admin clôt l'événement
   - Sélectionne les joueurs présents
   - event_inscriptions (update present = true)
   ↓
6. Attribution automatique d'XP
   - Pour chaque joueur présent :
     - xp_permanent_history (insert)
     - users.xp_permanent_total (update)
   ↓
7. Joueurs voient leur XP augmenté dans leur profil
   - Peuvent l'utiliser à la création du prochain personnage
```

---

## 6. Stratégie de Migration

### Phase 1 : Préparation (1 jour)
1. Créer les nouvelles tables dans la base de données
2. Créer les indices pour la performance
3. Sauvegarder les données existantes
4. Tester les migrations en environnement de développement

### Phase 2 : Migration des Données (1 jour)
1. Écrire les scripts de transformation
2. Migrer les races
3. Migrer les classes et sous-classes
4. Migrer les capacités avec leurs relations
5. Migrer les dons, compétences, héritage
6. Ajouter les nouvelles catégories

### Phase 3 : Validation (1 jour)
1. Vérifier l'intégrité des données migrées
2. Tester les relations croisées
3. Valider les contraintes de faction/race/classe
4. Tester la performance des requêtes
5. Vérifier que les anciens systèmes fonctionnent toujours

### Phase 4 : Déploiement (1 jour)
1. Déployer les nouvelles tables en production
2. Exécuter les scripts de migration
3. Activer les nouvelles procédures tRPC
4. Garder les anciennes tables comme fallback
5. Monitorer les performances

### Phase 5 : Cleanup (optionnel)
- Après 2 semaines de stabilité
- Supprimer les anciennes tables
- Archiver les données

---

## 7. Rollback Plan

En cas de problème :

1. **Immédiat** : Désactiver les nouvelles procédures tRPC
2. **Court terme** : Revenir aux anciennes tables
3. **Moyen terme** : Analyser le problème
4. **Long terme** : Corriger et redéployer

Les anciennes tables sont conservées pendant 2 semaines comme fallback.

---

## 8. Performance et Optimisations

### Indices Critiques
```sql
-- Recherche par catégorie
CREATE INDEX idx_categorie ON encyclopedie_entries(categorie);

-- Filtrage par faction
CREATE INDEX idx_faction ON encyclopedie_entries(faction_requise);

-- Recherche par nom
CREATE INDEX idx_nom ON encyclopedie_entries(nom);

-- Historique par entrée
CREATE INDEX idx_entry_history ON encyclopedie_history(entry_id, modified_at DESC);

-- Événements par date
CREATE INDEX idx_events_date ON events(date_event);

-- Inscriptions par événement
CREATE INDEX idx_inscriptions_event ON event_inscriptions(event_id);

-- XP par utilisateur
CREATE INDEX idx_xp_user ON xp_permanent_history(user_id, created_at DESC);
```

### Caching Strategy
- Cache les entrées de l'encyclopédie pendant 1 heure
- Invalide le cache quand une modification est effectuée
- Cache les résultats de recherche pendant 30 minutes

### Requêtes Optimisées
- Utiliser les JOINs au lieu de requêtes multiples
- Charger les relations en batch
- Limiter les résultats de recherche (pagination)

---

## 9. Sécurité

### Permissions
- **Joueurs** : Lecture seule de l'Encyclopédie
- **Admins** : CRUD complet de l'Encyclopédie
- **Organisateurs** : Gestion des événements

### Validation
- Valider toutes les entrées en base de données
- Vérifier les permissions avant chaque modification
- Enregistrer toutes les modifications dans l'audit trail

### Soft Delete
- Jamais supprimer physiquement une entrée
- Utiliser `deleted_at` pour les suppressions logiques
- Permettre la restauration

---

## 10. Documentation Requise

1. **Guide d'utilisation de l'Encyclopédie** (pour les admins)
2. **Documentation des procédures tRPC**
3. **Schéma de la base de données**
4. **Guide de migration**
5. **Exemples de requêtes**
6. **Troubleshooting guide**

