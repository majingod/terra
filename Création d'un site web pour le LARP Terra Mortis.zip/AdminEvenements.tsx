import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import Breadcrumbs from "@/components/Breadcrumbs";
import { Calendar, Plus, Pencil, Trash2, Users, Eye, EyeOff, Check, X, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useState } from "react";
import { toast } from "sonner";

interface EventForm {
  title: string;
  description: string;
  location: string;
  startDate: string;
  endDate: string;
  maxPlayers: number;
  status: "draft" | "published" | "cancelled" | "completed";
  faction: "Sanctum" | "Légion" | "Tous";
  price: string;
  notes: string;
}

const emptyForm: EventForm = {
  title: "",
  description: "",
  location: "Stukely-Sud, Québec",
  startDate: "",
  endDate: "",
  maxPlayers: 0,
  status: "draft",
  faction: "Tous",
  price: "",
  notes: "",
};

function getStatusLabel(status: string) {
  switch (status) {
    case "published": return "Publié";
    case "completed": return "Terminé";
    case "cancelled": return "Annulé";
    default: return "Brouillon";
  }
}

function getStatusColor(status: string) {
  switch (status) {
    case "published": return "oklch(0.45 0.15 145)";
    case "completed": return "oklch(0.4 0.08 240)";
    case "cancelled": return "oklch(0.45 0.15 25)";
    default: return "oklch(0.4 0.04 60)";
  }
}

export default function AdminEvenements() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: evenements, isLoading } = trpc.evenements.listAll.useQuery();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<EventForm>(emptyForm);
  const [expandedInscriptions, setExpandedInscriptions] = useState<number | null>(null);

  const createMutation = trpc.evenements.create.useMutation({
    onSuccess: () => {
      toast.success("Événement créé !");
      utils.evenements.listAll.invalidate();
      resetForm();
    },
    onError: (err) => toast.error(err.message),
  });

  const updateMutation = trpc.evenements.update.useMutation({
    onSuccess: () => {
      toast.success("Événement modifié !");
      utils.evenements.listAll.invalidate();
      resetForm();
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.evenements.delete.useMutation({
    onSuccess: () => {
      toast.success("Événement supprimé !");
      utils.evenements.listAll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  function resetForm() {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
  }

  function startEdit(evt: any) {
    setForm({
      title: evt.title,
      description: evt.description,
      location: evt.location,
      startDate: format(new Date(evt.startDate), "yyyy-MM-dd'T'HH:mm"),
      endDate: format(new Date(evt.endDate), "yyyy-MM-dd'T'HH:mm"),
      maxPlayers: evt.maxPlayers,
      status: evt.status,
      faction: evt.faction,
      price: evt.price || "",
      notes: evt.notes || "",
    });
    setEditingId(evt.id);
    setShowForm(true);
  }

  function handleSubmit() {
    if (!form.title || !form.description || !form.location || !form.startDate || !form.endDate) {
      toast.error("Veuillez remplir tous les champs obligatoires.");
      return;
    }
    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        data: {
          ...form,
          maxPlayers: form.maxPlayers,
          price: form.price || undefined,
          notes: form.notes || undefined,
        },
      });
    } else {
      createMutation.mutate({
        ...form,
        maxPlayers: form.maxPlayers,
        price: form.price || undefined,
        notes: form.notes || undefined,
      });
    }
  }

  if (!user || (user.role !== "admin" && user.role !== "organizer")) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Accès réservé aux organisateurs.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="container py-12">
        <Breadcrumbs items={[
          { label: "Administration", href: "/admin" },
          { label: "Événements" },
        ]} />

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-heading font-black"
            style={{
              background: "linear-gradient(135deg, oklch(0.82 0.2 85), oklch(0.65 0.18 45))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
            Gestion des événements
          </h1>
          <Button
            onClick={() => { resetForm(); setShowForm(!showForm); }}
            className="font-heading"
            style={{
              background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.5 0.22 25))",
              color: "oklch(0.98 0 0)",
            }}>
            <Plus className="w-4 h-4 mr-2" />
            Nouvel événement
          </Button>
        </div>

        {/* ─── Formulaire ─────────────────────────────────────────────────────── */}
        {showForm && (
          <div className="rounded-xl border border-border/40 p-6 mb-8"
            style={{ background: "linear-gradient(135deg, oklch(0.18 0.01 270 / 0.8), oklch(0.15 0.02 30 / 0.5))" }}>
            <h2 className="text-xl font-heading font-bold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              {editingId ? "Modifier l'événement" : "Nouvel événement"}
            </h2>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-muted-foreground mb-1">Titre *</label>
                <input type="text" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Nom de l'événement" />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-muted-foreground mb-1">Description *</label>
                <textarea className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground resize-none"
                  rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Description détaillée de l'événement..." />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Lieu *</label>
                <input type="text" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Prix</label>
                <input type="text" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Ex: 25$" />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Date de début *</label>
                <input type="datetime-local" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Date de fin *</label>
                <input type="datetime-local" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Places max (0 = illimité)</label>
                <input type="number" min="0" className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.maxPlayers} onChange={(e) => setForm({ ...form, maxPlayers: parseInt(e.target.value) || 0 })} />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Faction</label>
                <select className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.faction} onChange={(e) => setForm({ ...form, faction: e.target.value as any })}>
                  <option value="Tous">Toutes les factions</option>
                  <option value="Sanctum">Sanctum uniquement</option>
                  <option value="Légion">Légion uniquement</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Statut</label>
                <select className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground"
                  value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })}>
                  <option value="draft">Brouillon</option>
                  <option value="published">Publié</option>
                  <option value="cancelled">Annulé</option>
                  <option value="completed">Terminé</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-muted-foreground mb-1">Notes internes (organisateurs uniquement)</label>
                <textarea className="w-full rounded-lg border border-border/40 bg-background/50 px-3 py-2 text-sm text-foreground resize-none"
                  rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Notes visibles uniquement par les organisateurs..." />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending}
                className="font-heading"
                style={{ background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.5 0.22 25))", color: "oklch(0.98 0 0)" }}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingId ? "Enregistrer" : "Créer l'événement"}
              </Button>
              <Button variant="outline" onClick={resetForm}>Annuler</Button>
            </div>
          </div>
        )}

        {/* ─── Liste des événements ───────────────────────────────────────────── */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : !evenements || evenements.length === 0 ? (
          <div className="text-center py-20 rounded-xl border border-border/40"
            style={{ background: "oklch(0.18 0.01 270 / 0.5)" }}>
            <Calendar className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-40" />
            <p className="text-xl text-muted-foreground">Aucun événement créé</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Cliquez sur "Nouvel événement" pour commencer.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {evenements.map((evt: any) => (
              <EventCard
                key={evt.id}
                evt={evt}
                onEdit={() => startEdit(evt)}
                onDelete={() => {
                  if (confirm("Supprimer cet événement ?")) {
                    deleteMutation.mutate({ id: evt.id });
                  }
                }}
                expanded={expandedInscriptions === evt.id}
                onToggleInscriptions={() => setExpandedInscriptions(expandedInscriptions === evt.id ? null : evt.id)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function EventCard({ evt, onEdit, onDelete, expanded, onToggleInscriptions }: {
  evt: any;
  onEdit: () => void;
  onDelete: () => void;
  expanded: boolean;
  onToggleInscriptions: () => void;
}) {
  const { data: inscriptions } = trpc.evenements.inscriptions.useQuery(
    { evenementId: evt.id },
    { enabled: expanded }
  );
  const utils = trpc.useUtils();
  const updateInscMutation = trpc.evenements.updateInscription.useMutation({
    onSuccess: () => {
      toast.success("Inscription mise à jour.");
      utils.evenements.inscriptions.invalidate({ evenementId: evt.id });
    },
  });

  return (
    <div className="rounded-xl border border-border/40 overflow-hidden"
      style={{ background: "linear-gradient(135deg, oklch(0.18 0.01 270 / 0.8), oklch(0.15 0.02 30 / 0.5))" }}>
      <div className="p-5">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Date badge */}
          <div className="flex-shrink-0 w-16 h-16 rounded-lg flex flex-col items-center justify-center"
            style={{
              background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.2), oklch(0.45 0.15 30 / 0.1))",
              border: "1px solid oklch(0.65 0.18 45 / 0.3)",
            }}>
            <span className="text-xl font-heading font-black" style={{ color: "oklch(0.82 0.2 85)" }}>
              {format(new Date(evt.startDate), "d")}
            </span>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
              {format(new Date(evt.startDate), "MMM yyyy", { locale: fr })}
            </span>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h3 className="text-lg font-heading font-bold text-foreground">{evt.title}</h3>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                style={{ color: getStatusColor(evt.status), border: `1px solid ${getStatusColor(evt.status)}` }}>
                {getStatusLabel(evt.status)}
              </span>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-1">{evt.location} — {evt.faction}</p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <Button variant="outline" size="sm" onClick={onToggleInscriptions}
              className="text-xs">
              <Users className="w-3.5 h-3.5 mr-1" />
              Inscriptions
              {expanded ? <ChevronUp className="w-3.5 h-3.5 ml-1" /> : <ChevronDown className="w-3.5 h-3.5 ml-1" />}
            </Button>
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Pencil className="w-3.5 h-3.5" />
            </Button>
            <Button variant="outline" size="sm" onClick={onDelete}
              className="text-red-400 border-red-400/30 hover:bg-red-400/10">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Inscriptions panel */}
      {expanded && (
        <div className="border-t border-border/20 p-5"
          style={{ background: "oklch(0.14 0.005 270 / 0.5)" }}>
          <h4 className="text-sm font-heading font-bold text-muted-foreground mb-3">
            Inscriptions ({inscriptions?.length || 0})
          </h4>
          {!inscriptions || inscriptions.length === 0 ? (
            <p className="text-sm text-muted-foreground/60">Aucune inscription pour le moment.</p>
          ) : (
            <div className="space-y-2">
              {inscriptions.map((insc: any) => (
                <div key={insc.id} className="flex items-center gap-3 p-3 rounded-lg"
                  style={{ background: "oklch(0.18 0.01 270 / 0.5)", border: "1px solid oklch(0.25 0.02 270 / 0.3)" }}>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{insc.userName || "Joueur inconnu"}</p>
                    {insc.notes && <p className="text-xs text-muted-foreground mt-0.5">{insc.notes}</p>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 rounded-full"
                      style={{
                        color: insc.status === "confirmed" ? "oklch(0.65 0.18 145)" : insc.status === "cancelled" ? "oklch(0.65 0.18 25)" : "oklch(0.65 0.1 60)",
                        border: `1px solid ${insc.status === "confirmed" ? "oklch(0.45 0.12 145)" : insc.status === "cancelled" ? "oklch(0.45 0.12 25)" : "oklch(0.45 0.06 60)"}`,
                      }}>
                      {insc.status === "confirmed" ? "Confirmé" : insc.status === "cancelled" ? "Annulé" : "En attente"}
                    </span>
                    {insc.status !== "confirmed" && (
                      <Button variant="ghost" size="sm"
                        onClick={() => updateInscMutation.mutate({ id: insc.id, status: "confirmed" })}
                        className="h-7 w-7 p-0 text-green-400 hover:bg-green-400/10">
                        <Check className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    {insc.status !== "cancelled" && (
                      <Button variant="ghost" size="sm"
                        onClick={() => updateInscMutation.mutate({ id: insc.id, status: "cancelled" })}
                        className="h-7 w-7 p-0 text-red-400 hover:bg-red-400/10">
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
