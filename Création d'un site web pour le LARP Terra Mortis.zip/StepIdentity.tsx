import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface StepIdentityProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepIdentity({ charData, onCharDataChange }: StepIdentityProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">Nom du personnage</label>
        <Input
          placeholder="Entrez le nom de votre personnage"
          value={charData.name || ""}
          onChange={(e) =>
            onCharDataChange({ ...charData, name: e.target.value })
          }
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Arrière-plan</label>
        <Textarea
          placeholder="Décrivez l'arrière-plan de votre personnage..."
          value={charData.background || ""}
          onChange={(e) =>
            onCharDataChange({ ...charData, background: e.target.value })
          }
          rows={4}
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Notes personnelles</label>
        <Textarea
          placeholder="Ajoutez des notes pour votre personnage..."
          value={charData.notes || ""}
          onChange={(e) =>
            onCharDataChange({ ...charData, notes: e.target.value })
          }
          rows={3}
        />
      </div>
    </div>
  );
}
