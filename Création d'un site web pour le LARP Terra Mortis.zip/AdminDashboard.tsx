import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, Calendar, Users, Trophy, TrendingUp, Clock, X } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import StatisticsCharts from "@/components/StatisticsCharts";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [location] = useLocation();

  // Filtres
  const [factionFilter, setFactionFilter] = useState<string>("Tous");
  const [statusFilter, setStatusFilter] = useState<string>("published");

  // Synchroniser les filtres avec l'URL au chargement
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const faction = params.get("faction") || "Tous";
    const status = params.get("status") || "published";
    setFactionFilter(faction);
    setStatusFilter(status);
  }, []);

  // Mettre à jour l'URL quand les filtres changent
  const updateFilters = (newFaction?: string, newStatus?: string) => {
    const faction = newFaction ?? factionFilter;
    const status = newStatus ?? statusFilter;
    const params = new URLSearchParams();
    if (faction !== "Tous") params.set("faction", faction);
    if (status !== "published") params.set("status", status);
    const queryString = params.toString();
    window.history.replaceState({}, "", queryString ? `?${queryString}` : location);
  };

  // Récupérer les données du dashboard
  const { data: allUpcomingEvents, isLoading: loadingEvents } =
    trpc.admin.dashboardGetUpcomingEvents.useQuery(undefined, {
      enabled: !!user?.id && user.role === "admin",
    });

  // Filtrer les événements côté client
  const upcomingEvents = allUpcomingEvents?.filter(event => {
    const factionMatch = factionFilter === "Tous" || event.faction === factionFilter;
    const statusMatch = statusFilter === "published" || event.status === statusFilter;
    return factionMatch && statusMatch;
  }) ?? [];

  const { data: activeUsers, isLoading: loadingUsers } =
    trpc.admin.dashboardGetActiveUsers.useQuery(undefined, {
      enabled: !!user?.id && user.role === "admin",
    });

  const { data: allXPToDistribute, isLoading: loadingXP } =
    trpc.admin.dashboardGetXPToDistribute.useQuery(undefined, {
      enabled: !!user?.id && user.role === "admin",
    });

  // Filtrer les événements XP côté client
  const xpToDistribute = allXPToDistribute?.filter(event => {
    const factionMatch = factionFilter === "Tous" || event.faction === factionFilter;
    return factionMatch;
  }) ?? [];

  const { data: stats, isLoading: loadingStats } =
    trpc.admin.dashboardGetStats.useQuery(undefined, {
      enabled: !!user?.id && user.role === "admin",
    });

  if (!user || user.role !== "admin") {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Accès réservé aux administrateurs.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container py-8">
      {/* Filtres */}
      <div className="mb-6 p-4 bg-card border border-border rounded-lg">
        <div className="flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="text-sm font-medium mb-2 block">Faction</label>
            <Select value={factionFilter} onValueChange={(value) => {
              setFactionFilter(value);
              updateFilters(value, statusFilter);
            }}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Tous">Tous</SelectItem>
                <SelectItem value="Sanctum">Sanctum</SelectItem>
                <SelectItem value="Légion">Légion</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[200px]">
            <label className="text-sm font-medium mb-2 block">Statut</label>
            <Select value={statusFilter} onValueChange={(value) => {
              setStatusFilter(value);
              updateFilters(factionFilter, value);
            }}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="published">Publiés</SelectItem>
                <SelectItem value="draft">Brouillon</SelectItem>
                <SelectItem value="completed">Terminés</SelectItem>
                <SelectItem value="cancelled">Annulés</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setFactionFilter("Tous");
              setStatusFilter("published");
              window.history.replaceState({}, "", location);
            }}
          >
            <X className="h-4 w-4 mr-2" />
            Réinitialiser
          </Button>
        </div>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Dashboard Organisateur</h1>
        <p className="text-muted-foreground">
          Gestion centralisée des événements, inscriptions et distribution d'XP
        </p>
      </div>

      {/* Statistiques */}
      {loadingStats ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-3/4"></div>
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Événements Publiés
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalEvents || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <TrendingUp className="inline h-3 w-3 mr-1" />
                Actifs cette année
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Joueurs Inscrits
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <Users className="inline h-3 w-3 mr-1" />
                Utilisateurs actifs
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Inscriptions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalInscriptions || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <Calendar className="inline h-3 w-3 mr-1" />
                Au total
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                XP Distribué
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalXPDistributed || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <Trophy className="inline h-3 w-3 mr-1" />
                Points d'expérience
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Événements à venir */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Événements à Venir (30 jours)</CardTitle>
          <CardDescription>
            {upcomingEvents.length} événement{upcomingEvents.length !== 1 ? "s" : ""} correspondant aux filtres
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loadingEvents ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-muted rounded animate-pulse"></div>
              ))}
            </div>
          ) : upcomingEvents.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>Aucun événement à venir avec ces filtres</p>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div
                  key={event.id}
                  className="p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold">{event.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {format(new Date(event.startDate), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                      </p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline">{event.faction}</Badge>
                        <Badge variant="secondary">{event.status}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Lieu: {event.location}
                      </p>
                    </div>
                    <a href={`/admin/xp?eventId=${event.id}`}>
                      <Button
                        size="sm"
                        variant="default"
                        className="ml-2 flex-shrink-0"
                      >
                        <Trophy className="h-4 w-4 mr-2" />
                        Attribuer XP
                      </Button>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Joueurs actifs */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Joueurs Actifs (Top 10)</CardTitle>
          <CardDescription>Les joueurs les plus engagés</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingUsers ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-10 bg-muted rounded animate-pulse"></div>
              ))}
            </div>
          ) : activeUsers && activeUsers.length > 0 ? (
            <div className="space-y-2">
              {activeUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-2 border-b">
                  <span className="font-medium">{user.name || "Utilisateur"}</span>
                  <Badge variant="outline">{user.role}</Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-4">Aucun joueur actif</p>
          )}
        </CardContent>
      </Card>

      {/* XP à distribuer */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Événements Terminés (XP à Distribuer)</CardTitle>
          <CardDescription>
            {xpToDistribute.length} événement{xpToDistribute.length !== 1 ? "s" : ""} en attente
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loadingXP ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-muted rounded animate-pulse"></div>
              ))}
            </div>
          ) : xpToDistribute.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Trophy className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>Aucun événement en attente de distribution d'XP</p>
            </div>
          ) : (
            <div className="space-y-4">
              {xpToDistribute.map((event) => (
                <div
                  key={event.id}
                  className="p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold">{event.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Terminé le {format(new Date(event.endDate), "d MMMM yyyy", { locale: fr })}
                      </p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline">{event.faction}</Badge>
                        <Badge variant="destructive">En attente</Badge>
                      </div>
                    </div>
                    <a href={`/admin/xp?eventId=${event.id}`}>
                      <Button
                        size="sm"
                        variant="default"
                        className="ml-2 flex-shrink-0"
                      >
                        <Trophy className="h-4 w-4 mr-2" />
                        Distribuer XP
                      </Button>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Graphiques Statistiques */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Statistiques</h2>
        <StatisticsCharts 
          events={allUpcomingEvents || []}
          inscriptions={[]} 
          xpDistributions={[]}
        />
      </div>

      {/* Actions rapides */}
      <Card>
        <CardHeader>
          <CardTitle>Actions Rapides</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <a href="/admin/evenements">
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Gérer les Événements
            </Button>
          </a>
          <a href="/admin/xp">
            <Button variant="outline">
              <Trophy className="h-4 w-4 mr-2" />
              Distribuer XP
            </Button>
          </a>
          <a href="/mes-inscriptions">
            <Button variant="outline">
              <Users className="h-4 w-4 mr-2" />
              Voir les Inscriptions
            </Button>
          </a>
          <a href="/admin/encyclopedie">
            <Button variant="outline">
              <Clock className="h-4 w-4 mr-2" />
              Gérer l'Encyclopédie
            </Button>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
