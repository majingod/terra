/**
 * Calcule les stats finales du personnage en fonction de tous les bonus
 * Formules :
 * - PV = PV base (classe) + Bonus Résistance + Bonus racial + Bonus capacités (Voie) + Bonus dons + Bonus héritage
 * - PM = PM base (classe) + Bonus Esprit + Bonus racial + Bonus capacités (Voie) + Bonus dons + Bonus héritage
 * - Lutte = Bonus Puissance + Bonus racial + Bonus capacités (Voie) + Bonus dons + Bonus héritage
 * - Sauvegardes = Bonus Résistance + Bonus capacités (Voie) + Bonus héritage
 */

export interface StatsCalculatorInput {
  // Classe et voie
  classId: number | null;
  classPathId: number | null;
  
  // Caractéristiques
  puissance: number;
  resistance: number;
  esprit: number;
  
  // Race et bonus racial
  raceId: number | null;
  humanBonusType: 'pv' | 'pm' | null;
  
  // Données de référence
  classData?: any;
  raceData?: any[];
  pathData?: any[];
  abilityData?: any[];
  heritageData?: any[];
  donData?: any[];
  
  // Sélections du joueur
  selectedDons: number[];
  heritageAvantages: { id: number; times: number }[];
  selectedBonusAbilities: number[];
}

export interface FinalStats {
  maxPv: number;
  maxMana: number;
  lutte: number;
  sauvegardes: number;
  breakdown: {
    pv: StatsBreakdown;
    mana: StatsBreakdown;
    lutte: StatsBreakdown;
    sauvegardes: StatsBreakdown;
  };
}

export interface StatsBreakdown {
  base: number;
  characteristicBonus: number;
  racialBonus: number;
  pathBonus: number;
  giftBonus: number;
  heritageBonus: number;
  total: number;
}

/**
 * Calcule les stats finales du personnage
 */
export function calculateFinalStats(input: StatsCalculatorInput): FinalStats {
  const classInfo = input.classData;
  const raceInfo = input.raceData?.find((r) => r.id === input.raceId);
  const pathInfo = input.pathData?.find((p) => p.id === input.classPathId);

  // Bonus des caractéristiques
  const pvCharacteristicBonus = Math.floor(input.resistance / 2) * 2; // Résistance × 2
  const manaCharacteristicBonus = Math.floor(input.esprit / 2) * 2; // Esprit × 2
  const lutteCharacteristicBonus = Math.floor(input.puissance / 2) * 2; // Puissance × 2
  const sauvegardesCharacteristicBonus = Math.floor(input.resistance / 2) * 2; // Résistance × 2

  // Bonus raciaux
  let pvRacialBonus = raceInfo?.pvBonus || 0;
  let manaRacialBonus = raceInfo?.manaBonus || 0;
  let lutteRacialBonus = raceInfo?.luteBonus || 0;

  // Appliquer le choix de bonus racial Humain
  if (input.humanBonusType === 'pv') {
    pvRacialBonus += 1;
  } else if (input.humanBonusType === 'pm') {
    manaRacialBonus += 1;
  }

  // Bonus des capacités (voie)
  const pathPvBonus = pathInfo?.pvBonus || 0;
  const pathManaBonus = pathInfo?.manaBonus || 0;
  const pathLutteBonus = pathInfo?.luteBonus || 0;
  const pathSauvegardesBonus = pathInfo?.sauvegardesBonus || 0;

  // Bonus des dons
  const giftPvBonus = calculateGiftBonus(input.selectedDons, 'pv', input.donData);
  const giftManaBonus = calculateGiftBonus(input.selectedDons, 'mana', input.donData);
  const giftLutteBonus = calculateGiftBonus(input.selectedDons, 'lutte', input.donData);
  const giftSauvegardesBonus = calculateGiftBonus(input.selectedDons, 'sauvegardes', input.donData);

  // Bonus de l'héritage
  const heritagePvBonus = calculateHeritageBonus(input.heritageAvantages, 'pv', input.heritageData);
  const heritageManaBonus = calculateHeritageBonus(input.heritageAvantages, 'mana', input.heritageData);
  const heritageLutteBonus = calculateHeritageBonus(input.heritageAvantages, 'lutte', input.heritageData);
  const heritageSauvegardesBonus = calculateHeritageBonus(input.heritageAvantages, 'sauvegardes', input.heritageData);

  // Calculs finaux
  const maxPv =
    (classInfo?.pvBase || 0) +
    pvCharacteristicBonus +
    pvRacialBonus +
    pathPvBonus +
    giftPvBonus +
    heritagePvBonus;

  const maxMana =
    (classInfo?.manaBase || 0) +
    manaCharacteristicBonus +
    manaRacialBonus +
    pathManaBonus +
    giftManaBonus +
    heritageManaBonus;

  const lutte =
    lutteCharacteristicBonus +
    lutteRacialBonus +
    pathLutteBonus +
    giftLutteBonus +
    heritageLutteBonus;

  const sauvegardes =
    sauvegardesCharacteristicBonus +
    pathSauvegardesBonus +
    giftSauvegardesBonus +
    heritageSauvegardesBonus;

  return {
    maxPv,
    maxMana,
    lutte,
    sauvegardes,
    breakdown: {
      pv: {
        base: classInfo?.pvBase || 0,
        characteristicBonus: pvCharacteristicBonus,
        racialBonus: pvRacialBonus,
        pathBonus: pathPvBonus,
        giftBonus: giftPvBonus,
        heritageBonus: heritagePvBonus,
        total: maxPv,
      },
      mana: {
        base: classInfo?.manaBase || 0,
        characteristicBonus: manaCharacteristicBonus,
        racialBonus: manaRacialBonus,
        pathBonus: pathManaBonus,
        giftBonus: giftManaBonus,
        heritageBonus: heritageManaBonus,
        total: maxMana,
      },
      lutte: {
        base: 0,
        characteristicBonus: lutteCharacteristicBonus,
        racialBonus: lutteRacialBonus,
        pathBonus: pathLutteBonus,
        giftBonus: giftLutteBonus,
        heritageBonus: heritageLutteBonus,
        total: lutte,
      },
      sauvegardes: {
        base: 0,
        characteristicBonus: sauvegardesCharacteristicBonus,
        racialBonus: 0,
        pathBonus: pathSauvegardesBonus,
        giftBonus: giftSauvegardesBonus,
        heritageBonus: heritageSauvegardesBonus,
        total: sauvegardes,
      },
    },
  };
}

/**
 * Calcule le bonus des dons pour une stat donnée
 */
function calculateGiftBonus(selectedDons: number[], stat: string, donData: any[] = []): number {
  return selectedDons.reduce((total, donId) => {
    const don = donData?.find((d) => d.id === donId);
    if (!don) return total;

    const statKey = `${stat}Bonus`;
    return total + (don[statKey] || 0);
  }, 0);
}

/**
 * Calcule le bonus de l'héritage pour une stat donnée
 */
function calculateHeritageBonus(
  heritageAvantages: { id: number; times: number }[],
  stat: string,
  heritageData: any[] = []
): number {
  return heritageAvantages.reduce((total, heritage) => {
    const heritageInfo = heritageData?.find((h) => h.id === heritage.id);
    if (!heritageInfo) return total;

    const statKey = `${stat}Bonus`;
    return total + (heritageInfo[statKey] || 0) * heritage.times;
  }, 0);
}

/**
 * Valide les stats calculées
 */
export function validateStats(stats: FinalStats): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (stats.maxPv < 1) errors.push("Les PV doivent être au minimum 1");
  if (stats.maxMana < 0) errors.push("Le Mana ne peut pas être négatif");
  if (stats.lutte < 0) errors.push("La Lutte ne peut pas être négative");
  if (stats.sauvegardes < 0) errors.push("Les Sauvegardes ne peuvent pas être négatives");

  return {
    valid: errors.length === 0,
    errors,
  };
}
