import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { FactionBadge } from "@/components/FactionBadge";
import { TerraMortisCard } from "@/components/TerraMortisCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Users, MapPin, ChevronRight } from "lucide-react";
import { Link } from "wouter";

type FilterStatus = "all" | "upcoming" | "ongoing" | "past";
type FilterFaction = "all" | "Sanctum" | "Légion";

export function ListEvenements() {
  const { user } = useAuth();
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("upcoming");
  const [filterFaction, setFilterFaction] = useState<FilterFaction>("all");

  // Récupérer les événements (TODO: implémenter la procédure tRPC)
  const evenements = [
    {
      id: 1,
      nom: "Tournoi d'Armes",
      description: "Un grand tournoi de combat entre les deux factions",
      date: new Date(2026, 3, 15),
      lieu: "Arène Centrale",
      faction: "Tous",
      statut: "upcoming",
      inscrits: 24,
      maxInscrits: 50,
      xpRecompense: 100,
    },
    {
      id: 2,
      nom: "Expédition Sanctum",
      description: "Exploration des ruines anciennes de Sanctum",
      date: new Date(2026, 3, 20),
      lieu: "Ruines de Sanctum",
      faction: "Sanctum",
      statut: "upcoming",
      inscrits: 12,
      maxInscrits: 20,
      xpRecompense: 150,
    },
    {
      id: 3,
      nom: "Bataille de la Légion",
      description: "Combat épique pour le contrôle des terres",
      date: new Date(2026, 3, 10),
      lieu: "Plaines de Guerre",
      faction: "Légion",
      statut: "ongoing",
      inscrits: 30,
      maxInscrits: 40,
      xpRecompense: 200,
    },
  ];

  const filteredEvenements = evenements.filter((evt) => {
    const statusMatch =
      filterStatus === "all" || evt.statut === filterStatus;
    const factionMatch =
      filterFaction === "all" ||
      evt.faction === "Tous" ||
      evt.faction === filterFaction;
    return statusMatch && factionMatch;
  });

  const getStatusColor = (statut: string) => {
    switch (statut) {
      case "upcoming":
        return "oklch(0.65 0.18 45)";
      case "ongoing":
        return "oklch(0.45 0.15 140)";
      case "past":
        return "oklch(0.5 0.15 280)";
      default:
        return "oklch(0.65 0.18 45)";
    }
  };

  const getStatusLabel = (statut: string) => {
    switch (statut) {
      case "upcoming":
        return "À venir";
      case "ongoing":
        return "En cours";
      case "past":
        return "Passé";
      default:
        return statut;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/30 py-8">
        <div className="container">
          <TerraMortisHeading level={1} gradient="gold" className="text-4xl mb-2">
            Événements
          </TerraMortisHeading>
          <p className="text-muted-foreground">
            Découvrez tous les événements Terra Mortis et inscrivez-vous pour
            gagner de l'XP permanent.
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="border-b border-border/30 py-6 sticky top-0 bg-background/95 backdrop-blur-sm z-10">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Status Filter */}
            <div>
              <label className="text-sm font-semibold text-foreground/70 mb-2 block">
                Statut
              </label>
              <div className="flex gap-2 flex-wrap">
                {(["all", "upcoming", "ongoing", "past"] as FilterStatus[]).map(
                  (status) => (
                    <Button
                      key={status}
                      variant={filterStatus === status ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterStatus(status)}
                      className="font-heading"
                    >
                      {status === "all"
                        ? "Tous"
                        : status === "upcoming"
                          ? "À venir"
                          : status === "ongoing"
                            ? "En cours"
                            : "Passés"}
                    </Button>
                  )
                )}
              </div>
            </div>

            {/* Faction Filter */}
            <div>
              <label className="text-sm font-semibold text-foreground/70 mb-2 block">
                Faction
              </label>
              <div className="flex gap-2 flex-wrap">
                {(["all", "Sanctum", "Légion"] as FilterFaction[]).map(
                  (faction) => (
                    <Button
                      key={faction}
                      variant={filterFaction === faction ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFilterFaction(faction)}
                      className="font-heading"
                    >
                      {faction === "all" ? "Toutes" : faction}
                    </Button>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Events Grid */}
      <div className="py-12">
        <div className="container">
          {filteredEvenements.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">
                Aucun événement ne correspond à vos filtres.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvenements.map((evt) => (
                <Link key={evt.id} href={`/evenement/${evt.id}`}>
                  <TerraMortisCard faction={evt.faction === "Sanctum" ? "Sanctum" : evt.faction === "Légion" ? "Légion" : undefined}>
                    <div className="space-y-4">
                      {/* Header */}
                      <div>
                        <div className="flex items-start justify-between mb-2">
                          <TerraMortisHeading level={3} className="text-xl">
                            {evt.nom}
                          </TerraMortisHeading>
                          <Badge
                            style={{
                              background: `${getStatusColor(evt.statut)}20`,
                              color: getStatusColor(evt.statut),
                              border: `1px solid ${getStatusColor(evt.statut)}50`,
                            }}
                          >
                            {getStatusLabel(evt.statut)}
                          </Badge>
                        </div>
                        {evt.faction !== "Tous" && (
                          <FactionBadge
                            faction={evt.faction as "Sanctum" | "Légion"}
                            size="sm"
                          />
                        )}
                      </div>

                      {/* Description */}
                      <p className="text-sm text-foreground/70 line-clamp-2">
                        {evt.description}
                      </p>

                      {/* Details */}
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-foreground/60">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {evt.date.toLocaleDateString("fr-FR", {
                              day: "numeric",
                              month: "long",
                              year: "numeric",
                            })}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-foreground/60">
                          <MapPin className="w-4 h-4" />
                          <span>{evt.lieu}</span>
                        </div>
                        <div className="flex items-center gap-2 text-foreground/60">
                          <Users className="w-4 h-4" />
                          <span>
                            {evt.inscrits} / {evt.maxInscrits} inscrits
                          </span>
                        </div>
                      </div>

                      {/* XP Reward */}
                      <div
                        className="p-3 rounded-lg border"
                        style={{
                          background: "oklch(0.65 0.18 45 / 0.1)",
                          borderColor: "oklch(0.65 0.18 45 / 0.3)",
                        }}
                      >
                        <p className="text-sm font-semibold">
                          <span style={{ color: "oklch(0.65 0.18 45)" }}>
                            +{evt.xpRecompense} XP
                          </span>
                        </p>
                      </div>

                      {/* CTA */}
                      <Button
                        className="w-full font-heading"
                        style={{
                          background: "oklch(0.65 0.18 45)",
                          color: "oklch(0.1 0.01 260)",
                        }}
                      >
                        Voir détails
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </TerraMortisCard>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
