import { describe, it, expect, beforeEach, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import EncyclopediaDetail from "../EncyclopediaDetail";
import * as wouter from "wouter";

// Mock wouter
vi.mock("wouter", () => ({
  useLocation: () => ["/encyclopedie/races", vi.fn()],
}));

describe("EncyclopediaDetail", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("devrait afficher le titre de la catégorie", async () => {
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      expect(screen.getByText("Races")).toBeDefined();
    });
  });

  it("devrait afficher les entrées de la catégorie", async () => {
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      expect(screen.getByText("Humain")).toBeDefined();
      expect(screen.getByText("Elfe")).toBeDefined();
    });
  });

  it("devrait filtrer les entrées par recherche", async () => {
    const user = userEvent.setup();
    render(<EncyclopediaDetail />);
    
    const searchInput = screen.getByPlaceholderText("Rechercher...");
    await user.type(searchInput, "Humain");
    
    await waitFor(() => {
      expect(screen.getByText("Humain")).toBeDefined();
      expect(screen.queryByText("Elfe")).toBeNull();
    });
  });

  it("devrait afficher les détails d'une entrée sélectionnée", async () => {
    const user = userEvent.setup();
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      const humainCard = screen.getByText("Humain");
      expect(humainCard).toBeDefined();
    });
    
    const humainCard = screen.getByText("Humain");
    await user.click(humainCard);
    
    await waitFor(() => {
      expect(screen.getByText("Les humains sont les créatures les plus adaptables de Terra Mortis.")).toBeDefined();
    });
  });

  it("devrait afficher le message quand aucune entrée n'est trouvée", async () => {
    const user = userEvent.setup();
    render(<EncyclopediaDetail />);
    
    const searchInput = screen.getByPlaceholderText("Rechercher...");
    await user.type(searchInput, "XYZ123NonExistent");
    
    await waitFor(() => {
      expect(screen.getByText("Aucune entrée trouvée")).toBeDefined();
    });
  });

  it("devrait afficher les badges de faction", async () => {
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      const humainCard = screen.getByText("Humain");
      expect(humainCard).toBeDefined();
    });
  });

  it("devrait permettre de changer de catégorie", async () => {
    const user = userEvent.setup();
    render(<EncyclopediaDetail />);
    
    // Attendre le chargement initial
    await waitFor(() => {
      expect(screen.getByText("Races")).toBeDefined();
    });
    
    // Chercher le sélecteur de catégorie
    const categorySelects = screen.getAllByRole("combobox");
    expect(categorySelects.length).toBeGreaterThan(0);
  });

  it("devrait afficher le message d'aide quand aucune entrée n'est sélectionnée", async () => {
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      expect(screen.getByText("Sélectionnez une entrée pour voir les détails")).toBeDefined();
    });
  });

  it("devrait afficher les caractéristiques de l'entrée sélectionnée", async () => {
    const user = userEvent.setup();
    render(<EncyclopediaDetail />);
    
    await waitFor(() => {
      const humainCard = screen.getByText("Humain");
      expect(humainCard).toBeDefined();
    });
    
    const humainCard = screen.getByText("Humain");
    await user.click(humainCard);
    
    await waitFor(() => {
      expect(screen.getByText("Caractéristiques")).toBeDefined();
    });
  });
});
