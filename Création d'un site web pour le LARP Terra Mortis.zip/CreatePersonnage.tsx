import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import {
  ChevronRight, ChevronLeft, Check, User, Shield, Sword, Star, Gem, TrendingDown,
  Loader2, Lock, BookOpen
} from "lucide-react";
import { StepVoie, StepDonsResume, calcMaxDons } from "./StepVoieEtDons";
import { StepCapacitesBonus } from "./StepCapacitesBonus";

// ─── Types ────────────────────────────────────────────────────────────────────
type Faction = "Sanctum" | "Légion";

interface CharData {
  name: string;
  background: string;
  faction: Faction | null;
  raceId: number | null;
  classId: number | null;
  classPathId: number | null;
  puissance: number;
  resistance: number;
  esprit: number;
  competenceId: number | null;
  selectedDons: number[];
  heritageAvantages: { id: number; times: number }[];
  selectedDesavantages: number[];
  selectedBonusAbilities: number[];
  humanBonusType: 'pv' | 'pm' | null;
  notes: string;
}

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

// ─── Step config ──────────────────────────────────────────────────────────────
const STEPS = [
  { id: 1, label: "Identité", icon: User },
  { id: 2, label: "Désavantages", icon: TrendingDown },
  { id: 3, label: "Héritage", icon: Gem },
  { id: 4, label: "Compétence", icon: BookOpen },
  { id: 5, label: "Caractéristiques", icon: Star },
  { id: 6, label: "Faction", icon: Shield },
  { id: 7, label: "Race", icon: User },
  { id: 8, label: "Classe", icon: Sword },
  { id: 9, label: "Capacités bonus", icon: Star },
  { id: 10, label: "Dons", icon: Check },
  { id: 11, label: "Résumé", icon: Check },
];



// ─── XP Calculator ───────────────────────────────────────────────────────
function calcXP(data: CharData, desavantages: any[], heritageAvantages: any[]) {
  // XP temporaires gagnés par les désavantages
  const xpTemporaire = data.selectedDesavantages.reduce((sum, id) => {
    const d = desavantages.find((x) => x.id === id);
    return sum + (d?.xpGain ?? 0);
  }, 0);

  // XP permanents dépensés par l'héritage
  const xpPermanentDepense = data.heritageAvantages.reduce((sum, h) => {
    const ha = heritageAvantages.find((x) => x.id === h.id);
    return sum + (ha ? ha.xpCost * h.times : 0);
  }, 0);

  // Bilan XP : XP temporaires - XP permanents dépensés
  const xpBilan = xpTemporaire - xpPermanentDepense;

  return {
    xpTemporaire,
    xpPermanentDepense,
    xpBilan,
  };
}

// ─── Stat calculator ──────────────────────────────────────────────────────────
function calcStats(data: CharData, raceData: any, classData: any, donsData: any[], heritageData: any[]) {
  const pvBase = classData?.basePv ?? 0;
  const manaBase = classData?.baseMana ?? 0;
  const pvRace = raceData?.pvBonus ?? 0;
  const pvRaceMalus = raceData?.pvMalus ?? 0;
  const manaRace = raceData?.manaBonus ?? 0;
  const luteRace = raceData?.luteBonus ?? 0;

  let pvDons = 0, manaDons = 0, luteDons = 0;
  for (const donId of data.selectedDons) {
    const don = donsData.find((d) => d.id === donId);
    if (don) {
      pvDons += don.pvBonus ?? 0;
      manaDons += don.manaBonus ?? 0;
      luteDons += don.luteBonus ?? 0;
    }
  }

  let pvHeritage = 0, manaHeritage = 0, luteHeritage = 0;
  for (const h of data.heritageAvantages) {
    const ha = heritageData.find((x) => x.id === h.id);
    if (ha) {
      pvHeritage += (ha.pvBonus ?? 0) * h.times;
      manaHeritage += (ha.manaBonus ?? 0) * h.times;
      luteHeritage += (ha.luteBonus ?? 0) * h.times;
    }
  }

  const maxPv = pvBase + data.resistance * 2 + pvRace - pvRaceMalus + pvDons + pvHeritage;
  const maxMana = manaBase + data.esprit * 2 + manaRace + manaDons + manaHeritage;
  const lutte = data.puissance * 2 + luteRace + luteDons + luteHeritage;
  const sauvegardes = data.esprit;

  return { maxPv, maxMana, lutte, sauvegardes };
}

// ─── Step components ──────────────────────────────────────────────────────────

function StepIdentite({ data, onChange }: { data: CharData; onChange: (d: Partial<CharData>) => void }) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Identité du personnage</h2>
        <p className="text-muted-foreground text-sm">Donnez un nom et une histoire à votre personnage.</p>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-heading font-semibold mb-2 text-foreground">Nom du personnage *</label>
          <input
            type="text"
            value={data.name}
            onChange={(e) => onChange({ name: e.target.value })}
            placeholder="Ex: Aldric le Sombre"
            className="w-full px-4 py-3 rounded-lg bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-heading font-semibold mb-2 text-foreground">Histoire & Background</label>
          <textarea
            value={data.background}
            onChange={(e) => onChange({ background: e.target.value })}
            placeholder="Décrivez l'histoire de votre personnage, ses motivations, son passé..."
            rows={5}
            className="w-full px-4 py-3 rounded-lg bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border text-sm resize-none"
          />
        </div>
        <div>
          <label className="block text-sm font-heading font-semibold mb-2 text-foreground">Notes personnelles</label>
          <textarea
            value={data.notes}
            onChange={(e) => onChange({ notes: e.target.value })}
            placeholder="Notes supplémentaires pour vous ou les organisateurs..."
            rows={3}
            className="w-full px-4 py-3 rounded-lg bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border text-sm resize-none"
          />
        </div>
      </div>
    </div>
  );
}

function StepFaction({ data, onChange }: { data: CharData; onChange: (d: Partial<CharData>) => void }) {
  const factions = [
    {
      id: "Sanctum" as Faction,
      color: "oklch(0.55 0.18 240)",
      title: "Le Sanctum",
      description: "Alliance de la lumière, de la nature et de la guérison. Les membres du Sanctum cherchent à protéger les vivants et à repousser les ténèbres qui envahissent Stukely-Sud.",
      traits: ["Soins et protection", "Magie de lumière", "Défense des innocents", "Communion avec la nature"],
    },
    {
      id: "Légion" as Faction,
      color: "oklch(0.5 0.22 25)",
      title: "La Légion",
      description: "Armée des morts-vivants et des corrompus. La Légion cherche à étendre son emprise sur les terres et à transformer tous les vivants en serviteurs de l'obscurité.",
      traits: ["Nécromancie", "Magie noire", "Corruption", "Résurrection des morts"],
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Choisissez votre faction</h2>
        <p className="text-muted-foreground text-sm">La faction détermine votre camp dans la guerre qui déchire Stukely-Sud.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {factions.map((f) => (
          <button
            key={f.id}
            onClick={() => onChange({ faction: f.id, raceId: null, classId: null, classPathId: null })}
            className="p-6 rounded-xl border text-left transition-all"
            style={{
              background: data.faction === f.id ? `${f.color}15` : "oklch(0.16 0.02 260)",
              borderColor: data.faction === f.id ? `${f.color}60` : "oklch(0.28 0.03 260)",
              boxShadow: data.faction === f.id ? `0 0 30px ${f.color}20` : "none",
            }}
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-heading font-bold text-xl" style={{ color: f.color }}>{f.title}</h3>
              {data.faction === f.id && (
                <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: f.color }}>
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
            <p className="text-sm text-foreground/75 mb-4 leading-relaxed">{f.description}</p>
            <ul className="space-y-1">
              {f.traits.map((t, i) => (
                <li key={i} className="flex items-center gap-2 text-xs text-foreground/60">
                  <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: f.color }} />
                  {t}
                </li>
              ))}
            </ul>
          </button>
        ))}
      </div>
    </div>
  );
}

function StepRace({ data, onChange, races }: { data: CharData; onChange: (d: Partial<CharData>) => void; races: any[] }) {
  const filtered = races.filter((r) => r.faction === data.faction || r.faction === "Tous");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Choisissez votre race</h2>
        <p className="text-muted-foreground text-sm">Les races disponibles pour la faction {data.faction}.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map((race) => {
          const isSelected = data.raceId === race.id;
          const bonuses = asStrArr(race.bonuses);
          return (
            <button
              key={race.id}
              onClick={() => onChange({ raceId: race.id })}
              className="p-5 rounded-xl border text-left transition-all"
              style={{
                background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
                boxShadow: isSelected ? "0 0 20px oklch(0.65 0.18 45 / 0.15)" : "none",
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>{race.name}</h3>
                {isSelected && (
                  <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "oklch(0.65 0.18 45)" }}>
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              <p className="text-xs text-foreground/65 mb-3 leading-relaxed line-clamp-3">{race.description as string}</p>
              <div className="flex flex-wrap gap-1">
                {race.pvBonus > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/30 text-green-400">+{race.pvBonus} PV</span>}
                {race.manaBonus > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/30 text-blue-400">+{race.manaBonus} Mana</span>}
                {race.luteBonus > 0 && <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}>+{race.luteBonus} Lutte</span>}
                {race.pvMalus > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-red-900/30 text-red-400">-{race.pvMalus} PV</span>}
                {bonuses.slice(0, 2).map((b, i) => (
                  <span key={i} className="text-xs px-1.5 py-0.5 rounded bg-secondary/50 text-foreground/60 truncate max-w-[120px]">{b}</span>
                ))}
              </div>
            </button>
          );
        })}
      </div>

      {/* Bonus racial Humain */}
      {data.raceId && filtered.find((r) => r.id === data.raceId)?.name === "Humain" && (
        <div className="p-5 rounded-xl border border-border/40 bg-card/30 space-y-3">
          <div>
            <h3 className="font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>Choisissez votre bonus racial</h3>
            <p className="text-xs text-muted-foreground">Sélectionnez si votre bonus racial (+1) s'applique aux PV ou au Mana.</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onChange({ humanBonusType: "pv" })}
              className="flex-1 p-3 rounded-lg border transition-all font-heading font-semibold"
              style={{
                background: data.humanBonusType === "pv" ? "oklch(0.45 0.15 140 / 0.2)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === "pv" ? "oklch(0.45 0.15 140 / 0.6)" : "oklch(0.28 0.03 260)",
                color: data.humanBonusType === "pv" ? "oklch(0.65 0.2 140)" : "oklch(0.82 0.2 85)",
              }}
            >
              +1 PV
            </button>
            <button
              onClick={() => onChange({ humanBonusType: "pm" })}
              className="flex-1 p-3 rounded-lg border transition-all font-heading font-semibold"
              style={{
                background: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240 / 0.2)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240 / 0.6)" : "oklch(0.28 0.03 260)",
                color: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240)" : "oklch(0.82 0.2 85)",
              }}
            >
              +1 PM
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StepClasse({ data, onChange, classes }: { data: CharData; onChange: (d: Partial<CharData>) => void; classes: any[] }) {
  const { data: fullClass } = trpc.rules.classWithPathsAndAbilities.useQuery(
    { id: data.classId! },
    { enabled: !!data.classId }
  );
  const filtered = classes.filter((c) => c.faction === data.faction || c.faction === "Tous");
  const paths = fullClass?.paths || [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Choisissez votre classe</h2>
        <p className="text-muted-foreground text-sm">La classe définit votre rôle au combat et vos capacités.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map((cls) => {
          const isSelected = data.classId === cls.id;
          return (
            <button
              key={cls.id}
              onClick={() => onChange({ classId: cls.id, classPathId: null })}
              className="p-5 rounded-xl border text-left transition-all"
              style={{
                background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>{cls.name}</h3>
                {isSelected && (
                  <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "oklch(0.65 0.18 45)" }}>
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              <p className="text-xs text-foreground/65 mb-3 leading-relaxed line-clamp-3">{cls.description}</p>
              <div className="flex gap-2">
                <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/30 text-green-400">{cls.basePv} PV</span>
                {cls.baseMana > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/30 text-blue-400">{cls.baseMana} Mana</span>}
                {cls.requiresWeapon && <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}>Bâton requis</span>}
              </div>
            </button>
          );
        })}
      </div>

      {/* Path selection with abilities */}
      {data.classId && paths && paths.length > 0 && (
        <div className="mt-6">
          <h3 className="font-heading font-semibold mb-3 text-foreground">Choisissez une voie (obligatoire)</h3>
          <div className="space-y-3">
            {paths.map((path) => (
              <button
                key={path.id}
                onClick={() => onChange({ classPathId: path.id })}
                className="w-full p-4 rounded-lg border text-left transition-all"
                style={{
                  background: data.classPathId === path.id ? "oklch(0.65 0.18 45 / 0.1)" : "oklch(0.16 0.02 260)",
                  borderColor: data.classPathId === path.id ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.28 0.03 260)",
                }}
              >
                <h4 className="font-heading font-semibold text-sm mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>{path.name}</h4>
                {path.description && <p className="text-xs text-foreground/60 mb-3">{path.description}</p>}
                {path.abilities && path.abilities.length > 0 && (
                  <div className="text-xs text-foreground/70 space-y-1">
                    <p className="font-semibold text-foreground/80">Capacités par niveau:</p>
                    {path.abilities.map((ability) => (
                      <p key={ability.id} className="text-foreground/60">• Niveau {ability.level}: {ability.name}</p>
                    ))}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StepCaracteristiques({ data, onChange, heritageAvantages }: { data: CharData; onChange: (d: Partial<CharData>) => void; heritageAvantages: any[] }) {
  // Calculer le bonus de caractéristiques depuis l'héritage
  const characteristicBonus = data.heritageAvantages.reduce((sum, h) => {
    const ha = heritageAvantages.find((x) => x.id === h.id);
    return sum + ((ha?.extraCharacteristicPoints ?? 0) * h.times);
  }, 0);
  
  // Validation 3-2-1 obligatoire
  const values = [data.puissance, data.resistance, data.esprit].sort((a, b) => b - a);
  const isValid321 = values[0] === 3 && values[1] === 2 && values[2] === 1;
  const pointsUsed = data.puissance + data.resistance + data.esprit;
  const totalPoints = 6 + characteristicBonus;
  const pointsLeft = totalPoints - pointsUsed;

  const stats = [
    { key: "puissance" as const, label: "Puissance", desc: "Force physique, lutte, dommages au corps à corps", color: "oklch(0.55 0.22 25)" },
    { key: "resistance" as const, label: "Résistance", desc: "Endurance, Points de Vie supplémentaires", color: "oklch(0.45 0.15 140)" },
    { key: "esprit" as const, label: "Esprit", desc: "Force mentale, Mana, sauvegardes", color: "oklch(0.55 0.18 240)" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Caractéristiques</h2>
        <p className="text-muted-foreground text-sm">Répartissez {totalPoints} points entre vos 3 caractéristiques (minimum 1, maximum 5 chacune).{characteristicBonus > 0 && ` (+${characteristicBonus} bonus héritage)`}</p>
      </div>

      <div className="space-y-3">
        <div
          className="p-4 rounded-lg text-center font-heading"
          style={{
            background: pointsLeft === 0 ? "oklch(0.45 0.15 140 / 0.15)" : pointsLeft < 0 ? "oklch(0.55 0.22 25 / 0.15)" : "oklch(0.65 0.18 45 / 0.1)",
            border: `1px solid ${pointsLeft === 0 ? "oklch(0.45 0.15 140 / 0.4)" : pointsLeft < 0 ? "oklch(0.55 0.22 25 / 0.4)" : "oklch(0.65 0.18 45 / 0.3)"}`,
          }}
        >
          <span className="text-2xl font-bold" style={{ color: pointsLeft === 0 ? "oklch(0.65 0.2 140)" : pointsLeft < 0 ? "oklch(0.65 0.22 25)" : "oklch(0.82 0.2 85)" }}>
            {pointsLeft}
          </span>
          <span className="text-sm text-muted-foreground ml-2">points restants</span>
        </div>

        {!isValid321 && (
          <div
            className="p-3 rounded-lg border text-sm"
            style={{
              background: "oklch(0.55 0.22 25 / 0.1)",
              border: "1px solid oklch(0.55 0.22 25 / 0.4)",
              color: "oklch(0.75 0.22 25)",
            }}
          >
            ⚠️ Vous devez distribuer exactement 3-2-1 (un 3, un 2, un 1) avant de continuer.
          </div>
        )}
      </div>

      <div className="space-y-4">
        {stats.map((stat) => (
          <div key={stat.key} className="p-5 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="font-heading font-semibold" style={{ color: stat.color }}>{stat.label}</h3>
                <p className="text-xs text-foreground/60">{stat.desc}</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onChange({ [stat.key]: Math.max(1, data[stat.key] - 1) })}
                  disabled={data[stat.key] <= 1}
                  className="w-8 h-8 rounded-full border flex items-center justify-center text-lg font-bold transition-all disabled:opacity-30"
                  style={{ borderColor: stat.color, color: stat.color }}
                >
                  −
                </button>
                <span className="font-heading font-bold text-2xl w-8 text-center" style={{ color: stat.color }}>
                  {data[stat.key]}
                </span>
                <button
                  onClick={() => onChange({ [stat.key]: Math.min(5, data[stat.key] + 1) })}
                  disabled={data[stat.key] >= 5 || pointsLeft <= 0}
                  className="w-8 h-8 rounded-full border flex items-center justify-center text-lg font-bold transition-all disabled:opacity-30"
                  style={{ borderColor: stat.color, color: stat.color }}
                >
                  +
                </button>
              </div>
            </div>
            <div className="flex gap-1 mt-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <div
                  key={n}
                  className="h-2 flex-1 rounded-full transition-all"
                  style={{ background: n <= data[stat.key] ? stat.color : "oklch(0.28 0.03 260)" }}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StepCompetence({ data, onChange, competences }: { data: CharData; onChange: (d: Partial<CharData>) => void; competences: any[] }) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Compétence de départ</h2>
        <p className="text-muted-foreground text-sm">Choisissez une compétence pour votre personnage (optionnel).</p>
      </div>
      <div className="space-y-3">
        <button
          onClick={() => onChange({ competenceId: null })}
          className="w-full p-4 rounded-xl border text-left transition-all"
          style={{
            background: data.competenceId === null ? "oklch(0.65 0.18 45 / 0.1)" : "oklch(0.16 0.02 260)",
            borderColor: data.competenceId === null ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.28 0.03 260)",
          }}
        >
          <span className="font-heading text-sm text-foreground">Aucune compétence</span>
        </button>
        {competences.map((comp) => (
          <button
            key={comp.id}
            onClick={() => onChange({ competenceId: comp.id })}
            className="w-full p-4 rounded-xl border text-left transition-all"
            style={{
              background: data.competenceId === comp.id ? "oklch(0.65 0.18 45 / 0.1)" : "oklch(0.16 0.02 260)",
              borderColor: data.competenceId === comp.id ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.28 0.03 260)",
            }}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>{comp.name}</h3>
                <p className="text-xs text-foreground/65 leading-relaxed">{comp.description}</p>
                {comp.baseAdvantage && (
                  <p className="text-xs text-foreground/50 mt-1 italic">{comp.baseAdvantage}</p>
                )}
              </div>
              {data.competenceId === comp.id && (
                <div className="w-5 h-5 rounded-full flex items-center justify-center ml-3 flex-shrink-0" style={{ background: "oklch(0.65 0.18 45)" }}>
                  <Check className="w-3 h-3 text-white" />
                </div>
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function StepDons({ data, onChange, dons }: { data: CharData; onChange: (d: Partial<CharData>) => void; dons: any[] }) {
  const MAX_DONS = 3;

  const toggleDon = (donId: number) => {
    const current = data.selectedDons;
    if (current.includes(donId)) {
      onChange({ selectedDons: current.filter((id) => id !== donId) });
    } else if (current.length < MAX_DONS) {
      onChange({ selectedDons: [...current, donId] });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Dons</h2>
        <p className="text-muted-foreground text-sm">Choisissez jusqu'à {MAX_DONS} dons pour votre personnage.</p>
      </div>

      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Avantages d'héritage</h2>
        <p className="text-muted-foreground text-sm">Dépensez vos XP temporaires en avantages d'héritage permanents.</p>
      </div>

      <div className="space-y-3">
        {dons.map((don) => {
          const isSelected = data.selectedDons.includes(don.id);
          const isDisabled = !isSelected && data.selectedDons.length >= MAX_DONS;
          return (
            <button
              key={don.id}
              onClick={() => toggleDon(don.id)}
              disabled={isDisabled}
              className="w-full p-4 rounded-xl border text-left transition-all disabled:opacity-40"
              style={{
                background: isSelected ? "oklch(0.65 0.18 45 / 0.12)" : "oklch(0.16 0.02 260)",
                borderColor: isSelected ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>{don.name}</h3>
                    {don.canStack && (
                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.45 0.15 140 / 0.2)", color: "oklch(0.65 0.2 140)" }}>
                        ×{don.maxStacks}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-foreground/65 leading-relaxed">{don.description}</p>
                  <div className="flex gap-1 mt-2">
                    {(don.pvBonus ?? 0) > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/30 text-green-400">+{don.pvBonus} PV</span>}
                    {(don.manaBonus ?? 0) > 0 && <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/30 text-blue-400">+{don.manaBonus} Mana</span>}
                    {(don.luteBonus ?? 0) > 0 && <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)" }}>+{don.luteBonus} Lutte</span>}
                  </div>
                </div>
                <div
                  className="w-5 h-5 rounded border flex items-center justify-center ml-3 flex-shrink-0"
                  style={{
                    background: isSelected ? "oklch(0.65 0.18 45)" : "transparent",
                    borderColor: isSelected ? "oklch(0.65 0.18 45)" : "oklch(0.4 0.03 260)",
                  }}
                >
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function StepHeritage({ data, onChange, heritageAvantages, desavantages }: { data: CharData; onChange: (d: Partial<CharData>) => void; heritageAvantages: any[]; desavantages?: any[] }) {
  const MAX_XP = 15;
  const usedXP = data.heritageAvantages.reduce((sum, h) => {
    const ha = heritageAvantages.find((x) => x.id === h.id);
    return sum + (ha ? ha.xpCost * h.times : 0);
  }, 0);

  // Calculer les XP temporaires gagnés par les désavantages
  const desavantagesArray = desavantages ?? [];
  const xpTemporaire = desavantagesArray.length > 0 ? data.selectedDesavantages.reduce((sum, id) => {
    const d = desavantagesArray.find((x) => x.id === id);
    return sum + (d?.xpGain ?? 0);
  }, 0) : 0;

  // Bilan XP : XP temporaires - XP permanents dépensés
  const xpBilan = xpTemporaire - usedXP;

  const toggleHeritage = (haId: number) => {
    const ha = heritageAvantages.find((x) => x.id === haId);
    if (!ha) return;
    const current = data.heritageAvantages.find((h) => h.id === haId);
    if (current) {
      if (current.times < (ha.maxTimes ?? 1) && usedXP + ha.xpCost <= xpTemporaire) {
        onChange({ heritageAvantages: data.heritageAvantages.map((h) => h.id === haId ? { ...h, times: h.times + 1 } : h) });
      } else {
        onChange({ heritageAvantages: data.heritageAvantages.filter((h) => h.id !== haId) });
      }
    } else if (usedXP + ha.xpCost <= xpTemporaire) {
      onChange({ heritageAvantages: [...data.heritageAvantages, { id: haId, times: 1 }] });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Avantages d'héritage</h2>
        <p className="text-muted-foreground text-sm">Dépensez jusqu'à {MAX_XP} XP permanents en avantages d'héritage.</p>
      </div>

      <div className="space-y-3">
        {xpTemporaire > 0 && (
          <div
            className="p-3 rounded-lg font-heading"
            style={{ background: "oklch(0.55 0.22 25 / 0.1)", border: "1px solid oklch(0.55 0.22 25 / 0.3)" }}
          >
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">XP temporaires disponibles</span>
              <span className="font-bold" style={{ color: "oklch(0.75 0.22 25)" }}>+{xpTemporaire} XP</span>
            </div>
          </div>
        )}

        <div
          className="p-3 rounded-lg font-heading"
          style={{ background: "oklch(0.65 0.18 45 / 0.1)", border: "1px solid oklch(0.65 0.18 45 / 0.3)" }}
        >
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">XP permanents dépensés</span>
            <span className="font-bold" style={{ color: usedXP > xpTemporaire ? "oklch(0.65 0.22 25)" : "oklch(0.82 0.2 85)" }}>
              {usedXP}/{xpTemporaire} XP
            </span>
          </div>
          <div className="mt-2 h-2 rounded-full bg-secondary/30">
            <div
              className="h-2 rounded-full transition-all"
              style={{
                width: `${Math.min(100, xpTemporaire > 0 ? (usedXP / xpTemporaire) * 100 : 0)}%`,
                background: usedXP > xpTemporaire ? "oklch(0.55 0.22 25)" : "oklch(0.65 0.18 45)",
              }}
            />
          </div>
        </div>

        {xpBilan !== 0 && (
          <div
            className="p-3 rounded-lg font-heading text-center"
            style={{
              background: xpBilan >= 0 ? "oklch(0.45 0.15 140 / 0.1)" : "oklch(0.55 0.22 25 / 0.1)",
              border: `1px solid ${xpBilan >= 0 ? "oklch(0.45 0.15 140 / 0.3)" : "oklch(0.55 0.22 25 / 0.3)"}`,
            }}
          >
            <span className="text-sm text-muted-foreground">Bilan XP : </span>
            <span className="font-bold" style={{ color: xpBilan >= 0 ? "oklch(0.65 0.2 140)" : "oklch(0.65 0.22 25)" }}>
              {xpBilan >= 0 ? "+" : ""}{xpBilan} XP
            </span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {heritageAvantages.map((ha) => {
          const current = data.heritageAvantages.find((h) => h.id === ha.id);
          const times = current?.times ?? 0;
          const canAdd = usedXP + ha.xpCost <= xpTemporaire && times < (ha.maxTimes ?? 1);
          return (
            <div
              key={ha.id}
              className="p-4 rounded-xl border transition-all"
              style={{
                background: times > 0 ? "oklch(0.65 0.18 45 / 0.08)" : "oklch(0.16 0.02 260)",
                borderColor: times > 0 ? "oklch(0.65 0.18 45 / 0.5)" : "oklch(0.28 0.03 260)",
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>{ha.name}</h3>
                    <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.2)", color: "oklch(0.82 0.2 85)" }}>
                      {ha.xpCost} XP
                    </span>
                    {(ha.maxTimes ?? 1) > 1 && (
                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.55 0.18 240 / 0.15)", color: "oklch(0.65 0.2 240)" }}>
                        ×{ha.maxTimes} max
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-foreground/65 leading-relaxed">{ha.description}</p>
                </div>
                <div className="flex items-center gap-2 ml-3 flex-shrink-0">
                  {times > 0 && (
                    <button
                      onClick={() => {
                        if (times === 1) {
                          onChange({ heritageAvantages: data.heritageAvantages.filter((h) => h.id !== ha.id) });
                        } else {
                          onChange({ heritageAvantages: data.heritageAvantages.map((h) => h.id === ha.id ? { ...h, times: h.times - 1 } : h) });
                        }
                      }}
                      className="w-6 h-6 rounded-full border flex items-center justify-center text-sm"
                      style={{ borderColor: "oklch(0.55 0.22 25 / 0.5)", color: "oklch(0.65 0.22 25)" }}
                    >
                      −
                    </button>
                  )}
                  {times > 0 && (
                    <span className="font-heading font-bold text-sm w-4 text-center" style={{ color: "oklch(0.82 0.2 85)" }}>{times}</span>
                  )}
                  <button
                    onClick={() => toggleHeritage(ha.id)}
                    disabled={!canAdd && times === 0}
                    className="w-6 h-6 rounded-full border flex items-center justify-center text-sm disabled:opacity-30"
                    style={{ borderColor: "oklch(0.65 0.18 45 / 0.5)", color: "oklch(0.82 0.2 85)" }}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StepDesavantages({ data, onChange, desavantages }: { data: CharData; onChange: (d: Partial<CharData>) => void; desavantages: any[] }) {
  const MAX_DESAV = 3;

  const toggle = (id: number) => {
    const current = data.selectedDesavantages;
    if (current.includes(id)) {
      onChange({ selectedDesavantages: current.filter((x) => x !== id) });
    } else if (current.length < MAX_DESAV) {
      onChange({ selectedDesavantages: [...current, id] });
    }
  };

  const totalXP = data.selectedDesavantages.reduce((sum, id) => {
    const d = desavantages.find((x) => x.id === id);
    return sum + (d?.xpGain ?? 0);
  }, 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Désavantages</h2>
        <p className="text-muted-foreground text-sm">Choisissez de 0 à {MAX_DESAV} désavantages pour obtenir des XP supplémentaires (optionnel).</p>
      </div>

      <div
        className="p-4 rounded-lg font-heading"
        style={{
          background: totalXP > 0 ? "oklch(0.55 0.22 25 / 0.1)" : "oklch(0.28 0.03 260)",
          border: `1px solid ${totalXP > 0 ? "oklch(0.55 0.22 25 / 0.3)" : "oklch(0.28 0.03 260)"}`,
        }}
      >
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">XP temporaires gagnés</span>
          <span className="text-lg font-bold" style={{ color: totalXP > 0 ? "oklch(0.75 0.22 25)" : "oklch(0.5 0.02 60)" }}>
            +{totalXP} XP
          </span>
        </div>
        {totalXP > 0 && (
          <p className="text-xs text-muted-foreground mt-2">Ces XP seront disponibles pour acheter des avantages d'heritage a l'etape suivante.</p>
        )}
      </div>

      <div className="space-y-3">
        {desavantages.map((d) => {
          const isSelected = data.selectedDesavantages.includes(d.id);
          const isDisabled = !isSelected && data.selectedDesavantages.length >= MAX_DESAV;
          const forbidden = asStrArr(d.forbiddenClasses);
          return (
            <button
              key={d.id}
              onClick={() => toggle(d.id)}
              disabled={isDisabled}
              className="w-full p-4 rounded-xl border text-left transition-all disabled:opacity-40"
              style={{
                background: isSelected ? "oklch(0.55 0.22 25 / 0.1)" : "oklch(0.16 0.02 260)",
                borderColor: isSelected ? "oklch(0.55 0.22 25 / 0.5)" : "oklch(0.28 0.03 260)",
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>{d.name}</h3>
                    <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: "oklch(0.55 0.22 25 / 0.2)", color: "oklch(0.75 0.22 25)" }}>
                      +{d.xpGain} XP {d.xpType}
                    </span>
                  </div>
                  <p className="text-xs text-foreground/65 leading-relaxed">{d.description}</p>
                  {forbidden.length > 0 && (
                    <p className="text-xs text-muted-foreground mt-1">Interdit : {forbidden.join(", ")}</p>
                  )}
                </div>
                <div
                  className="w-5 h-5 rounded border flex items-center justify-center ml-3 flex-shrink-0"
                  style={{
                    background: isSelected ? "oklch(0.55 0.22 25)" : "transparent",
                    borderColor: isSelected ? "oklch(0.55 0.22 25)" : "oklch(0.4 0.03 260)",
                  }}
                >
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function StepResume({ data, races, classes, competences, dons, heritageAvantages, desavantages }: {
  data: CharData;
  races: any[];
  classes: any[];
  competences: any[];
  dons: any[];
  heritageAvantages: any[];
  desavantages: any[];
}) {
  const race = races.find((r) => r.id === data.raceId);
  const cls = classes.find((c) => c.id === data.classId);
  const comp = competences.find((c) => c.id === data.competenceId);
  const { maxPv, maxMana, lutte, sauvegardes } = calcStats(data, race, cls, dons, heritageAvantages);
  const selectedDonsData = dons.filter((d) => data.selectedDons.includes(d.id));
  const selectedDesavData = desavantages.filter((d) => data.selectedDesavantages.includes(d.id));
  const totalXPDesav = selectedDesavData.reduce((s, d) => s + d.xpGain, 0);
  const heritageXP = data.heritageAvantages.reduce((sum, h) => {
    const ha = heritageAvantages.find((x) => x.id === h.id);
    return sum + (ha ? ha.xpCost * h.times : 0);
  }, 0);

  const factionColor = data.faction === "Sanctum" ? "oklch(0.55 0.18 240)" : "oklch(0.5 0.22 25)";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-heading font-bold mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>Résumé du personnage</h2>
        <p className="text-muted-foreground text-sm">Vérifiez les informations avant de créer votre personnage.</p>
      </div>

      {/* Identity */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <h3 className="font-heading font-semibold mb-3 text-foreground">Identité</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className="text-xs text-muted-foreground">Nom</span>
            <p className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>{data.name || "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Faction</span>
            <p className="font-heading font-semibold" style={{ color: factionColor }}>{data.faction || "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Race</span>
            <p className="font-heading font-semibold text-foreground">{race?.name ?? "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Classe</span>
            <p className="font-heading font-semibold text-foreground">{cls?.name ?? "—"}</p>
          </div>
        </div>
        {data.background && (
          <div className="mt-3">
            <span className="text-xs text-muted-foreground">Background</span>
            <p className="text-sm text-foreground/75 mt-1 leading-relaxed line-clamp-3">{data.background}</p>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <h3 className="font-heading font-semibold mb-3 text-foreground">Statistiques calculées</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "PV max", value: maxPv, color: "oklch(0.45 0.15 140)" },
            { label: "Mana max", value: maxMana, color: "oklch(0.55 0.18 240)" },
            { label: "Lutte", value: lutte, color: "oklch(0.65 0.18 45)" },
            { label: "Sauvegardes", value: sauvegardes, color: "oklch(0.55 0.22 25)" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="p-3 rounded-lg text-center"
              style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}30` }}
            >
              <div className="text-2xl font-heading font-bold" style={{ color: stat.color }}>{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-3 mt-3">
          {[
            { label: "Puissance", value: data.puissance, color: "oklch(0.55 0.22 25)" },
            { label: "Résistance", value: data.resistance, color: "oklch(0.45 0.15 140)" },
            { label: "Esprit", value: data.esprit, color: "oklch(0.55 0.18 240)" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-lg font-heading font-bold" style={{ color: stat.color }}>{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Selections */}
      <div className="p-5 rounded-xl border border-border/40 bg-card/30">
        <h3 className="font-heading font-semibold mb-3 text-foreground">Sélections</h3>
        <div className="space-y-2">
          {comp && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Compétence</span>
              <span className="font-heading text-foreground">{comp.name}</span>
            </div>
          )}
          {selectedDonsData.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground">Dons</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {selectedDonsData.map((d) => (
                  <span key={d.id} className="text-xs px-2 py-0.5 rounded" style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.3)" }}>
                    {d.name}
                  </span>
                ))}
              </div>
            </div>
          )}
          {data.heritageAvantages.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground">Héritage ({heritageXP} XP)</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {data.heritageAvantages.map((h) => {
                  const ha = heritageAvantages.find((x) => x.id === h.id);
                  return ha ? (
                    <span key={h.id} className="text-xs px-2 py-0.5 rounded bg-secondary/50 text-foreground/70">
                      {ha.name}{h.times > 1 ? ` ×${h.times}` : ""}
                    </span>
                  ) : null;
                })}
              </div>
            </div>
          )}
          {selectedDesavData.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground">Désavantages (+{totalXPDesav} XP)</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {selectedDesavData.map((d) => (
                  <span key={d.id} className="text-xs px-2 py-0.5 rounded" style={{ background: "oklch(0.55 0.22 25 / 0.15)", color: "oklch(0.75 0.22 25)", border: "1px solid oklch(0.55 0.22 25 / 0.3)" }}>
                    {d.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function CreatePersonnage() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [charData, setCharData] = useState<CharData>({
    name: "",
    background: "",
    faction: null,
    raceId: null,
    classId: null,
    classPathId: null,
    puissance: 0,
    resistance: 0,
    esprit: 0,
    competenceId: null,
    selectedDons: [],
    heritageAvantages: [],
    selectedDesavantages: [],
    selectedBonusAbilities: [],
    humanBonusType: null,
    notes: "",
  });

  const { data: races = [] } = trpc.rules.races.useQuery();
  const { data: classes = [] } = trpc.rules.classes.useQuery();
  const { data: competences = [] } = trpc.rules.competences.useQuery();
  const { data: dons = [] } = trpc.rules.dons.useQuery();
  const { data: heritageAvantages = [] } = trpc.rules.heritageAvantages.useQuery();
  const { data: desavantages = [] } = trpc.rules.desavantages.useQuery();
  const { data: fullClass } = trpc.rules.classWithPathsAndAbilities.useQuery(
    { id: charData.classId! },
    { enabled: !!charData.classId }
  );

  const createMutation = trpc.personnages.create.useMutation({
    onSuccess: () => {
      toast.success("Personnage créé avec succès !");
      navigate("/mes-personnages");
    },
    onError: (err) => {
      toast.error("Erreur : " + err.message);
    },
  });

  const updateData = (partial: Partial<CharData>) => {
    setCharData((prev) => ({ ...prev, ...partial }));
  };

  const race = races.find((r) => r.id === charData.raceId);
  const cls = classes.find((c) => c.id === charData.classId);
  const stats = useMemo(
    () => calcStats(charData, race, cls, dons, heritageAvantages),
    [charData, race, cls, dons, heritageAvantages]
  );

  const canProceed = () => {
    switch (currentStep) {
      case 1: return charData.name.trim().length > 0;
      case 2: return charData.selectedDesavantages.length > 0 || true; // Désavantages optionnels
      case 3: return charData.heritageAvantages.length > 0 || true; // Héritage optionnel
      case 4: return charData.competenceId !== null || true; // Compétence optionnelle
      case 5: {
        // Validation stricte 3-2-1
        const values = [charData.puissance, charData.resistance, charData.esprit].sort((a, b) => b - a);
        return values[0] === 3 && values[1] === 2 && values[2] === 1;
      }
      case 6: return charData.faction !== null;
      case 7: return charData.raceId !== null;
      case 8: return charData.classId !== null && charData.classPathId !== null;
      case 9: return charData.classPathId !== null; // Voie obligatoire
      default: return true;
    }
  };

  const handleSubmit = async () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez compléter toutes les étapes obligatoires.");
      return;
    }
    const values = [charData.puissance, charData.resistance, charData.esprit].sort((a, b) => b - a);
    if (values[0] !== 3 || values[1] !== 2 || values[2] !== 1) {
      toast.error("Les caracteristiques doivent suivre 3-2-1");
      return;
    }
    const xpTemp = charData.selectedDesavantages.reduce((sum, id) => {
      const d = desavantages.find((x) => x.id === id);
      return sum + (d?.xpGain ?? 0);
    }, 0);
    const xpPerm = charData.heritageAvantages.reduce((sum, h) => {
      const ha = heritageAvantages.find((x) => x.id === h.id);
      return sum + (ha ? ha.xpCost * h.times : 0);
    }, 0);
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      selectedBonusAbilities: charData.selectedBonusAbilities,
      xpTemporaire: xpTemp,
      xpPermanent: xpPerm,
      notes: charData.notes || undefined,
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}>
            <Lock className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
          </div>
          <h2 className="text-2xl font-heading font-bold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
            Connexion requise
          </h2>
          <p className="text-muted-foreground mb-6">Vous devez être connecté pour créer un personnage.</p>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            className="font-heading"
            style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}
          >
            Se connecter
          </Button>
        </div>
      </div>
    );
  }

  const stepContent = () => {
    switch (currentStep) {
      case 1: return <StepIdentite data={charData} onChange={updateData} />;
      case 2: return <StepDesavantages data={charData} onChange={updateData} desavantages={desavantages} />;
      case 3: return <StepHeritage data={charData} onChange={updateData} heritageAvantages={heritageAvantages} desavantages={desavantages} />;
      case 4: return <StepCompetence data={charData} onChange={updateData} competences={competences} />;
      case 5: return <StepCaracteristiques data={charData} onChange={updateData} heritageAvantages={heritageAvantages} />;
      case 6: return <StepFaction data={charData} onChange={updateData} />;
      case 7: return <StepRace data={charData} onChange={updateData} races={races} />;
      case 8: return <StepClasse data={charData} onChange={updateData} classes={classes} />;
      case 9: {
        const hasExtraAbilities = charData.heritageAvantages.some((heritage: any) => {
          const heritageData = heritageAvantages.find((h: any) => h.id === heritage.id);
          if (!heritageData) return false;
          const level1Val = heritageData.extraAbilitiesLevel1 ?? 0;
          const level2Val = heritageData.extraAbilitiesLevel2 ?? 0;
          return level1Val > 0 || level2Val > 0;
        });
        if (hasExtraAbilities) {
          // Préparer les données pour StepCapacitesBonus
          const allAbilities = fullClass?.paths?.flatMap((p: any) => p.abilities ?? []) ?? [];
          const pathsDataForStep = (fullClass?.paths ?? []).map((path: any) => ({
            ...path,
            level1Abilities: (path.abilities ?? []).filter((a: any) => a.level === 1).map((a: any) => a.id),
            level2Abilities: (path.abilities ?? []).filter((a: any) => a.level === 2).map((a: any) => a.id),
          }));
          return <StepCapacitesBonus data={charData} onChange={updateData} heritageData={heritageAvantages} classData={fullClass} pathsData={pathsDataForStep} abilitiesData={allAbilities} />;
        } else {
          return <StepDons data={charData} onChange={updateData} dons={dons} />;
        }
      }
      case 10: return <StepDons data={charData} onChange={updateData} dons={dons} />;
      case 11: return <StepResume data={charData} races={races} classes={classes} competences={competences} dons={dons} heritageAvantages={heritageAvantages} desavantages={desavantages} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-3xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>
            Créer un personnage
          </h1>
          <p className="text-muted-foreground text-sm mt-1">Terra Mortis — Stukely-Sud</p>
        </div>

        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-muted-foreground font-heading">Étape {currentStep} sur {STEPS.length}</span>
            <span className="text-xs text-muted-foreground font-heading">{STEPS[currentStep - 1]?.label}</span>
          </div>
          <div className="h-2 rounded-full bg-secondary/30">
            <div
              className="h-2 rounded-full transition-all"
              style={{
                width: `${(currentStep / STEPS.length) * 100}%`,
                background: "oklch(0.65 0.18 45)",
              }}
            />
          </div>
          {/* Step indicators */}
          <div className="flex justify-between mt-3 overflow-x-auto gap-1">
            {STEPS.map((step) => {
              const Icon = step.icon;
              const isCompleted = step.id < currentStep;
              const isCurrent = step.id === currentStep;
              return (
                <button
                  key={step.id}
                  onClick={() => step.id < currentStep && setCurrentStep(step.id)}
                  className="flex flex-col items-center gap-1 flex-shrink-0"
                  disabled={step.id > currentStep}
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center transition-all"
                    style={{
                      background: isCompleted ? "oklch(0.45 0.15 140)" : isCurrent ? "oklch(0.65 0.18 45)" : "oklch(0.22 0.025 260)",
                      border: `2px solid ${isCompleted ? "oklch(0.45 0.15 140)" : isCurrent ? "oklch(0.65 0.18 45)" : "oklch(0.28 0.03 260)"}`,
                    }}
                  >
                    {isCompleted ? (
                      <Check className="w-4 h-4 text-white" />
                    ) : (
                      <Icon className="w-4 h-4" style={{ color: isCurrent ? "oklch(0.12 0.02 260)" : "oklch(0.5 0.02 60)" }} />
                    )}
                  </div>
                  <span className="text-xs hidden sm:block" style={{ color: isCurrent ? "oklch(0.82 0.2 85)" : "oklch(0.5 0.02 60)" }}>
                    {step.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step content */}
        <div
          className="p-6 rounded-xl border border-border/40 bg-card/20 mb-6"
          style={{ minHeight: "400px" }}
        >
          {stepContent()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            variant="outline"
            onClick={() => setCurrentStep((s) => Math.max(1, s - 1))}
            disabled={currentStep === 1}
            className="font-heading"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Précédent
          </Button>

          {/* Live stats preview */}
          {charData.raceId && charData.classId && (
            <div className="hidden sm:flex gap-3 text-xs font-heading">
              <span className="text-green-400">{stats.maxPv} PV</span>
              {stats.maxMana > 0 && <span className="text-blue-400">{stats.maxMana} Mana</span>}
              <span style={{ color: "oklch(0.82 0.2 85)" }}>{stats.lutte} Lutte</span>
            </div>
          )}

          {currentStep < STEPS.length ? (
            <Button
              onClick={() => setCurrentStep((s) => Math.min(STEPS.length, s + 1))}
              disabled={!canProceed()}
              className="font-heading"
              style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}
            >
              Suivant
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={createMutation.isPending || !charData.name || !charData.faction || !charData.raceId || !charData.classId}
              className="font-heading"
              style={{ background: "oklch(0.45 0.15 140)", color: "white" }}
            >
              {createMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Check className="w-4 h-4 mr-2" />
              )}
              Créer le personnage
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
