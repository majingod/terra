import { describe, it, expect } from "vitest";

describe("Stats Calculator", () => {
  it("should calculate PV correctly with base + characteristic bonus", () => {
    const classInfo = { pvBase: 10 };
    const resistance = 4; // floor(4/2)*2 = 4
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const maxPv = classInfo.pvBase + pvCharacteristicBonus;

    expect(pvCharacteristicBonus).toBe(4);
    expect(maxPv).toBe(14);
  });

  it("should calculate Mana correctly with base + characteristic bonus", () => {
    const classInfo = { manaBase: 8 };
    const esprit = 6; // floor(6/2)*2 = 6
    const manaCharacteristicBonus = Math.floor(esprit / 2) * 2;
    const maxMana = classInfo.manaBase + manaCharacteristicBonus;

    expect(manaCharacteristicBonus).toBe(6);
    expect(maxMana).toBe(14);
  });

  it("should calculate Lutte correctly with characteristic bonus", () => {
    const puissance = 5; // floor(5/2)*2 = 4
    const lutteCharacteristicBonus = Math.floor(puissance / 2) * 2;

    expect(lutteCharacteristicBonus).toBe(4);
  });

  it("should apply human racial bonus to PV", () => {
    const classInfo = { pvBase: 10 };
    const resistance = 4; // floor(4/2)*2 = 4
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const humanBonusType = "pv";
    const pvRacialBonus = humanBonusType === "pv" ? 1 : 0;

    const maxPv = classInfo.pvBase + pvCharacteristicBonus + pvRacialBonus;

    expect(maxPv).toBe(15); // 10 + 4 + 1 = 15
    expect(pvRacialBonus).toBe(1);
  });

  it("should apply human racial bonus to Mana", () => {
    const classInfo = { manaBase: 8 };
    const esprit = 6; // floor(6/2)*2 = 6
    const manaCharacteristicBonus = Math.floor(esprit / 2) * 2;
    const humanBonusType = "pm";
    const manaRacialBonus = humanBonusType === "pm" ? 1 : 0;

    const maxMana = classInfo.manaBase + manaCharacteristicBonus + manaRacialBonus;

    expect(maxMana).toBe(15); // 8 + 6 + 1 = 15
  });

  it("should not apply human bonus if humanBonusType is null", () => {
    const classInfo = { pvBase: 10 };
    const resistance = 4; // floor(4/2)*2 = 4
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const humanBonusType = null;
    const pvRacialBonus = humanBonusType === "pv" ? 1 : 0;

    const maxPv = classInfo.pvBase + pvCharacteristicBonus + pvRacialBonus;

    expect(maxPv).toBe(14); // 10 + 4 + 0 = 14
    expect(pvRacialBonus).toBe(0);
  });

  it("should calculate total stats with all bonuses", () => {
    const classInfo = { pvBase: 10, manaBase: 8 };
    const resistance = 4; // floor(4/2)*2 = 4
    const esprit = 6; // floor(6/2)*2 = 6
    const puissance = 5; // floor(5/2)*2 = 4

    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const manaCharacteristicBonus = Math.floor(esprit / 2) * 2;
    const lutteCharacteristicBonus = Math.floor(puissance / 2) * 2;

    const pvRacialBonus = 1; // Human +1 PV
    const pathPvBonus = 2;
    const giftPvBonus = 1;
    const heritagePvBonus = 0;

    const maxPv =
      classInfo.pvBase +
      pvCharacteristicBonus +
      pvRacialBonus +
      pathPvBonus +
      giftPvBonus +
      heritagePvBonus;

    expect(maxPv).toBe(18); // 10 + 4 + 1 + 2 + 1 + 0 = 18
  });

  it("should calculate Sauvegardes correctly", () => {
    const resistance = 4; // floor(4/2)*2 = 4
    const sauvegardesCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const pathSauvegardesBonus = 1;
    const giftSauvegardesBonus = 0;
    const heritageSauvegardesBonus = 0;

    const sauvegardes =
      sauvegardesCharacteristicBonus +
      pathSauvegardesBonus +
      giftSauvegardesBonus +
      heritageSauvegardesBonus;

    expect(sauvegardes).toBe(5); // 4 + 1 + 0 + 0 = 5
    expect(sauvegardesCharacteristicBonus).toBe(4);
  });

  it("should handle zero characteristic values", () => {
    const resistance = 0;
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;

    expect(pvCharacteristicBonus).toBe(0);
    expect(resistance).toBe(0);
  });

  it("should handle odd characteristic values", () => {
    const resistance = 5; // floor(5/2)*2 = 4
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;

    expect(pvCharacteristicBonus).toBe(4);
  });

  it("should accumulate multiple heritage bonuses", () => {
    const heritageAvantages = [
      { id: 1, times: 1 },
      { id: 2, times: 2 },
    ];
    const heritageData = [
      { id: 1, pvBonus: 1 },
      { id: 2, pvBonus: 2 },
    ];

    let totalPvBonus = 0;
    heritageAvantages.forEach((h) => {
      const heritage = heritageData.find((x) => x.id === h.id);
      if (heritage) {
        totalPvBonus += (heritage.pvBonus || 0) * h.times;
      }
    });

    expect(totalPvBonus).toBe(5); // 1*1 + 2*2 = 5
    expect(totalPvBonus).toBeGreaterThan(0);
  });

  it("should ensure minimum stats", () => {
    const classInfo = { pvBase: 1 };
    const resistance = 0;
    const pvCharacteristicBonus = Math.floor(resistance / 2) * 2;
    const maxPv = classInfo.pvBase + pvCharacteristicBonus;

    expect(maxPv).toBeGreaterThanOrEqual(1);
    expect(maxPv).toBe(1);
  });
});
