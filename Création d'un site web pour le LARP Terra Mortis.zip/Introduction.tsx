import { BookOpen, ChevronRight, Skull, Shield } from "lucide-react";
import { Link } from "wouter";

export default function Introduction() {
  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground transition-colors">Accueil</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Introduction</span>
        </nav>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}>
              <BookOpen className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            Introduction & Univers
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
        </div>

        {/* Content */}
        <div className="space-y-8">

          {/* Qu'est-ce qu'un GN */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
              Qu'est-ce qu'un grandeur nature (GN) ?
            </h2>
            <div className="space-y-3 text-foreground/85 leading-relaxed">
              <p>
                Un grandeur nature (GN) est un jeu de rôle en direct dans lequel les participants incarnent des personnages fictifs dans un cadre immersif. Contrairement aux jeux de rôle sur table, les joueurs se déplacent physiquement, portent des costumes et utilisent des accessoires pour donner vie à leurs personnages.
              </p>
              <p>
                Terra Mortis est un GN de type combat qui se déroule dans un cadre médiéval fantastique. Les joueurs participent à des événements organisés où ils peuvent combattre, explorer, négocier et vivre des aventures épiques dans l'univers de Terra Mortis.
              </p>
            </div>
          </section>

          {/* L'univers */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
              L'univers de Terra Mortis
            </h2>
            <div className="space-y-4 text-foreground/85 leading-relaxed">
              <p>
                <strong className="text-foreground">Vous êtes mort.</strong> L'après-vie est extrêmement chaotique depuis la destruction de la balance. Deux factions s'affrontent pour le droit d'accéder à Ysgard, le paradis des guerriers.
              </p>
              <p>
                Terra Mortis est le nom donné à cette plaine de l'après-vie où les âmes des guerriers se retrouvent après leur mort. C'est un lieu de conflit perpétuel, où les deux grandes factions — le <strong className="text-blue-400">Sanctum</strong> et la <strong className="text-red-400">Légion</strong> — s'affrontent pour la suprématie.
              </p>
              <p>
                Dans cet univers, la mort n'est pas une fin mais un recommencement. Les personnages peuvent tomber au combat et revenir pour continuer leur quête. Chaque événement est une nouvelle opportunité de gloire ou de défaite.
              </p>
            </div>
          </section>

          {/* Les factions */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-6" style={{ color: "oklch(0.82 0.2 85)" }}>
              Les deux factions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="relative p-8 rounded-xl border bg-card/30" style={{ borderColor: "oklch(0.55 0.18 240)50" }}>
                <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl" style={{ background: "linear-gradient(to right, transparent, oklch(0.55 0.18 240), transparent)" }} />
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "oklch(0.55 0.18 240)20", border: "2px solid oklch(0.55 0.18 240)50" }}>
                    <Shield className="w-6 h-6" style={{ color: "oklch(0.55 0.18 240)" }} />
                  </div>
                  <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.55 0.18 240)" }}>
                    Sanctum
                  </h3>
                </div>
                <p className="text-foreground/80 mb-6 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                  Les races et individus de Sanctum proviennent de civilisations avancées. Leur force réside dans l'union, la persévérance et l'organisation. En général, les membres de cette faction sont bienveillants, ayant tendance à penser aux besoins des autres avant les leurs.
                </p>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">Races disponibles</p>
                    <div className="flex flex-wrap gap-2">
                      {["Humain", "Elfe", "Nain"].map((race) => (
                        <span key={race} className="px-2 py-1 rounded text-xs font-heading" style={{ background: "oklch(0.55 0.18 240)15", border: "1px solid oklch(0.55 0.18 240)30", color: "oklch(0.55 0.18 240)" }}>
                          {race}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">Classes disponibles</p>
                    <div className="flex flex-wrap gap-2">
                      {["Druide", "Guerrier", "Magicien", "Roublard", "Medjai", "Paladin"].map((cls) => (
                        <span key={cls} className="px-2 py-1 rounded text-xs font-heading" style={{ background: "oklch(0.55 0.18 240)08", border: "1px dashed oklch(0.55 0.18 240)40", color: "oklch(0.55 0.18 240)" }}>
                          {cls}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative p-8 rounded-xl border bg-card/30" style={{ borderColor: "oklch(0.5 0.22 25)50" }}>
                <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl" style={{ background: "linear-gradient(to right, transparent, oklch(0.5 0.22 25), transparent)" }} />
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "oklch(0.5 0.22 25)20", border: "2px solid oklch(0.5 0.22 25)50" }}>
                    <Skull className="w-6 h-6" style={{ color: "oklch(0.5 0.22 25)" }} />
                  </div>
                  <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.5 0.22 25)" }}>
                    Légion
                  </h3>
                </div>
                <p className="text-foreground/80 mb-6 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                  La Légion regroupe les races et individus souillés par une forme de corruption. Leur force réside dans le nombre, la brutalité et la volonté de tout faire pour l'emporter. En général, les membres de cette faction sont malveillants, ayant tendance à penser à leurs besoins avant ceux des autres.
                </p>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">Races disponibles</p>
                    <div className="flex flex-wrap gap-2">
                      {["Humain", "Orc", "Drow", "Gobelin"].map((race) => (
                        <span key={race} className="px-2 py-1 rounded text-xs font-heading" style={{ background: "oklch(0.5 0.22 25)15", border: "1px solid oklch(0.5 0.22 25)30", color: "oklch(0.5 0.22 25)" }}>
                          {race}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2">Classes disponibles</p>
                    <div className="flex flex-wrap gap-2">
                      {["Druide", "Guerrier", "Magicien", "Roublard", "Chevalier de la Mort", "Sorcier"].map((cls) => (
                        <span key={cls} className="px-2 py-1 rounded text-xs font-heading" style={{ background: "oklch(0.5 0.22 25)08", border: "1px dashed oklch(0.5 0.22 25)40", color: "oklch(0.5 0.22 25)" }}>
                          {cls}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Règles de sécurité */}
          <section className="p-6 rounded-xl border border-border/50 bg-card/30">
            <h2 className="text-2xl font-heading font-semibold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
              Règles de sécurité fondamentales
            </h2>
            <div className="space-y-4">
              <div className="p-4 rounded-lg" style={{ background: "oklch(0.55 0.22 25 / 0.1)", border: "1px solid oklch(0.55 0.22 25 / 0.3)" }}>
                <h3 className="font-heading font-semibold mb-2" style={{ color: "oklch(0.75 0.22 25)" }}>Mot de sécurité : "HORS-JEU"</h3>
                <p className="text-sm text-foreground/80">
                  Si un joueur dit "HORS-JEU", le jeu s'arrête immédiatement dans la zone. Ce mot est utilisé en cas de blessure réelle, de malaise ou de tout problème de sécurité. Tout le monde doit respecter ce signal sans exception.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { title: "Frappes autorisées", desc: "Corps (sauf tête, cou, colonne, entrejambe). Les frappes doivent être contrôlées et ne jamais viser les zones interdites." },
                  { title: "Armes homologuées", desc: "Seules les armes de mousse approuvées par les organisateurs sont autorisées. Aucune arme réelle n'est permise sur le terrain." },
                  { title: "Respect des joueurs", desc: "Le harcèlement, la discrimination et tout comportement irrespectueux sont strictement interdits et peuvent entraîner l'expulsion." },
                  { title: "Alcool et drogues", desc: "La consommation d'alcool ou de drogues pendant les événements est interdite pour assurer la sécurité de tous." },
                ].map(item => (
                  <div key={item.title} className="p-3 rounded-lg bg-secondary/30">
                    <h4 className="font-heading text-sm font-semibold mb-1 text-foreground">{item.title}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Navigation vers les autres sections */}
          <div className="grid md:grid-cols-3 gap-4 pt-4">
            {[
              { href: "/regles/regles-base", label: "Règles de base", desc: "Système de combat, PV, mana..." },
              { href: "/regles/races", label: "Les races", desc: "Humain, Elfe, Nain, Orc..." },
              { href: "/regles/classes", label: "Les classes", desc: "Guerrier, Mage, Druide..." },
            ].map(link => (
              <Link key={link.href} href={link.href}>
                <div className="p-4 rounded-lg border border-border/50 bg-card/20 hover:bg-card/40 transition-all group cursor-pointer">
                  <h3 className="font-heading font-semibold text-foreground group-hover:text-primary transition-colors flex items-center gap-2">
                    {link.label}
                    <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">{link.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
