import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createUserContext(role: "user" | "admin" | "organizer" = "user"): { ctx: TrpcContext; clearedCookies: { name: string; options: Record<string, unknown> }[] } {
  const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-openid",
    email: "joueur@terra-mortis.com",
    name: "Joueur Test",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  const ctx: TrpcContext = {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };
  return { ctx, clearedCookies };
}

function createGuestContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

// ─── Auth tests ───────────────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1, httpOnly: true, path: "/" });
  });

  it("returns null for unauthenticated user via auth.me", async () => {
    const ctx = createGuestContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user object for authenticated user via auth.me", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Joueur Test");
    expect(result?.role).toBe("user");
  });
});

// ─── Access control tests ─────────────────────────────────────────────────────
describe("admin access control", () => {
  it("denies non-organizer access to admin.getAllPersonnages", async () => {
    const { ctx } = createUserContext("user");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.getAllPersonnages()).rejects.toThrow();
  });

  it("denies unauthenticated access to personnages.myPersonnages", async () => {
    const ctx = createGuestContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.personnages.myPersonnages()).rejects.toThrow();
  });

  it("denies non-admin access to admin.getAllUsers", async () => {
    const { ctx } = createUserContext("organizer");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.getAllUsers()).rejects.toThrow();
  });
});

// ─── Role-based access ────────────────────────────────────────────────────────
describe("role-based access", () => {
  it("organizer can access getAllPersonnages", async () => {
    const { ctx } = createUserContext("organizer");
    const caller = appRouter.createCaller(ctx);
    // This will fail at DB level (no DB in test), but should not throw FORBIDDEN
    try {
      await caller.admin.getAllPersonnages();
    } catch (err: any) {
      expect(err?.code).not.toBe("FORBIDDEN");
    }
  });

  it("admin can access getAllUsers", async () => {
    const { ctx } = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.admin.getAllUsers();
    } catch (err: any) {
      expect(err?.code).not.toBe("FORBIDDEN");
    }
  });
});

// ─── Public rules access ──────────────────────────────────────────────────────
describe("public rules access", () => {
  it("guest can access rules.races without authentication", async () => {
    const ctx = createGuestContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.rules.races();
    } catch (err: any) {
      // Should not be UNAUTHORIZED or FORBIDDEN
      expect(err?.code).not.toBe("UNAUTHORIZED");
      expect(err?.code).not.toBe("FORBIDDEN");
    }
  });

  it("guest can access rules.dons without authentication", async () => {
    const ctx = createGuestContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.rules.dons();
    } catch (err: any) {
      expect(err?.code).not.toBe("UNAUTHORIZED");
      expect(err?.code).not.toBe("FORBIDDEN");
    }
  });
});
