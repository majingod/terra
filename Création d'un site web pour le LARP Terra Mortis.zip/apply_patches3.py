#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Remplacer handleSubmit
old_code = '''  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez compléter toutes les étapes obligatoires.");
      return;
    }
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      notes: charData.notes || undefined,
    });
  };'''

new_code = '''  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez compléter toutes les étapes obligatoires.");
      return;
    }
    const values = [charData.puissance, charData.resistance, charData.esprit].sort((a, b) => b - a);
    if (values[0] !== 3 || values[1] !== 2 || values[2] !== 1) {
      toast.error("Les caracteristiques doivent suivre 3-2-1");
      return;
    }
    const xpTemp = charData.selectedDesavantages.reduce((sum, id) => {
      const d = desavantages.find((x) => x.id === id);
      return sum + (d?.xpGain ?? 0);
    }, 0);
    const xpPerm = charData.heritageAvantages.reduce((sum, h) => {
      const ha = heritageAvantages.find((x) => x.id === h.id);
      return sum + (ha ? ha.xpCost * h.times : 0);
    }, 0);
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      xpTemporaire: xpTemp,
      xpPermanent: xpPerm,
      notes: charData.notes || undefined,
    });
  };'''

if old_code in content:
    content = content.replace(old_code, new_code)
    print("✓ handleSubmit modifié")
else:
    print("✗ handleSubmit non trouvé")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
