import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ChevronRight, Loader2, User, Shield, Sword, Star, Gem, TrendingDown, BookOpen, ArrowLeft } from "lucide-react";
import { Link, useParams } from "wouter";

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

export default function PersonnageDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");
  const { isAuthenticated } = useAuth();

  const { data: p, isLoading } = trpc.personnages.getById.useQuery(
    { id },
    { enabled: isAuthenticated && id > 0 }
  );
  const { data: races } = trpc.rules.races.useQuery();
  const { data: classes } = trpc.rules.classes.useQuery();
  const { data: dons } = trpc.rules.dons.useQuery();
  const { data: heritageAvantages } = trpc.rules.heritageAvantages.useQuery();
  const { data: desavantages } = trpc.rules.desavantages.useQuery();
  const { data: competences } = trpc.rules.competences.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
      </div>
    );
  }

  if (!p) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Personnage introuvable.</p>
          <Link href="/mes-personnages">
            <Button variant="outline" className="font-heading">Retour</Button>
          </Link>
        </div>
      </div>
    );
  }

  const race = races?.find((r) => r.id === p.raceId);
  const cls = classes?.find((c) => c.id === p.classId);
  const comp = competences?.find((c) => c.id === p.competenceId);
  const factionColor = p.faction === "Sanctum" ? "oklch(0.55 0.18 240)" : "oklch(0.5 0.22 25)";

  const selectedDons = asStrArr(p.selectedDons as unknown);
  const selectedDesavantages = asStrArr(p.selectedDesavantages as unknown);
  const heritageList = Array.isArray(p.heritageAvantages) ? (p.heritageAvantages as { id: number; times: number }[]) : [];
  const languages = asStrArr(p.languages as unknown);

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground transition-colors">Accueil</Link>
          <ChevronRight className="w-4 h-4" />
          <Link href="/mes-personnages" className="hover:text-foreground transition-colors">Mes personnages</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">{p.name}</span>
        </nav>

        {/* Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-4xl font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>{p.name}</h1>
            <div className="flex items-center gap-3 mt-2">
              <span
                className="text-sm px-3 py-1 rounded-full font-heading"
                style={{ background: `${factionColor}20`, color: factionColor, border: `1px solid ${factionColor}40` }}
              >
                {p.faction}
              </span>
              <span className="text-sm text-muted-foreground">Niveau {p.level}</span>
            </div>
          </div>
          <Link href="/mes-personnages">
            <Button variant="outline" size="sm" className="font-heading">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Retour
            </Button>
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column */}
          <div className="lg:col-span-1 space-y-4">
            {/* Identity */}
            <div className="p-5 rounded-xl border border-border/40 bg-card/30">
              <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                <User className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                Identité
              </h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Race</span>
                  <span className="font-heading text-foreground">{race?.name ?? "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Classe</span>
                  <span className="font-heading text-foreground">{cls?.name ?? "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Faction</span>
                  <span className="font-heading" style={{ color: factionColor }}>{p.faction}</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="p-5 rounded-xl border border-border/40 bg-card/30">
              <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                <Star className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                Statistiques
              </h2>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "PV max", value: p.maxPv, color: "oklch(0.45 0.15 140)" },
                  { label: "Mana max", value: p.maxMana, color: "oklch(0.55 0.18 240)" },
                  { label: "Lutte", value: p.lutte, color: "oklch(0.65 0.18 45)" },
                  { label: "Sauvegardes", value: p.sauvegardes, color: "oklch(0.55 0.22 25)" },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-3 rounded-lg text-center"
                    style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}30` }}
                  >
                    <div className="text-xl font-heading font-bold" style={{ color: stat.color }}>{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Characteristics */}
            <div className="p-5 rounded-xl border border-border/40 bg-card/30">
              <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                <Shield className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                Caractéristiques
              </h2>
              <div className="space-y-2">
                {[
                  { label: "Puissance", value: p.puissance, color: "oklch(0.55 0.22 25)" },
                  { label: "Résistance", value: p.resistance, color: "oklch(0.45 0.15 140)" },
                  { label: "Esprit", value: p.esprit, color: "oklch(0.55 0.18 240)" },
                ].map((stat) => (
                  <div key={stat.label} className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((n) => (
                          <div
                            key={n}
                            className="w-3 h-3 rounded-sm"
                            style={{ background: n <= (stat.value ?? 0) ? stat.color : "oklch(0.28 0.03 260)" }}
                          />
                        ))}
                      </div>
                      <span className="font-heading font-bold text-sm w-4 text-right" style={{ color: stat.color }}>
                        {stat.value}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* XP */}
            <div className="p-5 rounded-xl border border-border/40 bg-card/30">
              <h2 className="font-heading font-semibold mb-3 text-foreground">Expérience</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">XP permanent</span>
                  <span className="font-heading text-foreground">{p.xpPermanent}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">XP temporaire</span>
                  <span className="font-heading text-foreground">{p.xpTemporaire}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="lg:col-span-2 space-y-4">
            {/* Background */}
            {p.background && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <BookOpen className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Histoire & Background
                </h2>
                <p className="text-sm text-foreground/80 leading-relaxed">{p.background}</p>
              </div>
            )}

            {/* Race abilities */}
            {race && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <User className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Capacités raciales — {race.name}
                </h2>
                {asStrArr(race.bonuses).length > 0 && (
                  <div className="mb-3">
                    <h4 className="text-xs font-heading font-semibold text-muted-foreground mb-2">AVANTAGES</h4>
                    <ul className="space-y-1">
                      {asStrArr(race.bonuses).map((b, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                          <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 bg-green-500" />
                          {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {(Array.isArray(race.abilities) ? race.abilities as { name: string; description: string }[] : []).map((ability, i) => (
                  <div key={i} className="p-3 rounded-lg bg-secondary/30 border border-border/30 mb-2">
                    <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>{ability.name}</h4>
                    <p className="text-xs text-foreground/70">{ability.description}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Class abilities */}
            {cls && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <Sword className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Capacités de classe — {cls.name}
                </h2>
                {(Array.isArray(cls.baseAbilities) ? cls.baseAbilities as { name: string; description: string }[] : []).map((ability, i) => (
                  <div key={i} className="p-3 rounded-lg bg-secondary/30 border border-border/30 mb-2">
                    <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>{ability.name}</h4>
                    <p className="text-xs text-foreground/70">{ability.description}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Competence */}
            {comp && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <BookOpen className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Compétence
                </h2>
                <div className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                  <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>{comp.name}</h4>
                  <p className="text-xs text-foreground/70 mb-2">{comp.description}</p>
                  <p className="text-xs text-foreground/60 italic">{comp.baseAdvantage}</p>
                </div>
              </div>
            )}

            {/* Dons */}
            {selectedDons.length > 0 && dons && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <Star className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Dons
                </h2>
                <div className="space-y-2">
                  {selectedDons.map((donId) => {
                    const don = dons.find((d) => String(d.id) === String(donId));
                    return don ? (
                      <div key={don.id} className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                        <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>{don.name}</h4>
                        <p className="text-xs text-foreground/70">{don.description}</p>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}

            {/* Heritage */}
            {heritageList.length > 0 && heritageAvantages && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <Gem className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Avantages d'héritage
                </h2>
                <div className="space-y-2">
                  {heritageList.map((h) => {
                    const ha = heritageAvantages.find((x) => x.id === h.id);
                    return ha ? (
                      <div key={ha.id} className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>
                            {ha.name}{h.times > 1 ? ` ×${h.times}` : ""}
                          </h4>
                          <span className="text-xs" style={{ color: "oklch(0.65 0.18 45)" }}>{ha.xpCost * h.times} XP</span>
                        </div>
                        <p className="text-xs text-foreground/70">{ha.description}</p>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}

            {/* Désavantages */}
            {selectedDesavantages.length > 0 && desavantages && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 flex items-center gap-2 text-foreground">
                  <TrendingDown className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
                  Désavantages
                </h2>
                <div className="space-y-2">
                  {selectedDesavantages.map((desavId) => {
                    const d = desavantages.find((x) => String(x.id) === String(desavId));
                    return d ? (
                      <div key={d.id} className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>{d.name}</h4>
                          <span className="text-xs" style={{ color: "oklch(0.75 0.22 25)" }}>+{d.xpGain} XP</span>
                        </div>
                        <p className="text-xs text-foreground/70">{d.description}</p>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}

            {/* Languages */}
            {languages.length > 0 && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 text-foreground">Langues</h2>
                <div className="flex flex-wrap gap-2">
                  {languages.map((lang, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded text-sm font-heading"
                      style={{ background: "oklch(0.22 0.025 260)", color: "oklch(0.7 0.02 60)", border: "1px solid oklch(0.28 0.03 260)" }}
                    >
                      {lang}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Notes */}
            {p.notes && (
              <div className="p-5 rounded-xl border border-border/40 bg-card/30">
                <h2 className="font-heading font-semibold mb-3 text-foreground">Notes</h2>
                <p className="text-sm text-foreground/75 leading-relaxed">{p.notes}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
