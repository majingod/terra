import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FactionBadge } from "@/components/FactionBadge";
import { TerraMortisHeading } from "@/components/TerraMortisHeading";
import { TerraMortisDivider } from "@/components/TerraMortisDivider";
import { Printer, Download, Edit2, Share2 } from "lucide-react";
import { toast } from "sonner";

interface PersonnageData {
  id: string;
  name: string;
  faction: "Sanctum" | "Légion";
  race: string;
  class: string;
  classPath: string;
  puissance: number;
  resistance: number;
  esprit: number;
  pv: number;
  pm: number;
  background: string;
  dons: string[];
  competences: string[];
  capacitesBonus: string[];
  heritages: string[];
  createdAt: string;
  userId: string;
}

export default function PersonnageSheet() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [personnage, setPersonnage] = useState<PersonnageData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPrinting, setIsPrinting] = useState(false);

  // TODO: Charger le personnage via tRPC
  useState(() => {
    // Données temporaires pour le développement
    setPersonnage({
      id: id || "1",
      name: "Aldric le Sombre",
      faction: "Sanctum",
      race: "Humain",
      class: "Guerrier",
      classPath: "Barbare",
      puissance: 3,
      resistance: 2,
      esprit: 1,
      pv: 25,
      pm: 10,
      background: "Un guerrier endurci par les batailles...",
      dons: ["Force", "Vitalité"],
      competences: ["Épée", "Survie"],
      capacitesBonus: ["Attaque puissante"],
      heritages: ["+1 Capacité de niveau 1"],
      createdAt: new Date().toISOString(),
      userId: "user-1",
    });
    setIsLoading(false);
  });

  const handlePrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 100);
  };

  const handleDownloadPDF = async () => {
    try {
      toast.loading("Génération du PDF...");
      // TODO: Implémenter l'export PDF via tRPC
      toast.success("PDF téléchargé avec succès !");
    } catch (error) {
      toast.error("Erreur lors du téléchargement du PDF");
    }
  };

  const handleEdit = () => {
    setLocation(`/creer-personnage-v2?edit=${id}`);
  };

  const handleShare = async () => {
    try {
      const url = `${window.location.origin}/personnage/${id}`;
      await navigator.clipboard.writeText(url);
      toast.success("Lien copié dans le presse-papiers !");
    } catch (error) {
      toast.error("Erreur lors de la copie du lien");
    }
  };

  if (isLoading) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <p className="text-muted-foreground">Chargement du personnage...</p>
        </div>
      </div>
    );
  }

  if (!personnage) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Personnage non trouvé</p>
          <Button onClick={() => setLocation("/mes-personnages")}>
            Retour à mes personnages
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-12">
      {/* Barre d'outils */}
      <div className="flex justify-between items-center mb-8 print:hidden">
        <TerraMortisHeading level={1} gradient="gold" className="text-4xl">
          {personnage.name}
        </TerraMortisHeading>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleEdit}>
            <Edit2 className="w-4 h-4 mr-2" />
            Modifier
          </Button>
          <Button variant="outline" size="sm" onClick={handleShare}>
            <Share2 className="w-4 h-4 mr-2" />
            Partager
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
            <Download className="w-4 h-4 mr-2" />
            PDF
          </Button>
          <Button variant="outline" size="sm" onClick={handlePrint} disabled={isPrinting}>
            <Printer className="w-4 h-4 mr-2" />
            Imprimer
          </Button>
        </div>
      </div>

      {/* Fiche de personnage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Colonne gauche — Informations principales */}
        <div className="lg:col-span-2 space-y-6">
          {/* En-tête */}
          <Card className="p-6 bg-gradient-to-r from-orange-900 to-orange-800 text-white border-orange-700">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm opacity-75">Faction</p>
                <FactionBadge faction={personnage.faction as "Sanctum" | "Légion"} size="lg" />
              </div>
              <div>
                <p className="text-sm opacity-75">Race</p>
                <p className="text-xl font-bold">{personnage.race}</p>
              </div>
              <div>
                <p className="text-sm opacity-75">Classe</p>
                <p className="text-xl font-bold">{personnage.class}</p>
              </div>
              <div>
                <p className="text-sm opacity-75">Voie</p>
                <p className="text-xl font-bold">{personnage.classPath}</p>
              </div>
            </div>
          </Card>

          {/* Caractéristiques */}
          <Card className="p-6">
            <TerraMortisHeading level={2} className="text-2xl mb-4">
              Caractéristiques
            </TerraMortisHeading>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                <p className="text-sm text-red-700 font-semibold">Puissance</p>
                <p className="text-3xl font-bold text-red-900">{personnage.puissance}</p>
              </div>
              <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                <p className="text-sm text-blue-700 font-semibold">Résistance</p>
                <p className="text-3xl font-bold text-blue-900">{personnage.resistance}</p>
              </div>
              <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                <p className="text-sm text-purple-700 font-semibold">Esprit</p>
                <p className="text-3xl font-bold text-purple-900">{personnage.esprit}</p>
              </div>
            </div>
          </Card>

          {/* Points de vie et mana */}
          <Card className="p-6">
            <TerraMortisHeading level={2} className="text-2xl mb-4">
              Ressources
            </TerraMortisHeading>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Points de Vie</p>
                <div className="w-full bg-gray-200 rounded-full h-8 flex items-center px-3">
                  <div
                    className="bg-red-500 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold"
                    style={{ width: "100%" }}
                  >
                    {personnage.pv}
                  </div>
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-2">Points de Mana</p>
                <div className="w-full bg-gray-200 rounded-full h-8 flex items-center px-3">
                  <div
                    className="bg-blue-500 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold"
                    style={{ width: "100%" }}
                  >
                    {personnage.pm}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Arrière-plan */}
          {personnage.background && (
            <Card className="p-6">
              <TerraMortisHeading level={2} className="text-2xl mb-4">
                Arrière-plan
              </TerraMortisHeading>
              <p className="text-muted-foreground whitespace-pre-wrap">{personnage.background}</p>
            </Card>
          )}
        </div>

        {/* Colonne droite — Sélections */}
        <div className="space-y-6">
          {/* Dons */}
          {personnage.dons.length > 0 && (
            <Card className="p-6">
              <TerraMortisHeading level={3} className="text-lg mb-4">
                Dons
              </TerraMortisHeading>
              <ul className="space-y-2">
                {personnage.dons.map((don, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <span className="mr-2">•</span>
                    <span>{don}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {/* Compétences */}
          {personnage.competences.length > 0 && (
            <Card className="p-6">
              <TerraMortisHeading level={3} className="text-lg mb-4">
                Compétences
              </TerraMortisHeading>
              <ul className="space-y-2">
                {personnage.competences.map((comp, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <span className="mr-2">•</span>
                    <span>{comp}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {/* Capacités bonus */}
          {personnage.capacitesBonus.length > 0 && (
            <Card className="p-6">
              <TerraMortisHeading level={3} className="text-lg mb-4">
                Capacités Bonus
              </TerraMortisHeading>
              <ul className="space-y-2">
                {personnage.capacitesBonus.map((cap, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <span className="mr-2">✨</span>
                    <span>{cap}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {/* Héritages */}
          {personnage.heritages.length > 0 && (
            <Card className="p-6 bg-amber-50 border-amber-200">
              <TerraMortisHeading level={3} className="text-lg mb-4 text-amber-900">
                Héritages
              </TerraMortisHeading>
              <ul className="space-y-2">
                {personnage.heritages.map((her, idx) => (
                  <li key={idx} className="text-sm flex items-start text-amber-800">
                    <span className="mr-2">✨</span>
                    <span>{her}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      </div>

      {/* Styles d'impression */}
      <style>{`
        @media print {
          body {
            background: white;
          }
          .container {
            max-width: 100%;
          }
          .print\\:hidden {
            display: none !important;
          }
          .page-break {
            page-break-after: always;
          }
        }
      `}</style>
    </div>
  );
}
