import { getDb } from "./db";
import { familyProfiles, personnages, xpPermanentHistory, inscriptions, evenements } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

/**
 * Procédures pour le partage d'XP entre personnages d'un même utilisateur
 */

/**
 * Récupérer l'XP permanent d'un profil de famille
 */
export async function getFamilyProfilePermanentXP(profileId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const profile = await db
    .select({ xpPermanent: familyProfiles.xpPermanent })
    .from(familyProfiles)
    .where(eq(familyProfiles.id, profileId));

  return profile[0]?.xpPermanent || 0;
}

/**
 * Récupérer tous les personnages d'un utilisateur avec leurs XP
 */
export async function getUserCharacters(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select({
      id: personnages.id,
      name: personnages.name,
      xpPermanent: personnages.xpPermanent,
      xpTemporaire: personnages.xpTemporaire,
      level: personnages.level,
    })
    .from(personnages)
    .where(eq(personnages.userId, userId))
    .orderBy(personnages.createdAt);
}

/**
 * Ajouter de l'XP permanent à un profil de famille (partagé entre tous les personnages)
 */
export async function addFamilyProfilePermanentXP(
  profileId: number,
  userId: number,
  amount: number,
  sourceType: string,
  sourceId?: number,
  description?: string,
  createdBy?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer le solde actuel
  const currentProfile = await db
    .select({ xpPermanent: familyProfiles.xpPermanent })
    .from(familyProfiles)
    .where(eq(familyProfiles.id, profileId));

  const soldeBefore = currentProfile[0]?.xpPermanent || 0;
  const soldeAfter = Math.max(0, soldeBefore + amount);

  // Mettre à jour l'XP du profil
  await db
    .update(familyProfiles)
    .set({ xpPermanent: soldeAfter })
    .where(eq(familyProfiles.id, profileId));

  // Enregistrer dans l'historique
  await db.insert(xpPermanentHistory).values({
    userId,
    montant: amount,
    soldeBefore,
    soldeAfter,
    sourceType,
    sourceId,
    description,
    createdBy,
  });

  return { soldeBefore, soldeAfter, montant: amount };
}

/**
 * Transférer de l'XP permanent d'un personnage à un autre
 */
export async function transferCharacterXP(
  fromCharacterId: number,
  toCharacterId: number,
  amount: number,
  userId: number,
  reason?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Vérifier que les deux personnages appartiennent à l'utilisateur
  const [fromChar, toChar] = await Promise.all([
    db
      .select()
      .from(personnages)
      .where(and(eq(personnages.id, fromCharacterId), eq(personnages.userId, userId))),
    db
      .select()
      .from(personnages)
      .where(and(eq(personnages.id, toCharacterId), eq(personnages.userId, userId))),
  ]);

  if (!fromChar || fromChar.length === 0) {
    throw new Error("Source character not found or does not belong to user");
  }
  if (!toChar || toChar.length === 0) {
    throw new Error("Target character not found or does not belong to user");
  }

  const fromCharacter = fromChar[0];
  const toCharacter = toChar[0];

  // Vérifier que le personnage source a assez d'XP
  if ((fromCharacter.xpTemporaire || 0) < amount) {
    throw new Error("Insufficient XP to transfer");
  }

  // Transférer l'XP
  await db
    .update(personnages)
    .set({ xpTemporaire: (fromCharacter.xpTemporaire || 0) - amount })
    .where(eq(personnages.id, fromCharacterId));

  await db
    .update(personnages)
    .set({ xpTemporaire: (toCharacter.xpTemporaire || 0) + amount })
    .where(eq(personnages.id, toCharacterId));

  return {
    fromCharacter: {
      id: fromCharacterId,
      xpBefore: fromCharacter.xpTemporaire,
      xpAfter: (fromCharacter.xpTemporaire || 0) - amount,
    },
    toCharacter: {
      id: toCharacterId,
      xpBefore: toCharacter.xpTemporaire,
      xpAfter: (toCharacter.xpTemporaire || 0) + amount,
    },
    amount,
    reason,
  };
}

/**
 * Récupérer l'historique d'XP d'un utilisateur
 */
export async function getUserXPHistory(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(xpPermanentHistory)
    .where(eq(xpPermanentHistory.userId, userId))
    .orderBy(xpPermanentHistory.createdAt)
    .limit(limit);
}

/**
 * Valider les limites d'XP par niveau
 */
export function validateXPLimits(level: number, xpPermanent: number): {
  isValid: boolean;
  maxXP: number;
  currentXP: number;
  message?: string;
} {
  // Limites d'XP par niveau (exemple)
  const xpLimits: Record<number, number> = {
    1: 100,
    2: 250,
    3: 450,
    4: 700,
    5: 1000,
    6: 1350,
    7: 1750,
    8: 2200,
    9: 2700,
    10: 3250,
  };

  const maxXP = xpLimits[level] || 3250; // Par défaut, limite du niveau 10

  if (xpPermanent > maxXP) {
    return {
      isValid: false,
      maxXP,
      currentXP: xpPermanent,
      message: `XP dépasse la limite du niveau ${level} (max: ${maxXP})`,
    };
  }

  return {
    isValid: true,
    maxXP,
    currentXP: xpPermanent,
  };
}

/**
 * Récupérer les statistiques d'XP d'un profil de famille
 */
export async function getFamilyProfileXPStats(profileId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const profile = await db
    .select({ xpPermanent: familyProfiles.xpPermanent })
    .from(familyProfiles)
    .where(eq(familyProfiles.id, profileId));

  const characters = await db
    .select({
      id: personnages.id,
      xpPermanent: personnages.xpPermanent,
      xpTemporaire: personnages.xpTemporaire,
    })
    .from(personnages)
    .where(eq(personnages.userId, userId));

  const totalXPTemporaire = characters.reduce((sum, char) => sum + (char.xpTemporaire || 0), 0);

  const history = await db
    .select()
    .from(xpPermanentHistory)
    .where(eq(xpPermanentHistory.userId, userId));

  const totalEarned = history
    .filter((h) => h.montant > 0)
    .reduce((sum, h) => sum + h.montant, 0);

  const totalSpent = history
    .filter((h) => h.montant < 0)
    .reduce((sum, h) => sum + Math.abs(h.montant), 0);

  return {
    profilePermanentXP: profile[0]?.xpPermanent || 0,
    characterCount: characters.length,
    totalCharacterXP: totalXPTemporaire,
    totalEarned,
    totalSpent,
    transactionCount: history.length,
  };
}

/**
 * Attribuer l'XP à partir d'une inscription validée.
 * Le personnage inscrit est prioritaire. Pour les anciennes inscriptions sans
 * personnage, le premier personnage actif du joueur est utilisé comme repli.
 * Si le personnage appartient à un profil familial, le solde partagé du profil
 * est augmenté et l'opération reste tracée dans l'historique de l'utilisateur.
 */
export async function awardXPForInscription(
  inscriptionId: number,
  amount: number,
  reason: string | undefined,
  awardedBy: number,
) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error("XP amount must be a positive integer");
  }

  const inscriptionRows = await db
    .select({
      inscription: inscriptions,
      eventTitle: evenements.title,
    })
    .from(inscriptions)
    .leftJoin(evenements, eq(inscriptions.evenementId, evenements.id))
    .where(eq(inscriptions.id, inscriptionId))
    .limit(1);

  const record = inscriptionRows[0];
  if (!record) throw new Error("Inscription not found");
  if (record.inscription.status === "cancelled") {
    throw new Error("Cannot award XP to a cancelled inscription");
  }

  const inscription = record.inscription;
  const characterRows = inscription.personnageId
    ? await db
        .select()
        .from(personnages)
        .where(and(eq(personnages.id, inscription.personnageId), eq(personnages.userId, inscription.userId)))
        .limit(1)
    : await db
        .select()
        .from(personnages)
        .where(and(eq(personnages.userId, inscription.userId), eq(personnages.isActive, true)))
        .orderBy(personnages.createdAt)
        .limit(1);

  const character = characterRows[0];
  if (!character) {
    throw new Error("No active character is linked to this inscription");
  }

  const description = reason?.trim() || `Événement : ${record.eventTitle || inscription.evenementId}`;
  let soldeBefore = character.xpPermanent;
  let soldeAfter = character.xpPermanent + amount;
  let targetType: "character" | "family_profile" = "character";
  let targetId = character.id;

  if (character.profileId) {
    const profileRows = await db
      .select({ xpPermanent: familyProfiles.xpPermanent })
      .from(familyProfiles)
      .where(eq(familyProfiles.id, character.profileId))
      .limit(1);
    const profile = profileRows[0];
    if (!profile) throw new Error("Family profile linked to character was not found");

    soldeBefore = profile.xpPermanent;
    soldeAfter = profile.xpPermanent + amount;
    targetType = "family_profile";
    targetId = character.profileId;

    await db
      .update(familyProfiles)
      .set({ xpPermanent: soldeAfter })
      .where(eq(familyProfiles.id, character.profileId));
  } else {
    await db
      .update(personnages)
      .set({ xpPermanent: soldeAfter })
      .where(eq(personnages.id, character.id));
  }

  await db.insert(xpPermanentHistory).values({
    userId: inscription.userId,
    montant: amount,
    soldeBefore,
    soldeAfter,
    sourceType: "event",
    sourceId: inscription.evenementId,
    description,
    createdBy: awardedBy,
  });

  return {
    inscriptionId,
    evenementId: inscription.evenementId,
    userId: inscription.userId,
    characterId: character.id,
    targetType,
    targetId,
    soldeBefore,
    soldeAfter,
    montant: amount,
    description,
  };
}
