import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { EncyclopediaPanel } from "../EncyclopediaPanel";

interface StepRaceProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepRace({ charData, onCharDataChange }: StepRaceProps) {
  const [races, setRaces] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRaceData, setSelectedRaceData] = useState<any>(null);

  useEffect(() => {
    // TODO: Remplacer par la procédure tRPC encyclopedia.getByCategory
    setTimeout(() => {
      setRaces([
        {
          id: 1,
          name: "Humain",
          description:
            "Les humains sont les créatures les plus adaptables. Ils possèdent une grande capacité d'apprentissage et une volonté inébranlable.",
          bonus: ["+1 Don", "+1 Compétence"],
          prerequisites: ["Aucun"],
        },
        {
          id: 2,
          name: "Elfe",
          description:
            "Les elfes sont gracieux et magiques. Ils vivent longtemps et possèdent une affinité naturelle avec la magie.",
          bonus: ["+2 Esprit", "+1 Capacité magique"],
          prerequisites: ["Aucun"],
        },
        {
          id: 3,
          name: "Nain",
          description:
            "Les nains sont forts et résistants. Ils excellent dans les métiers et possèdent une grande endurance.",
          bonus: ["+2 Résistance", "+1 Lutte"],
          prerequisites: ["Aucun"],
        },
      ]);
      setIsLoading(false);
    }, 300);
  }, []);

  const handleRaceSelect = (race: any) => {
    setSelectedRaceData(race);
    onCharDataChange({ ...charData, raceId: race.id });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Sélectionnez une race pour votre personnage
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {races.map((race: any) => (
              <div
                key={race.id}
                onClick={() => handleRaceSelect(race)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  charData.raceId === race.id
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <h3 className="font-bold mb-2">{race.name}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {race.description}
                </p>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-1">
          <div className="sticky top-4">
            <EncyclopediaPanel
              title={selectedRaceData?.name}
              description={selectedRaceData?.description}
              bonus={selectedRaceData?.bonus}
              prerequisites={selectedRaceData?.prerequisites}
              type="race"
              isLoading={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
