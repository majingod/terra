import { trpc } from "@/lib/trpc";
import { BookOpen, ChevronRight, Loader2, Skull } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

export default function Competences() {
  const { data: competences, isLoading: loadingComp } = trpc.rules.competences.useQuery();
  const [search, setSearch] = useState("");

  const filteredComp = competences?.filter(
    (c) => c.name.toLowerCase().includes(search.toLowerCase()) || c.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Compétences", active: true },
      ]} />
      <div className="container max-w-5xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <BookOpen className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Compétences
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-foreground/70 max-w-2xl mx-auto mt-4">
            Les compétences représentent votre expertise dans différents domaines. Chaque compétence offre des avantages de base et avancés.
          </p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Rechercher une compétence..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 rounded-lg text-sm bg-secondary/30 border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-border"
          />
        </div>

        {/* Competences */}
        {loadingComp ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
          </div>
        ) : (
          <div className="space-y-4">
            {filteredComp?.map((comp) => (
              <div
                key={comp.id}
                className="p-5 rounded-xl border border-border/40 bg-card/30 hover:border-border/70 transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-heading font-semibold text-lg" style={{ color: "oklch(0.82 0.2 85)" }}>
                    {comp.name}
                  </h3>
                  <div className="flex gap-2">
                    {comp.category && (
                      <span
                        className="text-xs px-2 py-1 rounded font-heading"
                        style={{ background: "oklch(0.65 0.18 45 / 0.15)", color: "oklch(0.75 0.15 85)", border: "1px solid oklch(0.65 0.18 45 / 0.3)" }}
                      >
                        {comp.category as string}
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-foreground/80 leading-relaxed">{comp.description}</p>
                {comp.baseAdvantage && (
                  <div
                    className="mt-3 p-3 rounded-lg text-sm"
                    style={{ background: "oklch(0.55 0.18 240 / 0.1)", border: "1px solid oklch(0.55 0.18 240 / 0.2)" }}
                  >
                    <span className="font-heading font-semibold text-xs" style={{ color: "oklch(0.65 0.2 240)" }}>Avantage de base : </span>
                    <span className="text-foreground/75">{comp.baseAdvantage}</span>
                  </div>
                )}
                {comp.advancedAdvantage && (
                  <div
                    className="mt-2 p-3 rounded-lg text-sm"
                    style={{ background: "oklch(0.45 0.15 140 / 0.1)", border: "1px solid oklch(0.45 0.15 140 / 0.2)" }}
                  >
                    <span className="font-heading font-semibold text-xs" style={{ color: "oklch(0.65 0.2 140)" }}>Avantage avancé : </span>
                    <span className="text-foreground/75">{comp.advancedAdvantage}</span>
                  </div>
                )}
              </div>
            ))}
            {filteredComp?.length === 0 && (
              <p className="text-center text-muted-foreground py-8">Aucune compétence trouvée.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
