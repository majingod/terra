import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, RotateCcw, Trash2, Calendar, User } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState } from "react";
import { toast } from "sonner";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AdminEncyclopediaHistory() {
  const { user } = useAuth();
  const [filterUser, setFilterUser] = useState<string>("");
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [filterStartDate, setFilterStartDate] = useState<string>("");
  const [filterEndDate, setFilterEndDate] = useState<string>("");

  // Récupérer l'historique des modifications
  const { data: history, isLoading: loadingHistory } =
    trpc.encyclopediaHistory.getRecentChanges.useQuery(
      { limit: 100 },
      { enabled: !!user?.id }
    );

  // Mutation pour restaurer une version
  const restoreMutation = trpc.encyclopediaHistory.restoreVersion.useMutation({
    onSuccess: () => {
      toast.success("Version restaurée avec succès");
      trpc.useUtils().encyclopediaHistory.getRecentChanges.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de la restauration");
    },
  });

  if (!user || user.role !== "admin") {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Accès réservé aux administrateurs.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      races: "Races",
      classes: "Classes",
      dons: "Dons",
      competences: "Compétences",
      heritage: "Héritages",
      desavantages: "Désavantages",
      voies: "Voies",
      capacites: "Capacités",
    };
    return labels[category] || category;
  };

  const getActionBadgeVariant = (action: string) => {
    switch (action) {
      case "create":
        return "default";
      case "update":
        return "secondary";
      case "delete":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getActionLabel = (action: string) => {
    switch (action) {
      case "create":
        return "Créé";
      case "update":
        return "Modifié";
      case "delete":
        return "Supprimé";
      default:
        return action;
    }
  };

  // Filtrer l'historique
  const filteredHistory = history?.filter((entry: any) => {
    if (filterUser && entry.userId !== parseInt(filterUser)) return false;
    if (filterCategory && entry.category !== filterCategory) return false;
    if (filterStartDate && new Date(entry.createdAt) < new Date(filterStartDate))
      return false;
    if (filterEndDate && new Date(entry.createdAt) > new Date(filterEndDate))
      return false;
    return true;
  });

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Historique de l'Encyclopédie</h1>
        <p className="text-muted-foreground">
          Consultez et restaurez les versions précédentes des entrées d'Encyclopédie
        </p>
      </div>

      {/* Filtres */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Filtres</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Catégorie</label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les catégories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Toutes les catégories</SelectItem>
                  <SelectItem value="races">Races</SelectItem>
                  <SelectItem value="classes">Classes</SelectItem>
                  <SelectItem value="dons">Dons</SelectItem>
                  <SelectItem value="competences">Compétences</SelectItem>
                  <SelectItem value="heritage">Héritages</SelectItem>
                  <SelectItem value="desavantages">Désavantages</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">
                Date de début
              </label>
              <Input
                type="date"
                value={filterStartDate}
                onChange={(e) => setFilterStartDate(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">
                Date de fin
              </label>
              <Input
                type="date"
                value={filterEndDate}
                onChange={(e) => setFilterEndDate(e.target.value)}
              />
            </div>

            <div className="flex items-end">
              <Button
                variant="outline"
                onClick={() => {
                  setFilterUser("");
                  setFilterCategory("");
                  setFilterStartDate("");
                  setFilterEndDate("");
                }}
              >
                Réinitialiser
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Historique */}
      <div className="space-y-4">
        {loadingHistory ? (
          <div className="text-center py-8">Chargement de l'historique...</div>
        ) : !filteredHistory || filteredHistory.length === 0 ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Aucune modification trouvée avec les filtres sélectionnés.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="grid gap-4">
            {filteredHistory.map((entry: any) => (
              <Card key={entry.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={getActionBadgeVariant(entry.action)}>
                          {getActionLabel(entry.action)}
                        </Badge>
                        <Badge variant="outline">
                          {getCategoryLabel(entry.category)}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg">{entry.entryName}</CardTitle>
                      <CardDescription className="mt-2">
                        {entry.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>
                        {format(new Date(entry.createdAt), "PPP p", {
                          locale: fr,
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{entry.userName || "Utilisateur inconnu"}</span>
                    </div>
                  </div>

                  {entry.changeDetails && (
                    <div className="bg-muted p-3 rounded text-sm max-h-32 overflow-y-auto">
                      <p className="font-semibold mb-2">Détails des modifications:</p>
                      <pre className="text-xs whitespace-pre-wrap break-words">
                        {typeof entry.changeDetails === "string"
                          ? entry.changeDetails
                          : JSON.stringify(entry.changeDetails, null, 2)}
                      </pre>
                    </div>
                  )}

                  <div className="flex justify-end gap-2">
                    {entry.action !== "delete" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (
                            confirm(
                              "Êtes-vous sûr de vouloir restaurer cette version ?"
                            )
                          ) {
                            restoreMutation.mutate({
                              entryId: entry.entryId,
                              versionId: entry.id,
                            });
                          }
                        }}
                        disabled={restoreMutation.isPending}
                      >
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Restaurer
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
