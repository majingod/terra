#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/StepVoieEtDons.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Trouver la section du résumé et ajouter le bonus racial Humain
old_summary = '''        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className="text-xs text-muted-foreground">Nom</span>
            <p className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
              {data.name || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Faction</span>
            <p className="font-heading font-semibold" style={{ color: factionColor }}>
              {data.faction || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Race</span>
            <p className="font-heading font-semibold text-foreground">{race?.name ?? "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Classe</span>
            <p className="font-heading font-semibold text-foreground">{cls?.name ?? "—"}</p>
          </div>
        </div>'''

new_summary = '''        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className="text-xs text-muted-foreground">Nom</span>
            <p className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
              {data.name || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Faction</span>
            <p className="font-heading font-semibold" style={{ color: factionColor }}>
              {data.faction || "—"}
            </p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Race</span>
            <p className="font-heading font-semibold text-foreground">{race?.name ?? "—"}</p>
          </div>
          <div>
            <span className="text-xs text-muted-foreground">Classe</span>
            <p className="font-heading font-semibold text-foreground">{cls?.name ?? "—"}</p>
          </div>
          {race?.name === "Humain" && data.humanBonusType && (
            <div>
              <span className="text-xs text-muted-foreground">Bonus racial</span>
              <p className="font-heading font-semibold text-foreground">
                +1 {data.humanBonusType === 'pv' ? 'PV' : 'PM'}
              </p>
            </div>
          )}
        </div>'''

content = content.replace(old_summary, new_summary)
print("✓ Affichage du bonus racial Humain ajouté au résumé")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/StepVoieEtDons.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
