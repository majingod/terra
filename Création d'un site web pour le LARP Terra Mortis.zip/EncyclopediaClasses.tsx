import { useState } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Loader2, LinkIcon } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function EncyclopediaClasses() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const pageSize = 10;

  const { data: classesData, isLoading: isLoadingClasses } =
    trpc.encyclopedia.getPaginatedByCategory.useQuery(
      {
        category: "classe",
        limit: pageSize,
        offset: (page - 1) * pageSize,
      },
      { enabled: true }
    );

  const { data: selectedClassData, isLoading: isLoadingDetail } =
    trpc.encyclopedia.getById.useQuery(
      { id: selectedClass || 0 },
      { enabled: !!selectedClass }
    );

  const { data: relatedEntries } =
    trpc.encyclopediaRelations.getRelatedEntries.useQuery(
      { entryId: selectedClass || 0 },
      { enabled: !!selectedClass }
    );

  const classes = classesData?.items || [];
  const totalPages = Math.ceil((classesData?.total || 0) / pageSize);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Encyclopédie - Classes</h1>
          <p className="text-muted-foreground mt-2">
            Découvrez les classes disponibles et leurs capacités
          </p>
        </div>

        <div className="flex gap-2">
          <Input
            placeholder="Rechercher une classe..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="flex-1"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <h2 className="text-xl font-semibold">Classes ({classesData?.total || 0})</h2>

            {isLoadingClasses ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : classes.length === 0 ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>Aucune classe trouvée</AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-2">
                {classes.map((classe: any) => (
                  <button
                    key={classe.id}
                    onClick={() => setSelectedClass(classe.id)}
                    className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${
                      selectedClass === classe.id
                        ? "border-primary bg-primary/10"
                        : "border-transparent hover:bg-muted"
                    }`}
                  >
                    <div className="font-medium">{classe.nom}</div>
                    <div className="text-sm text-muted-foreground">
                      {(classe as any).factionRequise || "Tous"}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {totalPages > 1 && (
              <div className="flex gap-2 justify-center pt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                >
                  Précédent
                </Button>
                <span className="py-2 text-sm">
                  Page {page} / {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </div>

          <div className="lg:col-span-2">
            {!selectedClass ? (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-muted-foreground text-center py-8">
                    Sélectionnez une classe pour voir les détails
                  </p>
                </CardContent>
              </Card>
            ) : isLoadingDetail ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : selectedClassData ? (
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{selectedClassData.nom}</CardTitle>
                        <CardDescription>{selectedClassData.description}</CardDescription>
                      </div>
                      <Badge>{(selectedClassData as any).factionRequise || "Tous"}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedClassData.proprietes && (
                      <div>
                        <h3 className="font-semibold mb-2">Caractéristiques</h3>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries((selectedClassData.proprietes as Record<string, any>) || {}).map(
                            ([key, value]: [string, any]) => (
                              <div key={key} className="text-sm">
                                <span className="font-medium">{key}:</span>{" "}
                                <span className="text-muted-foreground" suppressHydrationWarning>
                                  {typeof value === "object"
                                    ? JSON.stringify(value)
                                    : String(value)}
                                </span>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {relatedEntries && relatedEntries.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <LinkIcon className="h-4 w-4" />
                        Entrées Liées
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {relatedEntries.map((entry: any) => (
                          <div
                            key={entry.id}
                            className="p-2 rounded border hover:bg-muted cursor-pointer transition-colors"
                            onClick={() => setSelectedClass(entry.id)}
                          >
                            <div className="font-medium text-sm">{entry.nom}</div>
                            <div className="text-xs text-muted-foreground">
                              {entry.categorie}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
