# Terra Mortis - TODO

## Phase 2 : Schéma DB et données de règles
- [x] Schéma DB : tables races, classes, capacités, dons, compétences, héritage, désavantages
- [x] Schéma DB : table personnages liés aux utilisateurs
- [x] Seed des données de règles (races, classes, capacités, dons, compétences)
- [x] Migration DB (pnpm db:push)

## Phase 3 : Backend tRPC
- [x] Router règles : lecture publique (races, classes, dons, compétences, héritage)
- [x] Router admin : CRUD complet pour les organisateurs
- [x] Router personnages : CRUD pour les joueurs
- [x] Calcul automatique des statistiques (PV, Mana, Lutte)
- [x] Tests vitest pour les routes critiques

## Phase 4 : Design global et pages publiques
- [x] Design system : couleurs médiéval-fantastique sombre, typographie, tokens CSS
- [x] Navigation principale (top nav public + sidebar connecté)
- [x] Page d'accueil (landing page Terra Mortis)
- [x] Page règles générales (conduite, combat, fouille, objets)
- [x] Page races avec filtres par faction
- [x] Page classes avec onglets par classe
- [x] Page dons
- [x] Page compétences et artisanats
- [x] Page héritage et désavantages
- [x] Page magie (règles de mana, signes, incantations)

## Phase 5 : Créateur de personnage step-by-step
- [x] Step 1 : Informations de base (nom, background)
- [x] Step 2 : Choix de faction (Sanctum / Légion)
- [x] Step 3 : Choix de race (filtré par faction)
- [x] Step 4 : Choix de classe (filtré par faction)
- [x] Step 5 : Distribution des caractéristiques (Puissance, Résistance, Esprit)
- [x] Step 6 : Choix de compétence
- [x] Step 7 : Héritage et XP (avantages, désavantages)
- [x] Step 8 : Résumé et confirmation
- [x] Calcul en temps réel des stats (PV, Mana, Lutte, Sauvegardes)
- [x] Affichage fiche personnage complète

## Phase 6 : Espace joueur et organisateur
- [x] Page profil joueur avec liste de personnages
- [x] Visualisation détaillée d'un personnage
- [x] Modification d'un personnage existant
- [x] Suppression d'un personnage
- [x] Interface organisateur : tableau de bord
- [x] Interface organisateur : édition des races
- [x] Interface organisateur : édition des classes et capacités
- [x] Interface organisateur : édition des dons
- [x] Interface organisateur : édition des compétences
- [x] Promotion d'un utilisateur au rôle organisateur (admin)

## Phase 7 : Finalisation
- [x] Tests vitest complets (11 tests passés)
- [x] Vérification TypeScript (0 erreur)
- [x] Checkpoint final


## Corrections demandées
- [x] Créer une page Dons.tsx dédiée aux dons
- [x] Modifier Competences.tsx pour afficher uniquement les compétences
- [x] Mettre à jour la navbar pour pointer vers /regles/dons

## Améliorations UI/UX
- [x] Remplacer le menu top-right par un sidebar collapsible à gauche avec icônes de navigation rapide
- [x] Ajouter des sections collapsibles dans le sidebar (Règles, Personnage, Admin)
- [x] Ajouter un drawer/modal pour le sidebar sur mobile (< 768px) avec bouton hamburger
- [x] Compléter Admin : page Classes avec CRUD complet
- [x] Compléter Admin : page Compétences avec CRUD complet
- [x] Compléter Admin : page Héritage avec CRUD complet
- [x] Compléter Admin : page Désavantages avec CRUD complet

## Nouvelles demandes
- [x] Créer une page d'accueil des règles (hub central)
- [x] Mettre à jour les boutons "Consulter les règles" et "Règles complètes" pour pointer vers cette page

## Demandes en cours
- [x] Transformer RulesHub en page d'introduction complète avec contenu du PDF
- [x] Ajuster les routes pour que /regles/introduction pointe vers /regles

## Demandes de style
- [x] Ajuster le style et format de RulesHub pour qu'il ressemble à Home

## Nouvelles fonctionnalités
- [x] Créer un composant Breadcrumbs réutilisable
- [x] Ajouter les breadcrumbs à toutes les pages de règles

## Sidebar
- [x] Ajouter "Introduction" comme sous-catégorie dans la section Règles du sidebar (lien vers /regles)

## Corrections page d'accueil
- [x] Séparer Races et Classes dans les cartes de factions (Sanctum et Légion) sur la page d'accueil

## Nouvelles fonctionnalités (phase 2)
- [x] Ajouter "Combat" dans la section Règles du sidebar après "Magie"
- [x] Corriger les factions des races en DB (Orc, Drow, Gobelin → Légion)
- [x] Créer le schéma DB pour les événements et inscriptions
- [x] Créer les routes tRPC pour les événements (CRUD organisateurs + inscription joueurs)
- [x] Créer la page publique des événements
- [x] Créer la page de détail d'un événement avec inscription
- [x] Créer la page admin de gestion des événements
- [x] Ajouter "Evénements" dans le sidebar

## Corrections demandées (phase 3)
- [x] Améliorer la visibilité du bouton login/logout (actuellement en bas du sidebar)
- [x] Ajouter un bouton login/logout visible en haut du sidebar ou dans le header

## Restructuration des classes (phase 4)
- [x] Restructurer le schéma DB pour les voies et niveaux de classes
- [x] Mettre à jour le backend et l'interface admin des classes
- [x] Mettre à jour la page de consultation des classes
- [x] Mettre à jour le créateur de personnage avec sélection de voie

## Corrections demandées (phase 5)
- [x] Créer une page Désavantages séparée de Héritage
- [x] Réorganiser le menu Règles
- [x] Faire d'Événements un lien direct
- [x] Ajouter les sous-catégories Admin

## Restructuration du Générateur de Personnage (phase 6)
- [ ] Mettre à jour le schéma DB pour XP temporaire/permanent
- [ ] Mettre à jour les queries DB et routes tRPC
- [ ] Réécrire le générateur avec 10 étapes
- [ ] Implémenter le système de XP
- [ ] Implémenter les dépendances entre étapes
- [ ] Tester le flux complet

## Système de calcul XP et validation des caractéristiques (phase 7)
- [x] Implémenter le calcul automatique des XP temporaires (désavantages)
- [x] Implémenter le calcul automatique des XP permanents (héritage)
- [x] Afficher le bilan XP en temps réel
- [x] Implémenter la validation stricte 3-2-1 des caractéristiques
- [x] Ajouter le feedback visuel pour les XP et caractéristiques
- [x] Créer les tests vitest pour valider les deux systèmes (23 tests)
- [x] Tous les tests passent (34/34 tests)

## Système de sélection de voie avec capacités bonus (phase 8)
- [x] Créer le composant StepVoie pour sélectionner la voie de classe
- [x] Afficher les capacités par niveau pour chaque voie
- [x] Implémenter le calcul automatique du nombre de dons (1 + Esprit + héritage)
- [x] Créer le composant StepDonsResume avec sélection des dons et résumé final
- [x] Afficher les stats finales (PV, Mana, Lutte, Sauvegardes) dans le résumé
- [x] Créer 22 tests vitest pour valider le calcul des dons et la sélection de voie
- [x] Tous les tests passent (56/56 tests au total)

## Modifications supplémentaires (phase 9)
- [x] Modifier StepDesavantages pour permettre 0 à 3 désavantages
- [x] Créer la mutation tRPC pour sauvegarder le personnage en BD (existait déjà)
- [x] Ajouter le bouton "Créer le personnage" à l'étape 10
- [x] Ajouter la validation stricte des étapes précédentes (validation 3-2-1)
- [ ] Afficher les capacités bonus des autres voies si héritage les débloque
- [x] Tous les tests passent (56/56 tests)

## Affichage des capacités bonus (phase 10)
- [x] Analyser le schéma DB pour comprendre la structure héritage/voies bonus
- [x] Créer les fonctions calcExtraAbilities, getBonusPathIds, getBonusAbilities
- [x] Ajouter une section "Capacités bonus" dans StepDonsResume
- [x] Afficher les capacités par niveau des voies bonus avec descriptions
- [x] Écrire et exécuter les tests vitest (15 tests, tous passent)
- [x] Tous les tests passent (71/71 tests au total)

## Sélection des capacités bonus (phase 11)
- [x] Ajouter selectedBonusAbilities dans CharData et schéma DB
- [x] Créer des fonctions de validation pour la sélection
- [x] Ajouter des checkboxes dans StepDonsResume
- [x] Implémenter la validation en temps réel (opacité, disabled state)
- [x] Modifier handleSubmit pour persister en BD
- [x] Écrire et exécuter les tests vitest (14 tests, tous passent)
- [x] Tous les tests passent (85/85 tests au total)

## Modifications page des Règles (phase 12)
- [x] Remplacer la présentation des factions par celle de la page d'accueil
- [x] Diviser "Héritage & Désavantages" en 2 cartes cliquables
- [x] Ajouter la navigation vers les pages Héritage et Désavantages
- [x] Tester les modifications (TypeScript OK, serveur OK)

## Formules de calcul et bonus racial Humain (phase 13)
- [x] Mettre à jour les formules de PV, Mana, Lutte et Sauvegardes sur la page Combat
- [x] Corriger les textes explicatifs associés aux formules
- [x] Ajouter le choix de bonus racial pour Humain dans la création
- [x] Intégrer le choix du bonus racial dans les calculs de PV/PM
- [x] Écrire et exécuter les tests vitest (11 tests, tous passent)
- [x] Tous les tests passent (96/96 tests au total)

## Modifications du créateur de personnage (phase 14)
- [x] Réinitialiser les caractéristiques à 0 et adapter validation 3-2-1
- [x] Identifier les héritages "+1 Capacité de niveau 1" et "+1 Capacité de niveau 2"
- [x] Rendre l'étape "Capacités bonus" conditionnelle selon héritages achetés
- [x] Implémenter sélection des capacités bonus de niveau 1
- [x] Implémenter sélection des capacités bonus de niveau 2
- [x] Écrire et exécuter les tests vitest (11 tests, tous passent)
- [x] Tous les tests passent (107/107 tests au total)

## Finalisations du créateur de personnage (phase 15)
- [x] Vérifier et améliorer le choix de bonus racial Humain
- [x] Créer la fonction de calcul automatique des stats finales (statsCalculator.ts)
- [x] Intégrer StepCapacitesBonus dans CreatePersonnage.tsx avec logique conditionnelle
- [x] Ajouter l'affichage des capacités bonus dans StepDonsResume (déjà implémenté)
- [x] Afficher le choix de bonus racial Humain dans le résumé pour confirmation
- [x] Écrire et exécuter les tests vitest (12 tests, tous passent)
- [x] Tous les tests passent (119/119 tests au total)

## Correction - Points de caractéristiques (phase 16)
- [x] Corriger le nombre de points à dépenser de 9 à 6
- [x] Vérifier la validation 3-2-1 (fonctionne correctement)
- [x] Tester et sauvegarder le checkpoint (tous les 119 tests passent)

## Interface de choix bonus racial Humain (phase 17)
- [x] Ajouter des boutons de choix pour le bonus racial Humain dans StepRace
- [x] Afficher les boutons seulement quand Humain est sélectionné
- [x] Sauvegarder le choix dans charData.humanBonusType
- [x] Tester et sauvegarder le checkpoint (tous les 119 tests passent)

## Rendre le choix de voie obligatoire (phase 18)
- [x] Changer le titre de "optionnel" à "obligatoire"
- [x] Supprimer l'option "Aucune voie spécifique"
- [x] Ajouter une validation pour forcer le choix d'une voie
- [x] Désactiver le bouton "Suivant" si aucune voie n'est choisie
- [x] Tester et sauvegarder le checkpoint (tous les 119 tests passent)

## Correction - Intégration StepCapacitesBonus (phase 19)
- [x] Vérifier l'intégration de StepCapacitesBonus dans CreatePersonnage.tsx
- [x] Corriger le stepContent pour afficher StepCapacitesBonus à l'étape 9
- [x] Vérifier la logique conditionnelle pour afficher l'étape uniquement si héritages achetés
- [x] Tester et sauvegarder le checkpoint


## Corrections demandées (phase 20)
- [x] Séparer l'étape Dons & Résumé en deux étapes distinctes
- [x] Créer l'étape 9 (Capacités bonus) avec interface de sélection
- [x] Créer l'étape 10 (Dons) avec sélection des dons
- [x] Créer l'étape 11 (Résumé final) avec affichage complet du personnage
- [x] Corriger le calcul des points de caractéristiques avec bonus héritage
- [x] Tester le flux complet avec différents héritages


## Améliorations interface capacités bonus (phase 21)
- [x] Analyser la structure actuelle de StepCapacitesBonus
- [x] Ajouter des descriptions détaillées pour chaque capacité bonus
- [x] Améliorer le formatage avec meilleure organisation par niveau
- [x] Ajouter des icônes visuelles pour chaque capacité
- [x] Implémenter feedback visuel (hover, disabled state, etc.)
- [x] Tester les améliorations en navigateur
- [x] Sauvegarder le checkpoint


## Correction - Étape 9 (Capacités bonus) doit afficher les voies NON sélectionnées (phase 22)
- [x] Analyser la structure des voies et capacités par classe
- [x] Récupérer les capacités des 2 voies NON sélectionnées
- [x] Mettre à jour StepCapacitesBonus pour afficher les bonnes capacités
- [x] Implémenter la sélection des capacités bonus supplémentaires
- [x] Tester le flux complet avec différentes classes et voies
- [x] Mettre à jour les héritages en base de données (IDs 8 et 9)
- [x] Sauvegarder le checkpoint


---

# PHASE 1 & 2 : ARCHITECTURE MODULAIRE AVEC ENCYCLOPÉDIE

## Phase 1 : Analyse et Planification de l'Architecture

- [x] Créer le diagramme ERD (Entity Relationship Diagram) complet
- [x] Documenter le flux de données entre modules
- [x] Identifier les données existantes à migrer
- [x] Planifier la stratégie de migration sans perte de données
- [x] Documenter les dépendances entre les modules
- [x] Créer le document d'architecture détaillée
- [x] Valider l'architecture avec les contraintes du projet

## Phase 2 : Refonte de la Base de Données

### 2.1 - Création des Nouvelles Tables

- [x] Créer la table `encyclopedie_entries` (table centrale)
- [x] Créer la table `events` (gestion d'événements)
- [x] Créer la table `event_inscriptions` (inscriptions aux événements)
- [x] Créer la table `xp_permanent_history` (historique d'XP)
- [x] Ajouter les colonnes manquantes aux tables existantes (users, personnages)
- [x] Créer les indices de performance
- [x] Écrire les migrations Drizzle

### 2.2 - Migration des Données Existantes

- [x] Créer le script de migration (migrate-to-encyclopedia.mjs)
- [ ] Migrer les races vers `encyclopedie_entries`
- [ ] Migrer les classes vers `encyclopedie_entries`
- [ ] Migrer les sous-classes vers `encyclopedie_entries`
- [ ] Migrer les capacités vers `encyclopedie_entries`
- [ ] Migrer les dons vers `encyclopedie_entries`
- [ ] Migrer les compétences vers `encyclopedie_entries`
- [ ] Migrer les héritages (avantages + désavantages) vers `encyclopedie_entries`
- [ ] Ajouter les nouvelles catégories : ressources, matériaux, runes, recettes, règles de combat, symboles

### 2.3 - Structuration des Données JSON

- [ ] Définir le schéma JSON pour les propriétés de chaque catégorie
- [ ] Définir le schéma JSON pour les relations entre entrées
- [ ] Définir le schéma JSON pour les conditions (prérequis)
- [ ] Créer les scripts de transformation des données

### 2.4 - Validation et Tests

- [ ] Tester l'intégrité des données migrées
- [ ] Vérifier les références croisées
- [ ] Valider les contraintes de faction/race/classe
- [ ] Tester la performance des requêtes
- [ ] Créer les seeds de données pour le développement

### 2.5 - Procédures tRPC de Base

- [x] Préparer l'infrastructure pour les procédures tRPC
- [x] Créer `encyclopedia.getAll()`
- [x] Créer `encyclopedia.getByCategory(category)`
- [x] Créer `encyclopedia.getById(id)`
- [x] Créer `encyclopedia.search(query)`
- [x] Créer `encyclopedia.getRelated(id)`
- [x] Créer `encyclopedia.getByFaction(faction)`
- [x] Créer `encyclopedia.getStats()`

### 2.6 - Documentation

- [x] Documenter le schéma de la base de données (ARCHITECTURE_ERD.md)
- [x] Documenter l'architecture détaillée (ARCHITECTURE_DETAILLEE.md)
- [x] Créer un guide de migration (migrate-to-encyclopedia.mjs)
- [ ] Documenter les procédures tRPC
- [ ] Créer des exemples de requêtes

---

## Phase 3 : Transformation de la Section Règles en Encyclopédie Interactive

### 3.1 - Interface de Recherche et Filtres

- [x] Créer la page d'Encyclopédie détaillée (EncyclopediaDetail.tsx)
- [x] Implémenter la recherche globale
- [x] Ajouter les filtres par catégorie
- [x] Ajouter les filtres par faction
- [x] Ajouter la route /encyclopedie/:categorie
- [x] Mettre à jour RulesHub.tsx pour utiliser la nouvelle Encyclopédie
- [x] Écrire les tests vitest pour EncyclopediaDetail

### 3.2 - Pages Détaillées par Catégorie

- [x] Créer une page générique EncyclopediaCategory.tsx
- [x] Ajouter les routes dans App.tsx
- [x] Affichage des entrées par catégorie avec pagination
- [x] Affichage des informations de faction

### 3.3 - Système de Relations

- [x] Implémenter les relations entre entrées (prérequis, incompatible, débloque)
- [x] Afficher les entrées liées
- [x] Créer un système de navigation entre entrées liées
- [x] Créer 7 procédures tRPC pour les relations

### 3.4 - Performance et Optimisation

- [x] Implémenter la pagination (5 procédures tRPC)
- [x] Créer encyclopedia-pagination.ts
- [x] Ajouter getPaginated, getPaginatedByCategory, searchPaginated, getCategoryCounts, getRecentEntries
- [x] Tous les 152 tests passent

### 3.5 - Historique des Modifications

- [x] Table encyclopediaHistory existe déjà dans le schéma
- [x] Implémenter les procédures tRPC pour l'historique (encyclopedia-history.ts)
- [x] Ajouter les fonctions : getEntryHistory, getRecentChanges, getChangesByUser, recordChange, restoreVersion, getChangeStats
- [x] Créer une interface pour visualiser l'historique (EncyclopediaHistory.tsx)


---

## Phase 6 : Système d'Événements et Gestion d'XP Permanent

### 6.1 - Pages de Gestion d'Événements

- [x] Créer la page ListEvenements.tsx pour afficher tous les événements
- [x] Implémenter les filtres (statut, faction, date)
- [x] Créer la page EvenementDetail.tsx pour afficher les détails d'un événement
- [x] Implémenter le système d'inscription aux événements
- [x] Créer la page MesInscriptions.tsx pour voir les inscriptions du joueur
- [ ] Afficher l'historique des événements auxquels le joueur a participé

### 6.2 - Gestion d'XP Permanent

- [x] Créer la page XPPermanent.tsx pour afficher l'XP permanent du joueur
- [x] Implémenter l'historique d'XP (qui a gagné quand, combien, pour quel événement)
- [x] Créer le système de partage d'XP entre personnages (xp-sharing.ts)
- [x] Ajouter les procédures tRPC pour récupérer et mettre à jour l'XP permanent
- [x] Implémenter la validation des limites d'XP par niveau

### 6.3 - Interface Organisateur

- [x] Créer la page AdminEvenements.tsx pour gérer les événements
- [x] Implémenter le CRUD complet des événements (créer, modifier, supprimer)
- [x] Ajouter la gestion des inscriptions (approuver, rejeter, annuler)
- [x] Créer l'interface d'attribution d'XP aux joueurs (mutation réelle liée à l'inscription)
- [ ] Implémenter le système de notifications pour les inscriptions

### 6.4 - Design Terra Mortis

- [x] Appliquer TerraMortisCard aux cartes d'événements
- [x] Appliquer TerraMortisHeading aux titres d'événements
- [x] Ajouter FactionBadge pour les événements faction-spécifiques
- [ ] Implémenter les animations de transition pour les pages d'événements
- [ ] Ajouter les effets de glow pour les événements actifs

### 6.5 - Tests et Validation

- [ ] Écrire les tests vitest pour les procédures tRPC d'événements
- [ ] Tester le flux complet d'inscription et d'XP
- [ ] Valider la propagation d'XP entre personnages
- [ ] Tester les limites d'XP par niveau
- [x] Tous les 119 tests passent


## Mutations tRPC pour AdminEncyclopedia (Phase 23)

- [x] Ajouter la procédure tRPC `admin.races.create` pour créer une race
- [x] Ajouter la procédure tRPC `admin.races.update` pour mettre à jour une race
- [x] Ajouter la procédure tRPC `admin.races.delete` pour supprimer une race
- [x] Ajouter les procédures tRPC pour classes (create, update, delete)
- [x] Ajouter les procédures tRPC pour dons (create, update, delete)
- [x] Ajouter les procédures tRPC pour compétences (create, update, delete)
- [x] Connecter AdminEncyclopedia aux mutations tRPC
- [x] Tester les mutations avec vitest (12 nouveaux tests)
- [x] Tous les 131 tests passent


## Mutations tRPC pour Héritages et Désavantages (Phase 24)

- [x] Analyser les mutations tRPC existantes pour héritages et désavantages
- [x] Implémenter createHeritageAvantage, updateHeritageAvantage, deleteHeritageAvantage
- [x] Implémenter createDesavantage, updateDesavantage, deleteDesavantage
- [x] Connecter AdminEncyclopedia aux mutations tRPC pour héritages
- [x] Connecter AdminEncyclopedia aux mutations tRPC pour désavantages
- [x] Écrire les tests vitest pour les mutations (18 nouveaux tests)
- [x] Tous les 137 tests passent


## Validation Avancée des Prérequis (Phase 25)

- [x] Analyser la structure actuelle des prérequis et des contraintes
- [x] Créer un système de validation des prérequis côté serveur (tRPC)
- [x] Implémenter les validateurs pour dons (classe, race, niveau)
- [x] Implémenter les validateurs pour compétences (classe, race, niveau)
- [x] Implémenter les validateurs pour héritages (classe, race, niveau)
- [x] Ajouter les validations côté client dans le générateur de personnage
- [x] Implémenter les messages d'erreur détaillés pour les prérequis non respectés
- [x] Écrire les tests vitest pour les validations (15 nouveaux tests)
- [x] Tous les 152 tests passent


## Intégration Client-Side des Validations (Phase 26)

- [x] Analyser le générateur de personnage et identifier les points d'intégration
- [x] Créer un hook React useValidateDon pour les validations tRPC
- [x] Créer un hook React useValidateCompetence pour les validations tRPC
- [x] Créer un hook React useValidateHeritage pour les validations tRPC
- [x] Créer un hook React useValidateDesavantage pour les validations tRPC
- [x] Intégrer les validations dans le sélecteur de dons (StepDons.tsx)
- [x] Intégrer les validations dans le sélecteur de compétences (StepCompetences.tsx)
- [x] Intégrer les validations dans le sélecteur d'héritages (StepHeritage.tsx)
- [x] Implémenter l'affichage des toasts pour les erreurs (via sonner)
- [x] Implémenter l'affichage des messages d'erreur inline avec AlertCircle
- [x] Tous les 152 tests passent
- [x] Aucune erreur TypeScript


## Migration des Données Existantes (Phase 27)

- [x] Créer le script de migration (migrate-to-encyclopedia.mjs)
- [x] Créer le script de migration côté serveur (migrate-encyclopedia.ts)
- [x] Ajouter la procédure tRPC migration.runMigration
- [x] Migrer les races vers encyclopedie_entries
- [x] Migrer les classes vers encyclopedie_entries
- [x] Migrer les voies de classe vers encyclopedie_entries
- [x] Migrer les capacités de classe vers encyclopedie_entries
- [x] Migrer les dons vers encyclopedie_entries
- [x] Migrer les compétences vers encyclopedie_entries
- [x] Migrer les héritages (avantages + désavantages) vers encyclopedie_entries
- [x] Ajouter les nouvelles catégories : ressources, matériaux, runes, recettes, forge, objets_magiques, regles_combat, symboles, langues, armures, caracteristiques, factions
- [x] Tous les 152 tests passent
- [x] Aucune erreur TypeScript

## Phase 28 - Intégration des Événements (Finale)

- [x] Vérifier les procédures tRPC existantes pour les événements
- [x] Intégrer eventsRouter dans appRouter de manière stable (déjà existant)
- [x] Créer la page MesInscriptions.tsx avec interface utilisateur
- [x] Tester les procédures avec vitest

## Phase 29 - AdminEncyclopediaHistory

- [ ] Créer la page AdminEncyclopediaHistory.tsx (en attente de procédures tRPC)
- [ ] Ajouter les filtres par utilisateur/date
- [ ] Implémenter les options de restauration de versions
- [ ] Ajouter la route dans App.tsx

## Phase 30 - Gestion d'XP pour Organisateurs

- [x] Créer la page AdminXPManagement.tsx
- [x] Implémenter l'interface d'attribution d'XP
- [x] Ajouter le système de notifications
- [x] Ajouter la route dans App.tsx

## Finalisation

- [x] Exécuter tous les tests vitest (152 tests passent)
- [x] Vérifier qu'il n'y a pas d'erreurs TypeScript (0 erreurs)
- [ ] Créer le checkpoint final
- [ ] Préparer pour la publication


## Phase 32 - Refondre le modèle de données (Comptes familiaux)

- [ ] Créer table `Family` (id, name, createdBy, createdAt, updatedAt)
- [ ] Créer table `FamilyProfile` (id, familyId, name, role, xpPermanent, isChild, createdAt)
- [ ] Créer table `FamilySession` (id, familyId, activeProfileId, userId, createdAt)
- [ ] Migrer `personnages.userId` → `personnages.profileId`
- [ ] Ajouter check : enfants ne peuvent pas choisir artisanats
- [ ] Écrire tests vitest pour les migrations
- [ ] Tester les migrations en staging

## Phase 33 - Refondre le builder UI

- [ ] Créer wizard moderne avec stepper visible
- [ ] Ajouter validation temps réel
- [ ] Ajouter panneau résumé latéral persistant
- [ ] Ajouter infobulles sur les termes de règles
- [ ] Ajouter mode "Build assisté"
- [ ] Tester le builder avec les 8 étapes

## Phase 34 - Ajouter export PDF + notifications email

- [ ] Configurer SendGrid ou Mailjet
- [ ] Implémenter export PDF (fiche imprimable)
- [ ] Implémenter notifications email post-GN
- [ ] Tester export PDF sur mobile et desktop
- [ ] Tester notifications email

## Phase 35 - Ajouter écran gestion famille + journal personnage

- [ ] Créer écran "Gestion de famille"
- [ ] Ajouter bouton "Ajouter un enfant"
- [ ] Ajouter bouton "Basculer vers ce profil"
- [ ] Créer journal de personnage
- [ ] Afficher historique XP + participations
- [ ] Tester gestion famille

## Phase 36 - Tests exhaustifs + déploiement

- [ ] Exécuter tous les tests vitest
- [ ] Vérifier qu'il n'y a pas d'erreurs TypeScript
- [ ] Tester les migrations DB (forward + rollback)
- [ ] Tester le builder complet
- [ ] Tester export PDF
- [ ] Tester notifications email
- [ ] Tester gestion famille
- [ ] Créer checkpoint final
- [ ] Déployer en production


## Phase 37 - Migration vers Encyclopédie (Approche Simplifiée)

### 37.1 - Interface d'Administration pour Migration
- [x] Créer la page AdminEncyclopediaMigration.tsx
- [x] Afficher les statistiques : données dans tables existantes vs encyclopediaEntries
- [x] Ajouter boutons pour migrer par catégorie (races, classes, dons, etc.)
- [x] Afficher la progression de la migration
- [x] Ajouter la route /admin/migration-encyclopedie dans App.tsx

### 37.2 - Procédures tRPC pour Migration
- [x] Créer migration.getMigrationStatus() : compter les entrées dans chaque table
- [x] Créer migration.migrateRaces() : migrer les races
- [x] Créer migration.migrateClasses() : migrer les classes
- [x] Créer migration.migrateDons() : migrer les dons
- [x] Créer migration.migrateCompetences() : migrer les compétences
- [x] Créer migration.migrateHeritages() : migrer les héritages et désavantages
- [x] Créer migration.migrateDesavantages() : migrer les désavantages
- [x] Ajouter logging pour chaque migration

### 37.3 - Tests et Validation
- [x] Écrire les tests vitest pour chaque procédure de migration (9 tests)
- [x] Écrire les tests vitest pour la page AdminEncyclopediaMigration (6 tests)
- [x] Tester la migration sans perte de données
- [x] Valider les relations entre entrées après migration
- [x] Vérifier que les anciennes tables restent intactes
- [x] Tous les 175 tests passent

### 37.4 - Documentation
- [x] Documenter la stratégie de migration progressive
- [x] Ajouter des commentaires dans le code
- [x] Créer un guide pour les organisateurs (MIGRATION_GUIDE.md)



## MVP utilisable - Priorité de livraison

- [x] Auditer les parcours essentiels dans l'aperçu : accueil, règles/Encyclopédie, création de personnage, événements, inscriptions et espace organisateur
- [x] Finaliser l'interface organisateur d'attribution d'XP
- [x] Vérifier et corriger les routes et liens de navigation essentiels
- [x] Ajouter ou mettre à jour les tests MVP des parcours critiques (18 tests XP)
- [x] Exécuter la suite complète de tests et corriger les régressions (193 tests passants)
- [x] Vérifier l'état du serveur et l'aperçu final (serveur actif, TypeScript sans erreur)
- [x] Créer le checkpoint de livraison MVP (2299ec6b)

### Hors périmètre de cette livraison rapide

- [ ] Notifications avancées d'inscription
- [ ] Animations et effets visuels supplémentaires
- [ ] Refonte complète des rôles et permissions
- [ ] Déploiement en production
- [ ] Nettoyage ou suppression des tables legacy après migration

Ces tâches restent tracées pour une itération ultérieure et ne bloquent pas l'aperçu MVP.
