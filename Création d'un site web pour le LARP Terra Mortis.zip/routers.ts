import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { familyRouter } from "./family";
import { exportPdfRouter } from "./export-pdf";
import {
  createPersonnage,
  deletePersonnage,
  getAllClasses,
  getAllCompetences,
  getAllDesavantages,
  getAllDons,
  getAllHeritageAvantages,
  getAllPersonnages,
  getAllRaces,
  getAllUsers,
  getAbilitiesByClassId,
  getAbilitiesByPathId,
  getClassById,
  getClassWithPaths,
  getClassWithPathsAndAbilities,
  getPathsByClassId,
  getPersonnageById,
  getPersonnagesByUserId,
  getRaceById,
  updateAbility,
  updateClass,
  updateCompetence,
  updateDesavantage,
  updateDon,
  updateHeritageAvantage,
  updatePersonnage,
  updateRace,
  updateUserRole,
  createRace,
  deleteDon,
  deleteRace,
  getAllEvenements,
  getEvenementById,
  createEvenement,
  updateEvenement,
  deleteEvenement,
  getInscriptionsByEvenement,
  getInscriptionsByUser,
  getInscription,
  createInscription,
  updateInscription,
  deleteInscription,
  countInscriptions,
} from "./db";

// ─── Middleware organisateur/admin ────────────────────────────────────────────
const organizerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "organizer") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Accès réservé aux organisateurs." });
  }
  return next({ ctx });
});

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Accès réservé aux administrateurs." });
  }
  return next({ ctx });
});

// ─── Schémas Zod ──────────────────────────────────────────────────────────────
const PersonnageCreateSchema = z.object({
  name: z.string().min(1).max(150),
  background: z.string().optional(),
  faction: z.enum(["Sanctum", "Légion"]),
  raceId: z.number().int().positive(),
  classId: z.number().int().positive(),
  classPathId: z.number().int().positive().optional(),
  puissance: z.number().int().min(1).max(5),
  resistance: z.number().int().min(1).max(5),
  esprit: z.number().int().min(1).max(5),
  maxPv: z.number().int().positive(),
  maxMana: z.number().int().min(0),
  lutte: z.number().int().min(0),
  sauvegardes: z.number().int().min(0),
  competenceId: z.number().int().positive().optional(),
  selectedDons: z.array(z.number()).optional(),
  heritageAvantages: z.array(z.object({ id: z.number(), times: z.number() })).optional(),
  selectedDesavantages: z.array(z.number()).optional(),
  selectedBonusAbilities: z.array(z.number()).optional(),
  humanBonusType: z.enum(['pv', 'pm']).nullable().optional(),
  xpPermanent: z.number().int().min(0).default(0),
  xpTemporaire: z.number().int().min(0).default(0),
  startingMoney: z.object({ cuivre: z.number(), argent: z.number(), or: z.number() }).optional(),
  languages: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

export const appRouter = router({
  system: systemRouter,
  family: familyRouter,
  exportPdf: exportPdfRouter,

  // ─── Auth ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Règles publiques ──────────────────────────────────────────────────────
  rules: router({
    races: publicProcedure.query(() => getAllRaces()),
    raceById: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getRaceById(input.id)),
    classes: publicProcedure.query(() => getAllClasses()),
    classById: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getClassById(input.id)),
    classWithPaths: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getClassWithPaths(input.id)),
    classWithPathsAndAbilities: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getClassWithPathsAndAbilities(input.id)),
    pathsByClass: publicProcedure.input(z.object({ classId: z.number() })).query(({ input }) => getPathsByClassId(input.classId)),
    abilitiesByClass: publicProcedure.input(z.object({ classId: z.number() })).query(({ input }) => getAbilitiesByClassId(input.classId)),
    abilitiesByPath: publicProcedure.input(z.object({ pathId: z.number() })).query(({ input }) => getAbilitiesByPathId(input.pathId)),
    dons: publicProcedure.query(() => getAllDons()),
    competences: publicProcedure.query(() => getAllCompetences()),
    heritageAvantages: publicProcedure.query(() => getAllHeritageAvantages()),
    desavantages: publicProcedure.query(() => getAllDesavantages()),
    all: publicProcedure.query(async () => {
      const [racesList, classesList, donsList, competencesList, heritageList, desavantagesList] = await Promise.all([
        getAllRaces(),
        getAllClasses(),
        getAllDons(),
        getAllCompetences(),
        getAllHeritageAvantages(),
        getAllDesavantages(),
      ]);
      return { races: racesList, classes: classesList, dons: donsList, competences: competencesList, heritageAvantages: heritageList, desavantages: desavantagesList };
    }),
  }),

  // ─── Administration (organisateurs) ───────────────────────────────────────
  admin: router({
    // Races
    updateRace: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          faction: z.enum(["Sanctum", "Légion", "Tous"]).optional(),
          description: z.string().optional(),
          bonuses: z.array(z.string()).optional(),
          maluses: z.array(z.string()).optional(),
          abilities: z.array(z.object({ name: z.string(), description: z.string() })).optional(),
          physicalDescription: z.string().optional(),
          startingLanguages: z.array(z.string()).optional(),
          pvBonus: z.number().optional(),
          manaBonus: z.number().optional(),
          luteBonus: z.number().optional(),
          pvMalus: z.number().optional(),
        }),
      }))
      .mutation(({ input }) => updateRace(input.id, input.data as any)),

    createRace: organizerProcedure
      .input(z.object({
        name: z.string(),
        faction: z.enum(["Sanctum", "Légion", "Tous"]),
        description: z.string(),
        bonuses: z.array(z.string()),
        maluses: z.array(z.string()),
        abilities: z.array(z.object({ name: z.string(), description: z.string() })),
        physicalDescription: z.string(),
        startingLanguages: z.array(z.string()),
        pvBonus: z.number().default(0),
        manaBonus: z.number().default(0),
        luteBonus: z.number().default(0),
        pvMalus: z.number().default(0),
      }))
      .mutation(({ input }) => createRace(input as any)),

    deleteRace: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteRace(input.id)),

    // Classes
    updateClass: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          basePv: z.number().optional(),
          baseMana: z.number().optional(),
          baseAbilities: z.array(z.object({ name: z.string(), description: z.string() })).optional(),
          specialRules: z.array(z.string()).optional(),
          code: z.array(z.string()).nullable().optional(),
        }),
      }))
      .mutation(({ input }) => updateClass(input.id, input.data as any)),

    createClass: organizerProcedure
      .input(z.object({
        name: z.string(),
        faction: z.enum(["Sanctum", "Legion", "Tous"]),
        description: z.string(),
        basePv: z.number(),
        baseMana: z.number(),
        baseAbilities: z.array(z.object({ name: z.string(), description: z.string() })),
        specialRules: z.array(z.string()),
        requiresWeapon: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { classes } = await import("../drizzle/schema");
        const db = await getDb();
        if (!db) return;
        await db.insert(classes).values(input as any);
      }),

    deleteClass: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { classes } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return;
        await db.delete(classes).where(eq(classes.id, input.id));
      }),

    // Abilities
    updateAbility: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          manaCost: z.number().optional(),
          pvCost: z.number().optional(),
          usesPerHour: z.number().nullable().optional(),
          isBuff: z.boolean().optional(),
          isSign: z.boolean().optional(),
          isIncantation: z.boolean().optional(),
        }),
      }))
      .mutation(({ input }) => updateAbility(input.id, input.data as any)),

    // Dons
    updateDon: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          canStack: z.boolean().optional(),
          maxStacks: z.number().optional(),
          pvBonus: z.number().optional(),
          manaBonus: z.number().optional(),
          luteBonus: z.number().optional(),
        }),
      }))
      .mutation(({ input }) => updateDon(input.id, input.data as any)),

    createDon: organizerProcedure
      .input(z.object({
        name: z.string(),
        description: z.string(),
        canStack: z.boolean().default(false),
        maxStacks: z.number().default(1),
        pvBonus: z.number().default(0),
        manaBonus: z.number().default(0),
        luteBonus: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { dons } = await import("../drizzle/schema");
        const db = await getDb();
        if (!db) return;
        await db.insert(dons).values(input as any);
      }),

    deleteDon: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteDon(input.id)),

    // Competences
    updateCompetence: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          baseAdvantage: z.string().optional(),
          advancedAdvantage: z.string().nullable().optional(),
          requiredMaterial: z.string().nullable().optional(),
        }),
      }))
      .mutation(({ input }) => updateCompetence(input.id, input.data as any)),

    createCompetence: organizerProcedure
      .input(z.object({
        name: z.string(),
        category: z.enum(["simple", "artisanat"]),
        description: z.string(),
        baseAdvantage: z.string(),
        advancedAdvantage: z.string().optional(),
        requiredMaterial: z.string().optional(),
        isAdultOnly: z.boolean().default(false),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { competences } = await import("../drizzle/schema");
        const db = await getDb();
        if (!db) return;
        await db.insert(competences).values(input as any);
      }),

    deleteCompetence: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { competences } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return;
        await db.delete(competences).where(eq(competences.id, input.id));
      }),

    // Heritage
    updateHeritageAvantage: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          xpCost: z.number().optional(),
          maxTimes: z.number().optional(),
          pvBonus: z.number().optional(),
          manaBonus: z.number().optional(),
          luteBonus: z.number().optional(),
          moneyBonus: z.string().nullable().optional(),
        }),
      }))
      .mutation(({ input }) => updateHeritageAvantage(input.id, input.data as any)),

    createHeritage: organizerProcedure
      .input(z.object({
        name: z.string(),
        description: z.string(),
        xpCost: z.number(),
        maxTimes: z.number().default(1),
        pvBonus: z.number().default(0),
        manaBonus: z.number().default(0),
        luteBonus: z.number().default(0),
        moneyBonus: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { heritageAvantages } = await import("../drizzle/schema");
        const db = await getDb();
        if (!db) return;
        await db.insert(heritageAvantages).values(input as any);
      }),

    deleteHeritage: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { heritageAvantages } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return;
        await db.delete(heritageAvantages).where(eq(heritageAvantages.id, input.id));
      }),

    // Desavantages
    updateDesavantage: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          xpGain: z.number().optional(),
          forbiddenClasses: z.array(z.string()).nullable().optional(),
        }),
      }))
      .mutation(({ input }) => updateDesavantage(input.id, input.data as any)),

    createDesavantage: organizerProcedure
      .input(z.object({
        name: z.string(),
        description: z.string(),
        xpGain: z.number(),
        xpType: z.enum(["permanent", "temporaire"]),
        forbiddenClasses: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { desavantages } = await import("../drizzle/schema");
        const db = await getDb();
        if (!db) return;
        const { xpType, ...rest } = input;
        await db.insert(desavantages).values({ ...rest, xpType: xpType as any });
      }),

    deleteDesavantage: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { desavantages } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return;
        await db.delete(desavantages).where(eq(desavantages.id, input.id));
      }),

    // Gestion utilisateurs
    getAllUsers: adminProcedure.query(() => getAllUsers()),
    updateUserRole: adminProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["user", "admin", "organizer"]) }))
      .mutation(({ input }) => updateUserRole(input.userId, input.role)),

    // Vue d'ensemble des personnages
    getAllPersonnages: organizerProcedure.query(() => getAllPersonnages()),

    // Dashboard Organisateur - Evenements a venir
    dashboardGetUpcomingEvents: adminProcedure.query(async () => {
      const allEvents = await getAllEvenements();
      const now = new Date();
      const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      
      return allEvents
        .filter(e => e.status === "published" && 
                new Date(e.startDate) >= now && 
                new Date(e.startDate) <= thirtyDaysLater)
        .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
        .slice(0, 10);
    }),

    // Dashboard - Joueurs actifs
    dashboardGetActiveUsers: adminProcedure.query(async () => {
      const allUsers = await getAllUsers();
      return allUsers.slice(0, 10);
    }),

    // Dashboard - Evenements termines
    dashboardGetXPToDistribute: adminProcedure.query(async () => {
      const allEvents = await getAllEvenements();
      const now = new Date();
      
      return allEvents
        .filter(e => e.status === "completed" && 
                new Date(e.endDate) < now)
        .sort((a, b) => new Date(b.endDate).getTime() - new Date(a.endDate).getTime())
        .slice(0, 10);
    }),

    // Dashboard - Statistiques
    dashboardGetStats: adminProcedure.query(async () => {
      const allEvents = await getAllEvenements();
      const allUsers = await getAllUsers();
      
      return {
        totalEvents: allEvents.filter(e => e.status === "published").length,
        totalUsers: allUsers.length,
        totalInscriptions: 0,
        totalXPDistributed: 0,
      };
    }),

  }),

  // ─── Personnages (joueurs) ─────────────────────────────────────────────────
  personnages: router({
    myPersonnages: protectedProcedure.query(({ ctx }) => getPersonnagesByUserId(ctx.user.id)),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const p = await getPersonnageById(input.id);
        if (!p) throw new TRPCError({ code: "NOT_FOUND" });
        if (p.userId !== ctx.user.id && ctx.user.role !== "admin" && ctx.user.role !== "organizer") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return p;
      }),

    create: protectedProcedure
      .input(PersonnageCreateSchema)
      .mutation(async ({ input, ctx }) => {
        await createPersonnage({ ...input, userId: ctx.user.id } as any);
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: PersonnageCreateSchema.partial() }))
      .mutation(async ({ input, ctx }) => {
        const p = await getPersonnageById(input.id);
        if (!p) throw new TRPCError({ code: "NOT_FOUND" });
        if (p.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updatePersonnage(input.id, input.data as any);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const p = await getPersonnageById(input.id);
        if (!p) throw new TRPCError({ code: "NOT_FOUND" });
        if (p.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await deletePersonnage(input.id);
        return { success: true };
      }),
  }),

  // ─── Événements ─────────────────────────────────────────────────────────────
  evenements: router({
    // Liste publique des événements publiés
    list: publicProcedure.query(() => getAllEvenements(false)),

    // Liste admin (tous les événements)
    listAll: organizerProcedure.query(() => getAllEvenements(true)),

    // Détail d'un événement
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const evt = await getEvenementById(input.id);
        if (!evt) throw new TRPCError({ code: "NOT_FOUND" });
        const count = await countInscriptions(input.id);
        return { ...evt, inscriptionCount: count };
      }),

    // Créer un événement (organisateur)
    create: organizerProcedure
      .input(z.object({
        title: z.string().min(1).max(200),
        description: z.string().min(1),
        location: z.string().min(1).max(300),
        startDate: z.string(),
        endDate: z.string(),
        maxPlayers: z.number().int().min(0).default(0),
        status: z.enum(["draft", "published", "cancelled", "completed"]).default("draft"),
        faction: z.enum(["Sanctum", "Légion", "Tous"]).default("Tous"),
        price: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await createEvenement({
          ...input,
          startDate: new Date(input.startDate),
          endDate: new Date(input.endDate),
          createdBy: ctx.user.id,
        });
        return { success: true };
      }),

    // Modifier un événement (organisateur)
    update: organizerProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().min(1).max(200).optional(),
          description: z.string().min(1).optional(),
          location: z.string().min(1).max(300).optional(),
          startDate: z.string().optional(),
          endDate: z.string().optional(),
          maxPlayers: z.number().int().min(0).optional(),
          status: z.enum(["draft", "published", "cancelled", "completed"]).optional(),
          faction: z.enum(["Sanctum", "Légion", "Tous"]).optional(),
          price: z.string().optional(),
          notes: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        const updateData: Record<string, unknown> = { ...input.data };
        if (input.data.startDate) updateData.startDate = new Date(input.data.startDate);
        if (input.data.endDate) updateData.endDate = new Date(input.data.endDate);
        await updateEvenement(input.id, updateData as any);
        return { success: true };
      }),

    // Supprimer un événement (organisateur)
    delete: organizerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteEvenement(input.id);
        return { success: true };
      }),

    // Inscriptions d'un événement (organisateur)
    inscriptions: organizerProcedure
      .input(z.object({ evenementId: z.number() }))
      .query(({ input }) => getInscriptionsByEvenement(input.evenementId)),

    // Confirmer/annuler une inscription (organisateur)
    updateInscription: organizerProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "cancelled"]),
      }))
      .mutation(async ({ input }) => {
        await updateInscription(input.id, { status: input.status });
        return { success: true };
      }),
  }),

  // ─── Inscriptions (joueurs) ────────────────────────────────────────────────
  inscriptions: router({
    // Mes inscriptions
    mine: protectedProcedure.query(({ ctx }) => getInscriptionsByUser(ctx.user.id)),

    // Vérifier si inscrit à un événement
    check: protectedProcedure
      .input(z.object({ evenementId: z.number() }))
      .query(({ input, ctx }) => getInscription(input.evenementId, ctx.user.id)),

    // S'inscrire à un événement
    register: protectedProcedure
      .input(z.object({
        evenementId: z.number(),
        personnageId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Vérifier si déjà inscrit
        const existing = await getInscription(input.evenementId, ctx.user.id);
        if (existing && existing.status !== "cancelled") {
          throw new TRPCError({ code: "CONFLICT", message: "Vous êtes déjà inscrit à cet événement." });
        }
        // Vérifier si l'événement existe et est publié
        const evt = await getEvenementById(input.evenementId);
        if (!evt || evt.status !== "published") {
          throw new TRPCError({ code: "NOT_FOUND", message: "Événement non disponible." });
        }
        // Vérifier la capacité
        if (evt.maxPlayers > 0) {
          const count = await countInscriptions(input.evenementId);
          if (count >= evt.maxPlayers) {
            throw new TRPCError({ code: "PRECONDITION_FAILED", message: "L'événement est complet." });
          }
        }
        if (existing && existing.status === "cancelled") {
          await updateInscription(existing.id, { status: "confirmed", personnageId: input.personnageId ?? null, notes: input.notes ?? null });
        } else {
          await createInscription({
            evenementId: input.evenementId,
            userId: ctx.user.id,
            personnageId: input.personnageId ?? null,
            status: "confirmed",
            notes: input.notes ?? null,
          });
        }
        return { success: true };
      }),

    // Se désinscrire
    cancel: protectedProcedure
      .input(z.object({ evenementId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const existing = await getInscription(input.evenementId, ctx.user.id);
        if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
        await updateInscription(existing.id, { status: "cancelled" });
        return { success: true };
      }),
  }),

  // Validation des prérequis
  validation: router({
    validateDon: protectedProcedure
      .input(z.object({
        donId: z.number(),
        raceId: z.number().optional(),
        classId: z.number().optional(),
        level: z.number().optional(),
        selectedDons: z.array(z.number()).optional(),
      }))
      .query(async ({ input }) => {
        const { validateDon } = await import("./prerequisite-validation");
        return validateDon(input.donId, {
          raceId: input.raceId,
          classId: input.classId,
          level: input.level,
          selectedDons: input.selectedDons,
        });
      }),

    validateCompetence: protectedProcedure
      .input(z.object({
        competenceId: z.number(),
        raceId: z.number().optional(),
        classId: z.number().optional(),
        level: z.number().optional(),
        selectedCompetences: z.array(z.number()).optional(),
      }))
      .query(async ({ input }) => {
        const { validateCompetence } = await import("./prerequisite-validation");
        return validateCompetence(input.competenceId, {
          raceId: input.raceId,
          classId: input.classId,
          level: input.level,
          selectedCompetences: input.selectedCompetences,
        });
      }),

    validateHeritage: protectedProcedure
      .input(z.object({
        heritageId: z.number(),
        raceId: z.number().optional(),
        classId: z.number().optional(),
        level: z.number().optional(),
        selectedHeritages: z.array(z.number()).optional(),
      }))
      .query(async ({ input }) => {
        const { validateHeritage } = await import("./prerequisite-validation");
        return validateHeritage(input.heritageId, {
          raceId: input.raceId,
          classId: input.classId,
          level: input.level,
          selectedHeritages: input.selectedHeritages,
        });
      }),

    validateDesavantage: protectedProcedure
      .input(z.object({
        desavantageId: z.number(),
        raceId: z.number().optional(),
        classId: z.number().optional(),
        level: z.number().optional(),
        selectedDesavantages: z.array(z.number()).optional(),
      }))
      .query(async ({ input }) => {
        const { validateDesavantage } = await import("./prerequisite-validation");
        return validateDesavantage(input.desavantageId, {
          raceId: input.raceId,
          classId: input.classId,
          level: input.level,
          selectedDesavantages: input.selectedDesavantages,
        });
      }),

    validateCompleteSelection: protectedProcedure
      .input(z.object({
        raceId: z.number().optional(),
        classId: z.number().optional(),
        level: z.number().optional(),
        faction: z.enum(["Sanctum", "Légion"]).optional(),
        selectedDons: z.array(z.number()).optional(),
        selectedCompetences: z.array(z.number()).optional(),
        selectedHeritages: z.array(z.number()).optional(),
        selectedDesavantages: z.array(z.number()).optional(),
      }))
      .query(async ({ input }) => {
        const { validateCompleteSelection } = await import("./prerequisite-validation");
        return validateCompleteSelection(input);
      }),
  }),

  // Encyclopédie - Accès aux données centralisées
  encyclopedia: router({
    getAll: publicProcedure
      .input(z.object({
        limit: z.number().int().positive().default(100),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { getEncyclopediaAll } = await import("./encyclopedia-procedures");
        return getEncyclopediaAll(input.limit, input.offset);
      }),
    
    getByCategory: publicProcedure
      .input(z.object({
        category: z.string(),
        limit: z.number().int().positive().default(100),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { getEncyclopediaByCategory } = await import("./encyclopedia-procedures");
        return getEncyclopediaByCategory(input.category, input.limit, input.offset);
      }),
    
    getById: publicProcedure
      .input(z.object({
        id: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getEncyclopediaById } = await import("./encyclopedia-procedures");
        return getEncyclopediaById(input.id);
      }),
    
    search: publicProcedure
      .input(z.object({
        query: z.string().min(1),
        limit: z.number().int().positive().default(50),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { searchEncyclopedia } = await import("./encyclopedia-procedures");
        return searchEncyclopedia(input.query, input.limit, input.offset);
      }),
    
    getRelated: publicProcedure
      .input(z.object({
        id: z.number().int().positive(),
        relationTypes: z.array(z.string()).optional(),
      }))
      .query(async ({ input }) => {
        const { getEncyclopediaRelated } = await import("./encyclopedia-procedures");
        return getEncyclopediaRelated(input.id, input.relationTypes);
      }),
    
    getByFaction: publicProcedure
      .input(z.object({
        faction: z.string(),
        limit: z.number().int().positive().default(100),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { getEncyclopediaByFaction } = await import("./encyclopedia-procedures");
        return getEncyclopediaByFaction(input.faction, input.limit, input.offset);
      }),
    
    getStats: publicProcedure
      .query(async () => {
        const { getEncyclopediaStats } = await import("./encyclopedia-procedures");
        return getEncyclopediaStats();
      }),
    
    // Pagination et optimisation
    getPaginated: publicProcedure
      .input(z.object({
        limit: z.number().int().positive().max(100).default(20),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { getPaginatedEntries } = await import("./encyclopedia-pagination");
        return getPaginatedEntries(input);
      }),
    
    getPaginatedByCategory: publicProcedure
      .input(z.object({
        category: z.string().min(1),
        limit: z.number().int().positive().max(100).default(20),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { getPaginatedByCategory } = await import("./encyclopedia-pagination");
        return getPaginatedByCategory(input.category, { limit: input.limit, offset: input.offset });
      }),
    
    searchPaginated: publicProcedure
      .input(z.object({
        query: z.string().min(1),
        limit: z.number().int().positive().max(100).default(20),
        offset: z.number().int().nonnegative().default(0),
      }))
      .query(async ({ input }) => {
        const { searchPaginated } = await import("./encyclopedia-pagination");
        return searchPaginated(input.query, { limit: input.limit, offset: input.offset });
      }),
    
    getCategoryCounts: publicProcedure
      .query(async () => {
        const { getCategoryCounts } = await import("./encyclopedia-pagination");
        return getCategoryCounts();
      }),
    
    getRecentEntries: publicProcedure
      .input(z.object({
        limit: z.number().int().positive().max(100).default(10),
      }))
      .query(async ({ input }) => {
        const { getRecentEntries } = await import("./encyclopedia-pagination");
        return getRecentEntries(input.limit);
      }),
    
    // Historique des modifications
    history: router({
      getEntryHistory: publicProcedure
        .input(z.object({
          entryId: z.string().or(z.number()),
        }))
        .query(async ({ input }) => {
          const { getEntryHistory } = await import("./encyclopedia-history");
          const entryId = typeof input.entryId === "string" ? parseInt(input.entryId) : input.entryId;
          return getEntryHistory(entryId);
        }),
      
      getRecentChanges: publicProcedure
        .input(z.object({
          limit: z.number().int().positive().max(100).default(50),
        }))
        .query(async ({ input }) => {
          const { getRecentChanges } = await import("./encyclopedia-history");
          return getRecentChanges(input.limit);
        }),
      
      getChangesByUser: publicProcedure
        .input(z.object({
          userId: z.string().or(z.number()),
          limit: z.number().int().positive().max(100).default(50),
        }))
        .query(async ({ input }) => {
          const { getChangesByUser } = await import("./encyclopedia-history");
          const userId = typeof input.userId === "string" ? parseInt(input.userId) : input.userId;
          return getChangesByUser(userId, input.limit);
        }),
      
      getChangeStats: publicProcedure
        .input(z.object({
          days: z.number().int().positive().default(30),
        }))
        .query(async ({ input }) => {
          const { getChangeStats } = await import("./encyclopedia-history");
          return getChangeStats(input.days);
        }),
      
      recordChange: adminProcedure
        .input(z.object({
          entryId: z.number().int().positive(),
          action: z.enum(["create", "update", "delete"]),
          ancienContenu: z.any().optional(),
          nouveauContenu: z.any().optional(),
          raison: z.string().optional(),
        }))
        .mutation(async ({ input, ctx }) => {
          const { recordChange } = await import("./encyclopedia-history");
          return recordChange(
            input.entryId,
            input.action,
            input.ancienContenu,
            input.nouveauContenu,
            ctx.user?.id || 0,
            input.raison
          );
        }),
      
      restoreVersion: adminProcedure
        .input(z.object({
          historyId: z.number().int().positive(),
        }))
        .mutation(async ({ input, ctx }) => {
          const { restoreVersion } = await import("./encyclopedia-history");
          return restoreVersion(input.historyId, ctx.user?.id || 0);
        }),
    }),
  }),

  // Relations entre entrées d'Encyclopédie
  encyclopediaRelations: router({
    createRelation: adminProcedure
      .input(z.object({
        sourceId: z.number().int().positive(),
        cibleId: z.number().int().positive(),
        typeRelation: z.enum(["prerequis", "incompatible", "debloque", "liee"]),
      }))
      .mutation(async ({ input }) => {
        const { createRelation } = await import("./encyclopedia-relations");
        return createRelation(input.sourceId, input.cibleId, input.typeRelation);
      }),
    
    deleteRelation: adminProcedure
      .input(z.object({
        sourceId: z.number().int().positive(),
        cibleId: z.number().int().positive(),
        typeRelation: z.enum(["prerequis", "incompatible", "debloque", "liee"]),
      }))
      .mutation(async ({ input }) => {
        const { deleteRelation } = await import("./encyclopedia-relations");
        return deleteRelation(input.sourceId, input.cibleId, input.typeRelation);
      }),
    
    getPrerequisites: publicProcedure
      .input(z.object({
        entryId: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getPrerequisites } = await import("./encyclopedia-relations");
        return getPrerequisites(input.entryId);
      }),
    
    getIncompatibilities: publicProcedure
      .input(z.object({
        entryId: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getIncompatibilities } = await import("./encyclopedia-relations");
        return getIncompatibilities(input.entryId);
      }),
    
    getUnlocks: publicProcedure
      .input(z.object({
        entryId: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getUnlocks } = await import("./encyclopedia-relations");
        return getUnlocks(input.entryId);
      }),
    
    getRelatedEntries: publicProcedure
      .input(z.object({
        entryId: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getRelatedEntries } = await import("./encyclopedia-relations");
        return getRelatedEntries(input.entryId);
      }),
    
    validatePrerequisites: publicProcedure
      .input(z.object({
        entryId: z.number().int().positive(),
        selectedEntries: z.array(z.number().int().positive()),
      }))
      .query(async ({ input }) => {
        const { validatePrerequisites } = await import("./encyclopedia-relations");
        return validatePrerequisites(input.entryId, input.selectedEntries);
      }),
  }),

  // Migration des données
  xp: router({
    getFamilyProfileXP: protectedProcedure
      .input(z.object({
        profileId: z.number().int().positive(),
      }))
      .query(async ({ input }) => {
        const { getFamilyProfilePermanentXP } = await import("./xp-sharing");
        return getFamilyProfilePermanentXP(input.profileId);
      }),
    
    getUserCharacters: protectedProcedure
      .query(async ({ ctx }) => {
        const { getUserCharacters } = await import("./xp-sharing");
        return getUserCharacters(ctx.user?.id || 0);
      }),
    
    addFamilyProfileXP: adminProcedure
      .input(z.object({
        profileId: z.number().int().positive(),
        amount: z.number().int(),
        sourceType: z.string(),
        sourceId: z.number().int().optional(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { addFamilyProfilePermanentXP } = await import("./xp-sharing");
        return addFamilyProfilePermanentXP(
          input.profileId,
          ctx.user?.id || 0,
          input.amount,
          input.sourceType,
          input.sourceId,
          input.description,
          ctx.user?.id || 0
        );
      }),
    
    transferCharacterXP: protectedProcedure
      .input(z.object({
        fromCharacterId: z.number().int().positive(),
        toCharacterId: z.number().int().positive(),
        amount: z.number().int().positive(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { transferCharacterXP } = await import("./xp-sharing");
        return transferCharacterXP(
          input.fromCharacterId,
          input.toCharacterId,
          input.amount,
          ctx.user?.id || 0,
          input.reason
        );
      }),
    
    getUserXPHistory: protectedProcedure
      .input(z.object({
        limit: z.number().int().positive().max(100).default(50),
      }))
      .query(async ({ input, ctx }) => {
        const { getUserXPHistory } = await import("./xp-sharing");
        return getUserXPHistory(ctx.user?.id || 0, input.limit);
      }),
    
    validateXPLimits: publicProcedure
      .input(z.object({
        level: z.number().int().positive(),
        xpPermanent: z.number().int().nonnegative(),
      }))
      .query(async ({ input }) => {
        const { validateXPLimits } = await import("./xp-sharing");
        return validateXPLimits(input.level, input.xpPermanent);
      }),
    
    getFamilyProfileStats: protectedProcedure
      .input(z.object({
        profileId: z.number().int().positive(),
      }))
      .query(async ({ input, ctx }) => {
        const { getFamilyProfileXPStats } = await import("./xp-sharing");
        return getFamilyProfileXPStats(input.profileId, ctx.user?.id || 0);
      }),

    awardForInscription: organizerProcedure
      .input(z.object({
        inscriptionId: z.number().int().positive(),
        amount: z.number().int().positive().max(10000),
        reason: z.string().trim().max(255).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { awardXPForInscription } = await import("./xp-sharing");
        return awardXPForInscription(input.inscriptionId, input.amount, input.reason, ctx.user.id);
      }),
  }),

  migration: router({
    // Obtenir le statut de la migration
    getStatus: adminProcedure.query(async () => {
      const { getMigrationStatus } = await import("./migration");
      return getMigrationStatus();
    }),

    // Migrer les races
    migrateRaces: adminProcedure.mutation(async () => {
      const { migrateRaces } = await import("./migration");
      return migrateRaces();
    }),

    // Migrer les classes
    migrateClasses: adminProcedure.mutation(async () => {
      const { migrateClasses } = await import("./migration");
      return migrateClasses();
    }),

    // Migrer les dons
    migrateDons: adminProcedure.mutation(async () => {
      const { migrateDons } = await import("./migration");
      return migrateDons();
    }),

    // Migrer les compétences
    migrateCompetences: adminProcedure.mutation(async () => {
      const { migrateCompetences } = await import("./migration");
      return migrateCompetences();
    }),

    // Migrer les héritages
    migrateHeritages: adminProcedure.mutation(async () => {
      const { migrateHeritages } = await import("./migration");
      return migrateHeritages();
    }),

    // Migrer les désavantages
    migrateDesavantages: adminProcedure.mutation(async () => {
      const { migrateDesavantages } = await import("./migration");
      return migrateDesavantages();
    }),

    // Exécuter la migration complète (ancien système)
    runMigration: protectedProcedure
      .query(async ({ ctx }) => {
        // Vérifier que l'utilisateur est admin
        if (ctx.user?.role !== "admin") {
          throw new Error("Seuls les administrateurs peuvent exécuter la migration");
        }

        const { runMigration } = await import("./migrate-encyclopedia");
        return runMigration();
      }),
  }),
});
export type AppRouter = typeof appRouter;
// ─── Encyclopédie (Source Unique de Données) ──────────────────────────────────
// Note: Les procédures d'Encyclopédie seront ajoutées ici dans les prochaines phases
// Pour l'instant, on utilise les tables existantes (races, classes, dons, etc.)
// Les procédures tRPC pour l'Encyclopédie seront intégrées progressivement
