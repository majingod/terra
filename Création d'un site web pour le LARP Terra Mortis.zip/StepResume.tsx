import { Card } from "@/components/ui/card";

interface StepResumeProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepResume({ charData, heritageBonus }: StepResumeProps) {
  const totalStats = charData.puissance + charData.resistance + charData.esprit;
  const totalPoints = 6 + (heritageBonus?.extraStatsPoints || 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Identité */}
        <Card className="p-6">
          <h3 className="font-bold mb-4">Identité</h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="text-muted-foreground">Nom :</span> {charData.name || "—"}
            </p>
            <p>
              <span className="text-muted-foreground">Faction :</span> {charData.faction || "—"}
            </p>
            <p>
              <span className="text-muted-foreground">Race :</span> {charData.raceId ? `Race #${charData.raceId}` : "—"}
            </p>
          </div>
        </Card>

        {/* Classe */}
        <Card className="p-6">
          <h3 className="font-bold mb-4">Classe</h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="text-muted-foreground">Classe :</span> {charData.classId ? `Classe #${charData.classId}` : "—"}
            </p>
            <p>
              <span className="text-muted-foreground">Voie :</span> {charData.classPathId ? `Voie #${charData.classPathId}` : "—"}
            </p>
          </div>
        </Card>

        {/* Caractéristiques */}
        <Card className="p-6">
          <h3 className="font-bold mb-4">Caractéristiques</h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="text-muted-foreground">Puissance :</span> {charData.puissance}
            </p>
            <p>
              <span className="text-muted-foreground">Résistance :</span> {charData.resistance}
            </p>
            <p>
              <span className="text-muted-foreground">Esprit :</span> {charData.esprit}
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Total : {totalStats} / {totalPoints}
            </p>
          </div>
        </Card>

        {/* Sélections */}
        <Card className="p-6">
          <h3 className="font-bold mb-4">Sélections</h3>
          <div className="space-y-2 text-sm">
            <p>
              <span className="text-muted-foreground">Dons :</span> {charData.selectedDons?.length || 0}
            </p>
            <p>
              <span className="text-muted-foreground">Compétences :</span> {charData.selectedCompetences?.length || 0}
            </p>
            <p>
              <span className="text-muted-foreground">Capacités bonus :</span> {charData.selectedBonusAbilities?.length || 0}
            </p>
          </div>
        </Card>

        {/* Héritage */}
        {charData.heritageAvantages?.length > 0 && (
          <Card className="p-6 md:col-span-2">
            <h3 className="font-bold mb-4">Héritages</h3>
            <div className="space-y-2 text-sm">
              {charData.heritageAvantages.map((h: any) => (
                <p key={h.id}>
                  <span className="text-muted-foreground">Héritage #{h.id} :</span> x{h.times}
                </p>
              ))}
            </div>
          </Card>
        )}

        {/* Bonus d'Héritage */}
        {heritageBonus && Object.values(heritageBonus).some((v: any) => v > 0) && (
          <Card className="p-6 md:col-span-2 bg-amber-50 border-amber-200">
            <h3 className="font-bold mb-4 text-amber-900">✨ Bonus d'Héritage Actifs</h3>
            <div className="space-y-2 text-sm text-amber-800">
              {heritageBonus.extraStatsPoints > 0 && (
                <p>+{heritageBonus.extraStatsPoints} points de caractéristiques</p>
              )}
              {heritageBonus.extraDons > 0 && <p>+{heritageBonus.extraDons} dons</p>}
              {heritageBonus.extraCompetences > 0 && <p>+{heritageBonus.extraCompetences} compétences</p>}
              {heritageBonus.extraAbilitiesLevel1 > 0 && (
                <p>+{heritageBonus.extraAbilitiesLevel1} capacités bonus niveau 1</p>
              )}
              {heritageBonus.extraAbilitiesLevel2 > 0 && (
                <p>+{heritageBonus.extraAbilitiesLevel2} capacités bonus niveau 2</p>
              )}
              {heritageBonus.extraPv > 0 && <p>+{heritageBonus.extraPv} PV</p>}
              {heritageBonus.extraPm > 0 && <p>+{heritageBonus.extraPm} PM</p>}
            </div>
          </Card>
        )}
      </div>

      {/* Arrière-plan et notes */}
      {(charData.background || charData.notes) && (
        <div className="space-y-4">
          {charData.background && (
            <Card className="p-6">
              <h3 className="font-bold mb-4">Arrière-plan</h3>
              <p className="text-sm whitespace-pre-wrap">{charData.background}</p>
            </Card>
          )}

          {charData.notes && (
            <Card className="p-6">
              <h3 className="font-bold mb-4">Notes</h3>
              <p className="text-sm whitespace-pre-wrap">{charData.notes}</p>
            </Card>
          )}
        </div>
      )}

      {/* Message de validation */}
      <div className="p-6 rounded-lg bg-green-50 border border-green-200">
        <p className="text-green-900 font-semibold">
          ✓ Votre personnage est prêt à être créé !
        </p>
        <p className="text-sm text-green-800 mt-2">
          Cliquez sur le bouton "Valider" pour finaliser la création de votre personnage.
        </p>
      </div>
    </div>
  );
}
