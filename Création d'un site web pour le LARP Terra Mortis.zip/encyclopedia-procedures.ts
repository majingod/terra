import { getDb } from "./db";
import { encyclopediaEntries, encyclopediaRelations } from "../drizzle/schema";
import { eq, like, and, isNull } from "drizzle-orm";

/**
 * Procédures tRPC pour l'Encyclopédie
 * Fournit un accès aux données centralisées de l'Encyclopédie
 */

export async function getEncyclopediaAll(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaEntries)
    .where(isNull(encyclopediaEntries.deletedAt))
    .limit(limit)
    .offset(offset);
}

export async function getEncyclopediaByCategory(category: string, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaEntries)
    .where(and(eq(encyclopediaEntries.categorie, category), isNull(encyclopediaEntries.deletedAt)))
    .limit(limit)
    .offset(offset);
}

export async function getEncyclopediaById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const entry = await db
    .select()
    .from(encyclopediaEntries)
    .where(and(eq(encyclopediaEntries.id, id), isNull(encyclopediaEntries.deletedAt)))
    .limit(1);

  return entry[0] || null;
}

export async function searchEncyclopedia(query: string, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const searchPattern = `%${query}%`;

  return db
    .select()
    .from(encyclopediaEntries)
    .where(
      and(
        like(encyclopediaEntries.nom, searchPattern),
        isNull(encyclopediaEntries.deletedAt)
      )
    )
    .limit(limit)
    .offset(offset);
}

export async function getEncyclopediaRelated(id: number, relationTypes?: string[]) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer les relations sortantes
  let outgoingQuery = db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.cibleId, encyclopediaEntries.id));

  if (relationTypes && relationTypes.length > 0) {
    const outgoing = await outgoingQuery.where(
      and(
        eq(encyclopediaRelations.sourceId, id),
        eq(encyclopediaRelations.typeRelation, relationTypes[0])
      )
    );
    return { outgoing, incoming: [] };
  }

  const outgoing = await outgoingQuery.where(eq(encyclopediaRelations.sourceId, id));

  // Récupérer les relations entrantes
  let incomingQuery = db
    .select({
      relation: encyclopediaRelations.typeRelation,
      entry: encyclopediaEntries,
    })
    .from(encyclopediaRelations)
    .innerJoin(encyclopediaEntries, eq(encyclopediaRelations.sourceId, encyclopediaEntries.id));

  if (relationTypes && relationTypes.length > 0) {
    const incoming = await incomingQuery.where(
      and(
        eq(encyclopediaRelations.cibleId, id),
        eq(encyclopediaRelations.typeRelation, relationTypes[0])
      )
    );
    return { outgoing, incoming };
  }

  const incoming = await incomingQuery.where(eq(encyclopediaRelations.cibleId, id));

  return {
    outgoing,
    incoming,
  };
}

export async function getEncyclopediaByFaction(faction: string, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(encyclopediaEntries)
    .where(
      and(
        eq(encyclopediaEntries.factionRequise, faction),
        isNull(encyclopediaEntries.deletedAt)
      )
    )
    .limit(limit)
    .offset(offset);
}

export async function getEncyclopediaCategoryCount() {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const result = await db
    .selectDistinct({ categorie: encyclopediaEntries.categorie })
    .from(encyclopediaEntries)
    .where(isNull(encyclopediaEntries.deletedAt));

  return result.map((r) => r.categorie);
}

export async function getEncyclopediaStats() {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  const [totalEntries] = await db
    .select({ count: encyclopediaEntries.id })
    .from(encyclopediaEntries)
    .where(isNull(encyclopediaEntries.deletedAt));

  const categories = await getEncyclopediaCategoryCount();

  return {
    totalEntries: totalEntries?.count || 0,
    totalCategories: categories.length,
    categories,
  };
}
