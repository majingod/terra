import { ChevronRight, Skull, Zap } from "lucide-react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const magieData = [
  {
    title: "Principes de base",
    content: `La magie dans Terra Mortis est divisée en deux grandes familles selon les factions. Les lanceurs de sorts utilisent le Mana pour alimenter leurs incantations. Le Mana se régénère entre les combats et lors des repos.`,
  },
  {
    title: "Incantations",
    content: `Pour lancer un sort, le joueur doit réciter l'incantation complète à voix haute. L'incantation ne peut pas être interrompue par le lanceur lui-même. Si le lanceur est touché pendant l'incantation, le sort est annulé et le Mana est perdu.`,
  },
  {
    title: "Signes",
    content: `Certaines capacités sont des "Signes" qui ne nécessitent pas d'incantation verbale mais un geste physique codifié. Les signes sont plus rapides mais généralement moins puissants que les incantations.`,
  },
  {
    title: "Magie du Sanctum",
    content: `Les lanceurs du Sanctum utilisent principalement des sorts de soins, de protection et de contrôle. Ils portent des bâtons ou baguettes comme focalisateurs magiques. Leurs sorts sont souvent liés à la lumière, à la nature et à la guérison.`,
    faction: "Sanctum",
  },
  {
    title: "Magie de la Légion",
    content: `Les lanceurs de la Légion maîtrisent la magie noire, les malédictions et la nécromancie. Ils invoquent des forces obscures pour affaiblir leurs ennemis ou renforcer leurs alliés morts-vivants. Leurs sorts portent souvent des effets de corruption.`,
    faction: "Légion",
  },
  {
    title: "Résistance magique",
    content: `Certains personnages possèdent une résistance magique qui leur permet d'ignorer ou de réduire les effets des sorts. La résistance est indiquée par le mot "Résiste" prononcé à voix haute. Un personnage avec résistance peut choisir d'être affecté ou non par un sort.`,
  },
  {
    title: "Sorts de zone",
    content: `Les sorts de zone affectent tous les personnages dans un rayon défini. Le lanceur doit annoncer "Zone" avant de lancer le sort. Les alliés peuvent être affectés par les sorts de zone si le lanceur ne fait pas attention.`,
  },
  {
    title: "Mana et régénération",
    content: `Le Mana de base est déterminé par la classe. Il est augmenté par les caractéristiques (Esprit), les dons et les avantages d'héritage. Le Mana se régénère complètement après un repos de 10 minutes hors combat. En combat, certaines capacités permettent de récupérer du Mana.`,
  },
];

const factionColor = (faction?: string) => {
  if (faction === "Sanctum") return "oklch(0.55 0.18 240)";
  if (faction === "Légion") return "oklch(0.5 0.22 25)";
  return "oklch(0.65 0.18 45)";
};

export default function Magie() {
  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Magie", active: true },
      ]} />
      <div className="container max-w-4xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <Zap className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Système de Magie
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            La magie est au cœur du monde de Terra Mortis. Apprenez les règles qui régissent son utilisation.
          </p>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {magieData.map((section, i) => (
            <div
              key={i}
              className="p-6 rounded-xl border transition-all"
              style={{
                background: section.faction ? `${factionColor(section.faction)}08` : "oklch(0.16 0.02 260)",
                borderColor: section.faction ? `${factionColor(section.faction)}30` : "oklch(0.28 0.03 260)",
              }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div
                  className="w-2 h-6 rounded-full"
                  style={{ background: factionColor(section.faction) }}
                />
                <h2 className="text-xl font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
                  {section.title}
                </h2>
                {section.faction && (
                  <span
                    className="text-xs px-2 py-1 rounded font-heading ml-auto"
                    style={{
                      background: `${factionColor(section.faction)}20`,
                      color: factionColor(section.faction),
                      border: `1px solid ${factionColor(section.faction)}40`,
                    }}
                  >
                    {section.faction}
                  </span>
                )}
              </div>
              <p className="text-foreground/80 leading-relaxed">{section.content}</p>
            </div>
          ))}
        </div>

        {/* Reminder box */}
        <div
          className="mt-8 p-6 rounded-xl border"
          style={{ background: "oklch(0.65 0.18 45 / 0.08)", borderColor: "oklch(0.65 0.18 45 / 0.3)" }}
        >
          <h3 className="font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
            Rappel important
          </h3>
          <p className="text-sm text-foreground/80">
            Toutes les capacités magiques sont détaillées dans les fiches de classe. Les capacités spécifiques à chaque voie de classe
            sont accessibles depuis la page des Classes. Les règles de magie s'appliquent à toutes les classes utilisant le Mana.
          </p>
        </div>
      </div>
    </div>
  );
}
