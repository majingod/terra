import { describe, it, expect } from "vitest";

// ─── Mock data ───────────────────────────────────────────────────────────────
const mockDesavantages = [
  { id: 1, name: "Maudit", xpGain: 3, xpType: "temporaire" },
  { id: 2, name: "Faible", xpGain: 2, xpType: "temporaire" },
  { id: 3, name: "Maladif", xpGain: 4, xpType: "temporaire" },
];

const mockHeritageAvantages = [
  { id: 1, name: "Sang noble", xpCost: 2, maxTimes: 1 },
  { id: 2, name: "Héritage magique", xpCost: 3, maxTimes: 2 },
  { id: 3, name: "Ascendance guerrière", xpCost: 1, maxTimes: 3 },
];

// ─── Helper functions ─────────────────────────────────────────────────────────

/**
 * Calcule les XP temporaires gagnés par les désavantages sélectionnés
 */
function calcXPTemporaire(selectedDesavantageIds: number[], desavantages: any[]): number {
  return selectedDesavantageIds.reduce((sum, id) => {
    const d = desavantages.find((x) => x.id === id);
    return sum + (d?.xpGain ?? 0);
  }, 0);
}

/**
 * Calcule les XP permanents dépensés par l'héritage
 */
function calcXPPermanentDepense(heritageAvantages: { id: number; times: number }[], heritageData: any[]): number {
  return heritageAvantages.reduce((sum, h) => {
    const ha = heritageData.find((x) => x.id === h.id);
    return sum + (ha ? ha.xpCost * h.times : 0);
  }, 0);
}

/**
 * Valide la distribution des caractéristiques (3-2-1 obligatoire)
 */
function isValid321Distribution(puissance: number, resistance: number, esprit: number): boolean {
  const values = [puissance, resistance, esprit].sort((a, b) => b - a);
  return values[0] === 3 && values[1] === 2 && values[2] === 1;
}

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("Character Creation - XP System", () => {
  describe("calcXPTemporaire", () => {
    it("should return 0 when no disadvantages are selected", () => {
      const xp = calcXPTemporaire([], mockDesavantages);
      expect(xp).toBe(0);
    });

    it("should calculate XP from single disadvantage", () => {
      const xp = calcXPTemporaire([1], mockDesavantages);
      expect(xp).toBe(3); // "Maudit" gives 3 XP
    });

    it("should calculate XP from multiple disadvantages", () => {
      const xp = calcXPTemporaire([1, 2], mockDesavantages);
      expect(xp).toBe(5); // 3 + 2 = 5 XP
    });

    it("should handle maximum 2 disadvantages", () => {
      const xp = calcXPTemporaire([1, 3], mockDesavantages);
      expect(xp).toBe(7); // 3 + 4 = 7 XP
    });

    it("should ignore invalid disadvantage IDs", () => {
      const xp = calcXPTemporaire([1, 999], mockDesavantages);
      expect(xp).toBe(3); // Only "Maudit" counts
    });
  });

  describe("calcXPPermanentDepense", () => {
    it("should return 0 when no heritage advantages are selected", () => {
      const xp = calcXPPermanentDepense([], mockHeritageAvantages);
      expect(xp).toBe(0);
    });

    it("should calculate XP cost from single heritage advantage", () => {
      const xp = calcXPPermanentDepense([{ id: 1, times: 1 }], mockHeritageAvantages);
      expect(xp).toBe(2); // "Sang noble" costs 2 XP
    });

    it("should calculate XP cost from multiple heritage advantages", () => {
      const xp = calcXPPermanentDepense(
        [
          { id: 1, times: 1 },
          { id: 3, times: 1 },
        ],
        mockHeritageAvantages
      );
      expect(xp).toBe(3); // 2 + 1 = 3 XP
    });

    it("should handle stacking heritage advantages", () => {
      const xp = calcXPPermanentDepense([{ id: 2, times: 2 }], mockHeritageAvantages);
      expect(xp).toBe(6); // 3 * 2 = 6 XP
    });

    it("should handle mixed stacking and single advantages", () => {
      const xp = calcXPPermanentDepense(
        [
          { id: 1, times: 1 },
          { id: 2, times: 2 },
        ],
        mockHeritageAvantages
      );
      expect(xp).toBe(8); // 2 + (3 * 2) = 8 XP
    });
  });

  describe("XP Balance", () => {
    it("should calculate correct balance when XP temporaire > XP depense", () => {
      const temporaire = calcXPTemporaire([1, 2], mockDesavantages); // 5 XP
      const depense = calcXPPermanentDepense([{ id: 1, times: 1 }], mockHeritageAvantages); // 2 XP
      const bilan = temporaire - depense;
      expect(bilan).toBe(3);
    });

    it("should calculate correct balance when XP temporaire = XP depense", () => {
      const temporaire = calcXPTemporaire([1, 3], mockDesavantages); // 7 XP
      const depense = calcXPPermanentDepense(
        [
          { id: 1, times: 1 },
          { id: 2, times: 2 },
        ],
        mockHeritageAvantages
      ); // 2 + 6 = 8 XP (exceeds)
      const bilan = temporaire - depense;
      expect(bilan).toBe(-1); // Negative balance
    });

    it("should prevent overspending heritage XP", () => {
      const temporaire = calcXPTemporaire([1, 2], mockDesavantages); // 5 XP
      const depense = calcXPPermanentDepense([{ id: 2, times: 2 }], mockHeritageAvantages); // 6 XP
      expect(depense > temporaire).toBe(true); // Should not be allowed
    });
  });
});

describe("Character Creation - Characteristics Validation", () => {
  describe("isValid321Distribution", () => {
    it("should accept valid 3-2-1 distribution", () => {
      expect(isValid321Distribution(3, 2, 1)).toBe(true);
      expect(isValid321Distribution(3, 1, 2)).toBe(true);
      expect(isValid321Distribution(2, 3, 1)).toBe(true);
      expect(isValid321Distribution(1, 3, 2)).toBe(true);
      expect(isValid321Distribution(2, 1, 3)).toBe(true);
      expect(isValid321Distribution(1, 2, 3)).toBe(true);
    });

    it("should reject invalid distributions", () => {
      expect(isValid321Distribution(2, 2, 1)).toBe(false); // Two 2s
      expect(isValid321Distribution(3, 3, 1)).toBe(false); // Two 3s
      expect(isValid321Distribution(1, 1, 1)).toBe(false); // All 1s
      expect(isValid321Distribution(5, 2, 1)).toBe(false); // 5 is too high
      expect(isValid321Distribution(3, 2, 2)).toBe(false); // Two 2s
    });

    it("should reject distributions with wrong total", () => {
      expect(isValid321Distribution(4, 2, 1)).toBe(false); // Total = 7 instead of 6
      expect(isValid321Distribution(3, 2, 0)).toBe(false); // Total = 5 instead of 6
    });

    it("should reject distributions with zero or negative values", () => {
      expect(isValid321Distribution(0, 2, 1)).toBe(false);
      expect(isValid321Distribution(3, 0, 1)).toBe(false);
      expect(isValid321Distribution(3, 2, 0)).toBe(false);
    });
  });

  describe("Characteristic constraints", () => {
    it("should enforce minimum value of 1", () => {
      expect(isValid321Distribution(1, 2, 3)).toBe(true);
      expect(isValid321Distribution(0, 2, 3)).toBe(false);
    });

    it("should enforce maximum value of 5", () => {
      expect(isValid321Distribution(3, 2, 1)).toBe(true);
      expect(isValid321Distribution(5, 2, 1)).toBe(false); // 5 is too high for base distribution
    });

    it("should enforce total of 6 points distributed", () => {
      const total1 = 3 + 2 + 1;
      expect(total1).toBe(6);

      const total2 = 1 + 2 + 3;
      expect(total2).toBe(6);
    });
  });
});

describe("Character Creation - Integration", () => {
  it("should allow character creation with valid XP and characteristics", () => {
    // Select disadvantages (5 XP)
    const selectedDesavantages = [1, 2];
    const xpTemporaire = calcXPTemporaire(selectedDesavantages, mockDesavantages);
    expect(xpTemporaire).toBe(5);

    // Select heritage advantages (3 XP)
    const selectedHeritage = [{ id: 1, times: 1 }];
    const xpDepense = calcXPPermanentDepense(selectedHeritage, mockHeritageAvantages);
    expect(xpDepense).toBe(2);

    // Check balance is positive
    const bilan = xpTemporaire - xpDepense;
    expect(bilan).toBeGreaterThan(0);

    // Check valid characteristics
    const isValidChars = isValid321Distribution(3, 2, 1);
    expect(isValidChars).toBe(true);

    // Both conditions satisfied
    expect(xpTemporaire >= xpDepense && isValidChars).toBe(true);
  });

  it("should prevent character creation with invalid characteristics", () => {
    const selectedDesavantages = [1, 2];
    const xpTemporaire = calcXPTemporaire(selectedDesavantages, mockDesavantages);

    const selectedHeritage = [{ id: 1, times: 1 }];
    const xpDepense = calcXPPermanentDepense(selectedHeritage, mockHeritageAvantages);

    // Invalid characteristics
    const isValidChars = isValid321Distribution(2, 2, 1);
    expect(isValidChars).toBe(false);

    // Should not allow creation
    expect(xpTemporaire >= xpDepense && isValidChars).toBe(false);
  });

  it("should prevent character creation with overspent XP", () => {
    const selectedDesavantages = [1]; // 3 XP
    const xpTemporaire = calcXPTemporaire(selectedDesavantages, mockDesavantages);
    expect(xpTemporaire).toBe(3);

    // Try to spend 6 XP
    const selectedHeritage = [{ id: 2, times: 2 }];
    const xpDepense = calcXPPermanentDepense(selectedHeritage, mockHeritageAvantages);
    expect(xpDepense).toBe(6);

    // Check balance is negative
    const bilan = xpTemporaire - xpDepense;
    expect(bilan).toBeLessThan(0);

    // Valid characteristics
    const isValidChars = isValid321Distribution(3, 2, 1);
    expect(isValidChars).toBe(true);

    // Should not allow creation due to overspent XP
    expect(xpTemporaire >= xpDepense && isValidChars).toBe(false);
  });
});
