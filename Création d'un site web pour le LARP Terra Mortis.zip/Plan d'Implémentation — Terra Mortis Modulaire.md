# Plan d'Implémentation — Terra Mortis Modulaire

## Vue d'ensemble

Transformation complète de Terra Mortis en une architecture modulaire où l'**Encyclopédie est la source unique de données**. Le projet existant sera amélioré progressivement sans destruction du code actuel.

---

## 🎯 Objectifs Principaux

1. **Encyclopédie modulaire** : Remplacer la section "Règles" par une véritable encyclopédie interactive avec recherche, filtres, et liens automatiques
2. **Refonte du générateur de personnage** : Réorganiser les étapes avec Héritage en position 4 (critique)
3. **Système d'événements** : Créer une gestion d'événements avec inscription et attribution d'XP permanent
4. **Panneau administrateur enrichi** : Gestion complète de l'encyclopédie et des événements
5. **Zéro données codées en dur** : Tout doit être chargé dynamiquement depuis la base de données

---

## 📊 Architecture de la Base de Données

### Nouvelles tables à créer

```
encyclopedie_entries (table centrale)
├── id (PK)
├── nom
├── categorie (races, classes, sous_classes, capacites, dons, competences, etc.)
├── description (texte long)
├── proprietes (JSON structuré)
├── relations (JSON : références vers d'autres entrées)
├── faction_requise (null = toutes)
├── conditions (JSON : prérequis)
├── historique_modifications (JSON : audit trail)
├── created_at
├── updated_at

events
├── id (PK)
├── titre
├── date
├── lieu
├── description
├── factions_concernees (JSON array)
├── status (a_venir, en_cours, termine, annule)
├── created_at
├── updated_at

event_inscriptions
├── id (PK)
├── event_id (FK)
├── personnage_id (FK)
├── user_id (FK)
├── present (boolean, null avant clôture)
├── created_at

xp_permanent (table d'historique)
├── id (PK)
├── user_id (FK)
├── montant
├── source (event_id ou autre)
├── date
├── description
```

### Modifications des tables existantes

- **users** : Ajouter `xp_permanent_total` (somme calculée)
- **personnages** : Ajouter `xp_permanent_depense` (pour tracking)

---

## 🔄 Tâches Détaillées par Phase

### Phase 1 : Analyse et Planification

**À faire :**
- [x] Lire et analyser le document de spécifications complet
- [ ] Créer un document d'architecture détaillée (ERD, flux de données)
- [ ] Identifier les données existantes à migrer
- [ ] Planifier la stratégie de migration sans perte de données
- [ ] Documenter les dépendances entre les modules

**Livrables :**
- Document d'architecture complète
- Diagramme ERD (Entity Relationship Diagram)
- Matrice de migration des données

---

### Phase 2 : Refonte de la Base de Données

**À faire :**
- [ ] Créer les nouvelles tables (encyclopedie_entries, events, event_inscriptions, xp_permanent)
- [ ] Migrer les données existantes (races, classes, dons, compétences) vers encyclopedie_entries
- [ ] Ajouter les colonnes manquantes aux tables existantes
- [ ] Créer les indices de performance
- [ ] Écrire les migrations Drizzle
- [ ] Tester l'intégrité des données

**Données à structurer :**
- Races (6 entrées)
- Classes (8 entrées)
- Sous-classes (24 entrées)
- Capacités (120+ entrées)
- Dons (17 entrées)
- Compétences (11 entrées)
- Héritage avantages (15+ entrées)
- Héritage désavantages (12 entrées)
- Ressources, matériaux, runes, recettes, règles de combat, symboles

**Livrables :**
- Migrations Drizzle appliquées
- Scripts de peuplement des données
- Validation de l'intégrité

---

### Phase 3 : Encyclopédie Interactive

**À faire :**
- [ ] Créer la page `/regles` (hub principal)
- [ ] Implémenter la **recherche globale** dans toutes les entrées
- [ ] Ajouter les **filtres par catégorie**
- [ ] Créer les **pages détaillées** `/regles/[categorie]/[id]`
- [ ] Implémenter les **liens automatiques** entre entrées
- [ ] Créer les **tables interactives** (filtrables, triables)
- [ ] Ajouter la **navigation latérale** enrichie
- [ ] Créer les **procédures tRPC** pour récupérer les données

**Composants à créer :**
- `EncyclopediaHub.tsx` (page principale)
- `EncyclopediaSearch.tsx` (recherche globale)
- `EncyclopediaFilters.tsx` (filtres par catégorie)
- `EncyclopediaEntry.tsx` (page détaillée)
- `EncyclopediaTable.tsx` (tables interactives)
- `EncyclopediaLink.tsx` (liens automatiques)

**Procédures tRPC à créer :**
- `encyclopedia.search(query)`
- `encyclopedia.getByCategory(category)`
- `encyclopedia.getEntry(id)`
- `encyclopedia.getRelated(id)`

**Livrables :**
- Pages d'encyclopédie fonctionnelles
- Recherche et filtres opérationnels
- Liens automatiques entre entrées

---

### Phase 4 : Refonte du Générateur de Personnage

**Nouvel ordre des étapes :**
1. Faction (Sanctum / Légion)
2. Race (filtrée par faction)
3. Classe (filtrée par faction)
4. **Héritage** (NOUVEAU POSITION — critique)
   - 4a : Affichage XP permanent + temporaire
   - 4b : Sélection désavantages (optionnel)
   - 4c : Achat avantages
5. Sous-spécialisation (3 voies)
6. Caractéristiques (3-2-1, modifié par héritage)
7. Dons (1 + bonus héritage)
8. Compétences (1 + bonus héritage)
9. Récapitulatif et validation

**À faire :**
- [ ] Réorganiser les étapes du générateur existant
- [ ] Créer `StepFaction.tsx` (nouvelle étape 1)
- [ ] Créer `StepHeritage.tsx` refactorisé (nouvelle étape 4)
- [ ] Modifier `StepCaracteristiques.tsx` pour intégrer bonus héritage
- [ ] Modifier `StepDons.tsx` pour intégrer bonus héritage
- [ ] Modifier `StepCompetences.tsx` pour intégrer bonus héritage
- [ ] Implémenter la **propagation des bonus** héritage dans les étapes suivantes
- [ ] Ajouter la **validation des règles** complète
- [ ] Créer le **récapitulatif final** (étape 9)

**Logique critique :**
- Les bonus d'héritage (dons, compétences, caractéristiques, capacités) doivent se propager automatiquement
- Les restrictions de faction/race/classe doivent être vérifiées à chaque étape
- Le calcul des PV maximum (15) doit être appliqué partout
- Le système Énergie du Sorcier (PV+Mana fusionnés, max 20) doit être traité comme cas spécial

**Procédures tRPC à créer/modifier :**
- `character.getAvailableRaces(factionId)`
- `character.getAvailableClasses(factionId)`
- `character.getHeritageAvantages()`
- `character.getHeritageDesavantages()`
- `character.calculateStats(characterData)`
- `character.validateCharacter(characterData)`

**Livrables :**
- Générateur refondu avec nouvel ordre
- Propagation des bonus héritage
- Validation complète des règles

---

### Phase 5 : Fiches de Personnage

**À faire :**
- [ ] Créer la page `/personnages/[id]` (fiche détaillée)
- [ ] Implémenter le **calcul complet des statistiques**
- [ ] Créer la **version imprimable** (format A4, style parchemin)
- [ ] Ajouter les **capacités par niveau** avec descriptions
- [ ] Afficher les **codes de conduite** (Paladin, CdM)
- [ ] Implémenter la **sauvegarde/modification** du personnage
- [ ] Créer la **liste de mes personnages** (`/personnages`)

**Composants à créer :**
- `CharacterSheet.tsx` (fiche détaillée)
- `CharacterPrintable.tsx` (version imprimable)
- `CharacterList.tsx` (liste des personnages)
- `CharacterStats.tsx` (affichage des stats)

**Procédures tRPC à créer :**
- `character.getById(id)`
- `character.getMyCharacters()`
- `character.update(id, data)`
- `character.delete(id)`

**Livrables :**
- Fiches de personnage fonctionnelles
- Version imprimable en PDF
- Gestion complète des personnages

---

### Phase 6 : Système d'Événements

**À faire :**
- [ ] Créer la page `/evenements` (liste publique)
- [ ] Implémenter l'**inscription aux événements**
- [ ] Créer le **profil joueur** avec XP permanent
- [ ] Implémenter le **panneau événements admin**
- [ ] Créer la **clôture d'événement** avec attribution d'XP
- [ ] Ajouter l'**historique des XP** (audit trail)
- [ ] Implémenter le **calcul automatique de l'XP**

**Composants à créer :**
- `EventsList.tsx` (liste publique)
- `EventDetail.tsx` (détail d'un événement)
- `EventRegistration.tsx` (inscription)
- `PlayerProfile.tsx` (profil joueur avec XP)
- `AdminEvents.tsx` (panneau admin)
- `EventClosure.tsx` (clôture avec XP)

**Procédures tRPC à créer :**
- `events.getUpcoming()`
- `events.register(eventId, characterId)`
- `events.unregister(eventId, characterId)`
- `events.getMyRegistrations()`
- `events.create(data)` (admin)
- `events.update(id, data)` (admin)
- `events.close(id, presentUserIds)` (admin)
- `xp.getBalance(userId)`
- `xp.getHistory(userId)`

**Règles critiques :**
- XP permanent appartient au joueur (compte), pas au personnage
- XP dépensé sur un personnage est définitif
- Un joueur peut avoir plusieurs personnages et choisir sur lequel dépenser l'XP
- Historique complet des XP doit être consultable

**Livrables :**
- Système d'événements complet
- Gestion d'XP permanent fonctionnelle
- Historique d'audit

---

### Phase 7 : Panneau Administrateur Enrichi

**À faire :**
- [ ] Créer l'**interface de gestion de l'encyclopédie**
- [ ] Implémenter l'**ajout d'entrées**
- [ ] Implémenter la **modification d'entrées**
- [ ] Implémenter la **suppression d'entrées**
- [ ] Ajouter la **gestion des catégories**
- [ ] Créer l'**éditeur JSON** pour les propriétés
- [ ] Implémenter l'**historique des modifications** avec rollback
- [ ] Ajouter l'**import CSV/PDF**
- [ ] Créer la **vue d'impact** (quelles données affectées)

**Composants à créer :**
- `AdminEncyclopedia.tsx` (hub admin)
- `AdminEntryForm.tsx` (ajout/modification)
- `AdminEntryList.tsx` (liste des entrées)
- `AdminCategoryManager.tsx` (gestion des catégories)
- `AdminJsonEditor.tsx` (éditeur JSON)
- `AdminHistory.tsx` (historique avec rollback)
- `AdminImport.tsx` (import de données)

**Procédures tRPC à créer :**
- `admin.encyclopedia.create(data)`
- `admin.encyclopedia.update(id, data)`
- `admin.encyclopedia.delete(id)`
- `admin.encyclopedia.getHistory(id)`
- `admin.encyclopedia.rollback(id, versionId)`
- `admin.encyclopedia.import(file)`
- `admin.encyclopedia.getImpact(id)`

**Livrables :**
- Panneau admin complet
- Gestion CRUD de l'encyclopédie
- Historique et rollback

---

### Phase 8 : Design et Responsive

**À faire :**
- [ ] Appliquer le **thème Terra Mortis** (parchemin, médiéval-viking)
- [ ] Implémenter les **couleurs faction** (Sanctum : bleu/or, Légion : rouge/noir)
- [ ] Assurer la **responsivité mobile**
- [ ] Ajouter les **textures et illustrations**
- [ ] Créer les **animations cohérentes**
- [ ] Tester sur tous les appareils

**Couleurs :**
- Sanctum : bleu nuit, or, blanc
- Légion : rouge sang, noir, gris
- Neutre : tons brun/sépia/or

**Livrables :**
- Design cohérent Terra Mortis
- Responsive sur tous les appareils
- Animations et transitions

---

### Phase 9 : Tests et Déploiement

**À faire :**
- [ ] Tests unitaires (vitest)
- [ ] Tests d'intégration
- [ ] Tests de performance
- [ ] Tests de responsivité
- [ ] Tests de sécurité
- [ ] Déploiement en production

**Livrables :**
- Couverture de tests complète
- Déploiement sans erreur

---

## 🔑 Règles Critiques à Respecter

1. **Zéro données codées en dur** : Tout doit venir de l'encyclopédie
2. **Héritage en étape 4** : Position critique pour la propagation des bonus
3. **XP permanent = joueur** : Pas du personnage
4. **Propagation automatique** : Les bonus doivent affecter toutes les étapes suivantes
5. **Validation complète** : Toutes les règles vérifiées dynamiquement
6. **Audit trail** : Historique complet des modifications

---

## 📈 Estimation de Charge

| Phase | Complexité | Durée estimée |
|-------|-----------|---------------|
| 1 | Faible | 1 jour |
| 2 | Moyenne | 2-3 jours |
| 3 | Moyenne | 3-4 jours |
| 4 | **Élevée** | 5-7 jours |
| 5 | Moyenne | 2-3 jours |
| 6 | Moyenne | 3-4 jours |
| 7 | Moyenne | 2-3 jours |
| 8 | Faible | 1-2 jours |
| 9 | Moyenne | 2-3 jours |
| **Total** | | **21-32 jours** |

---

## 🚀 Prochaines Étapes

1. Valider ce plan avec vous
2. Commencer par la Phase 1 (analyse complète)
3. Créer les migrations de base de données
4. Progresser phase par phase avec checkpoints réguliers

