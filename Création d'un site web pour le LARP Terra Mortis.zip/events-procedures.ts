import { getDb } from "./db";
import { inscriptions, evenements } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

/**
 * Procédures pour la gestion des événements et de l'XP
 */

export async function getPlayerInscriptions(playerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  return db
    .select()
    .from(inscriptions)
    .where(eq(inscriptions.userId, playerId))
    .leftJoin(evenements, eq(inscriptions.evenementId, evenements.id))
    .orderBy(desc(inscriptions.createdAt));
}

export async function getPlayerXPHistory(playerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Note: xpHistory n'existe pas encore, retourner un tableau vide pour l'instant
  return [];
}

export async function unsubscribeFromEvent(inscriptionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Supprimer l'inscription
  await db.delete(inscriptions).where(eq(inscriptions.id, inscriptionId));

  return { success: true };
}

export async function getEventStats(eventId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  // Récupérer le nombre d'inscriptions
  const inscriptionsData = await db
    .select()
    .from(inscriptions)
    .where(eq(inscriptions.evenementId, eventId));

  return {
    inscriptionCount: inscriptionsData.length,
    totalXPDistributed: 0,
    averageXPPerPlayer: 0,
  };
}

export async function getPlayerTotalXP(playerId: number) {
  // Note: xpHistory n'existe pas encore, retourner 0 pour l'instant
  return 0;
}
