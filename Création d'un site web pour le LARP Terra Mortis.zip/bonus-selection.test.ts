import { describe, it, expect } from "vitest";

/**
 * Tests pour le système de sélection des capacités bonus
 */

describe("Bonus Abilities Selection System", () => {
  // Mock data
  const mockAbilities = [
    { id: 1001, name: "Coup de bouclier", level: 1 },
    { id: 1002, name: "Armure divine", level: 2 },
    { id: 1003, name: "Rage", level: 1 },
    { id: 1004, name: "Fureur totale", level: 2 },
    { id: 1005, name: "Jugement", level: 1 },
    { id: 1006, name: "Vengeance divine", level: 2 },
  ];

  describe("canSelectBonusAbility", () => {
    it("should allow selection when limit not reached", () => {
      const result = canSelectBonusAbility(
        1001,
        1,
        [],
        { level1: 2, level2: 1 },
        mockAbilities
      );
      expect(result).toBe(true);
    });

    it("should prevent selection when limit reached", () => {
      const result = canSelectBonusAbility(
        1005,
        1,
        [1001, 1003],
        { level1: 2, level2: 1 },
        mockAbilities
      );
      expect(result).toBe(false);
    });

    it("should allow deselection", () => {
      const result = canSelectBonusAbility(
        1001,
        1,
        [1001],
        { level1: 1, level2: 1 },
        mockAbilities
      );
      expect(result).toBe(true);
    });

    it("should respect level-specific limits", () => {
      const result1 = canSelectBonusAbility(
        1005,
        1,
        [1001, 1003],
        { level1: 2, level2: 2 },
        mockAbilities
      );
      expect(result1).toBe(false);

      const result2 = canSelectBonusAbility(
        1006,
        2,
        [1001, 1003],
        { level1: 2, level2: 2 },
        mockAbilities
      );
      expect(result2).toBe(true);
    });
  });

  describe("toggleBonusAbility", () => {
    it("should add ability when not selected", () => {
      const result = toggleBonusAbility(1001, []);
      expect(result).toEqual([1001]);
    });

    it("should remove ability when selected", () => {
      const result = toggleBonusAbility(1001, [1001, 1003]);
      expect(result).toEqual([1003]);
    });

    it("should maintain other selections", () => {
      const result = toggleBonusAbility(1001, [1003, 1005]);
      expect(result).toEqual([1003, 1005, 1001]);
    });
  });

  describe("countSelectedByLevel", () => {
    it("should count level 1 selections", () => {
      const result = countSelectedByLevel([1001, 1003, 1002], 1, mockAbilities);
      expect(result).toBe(2);
    });

    it("should count level 2 selections", () => {
      const result = countSelectedByLevel([1001, 1003, 1002, 1004], 2, mockAbilities);
      expect(result).toBe(2);
    });

    it("should return 0 when no selections", () => {
      const result = countSelectedByLevel([], 1, mockAbilities);
      expect(result).toBe(0);
    });

    it("should handle mixed selections", () => {
      const result1 = countSelectedByLevel([1001, 1002, 1003], 1, mockAbilities);
      const result2 = countSelectedByLevel([1001, 1002, 1003], 2, mockAbilities);
      expect(result1).toBe(2);
      expect(result2).toBe(1);
    });
  });

  describe("Integration scenarios", () => {
    it("should handle complete selection flow", () => {
      let selected: number[] = [];
      const extraAbilities = { level1: 2, level2: 1 };

      // Select first level 1 ability
      if (canSelectBonusAbility(1001, 1, selected, extraAbilities, mockAbilities)) {
        selected = toggleBonusAbility(1001, selected);
      }
      expect(selected).toEqual([1001]);

      // Select second level 1 ability
      if (canSelectBonusAbility(1003, 1, selected, extraAbilities, mockAbilities)) {
        selected = toggleBonusAbility(1003, selected);
      }
      expect(selected).toEqual([1001, 1003]);

      // Try to select third level 1 ability (should fail)
      if (canSelectBonusAbility(1005, 1, selected, extraAbilities, mockAbilities)) {
        selected = toggleBonusAbility(1005, selected);
      }
      expect(selected).toEqual([1001, 1003]); // No change

      // Select level 2 ability
      if (canSelectBonusAbility(1002, 2, selected, extraAbilities, mockAbilities)) {
        selected = toggleBonusAbility(1002, selected);
      }
      expect(selected).toEqual([1001, 1003, 1002]);

      // Verify counts
      expect(countSelectedByLevel(selected, 1, mockAbilities)).toBe(2);
      expect(countSelectedByLevel(selected, 2, mockAbilities)).toBe(1);
    });

    it("should handle deselection and reselection", () => {
      let selected = [1001, 1003, 1002];
      const extraAbilities = { level1: 2, level2: 1 };

      // Deselect level 1 ability
      selected = toggleBonusAbility(1001, selected);
      expect(selected).toEqual([1003, 1002]);

      // Now we can select another level 1 ability
      if (canSelectBonusAbility(1005, 1, selected, extraAbilities, mockAbilities)) {
        selected = toggleBonusAbility(1005, selected);
      }
      expect(selected).toEqual([1003, 1002, 1005]);
    });

    it("should enforce separate limits for each level", () => {
      const selected: number[] = [];
      const extraAbilities = { level1: 1, level2: 2 };

      // Can select 1 level 1
      expect(canSelectBonusAbility(1001, 1, selected, extraAbilities, mockAbilities)).toBe(true);

      // After selecting 1 level 1, can't select another
      const selected1 = toggleBonusAbility(1001, selected);
      expect(canSelectBonusAbility(1003, 1, selected1, extraAbilities, mockAbilities)).toBe(false);

      // But can still select level 2
      expect(canSelectBonusAbility(1002, 2, selected1, extraAbilities, mockAbilities)).toBe(true);
      expect(canSelectBonusAbility(1004, 2, selected1, extraAbilities, mockAbilities)).toBe(true);

      // After selecting 2 level 2, can't select another
      const selected2 = toggleBonusAbility(1002, selected1);
      const selected3 = toggleBonusAbility(1004, selected2);
      expect(canSelectBonusAbility(1006, 2, selected3, extraAbilities, mockAbilities)).toBe(false);
    });
  });
});

// Helper functions (copied from StepVoieEtDons.tsx for testing)
function canSelectBonusAbility(
  abilityId: number,
  level: 1 | 2,
  selectedBonusAbilities: number[],
  extraAbilities: { level1: number; level2: number },
  bonusAbilities: any[]
): boolean {
  const isSelected = selectedBonusAbilities.includes(abilityId);
  if (isSelected) return true;

  const limit = level === 1 ? extraAbilities.level1 : extraAbilities.level2;
  const selectedCount = selectedBonusAbilities.filter((id) => {
    const ability = bonusAbilities.find((a) => a.id === id);
    return ability && ability.level === level;
  }).length;

  return selectedCount < limit;
}

function toggleBonusAbility(abilityId: number, selectedBonusAbilities: number[]): number[] {
  if (selectedBonusAbilities.includes(abilityId)) {
    return selectedBonusAbilities.filter((id) => id !== abilityId);
  }
  return [...selectedBonusAbilities, abilityId];
}

function countSelectedByLevel(
  selectedBonusAbilities: number[],
  level: 1 | 2,
  bonusAbilities: any[]
): number {
  return selectedBonusAbilities.filter((id) => {
    const ability = bonusAbilities.find((a) => a.id === id);
    return ability && ability.level === level;
  }).length;
}
