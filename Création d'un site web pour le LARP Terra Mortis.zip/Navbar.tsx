import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  BookOpen,
  ChevronDown,
  Crown,
  LogIn,
  LogOut,
  Menu,
  Shield,
  Skull,
  Swords,
  User,
  Users,
  Wand2,
} from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const rulesLinks = [
  { href: "/regles/races", label: "Races", icon: Users },
  { href: "/regles/classes", label: "Classes", icon: Swords },
  { href: "/regles/dons", label: "Dons", icon: Crown },
  { href: "/regles/competences", label: "Compétences", icon: BookOpen },
  { href: "/regles/heritage", label: "Héritage", icon: Skull },
  { href: "/regles/magie", label: "Magie", icon: Wand2 },
  { href: "/regles/combat", label: "Combat", icon: Swords },
];

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isOrganizer = user?.role === "admin" || user?.role === "organizer";

  return (
    <header className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-md"
      style={{ background: "oklch(0.12 0.015 260 / 0.95)" }}>
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, oklch(0.65 0.18 45), oklch(0.45 0.15 30))" }}>
            <Skull className="w-4 h-4 text-black" />
          </div>
          <span className="font-heading text-lg font-bold hidden sm:block"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            Terra Mortis
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {/* Règles dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-1 text-foreground/80 hover:text-foreground font-heading text-sm tracking-wide">
                <BookOpen className="w-4 h-4" />
                Règles
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56 bg-card border-border">
              {rulesLinks.map((link) => (
                <DropdownMenuItem key={link.href} asChild>
                  <Link href={link.href} className="flex items-center gap-2 cursor-pointer">
                    <link.icon className="w-4 h-4 text-primary" />
                    {link.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Link href="/regles/races">
            <Button variant="ghost" className="font-heading text-sm tracking-wide text-foreground/80 hover:text-foreground">
              Races
            </Button>
          </Link>
          <Link href="/regles/dons">
            <Button variant="ghost" className="font-heading text-sm tracking-wide text-foreground/80 hover:text-foreground">
              Dons
            </Button>
          </Link>
          {isAuthenticated && (
            <Link href="/creer-personnage">
              <Button variant="ghost" className="font-heading text-sm tracking-wide"
                style={{ color: "oklch(0.82 0.2 85)" }}>
                <Swords className="w-4 h-4 mr-1" />
                Créer un personnage
              </Button>
            </Link>
          )}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 text-foreground/80 hover:text-foreground">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}>
                    {user?.name?.charAt(0)?.toUpperCase() || "?"}
                  </div>
                  <span className="hidden sm:block text-sm font-heading">{user?.name}</span>
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 bg-card border-border">
                <DropdownMenuItem asChild>
                  <Link href="/mes-personnages" className="flex items-center gap-2 cursor-pointer">
                    <User className="w-4 h-4" />
                    Mes personnages
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/creer-personnage" className="flex items-center gap-2 cursor-pointer">
                    <Swords className="w-4 h-4" />
                    Créer un personnage
                  </Link>
                </DropdownMenuItem>
                {isOrganizer && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/admin" className="flex items-center gap-2 cursor-pointer"
                        style={{ color: "oklch(0.82 0.2 85)" }}>
                        <Crown className="w-4 h-4" />
                        Espace organisateur
                      </Link>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="flex items-center gap-2 cursor-pointer text-destructive">
                  <LogOut className="w-4 h-4" />
                  Déconnexion
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              onClick={() => window.location.href = getLoginUrl()}
              size="sm"
              className="font-heading text-sm"
              style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}
            >
              <LogIn className="w-4 h-4 mr-1" />
              Connexion
            </Button>
          )}

          {/* Mobile menu */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 bg-card border-border p-0">
              <div className="flex flex-col h-full">
                <div className="p-4 border-b border-border"
                  style={{ background: "linear-gradient(135deg, oklch(0.16 0.02 260), oklch(0.14 0.018 260))" }}>
                  <div className="flex items-center gap-2">
                    <Skull className="w-5 h-5" style={{ color: "oklch(0.82 0.2 85)" }} />
                    <span className="font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>
                      Terra Mortis
                    </span>
                  </div>
                </div>
                <nav className="flex-1 overflow-y-auto p-4 space-y-1">
                  <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2 px-2">
                    Règles du GN
                  </p>
                  {rulesLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-md text-sm text-foreground/80 hover:text-foreground hover:bg-secondary transition-colors"
                    >
                      <link.icon className="w-4 h-4 text-primary" />
                      {link.label}
                    </Link>
                  ))}
                  {isAuthenticated && (
                    <>
                      <div className="border-t border-border my-3" />
                      <p className="text-xs font-heading uppercase tracking-widest text-muted-foreground mb-2 px-2">
                        Mon compte
                      </p>
                      <Link href="/mes-personnages" onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-2 px-3 py-2 rounded-md text-sm text-foreground/80 hover:text-foreground hover:bg-secondary transition-colors">
                        <User className="w-4 h-4 text-primary" />
                        Mes personnages
                      </Link>
                      <Link href="/creer-personnage" onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-2 px-3 py-2 rounded-md text-sm hover:bg-secondary transition-colors"
                        style={{ color: "oklch(0.82 0.2 85)" }}>
                        <Swords className="w-4 h-4" />
                        Créer un personnage
                      </Link>
                      {isOrganizer && (
                        <Link href="/admin" onClick={() => setMobileOpen(false)}
                          className="flex items-center gap-2 px-3 py-2 rounded-md text-sm hover:bg-secondary transition-colors"
                          style={{ color: "oklch(0.82 0.2 85)" }}>
                          <Crown className="w-4 h-4" />
                          Espace organisateur
                        </Link>
                      )}
                    </>
                  )}
                </nav>
                <div className="p-4 border-t border-border">
                  {isAuthenticated ? (
                    <Button onClick={logout} variant="outline" className="w-full" size="sm">
                      <LogOut className="w-4 h-4 mr-2" />
                      Déconnexion
                    </Button>
                  ) : (
                    <Button
                      onClick={() => window.location.href = getLoginUrl()}
                      className="w-full font-heading"
                      style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}
                    >
                      <LogIn className="w-4 h-4 mr-2" />
                      Connexion
                    </Button>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
