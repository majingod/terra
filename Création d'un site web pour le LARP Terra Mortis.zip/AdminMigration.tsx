import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminMigration() {
  const [isRunning, setIsRunning] = useState(false);
  const [migrationResult, setMigrationResult] = useState<number | null>(null);

  const migrationQuery = trpc.migration.runMigration.useQuery(undefined, {
    enabled: false,
  });

  const handleRunMigration = async () => {
    if (
      !confirm(
        "⚠️ Êtes-vous sûr ? Cette opération va migrer toutes les données existantes vers la nouvelle table encyclopedie_entries. Cette action ne peut pas être annulée."
      )
    ) {
      return;
    }

    setIsRunning(true);
    try {
      const result = await migrationQuery.refetch();
      if (result.data) {
        setMigrationResult(result.data);
        toast.success(`✅ Migration complétée ! ${result.data} entrées créées`);
      }
    } catch (error: any) {
      toast.error(`❌ Erreur lors de la migration : ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };



  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Migration des Données</h1>
        <p className="text-muted-foreground mt-2">
          Migrez toutes les données existantes vers la nouvelle table encyclopedie_entries
        </p>
      </div>

      <Card className="border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-yellow-500" />
            Migration des Données Existantes
          </CardTitle>
          <CardDescription>
            Cette opération va migrer toutes les races, classes, dons, compétences, héritages et désavantages vers la
            nouvelle table encyclopedie_entries. Les nouvelles catégories seront également ajoutées.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
            <p className="font-semibold text-foreground">Données qui seront migrées :</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Races</li>
              <li>Classes et voies de classe</li>
              <li>Capacités de classe</li>
              <li>Dons</li>
              <li>Compétences</li>
              <li>Héritages (avantages + désavantages)</li>
              <li>12 nouvelles catégories (ressources, matériaux, runes, recettes, etc.)</li>
            </ul>
          </div>

          {migrationResult !== null && (
            <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 p-4 rounded-lg flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-green-900 dark:text-green-100">Migration réussie !</p>
                <p className="text-green-800 dark:text-green-200 text-sm mt-1">
                  {migrationResult} entrées ont été créées dans encyclopedie_entries
                </p>
              </div>
            </div>
          )}

          <Button
            onClick={handleRunMigration}
            disabled={isRunning}
            className="w-full bg-orange-600 hover:bg-orange-700 text-white"
            size="lg"
          >
            {isRunning ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Migration en cours...
              </>
            ) : (
              "Exécuter la migration"
            )}
          </Button>

          <p className="text-xs text-muted-foreground">
            ⚠️ Cette opération peut prendre quelques secondes. Ne fermez pas la page pendant la migration.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
