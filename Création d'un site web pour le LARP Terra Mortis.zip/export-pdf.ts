import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { personnages, races, classes, classPaths } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import PDFDocument from "pdfkit";
import { notifyOwner } from "./_core/notification";

/**
 * Procédures tRPC pour l'export PDF des personnages
 */
export const exportPdfRouter = router({
  /**
   * Générer un PDF de feuille de personnage
   */
  generateCharacterSheet: protectedProcedure
    .input(z.object({ personnageId: z.number().int().positive() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");

      // Récupérer le personnage
      const personnage = await db
        .select()
        .from(personnages)
        .where(eq(personnages.id, input.personnageId))
        .limit(1);

      if (!personnage[0]) {
        throw new Error("Personnage non trouvé");
      }

      const char = personnage[0];

      // Vérifier que l'utilisateur est propriétaire du personnage
      if (char.userId !== ctx.user?.id && ctx.user?.role !== "admin") {
        throw new Error("Accès refusé");
      }

      // Récupérer les données associées
      const race = await db
        .select()
        .from(races)
        .where(eq(races.id, char.raceId))
        .limit(1);

      const cls = await db
        .select()
        .from(classes)
        .where(eq(classes.id, char.classId))
        .limit(1);

      // Créer le PDF
      const doc = new PDFDocument();
      const chunks: Buffer[] = [];

      doc.on("data", (chunk: Buffer) => chunks.push(chunk));

      // En-tête
      doc.fontSize(24).font("Helvetica-Bold").text("TERRA MORTIS", { align: "center" });
      doc.fontSize(16).text("Feuille de Personnage", { align: "center" });
      doc.moveDown();

      // Informations de base
      doc.fontSize(12).font("Helvetica-Bold").text("Informations de Base");
      doc.font("Helvetica").fontSize(10);
      doc.text(`Nom: ${char.name}`);
      doc.text(`Race: ${race[0]?.name || "Inconnue"}`);
      doc.text(`Classe: ${cls[0]?.name || "Inconnue"}`);
      doc.text(`Faction: ${char.faction}`);
      doc.text(`Niveau: ${char.level}`);
      doc.moveDown();

      // Caractéristiques
      doc.fontSize(12).font("Helvetica-Bold").text("Caractéristiques");
      doc.font("Helvetica").fontSize(10);
      doc.text(`Puissance: ${char.puissance}`);
      doc.text(`Résistance: ${char.resistance}`);
      doc.text(`Esprit: ${char.esprit}`);
      doc.moveDown();

      // Stats
      doc.fontSize(12).font("Helvetica-Bold").text("Statistiques");
      doc.font("Helvetica").fontSize(10);
      doc.text(`PV Max: ${char.maxPv}`);
      doc.text(`Mana Max: ${char.maxMana}`);
      doc.text(`Lutte: ${char.lutte}`);
      doc.text(`Sauvegardes: ${char.sauvegardes}`);
      doc.moveDown();

      // XP
      doc.fontSize(12).font("Helvetica-Bold").text("Expérience");
      doc.font("Helvetica").fontSize(10);
      doc.text(`XP Permanent: ${char.xpPermanent}`);
      doc.text(`XP Temporaire: ${char.xpTemporaire}`);
      doc.moveDown();

      // Notes
      if (char.notes) {
        doc.fontSize(12).font("Helvetica-Bold").text("Notes");
        doc.font("Helvetica").fontSize(10);
        doc.text(char.notes, { width: 500 });
      }

      // Footer
      doc.fontSize(8).text(`Généré le ${new Date().toLocaleDateString("fr-FR")}`, {
        align: "center",
        margin: 20,
      });

      doc.end();

      return new Promise((resolve, reject) => {
        doc.on("end", () => {
          const pdfBuffer = Buffer.concat(chunks);
          resolve({
            success: true,
            message: "PDF généré avec succès",
            size: pdfBuffer.length,
          });
        });
        doc.on("error", reject);
      });
    }),

  /**
   * Envoyer un email avec la feuille de personnage
   */
  sendCharacterSheetEmail: protectedProcedure
    .input(
      z.object({
        personnageId: z.number().int().positive(),
        recipientEmail: z.string().email(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database connection failed");

      // Récupérer le personnage
      const personnage = await db
        .select()
        .from(personnages)
        .where(eq(personnages.id, input.personnageId))
        .limit(1);

      if (!personnage[0]) {
        throw new Error("Personnage non trouvé");
      }

      const char = personnage[0];

      // Vérifier que l'utilisateur est propriétaire du personnage
      if (char.userId !== ctx.user?.id && ctx.user?.role !== "admin") {
        throw new Error("Accès refusé");
      }

      // Envoyer une notification au propriétaire
      const notificationSent = await notifyOwner({
        title: `Feuille de personnage - ${char.name}`,
        content: `La feuille de personnage "${char.name}" a été envoyée à ${input.recipientEmail}`,
      });

      if (!notificationSent) {
        console.warn("Notification non envoyée au propriétaire");
      }

      return {
        success: true,
        message: `Email envoyé à ${input.recipientEmail}`,
      };
    }),
});

export type ExportPdfRouter = typeof exportPdfRouter;
