import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface UseValidateDesavantageOptions {
  raceId?: number;
  classId?: number;
  level?: number;
  selectedDesavantages?: number[];
  showToasts?: boolean;
}

export function useValidateDesavantage() {
  const [validationResults, setValidationResults] = useState<Map<number, ValidationResult>>(new Map());
  const [isValidating, setIsValidating] = useState(false);

  const validateDesavantage = useCallback(
    async (desavantageId: number, options: UseValidateDesavantageOptions = {}) => {
      const { showToasts = true } = options;
      setIsValidating(true);

      try {
        // Appeler la procédure tRPC de validation
        const result = await new Promise<ValidationResult>((resolve) => {
          fetch("/api/trpc/validation.validateDesavantage", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              desavantageId,
              raceId: options.raceId,
              classId: options.classId,
              level: options.level,
              selectedDesavantages: options.selectedDesavantages,
            }),
          })
            .then((res) => res.json())
            .then((data) => {
              const result = data.result || { isValid: true, errors: [], warnings: [] };
              resolve(result);
            })
            .catch(() => {
              resolve({ isValid: true, errors: [], warnings: [] });
            });
        });

        // Stocker le résultat
        setValidationResults((prev) => new Map(prev).set(desavantageId, result));

        // Afficher les toasts si demandé
        if (showToasts) {
          if (!result.isValid && result.errors.length > 0) {
            result.errors.forEach((error) => {
              toast.error(error);
            });
          }
          if (result.warnings.length > 0) {
            result.warnings.forEach((warning) => {
              toast.warning(warning);
            });
          }
        }

        return result;
      } catch (error) {
        console.error("Erreur lors de la validation du désavantage:", error);
        const errorResult: ValidationResult = {
          isValid: false,
          errors: ["Erreur lors de la validation"],
          warnings: [],
        };
        setValidationResults((prev) => new Map(prev).set(desavantageId, errorResult));
        if (showToasts) {
          toast.error("Erreur lors de la validation du désavantage");
        }
        return errorResult;
      } finally {
        setIsValidating(false);
      }
    },
    []
  );

  const getValidationResult = useCallback(
    (desavantageId: number): ValidationResult | undefined => {
      return validationResults.get(desavantageId);
    },
    [validationResults]
  );

  const clearValidation = useCallback((desavantageId?: number) => {
    if (desavantageId) {
      setValidationResults((prev) => {
        const newMap = new Map(prev);
        newMap.delete(desavantageId);
        return newMap;
      });
    } else {
      setValidationResults(new Map());
    }
  }, []);

  return {
    validateDesavantage,
    getValidationResult,
    clearValidation,
    isValidating,
    validationResults,
  };
}
