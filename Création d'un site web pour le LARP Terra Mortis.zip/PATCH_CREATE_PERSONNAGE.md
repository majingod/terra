# Patch pour CreatePersonnage.tsx

## 1. Modifier handleSubmit (ligne 1036)

Remplacer:
```typescript
  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez completer toutes les etapes obligatoires.");
      return;
    }
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      notes: charData.notes || undefined,
    });
  };
```

Par:
```typescript
  const handleSubmit = () => {
    if (!charData.faction || !charData.raceId || !charData.classId) {
      toast.error("Veuillez completer toutes les etapes obligatoires.");
      return;
    }
    const values = [charData.puissance, charData.resistance, charData.esprit].sort((a, b) => b - a);
    if (values[0] !== 3 || values[1] !== 2 || values[2] !== 1) {
      toast.error("Les caracteristiques doivent suivre 3-2-1");
      return;
    }
    const xpTemp = charData.selectedDesavantages.reduce((sum, id) => {
      const d = desavantages.find((x) => x.id === id);
      return sum + (d?.xpGain ?? 0);
    }, 0);
    const xpPerm = charData.heritageAvantages.reduce((sum, h) => {
      const ha = heritageAvantages.find((x) => x.id === h.id);
      return sum + (ha ? ha.xpCost * h.times : 0);
    }, 0);
    createMutation.mutate({
      name: charData.name,
      background: charData.background || undefined,
      faction: charData.faction,
      raceId: charData.raceId,
      classId: charData.classId,
      classPathId: charData.classPathId || undefined,
      puissance: charData.puissance,
      resistance: charData.resistance,
      esprit: charData.esprit,
      maxPv: stats.maxPv,
      maxMana: stats.maxMana,
      lutte: stats.lutte,
      sauvegardes: stats.sauvegardes,
      competenceId: charData.competenceId || undefined,
      selectedDons: charData.selectedDons,
      heritageAvantages: charData.heritageAvantages,
      selectedDesavantages: charData.selectedDesavantages,
      xpTemporaire: xpTemp,
      xpPermanent: xpPerm,
      notes: charData.notes || undefined,
    });
  };
```

## 2. Modifier l'appel à StepDonsResume (ligne 1106)

Remplacer:
```typescript
      case 10: return <StepDonsResume data={charData} onChange={updateData} dons={dons} heritageAvantages={heritageAvantages} races={races} classes={classes} competences={competences} desavantages={desavantages} calcStats={calcStats} />;
```

Par:
```typescript
      case 10: return <StepDonsResume data={charData} onChange={updateData} dons={dons} heritageAvantages={heritageAvantages} races={races} classes={classes} competences={competences} desavantages={desavantages} calcStats={calcStats} onCreatePersonnage={handleSubmit} isCreating={createMutation.isPending} />;
```

## 3. Ajouter le bouton "Suivant" dans le footer

À la fin du composant, modifier le bouton "Suivant" pour l'étape 10 afin qu'il n'apparaisse pas (car on utilise le bouton "Créer le personnage" à la place).
