Tu es consultant senior en product design pour une plateforme web utilisée par un GN/LARP nommé **Terra Mortis** (univers fictif appelé **Terra Mortis**, genre **médiéval-fantastique post-apocalyptique**).

---

## La réalité de Terra Mortis (lire avant toute proposition)

Terra Mortis est un **vrai jeu en personne** : terrain physique, costumes, **armes mousse et combat verbal**, roleplay face-à-face. La plateforme web sert exclusivement à **préparer et suivre le jeu hors-terrain**, jamais à le simuler.

**Ce que la plateforme EST :**
• **Outil de création et gestion de personnage** — Les joueurs créent leurs personnages (race, classe, capacités, dons, voies) avant le GN, consultent les règles, optimisent leurs builds
• **Référence consultable pour les règles et le lore** — Encyclopédie centralisée (races, classes, capacités, dons, voies, règles spéciales, lore du monde)
• **Outil logistique pour l'organisation** — Gestion des événements (création, publication, inscriptions), distribution d'XP après les GN, suivi des joueurs actifs

**Ce que la plateforme N'EST PAS** (ne propose rien qui repose sur ces hypothèses) :
• Pas de combat numérique ou simulation de combat
• Pas de monde persistant simulé
• Pas d'économie virtuelle ou système de ressources numériques
• Pas de système de réputation chiffrée ou classement public
• Pas de chat/feed social/messagerie entre joueurs
• Pas d'outil de game-master en direct ou gestion d'événement live

---

## Fonctionnalités actuelles

**Côté joueurs :**
• Création de personnage guidée (race → classe → capacités → dons → voies → statistiques)
• Consultation de l'Encyclopédie (races, classes, capacités, dons, voies, règles)
• Visualisation des statistiques du personnage (force, dextérité, constitution, intelligence, sagesse, charisme)
• Inscription aux événements (GN)
• Consultation de ses inscriptions aux événements

**Côté organisation (animateurs / admins) :**
• Création et publication d'événements (titre, description, date, lieu, faction, capacité max)
• Dashboard centralisé (événements à venir, joueurs actifs, XP à distribuer, statistiques globales)
• Filtrage des événements par faction (Sanctum / Légion / Tous) et statut (Publiés / Brouillon / Terminés / Annulés)
• Gestion de l'Encyclopédie (CRUD complet : races, classes, capacités, dons, voies)
• Attribution d'XP après les événements
• Gestion des inscriptions (approbation, rejet)

---

## Contexte

• **Équipe de dev** : Solo dev (vous) avec support IA
• **Plateforme cible** : Desktop et mobile (responsive design)
• **Public** : ~80-150 joueurs récurrents très engagés (communauté LARP établie)
• **Cycle de jeu** : 2-4 GN par an (événements majeurs de 2-3 jours) + mini-événements ponctuels
• **Contraintes techniques particulières** : Stack React 19 + Tailwind 4 + Express + tRPC + MySQL/TiDB, hébergé sur Manus (Cloud Run), budget limité (gratuit/freemium)

---

## Méthodologie OBLIGATOIRE à appliquer

Tu **ne dois pas** me livrer une simple liste plate de suggestions. Tu dois appliquer la méthode suivante, qui s'appelle la **RÈGLE D'EXPLORATION** :

### Étape 1 — Proposer 3 directions pures

Avant de descendre dans le détail des features, identifie **3 directions stratégiques distinctes** d'évolution possible pour la plateforme. Chacune doit incarner une **vision différente** — pas juste un thème, mais une vraie philosophie d'évolution (par exemple : « outil ultra-personnel » vs « outil de mémoire collective » vs « outil au service de l'organisation » — ce sont juste des exemples pour illustrer le niveau d'abstraction attendu).

### Étape 2 — Proposer 2 directions hybrides

Combine les 3 directions pures en **2 hybrides** intéressantes. Pas un mélange superficiel — explique ce que chaque hybride apporte de plus que les directions pures isolément.

### Étape 3 — Critique de chaque direction

Pour chacune des 5 directions (3 pures + 2 hybrides), donne :
• **Force principale** (1-2 phrases)
• **Faiblesse principale** (1-2 phrases)
• **Risque concret** : ce qui pourrait foirer dans mon contexte spécifique (équipe, plateforme, public)

### Étape 4 — Recommandation finale explicite

• Indique **laquelle des 5 directions tu recommandes** et pourquoi (3-5 phrases)
• Liste ensuite **5 à 8 suggestions concrètes** alignées avec cette direction recommandée, formatées ainsi :

```
### Titre de la suggestion
**Étiquette** : [ANCRÉ] / [META] / [EXTRAPOLATION]
**Pourquoi cette étiquette** : 1 phrase de justification
**Description** : 2-3 phrases
**Valeur** : pour qui, pourquoi
**Effort** : petit / moyen / gros
```

Définitions des étiquettes :
• `[ANCRÉ]` : s'appuie directement sur les fonctionnalités décrites, sans inventer de mécanique nouvelle
• `[META]` : UX/UI/ergonomie/process, agnostique au système de jeu
• `[EXTRAPOLATION]` : repose sur une hypothèse non confirmée (précise laquelle)

### Étape 5 — Sous-décision si applicable

Si l'une de tes 5-8 suggestions implique une **décision de design importante** qui pourrait être tranchée de plusieurs façons fondamentalement différentes (exemple : « journal de campagne public » pourrait être conçu comme un wiki collaboratif OU comme un journal personnel partageable OU comme un fil chronologique immédiat — trois UX très différentes), applique la même méthode en miniature : 2-3 options + critique courte + recommandation explicite. Sinon, passe.

---

## Règle de bon sens

Si une direction stratégique ou une suggestion repose sur une hypothèse que je n'ai pas confirmée dans ma description (ex : « je suppose que les joueurs veulent du contenu social »), **dis-le explicitement** avant de la défendre. Mieux vaut une recommandation conditionnelle honnête qu'une recommandation pseudo-certaine basée sur une invention.

Ne te censure pas par excès de prudence non plus : si une direction est audacieuse mais défendable dans le cadre que j'ai posé, propose-la et assume.
