# Design du Dashboard Organisateur

## Vue d'ensemble
Le dashboard organisateur centralise la gestion des événements, inscriptions et XP. Les procédures tRPC doivent fournir les données nécessaires pour afficher 4 sections principales.

---

## Procédures tRPC à Implémenter

### 1. `admin.dashboard.getUpcomingEvents`
**Objectif** : Afficher les événements à venir dans les 30 prochains jours

**Input** : Aucun

**Output** :
```typescript
Array<{
  id: number;
  title: string;
  description: string;
  location: string;
  startDate: Date;
  endDate: Date;
  maxPlayers: number;
  status: "draft" | "published" | "cancelled" | "completed";
  faction: "Sanctum" | "Légion" | "Tous";
  price?: string;
  createdBy: number;
}>
```

**Logique** :
- Filtrer les événements avec `status === "published"`
- Filtrer par date : `startDate >= now && startDate <= now + 30 jours`
- Trier par `startDate` croissant
- Limiter à 10 résultats

**Raison du design** :
- Les organisateurs ont besoin de voir rapidement les événements imminents
- 30 jours = horizon de planification standard
- 10 résultats = limite UI raisonnable

---

### 2. `admin.dashboard.getActiveUsers`
**Objectif** : Afficher les joueurs les plus actifs (top 10)

**Input** : Aucun

**Output** :
```typescript
Array<{
  id: number;
  name: string;
  email: string;
  role: "admin" | "user";
  xp: number;
  createdAt: Date;
  inscriptionCount?: number; // Nombre d'inscriptions
}>
```

**Logique** :
- Récupérer tous les utilisateurs
- Trier par nombre d'inscriptions décroissant (ou par XP)
- Limiter à 10 résultats

**Raison du design** :
- Les organisateurs veulent identifier les joueurs engagés
- Permet de cibler les communications/récompenses
- Top 10 = affichage lisible

---

### 3. `admin.dashboard.getXPToDistribute`
**Objectif** : Afficher les événements terminés sans XP attribué

**Input** : Aucun

**Output** :
```typescript
Array<{
  id: number;
  title: string;
  description: string;
  location: string;
  startDate: Date;
  endDate: Date;
  maxPlayers: number;
  status: "completed";
  faction: "Sanctum" | "Légion" | "Tous";
  inscriptionCount?: number; // Nombre d'inscrits
}>
```

**Logique** :
- Filtrer les événements avec `status === "completed"`
- Filtrer par date : `endDate < now`
- Trier par `endDate` décroissant (plus récents en premier)
- Limiter à 10 résultats

**Raison du design** :
- Les organisateurs doivent distribuer l'XP rapidement après un événement
- Afficher les événements les plus récents en premier
- Permet d'accéder directement à la page de distribution d'XP

---

### 4. `admin.dashboard.getStats`
**Objectif** : Afficher les statistiques globales du dashboard

**Input** : Aucun

**Output** :
```typescript
{
  totalEvents: number;           // Nombre d'événements publiés
  totalUsers: number;            // Nombre d'utilisateurs
  totalInscriptions: number;     // Nombre total d'inscriptions
  totalXPDistributed: number;    // Total d'XP distribué
  eventsByFaction?: {            // Optionnel : répartition par faction
    Sanctum: number;
    Légion: number;
    Tous: number;
  };
}
```

**Logique** :
- `totalEvents` = nombre d'événements avec `status === "published"`
- `totalUsers` = nombre total d'utilisateurs
- `totalInscriptions` = nombre total de lignes dans la table `inscriptions`
- `totalXPDistributed` = somme des XP attribués (via les inscriptions)

**Raison du design** :
- Vue d'ensemble rapide de la santé de la plateforme
- Métriques clés pour les décisions stratégiques
- Répartition par faction = utile pour équilibrer les événements

---

## Sécurité

Toutes les procédures utilisent `adminProcedure`, ce qui signifie :
- ✅ Seuls les administrateurs peuvent accéder
- ✅ Authentification requise
- ✅ Vérification du rôle côté serveur

---

## Optimisations Futures

1. **Pagination** : Ajouter `skip` et `take` pour les listes longues
2. **Filtrage** : Permettre de filtrer par faction, statut, etc.
3. **Caching** : Mettre en cache les statistiques (mise à jour toutes les heures)
4. **Recherche** : Ajouter une recherche par titre d'événement

---

## Cas d'Usage

### Scénario 1 : Organisateur arrive le matin
1. Consulte `getUpcomingEvents` → voit les événements de la semaine
2. Consulte `getStats` → vérifie la santé générale
3. Consulte `getXPToDistribute` → distribue l'XP des événements d'hier

### Scénario 2 : Organisateur gère les joueurs
1. Consulte `getActiveUsers` → identifie les joueurs engagés
2. Peut envoyer des communications ciblées
3. Peut récompenser les joueurs les plus actifs

---

## Notes d'Implémentation

- Les procédures doivent être **rapides** (< 500ms)
- Les requêtes doivent être **optimisées** (pas de N+1 queries)
- Les données doivent être **fraîches** (pas de cache agressif)
- Les erreurs doivent être **gérées** (fallback gracieux)
