import { useState } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Minus, Check, X } from "lucide-react";
import { toast } from "sonner";

interface XPDistribution {
  personnageId: number;
  personnageName: string;
  currentXP: number;
  xpToAdd: number;
  reason: string;
}

export default function AdminAttributeXP() {
  const [distributions, setDistributions] = useState<XPDistribution[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Récupérer les événements
  const { data: events, isLoading: eventsLoading } = trpc.evenements.getAll.useQuery();

  // Récupérer les personnages pour un événement
  const { data: eventPersonnages } = trpc.evenements.getPersonnages.useQuery(
    { eventId: selectedEventId || 0 },
    { enabled: !!selectedEventId }
  );

  const handleSelectEvent = (eventId: number) => {
    setSelectedEventId(eventId);
    setDistributions([]);
  };

  const handleAddPersonnage = (personnageId: number, personnageName: string) => {
    if (!distributions.find((d) => d.personnageId === personnageId)) {
      setDistributions([
        ...distributions,
        {
          personnageId,
          personnageName,
          currentXP: 0,
          xpToAdd: 0,
          reason: "",
        },
      ]);
    }
  };

  const handleRemovePersonnage = (personnageId: number) => {
    setDistributions(distributions.filter((d) => d.personnageId !== personnageId));
  };

  const handleXPChange = (personnageId: number, xpToAdd: number) => {
    setDistributions(
      distributions.map((d) =>
        d.personnageId === personnageId ? { ...d, xpToAdd: Math.max(0, xpToAdd) } : d
      )
    );
  };

  const handleReasonChange = (personnageId: number, reason: string) => {
    setDistributions(
      distributions.map((d) =>
        d.personnageId === personnageId ? { ...d, reason } : d
      )
    );
  };

  const handleSaveDistribution = async () => {
    if (!selectedEventId) {
      toast.error("Sélectionnez un événement");
      return;
    }

    if (distributions.length === 0) {
      toast.error("Aucun personnage sélectionné");
      return;
    }

    setIsSaving(true);
    try {
      // TODO: Appeler la procédure tRPC pour sauvegarder l'XP
      toast.success(`XP attribué à ${distributions.length} personnage(s)`);
      setDistributions([]);
      setSelectedEventId(null);
    } catch (error) {
      toast.error("Erreur lors de l'attribution de l'XP");
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  const selectedEvent = events?.find((e: any) => e.id === selectedEventId);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Attribuer l'XP</h1>
          <p className="text-muted-foreground">
            Distribuez l'XP aux personnages après un événement
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Événements à traiter */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Événements</CardTitle>
                <CardDescription>Sélectionnez un événement</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {eventsLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin" />
                  </div>
                ) : events && events.length > 0 ? (
                  events.map((event: any) => (
                    <Button
                      key={event.id}
                      variant={selectedEventId === event.id ? "default" : "outline"}
                      className="w-full justify-start text-left h-auto py-2"
                      onClick={() => handleSelectEvent(event.id)}
                    >
                      <div className="flex flex-col gap-1 w-full">
                        <span className="font-semibold">{event.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {event.status === "completed" ? "Terminé" : event.status}
                        </span>
                      </div>
                    </Button>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Aucun événement disponible
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Distribution d'XP */}
          <div className="lg:col-span-2">
            {selectedEventId && selectedEvent ? (
              <Card>
                <CardHeader>
                  <CardTitle>{selectedEvent.name}</CardTitle>
                  <CardDescription>
                    Distribution d'XP - Sélectionnez les personnages et entrez l'XP
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Liste des personnages disponibles */}
                  {eventPersonnages && eventPersonnages.length > 0 && (
                    <div className="space-y-2 mb-4 pb-4 border-b">
                      <p className="text-sm font-semibold">Ajouter des personnages</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {eventPersonnages.map((p: any) => (
                          <Button
                            key={p.id}
                            variant="outline"
                            size="sm"
                            onClick={() => handleAddPersonnage(p.id, p.name)}
                            disabled={distributions.some((d) => d.personnageId === p.id)}
                            className="justify-start"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            {p.name}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Personnages sélectionnés */}
                  {distributions.length > 0 ? (
                    <div className="space-y-3">
                      {distributions.map((dist) => (
                        <div
                          key={dist.personnageId}
                          className="p-3 border rounded-lg space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-semibold">{dist.personnageName}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemovePersonnage(dist.personnageId)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-medium">XP à attribuer</label>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  handleXPChange(dist.personnageId, dist.xpToAdd - 5)
                                }
                              >
                                <Minus className="w-4 h-4" />
                              </Button>
                              <Input
                                type="number"
                                value={dist.xpToAdd}
                                onChange={(e) =>
                                  handleXPChange(
                                    dist.personnageId,
                                    parseInt(e.target.value) || 0
                                  )
                                }
                                className="text-center"
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  handleXPChange(dist.personnageId, dist.xpToAdd + 5)
                                }
                              >
                                <Plus className="w-4 h-4" />
                              </Button>
                              <Badge variant="secondary">{dist.xpToAdd} XP</Badge>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-medium">Raison</label>
                            <Input
                              placeholder="Ex: Participation, Victoire, Bonus..."
                              value={dist.reason}
                              onChange={(e) =>
                                handleReasonChange(dist.personnageId, e.target.value)
                              }
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      Aucun personnage sélectionné
                    </p>
                  )}

                  {/* Boutons d'action */}
                  {distributions.length > 0 && (
                    <div className="flex gap-2 pt-4 border-t">
                      <Button
                        onClick={handleSaveDistribution}
                        disabled={isSaving}
                        className="flex-1"
                      >
                        {isSaving ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Sauvegarde...
                          </>
                        ) : (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Valider et sauvegarder
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setDistributions([])}
                        disabled={isSaving}
                      >
                        Annuler
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <p className="text-muted-foreground">
                    Sélectionnez un événement pour commencer
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
