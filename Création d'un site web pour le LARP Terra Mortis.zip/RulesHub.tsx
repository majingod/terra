import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Sword, Wand2, Heart, Crown, Scroll, Flame, Shield, Skull, ChevronRight } from "lucide-react";
import Breadcrumbs from "@/components/Breadcrumbs";

export default function RulesHub() {
  const [, navigate] = useLocation();

  const rulesSections = [
    {
      id: "races",
      title: "Races",
      description: "Explorez les différentes races jouables et leurs caractéristiques uniques.",
      icon: Crown,
      color: "oklch(0.55 0.18 240)",
      path: "/encyclopedie/races",
    },
    {
      id: "classes",
      title: "Classes",
      description: "Découvrez les classes disponibles et leurs capacités spéciales.",
      icon: Sword,
      color: "oklch(0.5 0.22 25)",
      path: "/encyclopedie/classes",
    },
    {
      id: "competences",
      title: "Compétences",
      description: "Maîtrisez les compétences et artisanats disponibles pour votre personnage.",
      icon: Scroll,
      color: "oklch(0.65 0.18 45)",
      path: "/encyclopedie/competences",
    },
    {
      id: "dons",
      title: "Dons",
      description: "Améliorez votre personnage avec des dons puissants et variés.",
      icon: Flame,
      color: "oklch(0.45 0.15 140)",
      path: "/encyclopedie/dons",
    },
    {
      id: "heritage",
      title: "Héritage & Désavantages",
      description: "Définissez le passé de votre personnage avec héritage et désavantages.",
      icon: Heart,
      color: "oklch(0.5 0.18 10)",
      path: "/encyclopedie/heritage_avantages",
    },
    {
      id: "magie",
      title: "Magie",
      description: "Apprenez les règles de la magie, des signes et des incantations.",
      icon: Wand2,
      color: "oklch(0.55 0.15 280)",
      path: "/encyclopedie/capacites",
    },
    {
      id: "combat",
      title: "Combat & Règles",
      description: "Maîtrisez les règles de combat, fouille et gestion des objets.",
      icon: Shield,
      color: "oklch(0.5 0.18 200)",
      path: "/encyclopedie/regles_combat",
    },
  ];

  return (
    <div className="min-h-screen">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles", active: true },
      ]} />
      {/* ─── Hero Section ────────────────────────────────────────────────────── */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0"
            style={{
              background: "radial-gradient(ellipse at center, oklch(0.2 0.04 270 / 0.4) 0%, transparent 70%)",
            }} />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.65 0.18 45)" }} />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full blur-3xl opacity-10"
            style={{ background: "oklch(0.5 0.22 25)" }} />
          {/* Decorative runes */}
          <div className="absolute top-10 left-10 text-6xl opacity-5 font-heading select-none">ᚠ</div>
          <div className="absolute top-20 right-20 text-4xl opacity-5 font-heading select-none">ᚢ</div>
          <div className="absolute bottom-20 left-20 text-5xl opacity-5 font-heading select-none">ᚦ</div>
          <div className="absolute bottom-10 right-10 text-7xl opacity-5 font-heading select-none">ᚨ</div>
        </div>

        <div className="container relative z-10 text-center py-20">
          {/* Skull icon */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="w-24 h-24 rounded-full flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, oklch(0.65 0.18 45 / 0.2), oklch(0.45 0.15 30 / 0.1))",
                  border: "2px solid oklch(0.65 0.18 45 / 0.4)",
                  boxShadow: "0 0 40px oklch(0.65 0.18 45 / 0.2)",
                }}>
                <BookOpen className="w-12 h-12" style={{ color: "oklch(0.82 0.2 85)" }} />
              </div>
            </div>
          </div>

          {/* Title */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-black mb-4 leading-tight"
            style={{
              background: "linear-gradient(135deg, oklch(0.82 0.2 85), oklch(0.65 0.18 45), oklch(0.82 0.2 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              textShadow: "none",
            }}>
            RÈGLES COMPLÈTES
          </h1>

          <p className="text-xl md:text-2xl font-heading text-muted-foreground mb-2 tracking-widest uppercase">
            Terra Mortis — Stukely-Sud
          </p>

          {/* Decorative divider */}
          <div className="flex items-center justify-center gap-4 my-8">
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-5 h-5" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px flex-1 max-w-32"
              style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>

          {/* Intro text */}
          <p className="text-lg md:text-xl max-w-3xl mx-auto text-foreground/80 mb-10 leading-relaxed"
            style={{ fontFamily: "'Crimson Text', serif", fontStyle: "italic" }}>
            Bienvenue dans le guide complet de Terra Mortis. Consultez toutes les règles, races, classes et compétences pour préparer votre aventure.
          </p>
        </div>
      </section>

      {/* ─── What is LARP Section ────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-heading text-center mb-4"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            Qu'est-ce qu'un Grandeur Nature ?
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Un Grandeur Nature est une activité médiévale fantastique où plusieurs joueurs se regroupent pour vivre ensemble diverses aventures immersives.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300"
              style={{
                boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
              }}>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                style={{ background: "oklch(0.65 0.18 45 / 0.2)", border: "1px solid oklch(0.65 0.18 45 / 0.4)" }}>
                <Skull className="w-6 h-6" style={{ color: "oklch(0.65 0.18 45)" }} />
              </div>
              <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">
                Incarnation
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Incarnez un personnage unique dans un univers médiéval fantastique riche et détaillé.
              </p>
            </div>

            <div className="relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300"
              style={{
                boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
              }}>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                style={{ background: "oklch(0.5 0.22 25 / 0.2)", border: "1px solid oklch(0.5 0.22 25 / 0.4)" }}>
                <Sword className="w-6 h-6" style={{ color: "oklch(0.5 0.22 25)" }} />
              </div>
              <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">
                Aventures
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Participez à des quêtes épiques, des combats mémorables et des intrigues complexes.
              </p>
            </div>

            <div className="relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300"
              style={{
                boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
              }}>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                style={{ background: "oklch(0.55 0.18 240 / 0.2)", border: "1px solid oklch(0.55 0.18 240 / 0.4)" }}>
                <Shield className="w-6 h-6" style={{ color: "oklch(0.55 0.18 240)" }} />
              </div>
              <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">
                Factions
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Rejoignez l'une des deux factions et combattez pour la victoire finale.
              </p>
            </div>

            <div className="relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300"
              style={{
                boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
              }}>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                style={{ background: "oklch(0.45 0.15 140 / 0.2)", border: "1px solid oklch(0.45 0.15 140 / 0.4)" }}>
                <Wand2 className="w-6 h-6" style={{ color: "oklch(0.45 0.15 140)" }} />
              </div>
              <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">
                Progression
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Progressez votre personnage au fil des événements et débloquez de nouveaux pouvoirs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Campaign Lore Section ────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-heading text-center mb-4"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            La Campagne : Terra Mortis
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Vous êtes mort. L'après-vie est extrêmement chaotique depuis la destruction de la balance. Deux factions s'affrontent pour le droit d'accéder à Ysgard.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="relative p-8 rounded-xl border bg-card/30"
              style={{ borderColor: "oklch(0.55 0.18 240 / 0.5)" }}>
              <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl"
                style={{ background: "linear-gradient(to right, transparent, oklch(0.55 0.18 240), transparent)" }} />

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ background: "oklch(0.55 0.18 240 / 0.2)", border: "2px solid oklch(0.55 0.18 240 / 0.5)" }}>
                  <Shield className="w-6 h-6" style={{ color: "oklch(0.55 0.18 240)" }} />
                </div>
                <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.55 0.18 240)" }}>
                  Sanctum
                </h3>
              </div>

              <p className="text-foreground/80 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                Les races et individus de Sanctum proviennent de civilisations avancées. Leur force réside dans l'union, la persévérance et l'organisation. En général, les membres de cette faction sont bienveillants, ayant tendance à penser aux besoins des autres avant les leurs.
              </p>
            </div>

            <div className="relative p-8 rounded-xl border bg-card/30"
              style={{ borderColor: "oklch(0.5 0.22 25 / 0.5)" }}>
              <div className="absolute top-0 left-0 right-0 h-1 rounded-t-xl"
                style={{ background: "linear-gradient(to right, transparent, oklch(0.5 0.22 25), transparent)" }} />

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ background: "oklch(0.5 0.22 25 / 0.2)", border: "2px solid oklch(0.5 0.22 25 / 0.5)" }}>
                  <Skull className="w-6 h-6" style={{ color: "oklch(0.5 0.22 25)" }} />
                </div>
                <h3 className="text-2xl font-heading font-bold" style={{ color: "oklch(0.5 0.22 25)" }}>
                  Légion
                </h3>
              </div>

              <p className="text-foreground/80 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
                La Légion regroupe les races et individus souillés par une forme de corruption. Leur force réside dans le nombre, la brutalité et la volonté de tout faire pour l'emporter. En général, les membres de cette faction sont malveillants.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Rules Sections Grid ────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-heading text-center mb-4"
            style={{ color: "oklch(0.82 0.2 85)" }}>
            Explorez les Règles Complètes
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Consultez toutes les sections de règles pour préparer votre personnage et maîtriser les mécaniques du jeu.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {rulesSections.map((section) => {
              const IconComponent = section.icon;
              return (
                <div key={section.id} className="group relative p-6 rounded-lg border border-border/50 bg-card/50 hover:bg-card transition-all duration-300 cursor-pointer h-full"
                  style={{
                    boxShadow: "0 2px 20px oklch(0 0 0 / 0.3)",
                  }}
                  onClick={() => navigate(section.path)}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLDivElement).style.boxShadow = `0 0 30px ${section.color}30, 0 4px 20px oklch(0 0 0 / 0.4)`;
                    (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)";
                    (e.currentTarget as HTMLDivElement).style.borderColor = `${section.color}60`;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLDivElement).style.boxShadow = "0 2px 20px oklch(0 0 0 / 0.3)";
                    (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
                    (e.currentTarget as HTMLDivElement).style.borderColor = "";
                  }}>
                  <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                    style={{ background: `${section.color}20`, border: `1px solid ${section.color}40` }}>
                    <IconComponent className="w-6 h-6" style={{ color: section.color }} />
                  </div>
                  <h3 className="font-heading text-lg font-semibold mb-2 text-foreground">
                    {section.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {section.description}
                  </p>
                  <ChevronRight className="w-4 h-4 absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ color: section.color }} />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ─── Quick Links Section ────────────────────────────────────────────── */}
      <section className="py-20 border-t border-border/30">
        <div className="container">
          <div className="bg-card/30 border border-border/30 rounded-xl p-8 max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-heading text-center mb-4"
              style={{ color: "oklch(0.82 0.2 85)" }}>
              Prêt à commencer ?
            </h2>
            <p className="text-center text-muted-foreground mb-8 max-w-2xl mx-auto">
              Lancez le créateur de personnage ou consultez vos personnages existants.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="font-heading tracking-wide text-base px-8 py-6"
                style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.1 0.01 260)" }}
                onClick={() => navigate("/creer-personnage")}>
                <Sword className="w-5 h-5 mr-2" />
                Créer un personnage
              </Button>
              <Button size="lg" variant="outline" className="font-heading tracking-wide text-base px-8 py-6 border-2"
                style={{ borderColor: "oklch(0.65 0.18 45 / 0.5)", color: "oklch(0.82 0.2 85)" }}
                onClick={() => navigate("/mes-personnages")}>
                <BookOpen className="w-5 h-5 mr-2" />
                Mes personnages
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
