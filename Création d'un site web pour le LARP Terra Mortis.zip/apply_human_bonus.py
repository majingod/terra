#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Trouver la fin de StepRace et ajouter le choix de bonus racial
old_step_race_end = '''              </button>
            );
        })}
      </div>
    </div>
  );
}

function StepClasse'''

new_step_race_end = '''              </button>
            );
        })}
      </div>
      
      {/* Bonus racial pour Humain */}
      {data.raceId && races.find(r => r.id === data.raceId)?.name === "Humain" && (
        <div className="mt-8 p-6 rounded-xl border" style={{ borderColor: "oklch(0.65 0.18 45 / 0.4)", background: "oklch(0.65 0.18 45 / 0.08)" }}>
          <h3 className="font-heading font-semibold text-lg mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Bonus racial Humain
          </h3>
          <p className="text-sm text-foreground/75 mb-4">
            Les Humains peuvent choisir d'appliquer leur bonus racial (+1) soit aux Points de Vie, soit aux Points de Mana.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => onChange({ humanBonusType: 'pv' })}
              className="flex-1 p-4 rounded-lg border transition-all"
              style={{
                background: data.humanBonusType === 'pv' ? "oklch(0.65 0.18 45 / 0.15)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === 'pv' ? "oklch(0.65 0.18 45 / 0.6)" : "oklch(0.28 0.03 260)",
                boxShadow: data.humanBonusType === 'pv' ? "0 0 15px oklch(0.65 0.18 45 / 0.15)" : "none",
              }}
            >
              <div className="font-heading font-semibold text-foreground mb-1">+1 Points de Vie</div>
              <div className="text-xs text-foreground/60">Augmente votre résistance physique</div>
            </button>
            <button
              onClick={() => onChange({ humanBonusType: 'pm' })}
              className="flex-1 p-4 rounded-lg border transition-all"
              style={{
                background: data.humanBonusType === 'pm' ? "oklch(0.45 0.15 140 / 0.15)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === 'pm' ? "oklch(0.45 0.15 140 / 0.6)" : "oklch(0.28 0.03 260)",
                boxShadow: data.humanBonusType === 'pm' ? "0 0 15px oklch(0.45 0.15 140 / 0.15)" : "none",
              }}
            >
              <div className="font-heading font-semibold text-foreground mb-1">+1 Points de Mana</div>
              <div className="text-xs text-foreground/60">Augmente votre énergie magique</div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StepClasse'''

content = content.replace(old_step_race_end, new_step_race_end)
print("✓ Choix de bonus racial pour Humain ajouté")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
