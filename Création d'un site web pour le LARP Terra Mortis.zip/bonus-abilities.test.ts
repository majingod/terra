import { describe, it, expect } from "vitest";

/**
 * Tests pour le système de capacités bonus débloquées par l'héritage
 */

describe("Bonus Abilities System", () => {
  // Mock data
  const mockClasses = [
    {
      id: 1,
      name: "Guerrier",
      paths: [
        { id: 101, name: "Chevalier", abilities: [
          { id: 1001, name: "Coup de bouclier", level: 1, description: "Attaque avec bouclier" },
          { id: 1002, name: "Armure divine", level: 2, description: "Protection magique" },
        ]},
        { id: 102, name: "Barbare", abilities: [
          { id: 1003, name: "Rage", level: 1, description: "Augmente la puissance" },
          { id: 1004, name: "Fureur totale", level: 2, description: "Attaque surpuissante" },
        ]},
        { id: 103, name: "Paladin", abilities: [
          { id: 1005, name: "Jugement", level: 1, description: "Attaque sainte" },
          { id: 1006, name: "Vengeance divine", level: 2, description: "Contre-attaque sainte" },
        ]},
      ],
    },
  ];

  const mockHeritageAvantages = [
    { id: 1, name: "Héritage mineur", extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 0 },
    { id: 2, name: "Héritage majeur", extraAbilitiesLevel1: 1, extraAbilitiesLevel2: 1 },
    { id: 3, name: "Héritage double", extraAbilitiesLevel1: 2, extraAbilitiesLevel2: 1 },
  ];

  describe("calcExtraAbilities", () => {
    it("should return 0 abilities when no heritage is selected", () => {
      const result = calcExtraAbilities([], mockHeritageAvantages);
      expect(result.level1).toBe(0);
      expect(result.level2).toBe(0);
    });

    it("should calculate abilities from single heritage", () => {
      const result = calcExtraAbilities([{ id: 1, times: 1 }], mockHeritageAvantages);
      expect(result.level1).toBe(1);
      expect(result.level2).toBe(0);
    });

    it("should calculate abilities from multiple heritages", () => {
      const result = calcExtraAbilities(
        [
          { id: 1, times: 1 },
          { id: 2, times: 1 },
        ],
        mockHeritageAvantages
      );
      expect(result.level1).toBe(2);
      expect(result.level2).toBe(1);
    });

    it("should multiply abilities by times", () => {
      const result = calcExtraAbilities([{ id: 3, times: 2 }], mockHeritageAvantages);
      expect(result.level1).toBe(4); // 2 * 2
      expect(result.level2).toBe(2); // 1 * 2
    });

    it("should handle missing heritage gracefully", () => {
      const result = calcExtraAbilities([{ id: 999, times: 1 }], mockHeritageAvantages);
      expect(result.level1).toBe(0);
      expect(result.level2).toBe(0);
    });
  });

  describe("getBonusPathIds", () => {
    it("should return empty array when no class is selected", () => {
      const result = getBonusPathIds(null, null, mockClasses);
      expect(result).toEqual([]);
    });

    it("should return all path IDs except selected path", () => {
      const result = getBonusPathIds(1, 101, mockClasses);
      expect(result).toEqual([102, 103]);
    });

    it("should return all path IDs when no path is selected", () => {
      const result = getBonusPathIds(1, null, mockClasses);
      expect(result).toEqual([101, 102, 103]);
    });

    it("should return empty array when class not found", () => {
      const result = getBonusPathIds(999, 101, mockClasses);
      expect(result).toEqual([]);
    });
  });

  describe("getBonusAbilities", () => {
    it("should return empty array when no bonus paths", () => {
      const result = getBonusAbilities([], 1, mockClasses);
      expect(result).toEqual([]);
    });

    it("should return level 1 abilities from bonus paths", () => {
      const result = getBonusAbilities([102, 103], 1, mockClasses);
      expect(result).toHaveLength(2);
      expect(result.map((a) => a.name)).toContain("Rage");
      expect(result.map((a) => a.name)).toContain("Jugement");
    });

    it("should return level 2 abilities from bonus paths", () => {
      const result = getBonusAbilities([102, 103], 2, mockClasses);
      expect(result).toHaveLength(2);
      expect(result.map((a) => a.name)).toContain("Fureur totale");
      expect(result.map((a) => a.name)).toContain("Vengeance divine");
    });

    it("should not include selected path abilities", () => {
      const result = getBonusAbilities([102, 103], 1, mockClasses);
      expect(result.map((a) => a.name)).not.toContain("Coup de bouclier");
    });
  });

  describe("Integration scenarios", () => {
    it("should handle complete bonus ability selection flow", () => {
      // Joueur choisit Guerrier + Chevalier
      const selectedClass = 1;
      const selectedPath = 101;

      // Joueur achète héritage majeur (1 niveau 1 + 1 niveau 2)
      const heritage = [{ id: 2, times: 1 }];

      // Calculer les capacités bonus
      const extraAbilities = calcExtraAbilities(heritage, mockHeritageAvantages);
      const bonusPathIds = getBonusPathIds(selectedClass, selectedPath, mockClasses);
      const level1Abilities = getBonusAbilities(bonusPathIds, 1, mockClasses);
      const level2Abilities = getBonusAbilities(bonusPathIds, 2, mockClasses);

      // Vérifications
      expect(extraAbilities.level1).toBe(1);
      expect(extraAbilities.level2).toBe(1);
      expect(bonusPathIds).toEqual([102, 103]);
      expect(level1Abilities).toHaveLength(2);
      expect(level2Abilities).toHaveLength(2);
    });

    it("should handle no bonus abilities scenario", () => {
      const selectedClass = 1;
      const selectedPath = 101;
      const heritage: any[] = [];

      const extraAbilities = calcExtraAbilities(heritage, mockHeritageAvantages);
      expect(extraAbilities.level1).toBe(0);
      expect(extraAbilities.level2).toBe(0);
    });
  });
});

// Helper functions (copied from StepVoieEtDons.tsx for testing)
function calcExtraAbilities(heritageAvantages: { id: number; times: number }[], heritageData: any[]): { level1: number; level2: number } {
  let level1 = 0;
  let level2 = 0;

  heritageAvantages.forEach((h) => {
    const ha = heritageData.find((x) => x.id === h.id);
    if (ha) {
      level1 += (ha.extraAbilitiesLevel1 ?? 0) * h.times;
      level2 += (ha.extraAbilitiesLevel2 ?? 0) * h.times;
    }
  });

  return { level1, level2 };
}

function getBonusPathIds(classId: number | null, selectedPathId: number | null, classes: any[]): number[] {
  if (!classId) return [];
  const cls = classes.find((c) => c.id === classId);
  if (!cls || !cls.paths) return [];

  const allPathIds = cls.paths.map((p: any) => p.id);
  return allPathIds.filter((id: number) => id !== selectedPathId);
}

function getBonusAbilities(bonusPathIds: number[], level: 1 | 2, classes: any[]): any[] {
  const abilities: any[] = [];

  bonusPathIds.forEach((pathId) => {
    classes.forEach((cls) => {
      if (cls.paths) {
        const path = cls.paths.find((p: any) => p.id === pathId);
        if (path && path.abilities) {
          const filteredAbilities = path.abilities.filter((a: any) => a.level === level);
          abilities.push(...filteredAbilities);
        }
      }
    });
  });

  return abilities;
}
