import { useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Loader2, ChevronLeft, Link as LinkIcon } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function EncyclopediaRaces() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [selectedRace, setSelectedRace] = useState<number | null>(null);
  const pageSize = 10;

  // Récupérer les races avec pagination
  const { data: racesData, isLoading: isLoadingRaces } =
    trpc.encyclopedia.getPaginatedByCategory.useQuery(
      {
        category: "race",
        limit: pageSize,
        offset: (page - 1) * pageSize,
      },
      { enabled: true }
    );

  // Récupérer les détails de la race sélectionnée
  const { data: selectedRaceData, isLoading: isLoadingDetail } =
    trpc.encyclopedia.getById.useQuery(
      { id: selectedRace || 0 },
      { enabled: !!selectedRace }
    );

  // Récupérer les entrées liées (classes compatibles, dons disponibles, etc.)
  const { data: relatedEntries } =
    trpc.encyclopediaRelations.getRelatedEntries.useQuery(
      { entryId: selectedRace || 0 },
      { enabled: !!selectedRace }
    );

  const races = racesData?.items || [];
  const totalPages = Math.ceil((racesData?.total || 0) / pageSize);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* En-tête */}
        <div>
          <h1 className="text-3xl font-bold">Encyclopédie - Races</h1>
          <p className="text-muted-foreground mt-2">
            Explorez les races disponibles et leurs caractéristiques
          </p>
        </div>

        {/* Barre de recherche */}
        <div className="flex gap-2">
          <Input
            placeholder="Rechercher une race..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="flex-1"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Liste des races */}
          <div className="lg:col-span-1 space-y-4">
            <h2 className="text-xl font-semibold">Races ({racesData?.total || 0})</h2>

            {isLoadingRaces ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : races.length === 0 ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>Aucune race trouvée</AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-2">
                {races.map((race: any) => (
                  <button
                    key={race.id}
                    onClick={() => setSelectedRace(race.id)}
                    className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${
                      selectedRace === race.id
                        ? "border-primary bg-primary/10"
                        : "border-transparent hover:bg-muted"
                    }`}
                  >
                    <div className="font-medium">{race.nom}</div>
                    <div className="text-sm text-muted-foreground">
                      {(race as any).factionRequise || "Tous"}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex gap-2 justify-center pt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                >
                  Précédent
                </Button>
                <span className="py-2 text-sm">
                  Page {page} / {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </div>

          {/* Détails de la race */}
          <div className="lg:col-span-2">
            {!selectedRace ? (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-muted-foreground text-center py-8">
                    Sélectionnez une race pour voir les détails
                  </p>
                </CardContent>
              </Card>
            ) : isLoadingDetail ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : selectedRaceData ? (
              <div className="space-y-4">
                {/* Informations principales */}
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{selectedRaceData.nom}</CardTitle>
                        <CardDescription>{selectedRaceData.description}</CardDescription>
                      </div>
                      <Badge>{(selectedRaceData as any).factionRequise || "Tous"}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Propriétés JSON */}                    {selectedClassData.proprietes && selectedClassData.proprietes !== null && (electedRaceData.proprietes !== null && (
                      <div>
                        <h3 className="font-semibold mb-2">Caractéristiques</h3>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries((selectedRaceData.proprietes as Record<string, any>) || {}).map(
                            ([key, value]: [string, any]) => (
                              <div key={key} className="text-sm">
                                <span className="font-medium">{key}:</span>{" "}
                                <span className="text-muted-foreground" suppressHydrationWarning>
                                  {typeof value === "object"
                                    ? JSON.stringify(value)
                                    : String(value)}
                                </span>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Entrées liées */}
                {relatedEntries && (relatedEntries as any[]).length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <LinkIcon className="h-4 w-4" />
                        Entrées Liées
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {(relatedEntries as any[]).map((entry: any) => (
                          <div
                            key={entry.id}
                            className="p-2 rounded border hover:bg-muted cursor-pointer transition-colors"
                            onClick={() => setSelectedRace(entry.id)}
                          >
                            <div className="font-medium text-sm">{entry.nom}</div>
                            <div className="text-xs text-muted-foreground">
                              {entry.categorie}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
