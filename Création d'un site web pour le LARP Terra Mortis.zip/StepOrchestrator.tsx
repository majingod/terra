import { useState, useMemo } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Orchestrateur des étapes du créateur de personnage V2
 * Gère l'ordre des étapes et la propagation des bonus d'Héritage
 */

export interface StepConfig {
  id: number;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  component: React.ComponentType<any>;
  canSkip?: boolean;
  dependsOn?: number[]; // IDs des étapes dont celle-ci dépend
}

export interface StepOrchestrationProps {
  steps: StepConfig[];
  onStepChange: () => void;
  onComplete: () => void;
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus: any;
}

export function StepOrchestrator({
  steps,
  onStepChange,
  onComplete,
  charData,
  onCharDataChange,
  heritageBonus,
}: StepOrchestrationProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const currentStep = steps[currentStepIndex];
  const isFirstStep = currentStepIndex === 0;
  const isLastStep = currentStepIndex === steps.length - 1;

  // Vérifier si l'étape actuelle peut être complétée
  const canProceed = useMemo(() => {
    // Logique de validation spécifique à chaque étape
    switch (currentStep?.id) {
      case 1: // Identité
        return charData.name && charData.name.trim().length > 0;
      case 2: // Faction
        return charData.faction !== null;
      case 3: // Race
        return charData.raceId !== null;
      case 4: // Héritage
        return true; // Héritage est optionnel
      case 5: // Classe
        return charData.classId !== null && charData.classPathId !== null;
      case 6: // Caractéristiques
        return charData.puissance + charData.resistance + charData.esprit === 6;
      case 7: // Dons
        return charData.selectedDons.length > 0;
      case 8: // Compétences
        return charData.competenceId !== null;
      case 9: // Capacités bonus
        return charData.selectedBonusAbilities.length >= heritageBonus.extraAbilitiesLevel1;
      case 10: // Résumé
        return true;
      default:
        return true;
    }
  }, [currentStep, charData, heritageBonus]);

  const handleNext = () => {
    if (!canProceed) return;

    onStepChange();

    if (isLastStep) {
      onComplete();
    } else {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (isFirstStep) return;
    setCurrentStepIndex((prev) => prev - 1);
  };

  const CurrentStepComponent = currentStep?.component;

  return (
    <div className="space-y-6">
      {/* Indicateur de progression */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">
            Étape {currentStepIndex + 1} / {steps.length}
          </span>
        </div>
        <div className="flex gap-1">
          {steps.map((step, idx) => (
            <div
              key={step.id}
              className={`h-2 rounded-full transition-all ${
                idx <= currentStepIndex
                  ? "bg-primary w-4"
                  : "bg-muted w-2"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Titre de l'étape */}
      <div className="space-y-2">
        <h2 className="text-2xl font-bold">{currentStep?.label}</h2>
        {heritageBonus && Object.values(heritageBonus).some((v: any) => v > 0) && (
          <div className="text-sm text-amber-600 bg-amber-50 p-2 rounded">
            ✨ Bonus d'Héritage actifs : {JSON.stringify(heritageBonus)}
          </div>
        )}
      </div>

      {/* Contenu de l'étape */}
      {CurrentStepComponent && (
        <CurrentStepComponent
          charData={charData}
          onCharDataChange={onCharDataChange}
          heritageBonus={heritageBonus}
        />
      )}

      {/* Boutons de navigation */}
      <div className="flex gap-4 justify-between pt-6">
        <Button
          variant="outline"
          onClick={handlePrev}
          disabled={isFirstStep}
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Précédent
        </Button>

        <Button
          onClick={handleNext}
          disabled={!canProceed}
        >
          {isLastStep ? "Valider" : "Suivant"}
          {!isLastStep && <ChevronRight className="w-4 h-4 ml-2" />}
        </Button>
      </div>
    </div>
  );
}
