#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Trouver la fin de la grille des races et ajouter l'interface de choix
old_code = '''      </div>
    </div>
  );
}

function StepClasse({ data, onChange, classes }: { data: CharData; onChange: (d: Partial<CharData>) => void; classes: any[] }) {'''

new_code = '''      </div>

      {/* Bonus racial Humain */}
      {data.raceId && filtered.find((r) => r.id === data.raceId)?.name === "Humain" && (
        <div className="p-5 rounded-xl border border-border/40 bg-card/30 space-y-3">
          <div>
            <h3 className="font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>Choisissez votre bonus racial</h3>
            <p className="text-xs text-muted-foreground">Sélectionnez si votre bonus racial (+1) s'applique aux PV ou au Mana.</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onChange({ humanBonusType: "pv" })}
              className="flex-1 p-3 rounded-lg border transition-all font-heading font-semibold"
              style={{
                background: data.humanBonusType === "pv" ? "oklch(0.45 0.15 140 / 0.2)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === "pv" ? "oklch(0.45 0.15 140 / 0.6)" : "oklch(0.28 0.03 260)",
                color: data.humanBonusType === "pv" ? "oklch(0.65 0.2 140)" : "oklch(0.82 0.2 85)",
              }}
            >
              +1 PV
            </button>
            <button
              onClick={() => onChange({ humanBonusType: "pm" })}
              className="flex-1 p-3 rounded-lg border transition-all font-heading font-semibold"
              style={{
                background: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240 / 0.2)" : "oklch(0.16 0.02 260)",
                borderColor: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240 / 0.6)" : "oklch(0.28 0.03 260)",
                color: data.humanBonusType === "pm" ? "oklch(0.55 0.18 240)" : "oklch(0.82 0.2 85)",
              }}
            >
              +1 PM
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StepClasse({ data, onChange, classes }: { data: CharData; onChange: (d: Partial<CharData>) => void; classes: any[] }) {'''

content = content.replace(old_code, new_code)
print("✓ Interface de choix du bonus racial Humain ajoutée")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
