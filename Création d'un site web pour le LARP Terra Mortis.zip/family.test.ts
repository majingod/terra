import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { families, familyProfiles, familySessions, users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Family Management", () => {
  let db: any;
  let testUserId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Créer un utilisateur de test
    const userResult = await db.insert(users).values({
      openId: "test-family-" + Date.now(),
      name: "Test Parent",
      email: "test@family.com",
      role: "user",
      loginMethod: "oauth",
    });
    testUserId = userResult[0].insertId as number;
  });

  afterAll(async () => {
    if (!db) return;

    // Nettoyer les données de test
    const familyRecords = await db
      .select()
      .from(families)
      .where(eq(families.createdBy, testUserId));

    for (const family of familyRecords) {
      // Supprimer les sessions
      await db
        .delete(familySessions)
        .where(eq(familySessions.familyId, family.id));

      // Supprimer les profils
      await db
        .delete(familyProfiles)
        .where(eq(familyProfiles.familyId, family.id));

      // Supprimer la famille
      await db.delete(families).where(eq(families.id, family.id));
    }

    // Supprimer l'utilisateur
    await db.delete(users).where(eq(users.id, testUserId));
  });

  it("should create a family with parent profile", async () => {
    const familyName = "Test Family " + Date.now();

    const familyResult = await db.insert(families).values({
      name: familyName,
      createdBy: testUserId,
    });

    const familyId = familyResult[0].insertId as number;
    expect(familyId).toBeGreaterThan(0);

    // Vérifier que la famille a été créée
    const family = await db
      .select()
      .from(families)
      .where(eq(families.id, familyId))
      .limit(1);

    expect(family.length).toBe(1);
    expect(family[0].name).toBe(familyName);
    expect(family[0].createdBy).toBe(testUserId);
  });

  it("should create parent and child profiles", async () => {
    const familyName = "Family with Children " + Date.now();

    const familyResult = await db.insert(families).values({
      name: familyName,
      createdBy: testUserId,
    });

    const familyId = familyResult[0].insertId as number;

    // Créer profil parent
    const parentResult = await db.insert(familyProfiles).values({
      familyId: familyId,
      name: "Parent",
      role: "parent",
      isChild: false,
      xpPermanent: 0,
    });

    const parentId = parentResult[0].insertId as number;

    // Créer profil enfant
    const childResult = await db.insert(familyProfiles).values({
      familyId: familyId,
      name: "Child",
      role: "child",
      isChild: true,
      xpPermanent: 0,
    });

    const childId = childResult[0].insertId as number;

    // Vérifier les profils
    const profiles = await db
      .select()
      .from(familyProfiles)
      .where(eq(familyProfiles.familyId, familyId));

    expect(profiles.length).toBe(2);
    expect(profiles.some((p: any) => p.role === "parent")).toBe(true);
    expect(profiles.some((p: any) => p.role === "child")).toBe(true);
  });

  it("should create and update family session", async () => {
    const familyName = "Family with Session " + Date.now();

    const familyResult = await db.insert(families).values({
      name: familyName,
      createdBy: testUserId,
    });

    const familyId = familyResult[0].insertId as number;

    // Créer profil
    const profileResult = await db.insert(familyProfiles).values({
      familyId: familyId,
      name: "Profile",
      role: "parent",
      isChild: false,
      xpPermanent: 0,
    });

    const profileId = profileResult[0].insertId as number;

    // Créer session
    const sessionResult = await db.insert(familySessions).values({
      familyId: familyId,
      activeProfileId: profileId,
      userId: testUserId,
    });

    const sessionId = sessionResult[0].insertId as number;
    expect(sessionId).toBeGreaterThan(0);

    // Vérifier la session
    const session = await db
      .select()
      .from(familySessions)
      .where(eq(familySessions.id, sessionId))
      .limit(1);

    expect(session.length).toBe(1);
    expect(session[0].activeProfileId).toBe(profileId);
  });

  it("should track XP permanent per profile", async () => {
    const familyName = "Family with XP " + Date.now();

    const familyResult = await db.insert(families).values({
      name: familyName,
      createdBy: testUserId,
    });

    const familyId = familyResult[0].insertId as number;

    // Créer profil avec XP
    const profileResult = await db.insert(familyProfiles).values({
      familyId: familyId,
      name: "Profile with XP",
      role: "parent",
      isChild: false,
      xpPermanent: 50,
    });

    const profileId = profileResult[0].insertId as number;

    // Vérifier le XP
    const profile = await db
      .select()
      .from(familyProfiles)
      .where(eq(familyProfiles.id, profileId))
      .limit(1);

    expect(profile[0].xpPermanent).toBe(50);
  });

  it("should restrict child profiles from certain features", async () => {
    const familyName = "Family with Child Restrictions " + Date.now();

    const familyResult = await db.insert(families).values({
      name: familyName,
      createdBy: testUserId,
    });

    const familyId = familyResult[0].insertId as number;

    // Créer profil enfant
    const childResult = await db.insert(familyProfiles).values({
      familyId: familyId,
      name: "Child",
      role: "child",
      isChild: true,
      xpPermanent: 0,
    });

    const childId = childResult[0].insertId as number;

    // Vérifier que isChild est true
    const profile = await db
      .select()
      .from(familyProfiles)
      .where(eq(familyProfiles.id, childId))
      .limit(1);

    expect(profile[0].isChild).toBe(true);
  });
});
