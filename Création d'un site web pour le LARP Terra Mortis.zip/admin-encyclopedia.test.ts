import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { races, classes, dons, competences } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Admin Encyclopedia Mutations", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  describe("Races", () => {
    it("should create a new race", async () => {
      const timestamp = Date.now();
      const newRace = {
        name: `Test Race Create ${timestamp}`,
        faction: "Sanctum" as const,
        description: "A test race",
        bonuses: ["Bonus 1"],
        maluses: ["Malus 1"],
        abilities: [{ name: "Ability 1", description: "Test ability" }],
        physicalDescription: "Physical description",
        startingLanguages: ["Language 1"],
        pvBonus: 5,
        manaBonus: 3,
        luteBonus: 2,
        pvMalus: 0,
      };

      await db.insert(races).values(newRace);

      const created = await db
        .select()
        .from(races)
        .where(eq(races.name, `Test Race Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Race Create ${timestamp}`);
      expect(created[0].faction).toBe("Sanctum");
      expect(created[0].pvBonus).toBe(5);
    });

    it("should update an existing race", async () => {
      const newRace = {
        name: "Test Race Update",
        faction: "Légion" as const,
        description: "Original description",
        bonuses: [],
        maluses: [],
        abilities: [],
        physicalDescription: "",
        startingLanguages: [],
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
        pvMalus: 0,
      };

      await db.insert(races).values(newRace);
      const created = await db
        .select()
        .from(races)
        .where(eq(races.name, "Test Race Update"));
      const raceId = created[0].id;

      await db
        .update(races)
        .set({ description: "Updated description", pvBonus: 10 })
        .where(eq(races.id, raceId));

      const updated = await db
        .select()
        .from(races)
        .where(eq(races.id, raceId));

      expect(updated[0].description).toBe("Updated description");
      expect(updated[0].pvBonus).toBe(10);
    });

    it("should delete a race", async () => {
      const newRace = {
        name: "Test Race Delete",
        faction: "Tous" as const,
        description: "To be deleted",
        bonuses: [],
        maluses: [],
        abilities: [],
        physicalDescription: "",
        startingLanguages: [],
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
        pvMalus: 0,
      };

      await db.insert(races).values(newRace);
      const created = await db
        .select()
        .from(races)
        .where(eq(races.name, "Test Race Delete"));
      const raceId = created[0].id;

      await db.delete(races).where(eq(races.id, raceId));

      const deleted = await db
        .select()
        .from(races)
        .where(eq(races.id, raceId));

      expect(deleted).toHaveLength(0);
    });
  });

  describe("Classes", () => {
    it("should create a new class", async () => {
      const timestamp = Date.now();
      const newClass = {
        name: `Test Class Create ${timestamp}`,
        faction: "Sanctum" as const,
        description: "A test class",
        basePv: 15,
        baseMana: 10,
        baseAbilities: [{ name: "Ability 1", description: "Test ability" }],
        specialRules: ["Rule 1"],
        requiresWeapon: true,
      };

      await db.insert(classes).values(newClass);

      const created = await db
        .select()
        .from(classes)
        .where(eq(classes.name, `Test Class Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Class Create ${timestamp}`);
      expect(created[0].basePv).toBe(15);
    });

    it("should update an existing class", async () => {
      const newClass = {
        name: "Test Class Update",
        faction: "Légion" as const,
        description: "Original",
        basePv: 10,
        baseMana: 5,
        baseAbilities: [],
        specialRules: [],
        requiresWeapon: false,
      };

      await db.insert(classes).values(newClass);
      const created = await db
        .select()
        .from(classes)
        .where(eq(classes.name, "Test Class Update"));
      const classId = created[0].id;

      await db
        .update(classes)
        .set({ description: "Updated", basePv: 20 })
        .where(eq(classes.id, classId));

      const updated = await db
        .select()
        .from(classes)
        .where(eq(classes.id, classId));

      expect(updated[0].description).toBe("Updated");
      expect(updated[0].basePv).toBe(20);
    });

    it("should delete a class", async () => {
      const newClass = {
        name: "Test Class Delete",
        faction: "Tous" as const,
        description: "To be deleted",
        basePv: 10,
        baseMana: 5,
        baseAbilities: [],
        specialRules: [],
        requiresWeapon: false,
      };

      await db.insert(classes).values(newClass);
      const created = await db
        .select()
        .from(classes)
        .where(eq(classes.name, "Test Class Delete"));
      const classId = created[0].id;

      await db.delete(classes).where(eq(classes.id, classId));

      const deleted = await db
        .select()
        .from(classes)
        .where(eq(classes.id, classId));

      expect(deleted).toHaveLength(0);
    });
  });

  describe("Dons", () => {
    it("should create a new don", async () => {
      const timestamp = Date.now();
      const newDon = {
        name: `Test Don Create ${timestamp}`,
        description: "A test don",
        canStack: true,
        maxStacks: 3,
        pvBonus: 2,
        manaBonus: 1,
        luteBonus: 0,
      };

      await db.insert(dons).values(newDon);

      const created = await db
        .select()
        .from(dons)
        .where(eq(dons.name, `Test Don Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Don Create ${timestamp}`);
      expect(created[0].canStack).toBe(true);
      expect(created[0].maxStacks).toBe(3);
    });

    it("should update an existing don", async () => {
      const newDon = {
        name: "Test Don Update",
        description: "Original",
        canStack: false,
        maxStacks: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
      };

      await db.insert(dons).values(newDon);
      const created = await db
        .select()
        .from(dons)
        .where(eq(dons.name, "Test Don Update"));
      const donId = created[0].id;

      await db
        .update(dons)
        .set({ description: "Updated", pvBonus: 5 })
        .where(eq(dons.id, donId));

      const updated = await db
        .select()
        .from(dons)
        .where(eq(dons.id, donId));

      expect(updated[0].description).toBe("Updated");
      expect(updated[0].pvBonus).toBe(5);
    });

    it("should delete a don", async () => {
      const newDon = {
        name: "Test Don Delete",
        description: "To be deleted",
        canStack: false,
        maxStacks: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
      };

      await db.insert(dons).values(newDon);
      const created = await db
        .select()
        .from(dons)
        .where(eq(dons.name, "Test Don Delete"));
      const donId = created[0].id;

      await db.delete(dons).where(eq(dons.id, donId));

      const deleted = await db
        .select()
        .from(dons)
        .where(eq(dons.id, donId));

      expect(deleted).toHaveLength(0);
    });
  });

  describe("Competences", () => {
    it("should create a new competence", async () => {
      const timestamp = Date.now();
      const newCompetence = {
        name: `Test Competence Create ${timestamp}`,
        category: "simple" as const,
        description: "A test competence",
        baseAdvantage: "Advantage 1",
        advancedAdvantage: "Advanced 1",
        requiredMaterial: "Material 1",
        isAdultOnly: false,
      };

      await db.insert(competences).values(newCompetence);

      const created = await db
        .select()
        .from(competences)
        .where(eq(competences.name, `Test Competence Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Competence Create ${timestamp}`);
      expect(created[0].category).toBe("simple");
    });

    it("should update an existing competence", async () => {
      const newCompetence = {
        name: "Test Competence Update",
        category: "artisanat" as const,
        description: "Original",
        baseAdvantage: "Base",
        advancedAdvantage: null,
        requiredMaterial: null,
        isAdultOnly: false,
      };

      await db.insert(competences).values(newCompetence);
      const created = await db
        .select()
        .from(competences)
        .where(eq(competences.name, "Test Competence Update"));
      const competenceId = created[0].id;

      await db
        .update(competences)
        .set({ description: "Updated", baseAdvantage: "Updated Base" })
        .where(eq(competences.id, competenceId));

      const updated = await db
        .select()
        .from(competences)
        .where(eq(competences.id, competenceId));

      expect(updated[0].description).toBe("Updated");
      expect(updated[0].baseAdvantage).toBe("Updated Base");
    });

    it("should delete a competence", async () => {
      const newCompetence = {
        name: "Test Competence Delete",
        category: "simple" as const,
        description: "To be deleted",
        baseAdvantage: "Base",
        advancedAdvantage: null,
        requiredMaterial: null,
        isAdultOnly: false,
      };

      await db.insert(competences).values(newCompetence);
      const created = await db
        .select()
        .from(competences)
        .where(eq(competences.name, "Test Competence Delete"));
      const competenceId = created[0].id;

      await db.delete(competences).where(eq(competences.id, competenceId));

      const deleted = await db
        .select()
        .from(competences)
        .where(eq(competences.id, competenceId));

      expect(deleted).toHaveLength(0);
    });
  });

  describe("Heritages", () => {
    it("should create a new heritage", async () => {
      const { heritageAvantages } = await import("../drizzle/schema");
      const timestamp = Date.now();

      const newHeritage = {
        name: `Test Heritage Create ${timestamp}`,
        description: "A test heritage",
        xpCost: 5,
        maxTimes: 2,
        pvBonus: 3,
        manaBonus: 2,
        luteBonus: 1,
        moneyBonus: "100 pièces",
      };

      await db.insert(heritageAvantages).values(newHeritage);

      const created = await db
        .select()
        .from(heritageAvantages)
        .where(eq(heritageAvantages.name, `Test Heritage Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Heritage Create ${timestamp}`);
      expect(created[0].xpCost).toBe(5);
      expect(created[0].pvBonus).toBe(3);
    });

    it("should update an existing heritage", async () => {
      const { heritageAvantages } = await import("../drizzle/schema");

      const newHeritage = {
        name: "Test Heritage Update",
        description: "Original",
        xpCost: 3,
        maxTimes: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
        moneyBonus: null,
      };

      await db.insert(heritageAvantages).values(newHeritage);
      const created = await db
        .select()
        .from(heritageAvantages)
        .where(eq(heritageAvantages.name, "Test Heritage Update"));
      const heritageId = created[0].id;

      await db
        .update(heritageAvantages)
        .set({ description: "Updated", xpCost: 10 })
        .where(eq(heritageAvantages.id, heritageId));

      const updated = await db
        .select()
        .from(heritageAvantages)
        .where(eq(heritageAvantages.id, heritageId));

      expect(updated[0].description).toBe("Updated");
      expect(updated[0].xpCost).toBe(10);
    });

    it("should delete a heritage", async () => {
      const { heritageAvantages } = await import("../drizzle/schema");

      const newHeritage = {
        name: "Test Heritage Delete",
        description: "To be deleted",
        xpCost: 2,
        maxTimes: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
        moneyBonus: null,
      };

      await db.insert(heritageAvantages).values(newHeritage);
      const created = await db
        .select()
        .from(heritageAvantages)
        .where(eq(heritageAvantages.name, "Test Heritage Delete"));
      const heritageId = created[0].id;

      await db.delete(heritageAvantages).where(eq(heritageAvantages.id, heritageId));

      const deleted = await db
        .select()
        .from(heritageAvantages)
        .where(eq(heritageAvantages.id, heritageId));

      expect(deleted).toHaveLength(0);
    });
  });

  describe("Desavantages", () => {
    it("should create a new desavantage", async () => {
      const { desavantages } = await import("../drizzle/schema");
      const timestamp = Date.now();

      const newDesavantage = {
        name: `Test Desavantage Create ${timestamp}`,
        description: "A test desavantage",
        xpGain: 5,
        xpType: "temporaire" as const,
        forbiddenClasses: ["Guerrier"],
      };

      await db.insert(desavantages).values(newDesavantage);

      const created = await db
        .select()
        .from(desavantages)
        .where(eq(desavantages.name, `Test Desavantage Create ${timestamp}`));

      expect(created).toHaveLength(1);
      expect(created[0].name).toBe(`Test Desavantage Create ${timestamp}`);
      expect(created[0].xpGain).toBe(5);
      expect(created[0].xpType).toBe("temporaire");
    });

    it("should update an existing desavantage", async () => {
      const { desavantages } = await import("../drizzle/schema");

      const newDesavantage = {
        name: "Test Desavantage Update",
        description: "Original",
        xpGain: 3,
        xpType: "permanent" as const,
        forbiddenClasses: [],
      };

      await db.insert(desavantages).values(newDesavantage);
      const created = await db
        .select()
        .from(desavantages)
        .where(eq(desavantages.name, "Test Desavantage Update"));
      const desavantageId = created[0].id;

      await db
        .update(desavantages)
        .set({ description: "Updated", xpGain: 8 })
        .where(eq(desavantages.id, desavantageId));

      const updated = await db
        .select()
        .from(desavantages)
        .where(eq(desavantages.id, desavantageId));

      expect(updated[0].description).toBe("Updated");
      expect(updated[0].xpGain).toBe(8);
    });

    it("should delete a desavantage", async () => {
      const { desavantages } = await import("../drizzle/schema");

      const newDesavantage = {
        name: "Test Desavantage Delete",
        description: "To be deleted",
        xpGain: 2,
        xpType: "temporaire" as const,
        forbiddenClasses: [],
      };

      await db.insert(desavantages).values(newDesavantage);
      const created = await db
        .select()
        .from(desavantages)
        .where(eq(desavantages.name, "Test Desavantage Delete"));
      const desavantageId = created[0].id;

      await db.delete(desavantages).where(eq(desavantages.id, desavantageId));

      const deleted = await db
        .select()
        .from(desavantages)
        .where(eq(desavantages.id, desavantageId));

      expect(deleted).toHaveLength(0);
    });
  });
});
