import { ChevronRight, Skull, Sword } from "lucide-react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const combatSections = [
  {
    title: "Points de Vie (PV)",
    icon: "❤️",
    content: `Les Points de Vie représentent la résistance physique de votre personnage. Ils sont calculés selon la formule : PV = PV de base (classe) + Résistance × 2 + bonus raciaux + bonus des dons. Lorsque vos PV tombent à 0, vous êtes à terre et en état d'agonie.`,
  },
  {
    title: "Agonie et Mort",
    icon: "💀",
    content: `Quand un personnage tombe à 0 PV, il est en agonie. Il doit s'allonger au sol et ne peut plus agir. Un allié peut le stabiliser avec une compétence de soin. Sans aide, le personnage meurt après 5 minutes. La mort permanente est rare et nécessite des circonstances spéciales.`,
  },
  {
    title: "Lutte",
    icon: "⚔️",
    content: `La Lutte représente la capacité de votre personnage à résister aux effets de contrôle (immobilisation, renversement, etc.). Elle est calculée : Lutte = Puissance × 2 + bonus raciaux + bonus des dons. Quand un effet de contrôle vous cible, vous pouvez dépenser votre Lutte pour y résister.`,
  },
  {
    title: "Sauvegardes",
    icon: "🛡️",
    content: `Les Sauvegardes permettent de résister à certains effets négatifs (poison, malédiction, etc.). Elles sont calculées : Sauvegardes = Esprit + bonus divers. Chaque sauvegarde utilisée est perdue jusqu'au prochain repos.`,
  },
  {
    title: "Caractéristiques",
    icon: "📊",
    content: `Chaque personnage possède 3 caractéristiques : Puissance (force physique), Résistance (endurance), Esprit (force mentale). Chaque caractéristique va de 1 à 5. Vous disposez de 6 points à répartir entre les 3 caractéristiques lors de la création.`,
  },
  {
    title: "Dommages",
    icon: "🗡️",
    content: `Les dommages sont annoncés à voix haute lors des frappes. Le format est : "[Nombre] dommages". Par exemple "3 dommages". Les dommages spéciaux (magiques, feu, etc.) sont annoncés avec leur type. Les armures peuvent réduire les dommages reçus.`,
  },
  {
    title: "Effets de combat",
    icon: "✨",
    content: `Plusieurs effets peuvent survenir en combat : Immobilisé (ne peut plus bouger), Renversé (doit s'allonger), Désarmé (perd son arme), Aveuglé (ne peut plus voir), Silencieux (ne peut plus parler). Ces effets ont une durée limitée ou peuvent être résistés avec la Lutte.`,
  },
  {
    title: "Règles de sécurité",
    icon: "🔒",
    content: `Les frappes doivent être contrôlées et ne jamais viser la tête, le cou, la colonne vertébrale ou les zones génitales. Les frappes doivent être claires mais sans force excessive. En cas de blessure réelle, criez "HORS-JEU" pour arrêter le jeu. La sécurité des joueurs prime toujours sur le jeu.`,
  },
  {
    title: "Appels de combat",
    icon: "📢",
    content: `Plusieurs appels standardisés sont utilisés : "Résiste" (immunité à un effet), "Esquive" (évite une attaque), "Parade" (bloque une attaque avec une arme), "Hors-Jeu" (urgence réelle), "En jeu" (retour au jeu), "Pause" (pause de jeu).`,
  },
];

export default function Combat() {
  return (
    <div className="min-h-screen py-12">
      <Breadcrumbs items={[
        { label: "Règles", href: "/regles" },
        { label: "Combat & Règles", active: true },
      ]} />
      <div className="container max-w-4xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.65 0.18 45 / 0.15)", border: "2px solid oklch(0.65 0.18 45 / 0.4)" }}
            >
              <Sword className="w-8 h-8" style={{ color: "oklch(0.82 0.2 85)" }} />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Règles de Combat
          </h1>
          <div className="flex items-center justify-center gap-4 my-4">
            <div className="h-px w-24" style={{ background: "linear-gradient(to right, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
            <Skull className="w-4 h-4" style={{ color: "oklch(0.65 0.18 45)" }} />
            <div className="h-px w-24" style={{ background: "linear-gradient(to left, transparent, oklch(0.65 0.18 45 / 0.6))" }} />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Maîtrisez les règles de combat de Terra Mortis pour survivre dans les terres maudites de Stukely-Sud.
          </p>
        </div>

        {/* Formulas summary */}
        <div
          className="p-6 rounded-xl border mb-8"
          style={{ background: "oklch(0.65 0.18 45 / 0.08)", borderColor: "oklch(0.65 0.18 45 / 0.3)" }}
        >
          <h2 className="font-heading font-semibold text-lg mb-4" style={{ color: "oklch(0.82 0.2 85)" }}>
            Formules de calcul
          </h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {[
              { label: "PV", formula: "PV base (classe) + Résistance × 2 + bonus" },
              { label: "Mana", formula: "Mana base (classe) + Esprit × 2 + bonus" },
              { label: "Lutte", formula: "Puissance × 2 + bonus raciaux + dons" },
              { label: "Sauvegardes", formula: "Esprit + bonus divers" },
            ].map((item) => (
              <div
                key={item.label}
                className="p-3 rounded-lg"
                style={{ background: "oklch(0.22 0.025 260)", border: "1px solid oklch(0.28 0.03 260)" }}
              >
                <span className="font-heading font-bold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>{item.label} = </span>
                <span className="text-sm text-foreground/75">{item.formula}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Combat sections */}
        <div className="space-y-4">
          {combatSections.map((section, i) => (
            <div
              key={i}
              className="p-6 rounded-xl border border-border/40 bg-card/30 hover:border-border/60 transition-all"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">{section.icon}</span>
                <h2 className="text-xl font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
                  {section.title}
                </h2>
              </div>
              <p className="text-foreground/80 leading-relaxed">{section.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
