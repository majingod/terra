import { cn } from "@/lib/utils";

interface FactionBadgeProps {
  faction: "Sanctum" | "Légion";
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function FactionBadge({ faction, className, size = "md" }: FactionBadgeProps) {
  const isSanctum = faction === "Sanctum";
  const baseClasses = "faction-badge font-cinzel font-semibold";
  
  const sizeClasses = {
    sm: "px-2 py-0.5 text-xs",
    md: "px-3 py-1 text-sm",
    lg: "px-4 py-2 text-base",
  };
  
  const factionClasses = isSanctum ? "faction-badge-sanctum" : "faction-badge-legion";
  
  return (
    <span className={cn(baseClasses, sizeClasses[size], factionClasses, className)}>
      {faction}
    </span>
  );
}
