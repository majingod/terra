import { describe, it, expect } from "vitest";

// ─── Mock data ───────────────────────────────────────────────────────────────
const mockHeritageAvantages = [
  { id: 1, name: "Sang noble", xpCost: 2, maxTimes: 1, extraDons: 0 },
  { id: 2, name: "Héritage magique", xpCost: 3, maxTimes: 2, extraDons: 1 },
  { id: 3, name: "Ascendance guerrière", xpCost: 1, maxTimes: 3, extraDons: 0 },
];

const mockClasses = [
  {
    id: 1,
    name: "Guerrier",
    paths: [
      {
        id: 101,
        name: "Chevalier",
        description: "Maître du combat au corps à corps",
        abilities: [
          { id: 1001, level: 1, name: "Coup puissant" },
          { id: 1002, level: 2, name: "Armure renforcée" },
        ],
      },
      {
        id: 102,
        name: "Berserker",
        description: "Guerrier enragé",
        abilities: [
          { id: 1003, level: 1, name: "Rage" },
          { id: 1004, level: 3, name: "Frappe dévastatrice" },
        ],
      },
    ],
  },
];

// ─── Helper functions ─────────────────────────────────────────────────────────

/**
 * Calcule le nombre maximum de dons autorisés
 * Formule: 1 (de base) + 1 (si Esprit >= 3) + bonus héritage
 */
function calcMaxDons(esprit: number, heritageAvantages: { id: number; times: number }[], heritageData: any[]): number {
  let maxDons = 1;

  if (esprit >= 3) {
    maxDons += 1;
  }

  const extraDons = heritageAvantages.reduce((sum, h) => {
    const ha = heritageData.find((x) => x.id === h.id);
    return sum + (ha ? (ha.extraDons ?? 0) * h.times : 0);
  }, 0);

  return maxDons + extraDons;
}

/**
 * Valide la sélection de voie pour une classe donnée
 */
function isValidPathSelection(classId: number, pathId: number | null, classes: any[]): boolean {
  if (pathId === null) return false;
  const cls = classes.find((c) => c.id === classId);
  if (!cls) return false;
  return cls.paths.some((p: any) => p.id === pathId);
}

/**
 * Récupère les capacités d'une voie
 */
function getPathAbilities(classId: number, pathId: number, classes: any[]): any[] {
  const cls = classes.find((c) => c.id === classId);
  if (!cls) return [];
  const path = cls.paths.find((p: any) => p.id === pathId);
  return path?.abilities ?? [];
}

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("Dons Calculation", () => {
  describe("calcMaxDons", () => {
    it("should return 1 don by default (Esprit < 3, no heritage)", () => {
      const maxDons = calcMaxDons(1, [], mockHeritageAvantages);
      expect(maxDons).toBe(1);
    });

    it("should return 2 dons when Esprit >= 3", () => {
      const maxDons = calcMaxDons(3, [], mockHeritageAvantages);
      expect(maxDons).toBe(2);
    });

    it("should return 3 dons when Esprit >= 3 and heritage bonus", () => {
      const heritage = [{ id: 2, times: 1 }]; // Héritage magique gives 1 extra don
      const maxDons = calcMaxDons(3, heritage, mockHeritageAvantages);
      expect(maxDons).toBe(3); // 1 base + 1 Esprit + 1 heritage
    });

    it("should return 4 dons with multiple heritage bonuses", () => {
      const heritage = [{ id: 2, times: 2 }]; // 2 times Héritage magique = 2 extra dons
      const maxDons = calcMaxDons(3, heritage, mockHeritageAvantages);
      expect(maxDons).toBe(4); // 1 base + 1 Esprit + 2 heritage
    });

    it("should return 2 dons when Esprit < 3 but has heritage bonus", () => {
      const heritage = [{ id: 2, times: 1 }];
      const maxDons = calcMaxDons(2, heritage, mockHeritageAvantages);
      expect(maxDons).toBe(2); // 1 base + 1 heritage (no Esprit bonus)
    });

    it("should handle invalid heritage IDs", () => {
      const heritage = [{ id: 999, times: 1 }];
      const maxDons = calcMaxDons(3, heritage, mockHeritageAvantages);
      expect(maxDons).toBe(2); // Only base + Esprit, invalid ID ignored
    });
  });

  describe("Dons constraints", () => {
    it("should enforce minimum 1 don", () => {
      const maxDons = calcMaxDons(1, [], mockHeritageAvantages);
      expect(maxDons).toBeGreaterThanOrEqual(1);
    });

    it("should enforce maximum 5 dons", () => {
      const heritage = [{ id: 2, times: 3 }]; // 3 extra dons
      const maxDons = calcMaxDons(3, heritage, mockHeritageAvantages);
      expect(maxDons).toBeLessThanOrEqual(5);
    });
  });
});

describe("Path Selection", () => {
  describe("isValidPathSelection", () => {
    it("should accept valid path selection", () => {
      const isValid = isValidPathSelection(1, 101, mockClasses);
      expect(isValid).toBe(true);
    });

    it("should reject null path ID", () => {
      const isValid = isValidPathSelection(1, null, mockClasses);
      expect(isValid).toBe(false);
    });

    it("should reject invalid path ID", () => {
      const isValid = isValidPathSelection(1, 999, mockClasses);
      expect(isValid).toBe(false);
    });

    it("should reject invalid class ID", () => {
      const isValid = isValidPathSelection(999, 101, mockClasses);
      expect(isValid).toBe(false);
    });

    it("should accept both paths for Guerrier class", () => {
      expect(isValidPathSelection(1, 101, mockClasses)).toBe(true);
      expect(isValidPathSelection(1, 102, mockClasses)).toBe(true);
    });
  });

  describe("getPathAbilities", () => {
    it("should return abilities for Chevalier path", () => {
      const abilities = getPathAbilities(1, 101, mockClasses);
      expect(abilities.length).toBe(2);
      expect(abilities[0].name).toBe("Coup puissant");
      expect(abilities[1].name).toBe("Armure renforcée");
    });

    it("should return abilities for Berserker path", () => {
      const abilities = getPathAbilities(1, 102, mockClasses);
      expect(abilities.length).toBe(2);
      expect(abilities[0].name).toBe("Rage");
      expect(abilities[1].name).toBe("Frappe dévastatrice");
    });

    it("should return empty array for invalid path", () => {
      const abilities = getPathAbilities(1, 999, mockClasses);
      expect(abilities).toEqual([]);
    });

    it("should return empty array for invalid class", () => {
      const abilities = getPathAbilities(999, 101, mockClasses);
      expect(abilities).toEqual([]);
    });

    it("should have correct ability levels", () => {
      const abilities = getPathAbilities(1, 101, mockClasses);
      expect(abilities[0].level).toBe(1);
      expect(abilities[1].level).toBe(2);
    });
  });
});

describe("Integration - Dons & Path Selection", () => {
  it("should allow character creation with valid dons and path", () => {
    const esprit = 3;
    const heritage = [{ id: 2, times: 1 }];
    const maxDons = calcMaxDons(esprit, heritage, mockHeritageAvantages);
    const pathValid = isValidPathSelection(1, 101, mockClasses);

    expect(maxDons).toBeGreaterThanOrEqual(1);
    expect(pathValid).toBe(true);
  });

  it("should calculate correct dons with path selection", () => {
    // Character with Esprit 2, no heritage bonus
    const maxDons1 = calcMaxDons(2, [], mockHeritageAvantages);
    const pathValid1 = isValidPathSelection(1, 102, mockClasses);
    expect(maxDons1).toBe(1);
    expect(pathValid1).toBe(true);

    // Character with Esprit 3, heritage bonus
    const heritage = [{ id: 2, times: 1 }];
    const maxDons2 = calcMaxDons(3, heritage, mockHeritageAvantages);
    const pathValid2 = isValidPathSelection(1, 101, mockClasses);
    expect(maxDons2).toBe(3);
    expect(pathValid2).toBe(true);
  });

  it("should prevent character creation with invalid path", () => {
    const pathValid = isValidPathSelection(1, 999, mockClasses);
    expect(pathValid).toBe(false);
  });

  it("should show correct abilities for selected path", () => {
    const classId = 1;
    const pathId = 102; // Berserker
    const abilities = getPathAbilities(classId, pathId, mockClasses);

    expect(abilities.length).toBe(2);
    expect(abilities.some((a) => a.name === "Rage")).toBe(true);
    expect(abilities.some((a) => a.name === "Frappe dévastatrice")).toBe(true);
  });
});
