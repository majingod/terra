import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface UseValidateCompetenceOptions {
  raceId?: number;
  classId?: number;
  level?: number;
  selectedCompetences?: number[];
  showToasts?: boolean;
}

export function useValidateCompetence() {
  const [validationResults, setValidationResults] = useState<Map<number, ValidationResult>>(new Map());
  const [isValidating, setIsValidating] = useState(false);

  const validateCompetence = useCallback(
    async (competenceId: number, options: UseValidateCompetenceOptions = {}) => {
      const { showToasts = true } = options;
      setIsValidating(true);

      try {
        // Appeler la procédure tRPC de validation
        const result = await new Promise<ValidationResult>((resolve) => {
          fetch("/api/trpc/validation.validateCompetence", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              competenceId,
              raceId: options.raceId,
              classId: options.classId,
              level: options.level,
              selectedCompetences: options.selectedCompetences,
            }),
          })
            .then((res) => res.json())
            .then((data) => {
              const result = data.result || { isValid: true, errors: [], warnings: [] };
              resolve(result);
            })
            .catch(() => {
              resolve({ isValid: true, errors: [], warnings: [] });
            });
        });

        // Stocker le résultat
        setValidationResults((prev) => new Map(prev).set(competenceId, result));

        // Afficher les toasts si demandé
        if (showToasts) {
          if (!result.isValid && result.errors.length > 0) {
            result.errors.forEach((error) => {
              toast.error(error);
            });
          }
          if (result.warnings.length > 0) {
            result.warnings.forEach((warning) => {
              toast.warning(warning);
            });
          }
        }

        return result;
      } catch (error) {
        console.error("Erreur lors de la validation de la compétence:", error);
        const errorResult: ValidationResult = {
          isValid: false,
          errors: ["Erreur lors de la validation"],
          warnings: [],
        };
        setValidationResults((prev) => new Map(prev).set(competenceId, errorResult));
        if (showToasts) {
          toast.error("Erreur lors de la validation de la compétence");
        }
        return errorResult;
      } finally {
        setIsValidating(false);
      }
    },
    []
  );

  const getValidationResult = useCallback(
    (competenceId: number): ValidationResult | undefined => {
      return validationResults.get(competenceId);
    },
    [validationResults]
  );

  const clearValidation = useCallback((competenceId?: number) => {
    if (competenceId) {
      setValidationResults((prev) => {
        const newMap = new Map(prev);
        newMap.delete(competenceId);
        return newMap;
      });
    } else {
      setValidationResults(new Map());
    }
  }, []);

  return {
    validateCompetence,
    getValidationResult,
    clearValidation,
    isValidating,
    validationResults,
  };
}
