SELECT id, name, xpCost, extraAbilitiesLevel1, extraAbilitiesLevel2, extraCharacteristicPoints FROM heritage_avantages ORDER BY id;
