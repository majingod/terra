# Audit MVP — Terra Mortis

## Vérifications du 17 août 2026

L'aperçu de développement est accessible à l'URL fournie par l'environnement et le serveur est en fonctionnement. La page d'accueil se charge avec l'identité visuelle Terra Mortis, la navigation principale et les appels à l'action vers les règles et le créateur de personnage.

La page `/evenements` se charge correctement. Elle distingue les prochains événements, affiche un état vide explicite lorsqu'il n'y en a pas et conserve un appel à la connexion pour l'inscription. Un événement passé est visible dans l'environnement de test.

La page `/regles` se charge correctement et expose le hub des règles : races, classes, compétences, dons, héritage et désavantages, magie et combat. Les appels à l'action de création de personnage et de consultation des personnages sont présents.

La page `/admin/xp` est protégée lorsqu'aucune session n'est active, ce qui confirme le contrôle d'accès côté interface. Avec une session organisateur/admin, l'interface d'attribution d'XP est prévue pour sélectionner un événement et une inscription, saisir un montant et journaliser l'opération.

## Corrections MVP réalisées

L'interface d'attribution d'XP appelle désormais une mutation serveur réelle. La mutation cible en priorité le personnage lié à l'inscription, prend en charge le solde partagé du profil familial lorsqu'il existe, utilise un personnage actif comme repli pour les anciennes inscriptions sans personnage et écrit une ligne dans `xpPermanentHistory`. Les rôles `admin` et `organizer` sont autorisés par la procédure serveur.

## Limites connues non bloquantes pour l'aperçu

L'aperçu reste un environnement de développement et n'est pas un lien public permanent. Les notifications avancées, les animations supplémentaires, le nettoyage des tables legacy et la publication en production restent hors périmètre de cette livraison MVP.


La route `/creer-personnage-v2` se charge correctement et protège le parcours en affichant une demande de connexion lorsque la session est absente. L'aperçu final reste actif, la compilation TypeScript est sans erreur et la suite complète de tests compte 193 tests passants sur 15 fichiers.
