import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Plus, Minus, AlertCircle } from "lucide-react";
import { useValidateHeritage } from "@/hooks/useValidateHeritage";

interface StepHeritageProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepHeritage({ charData, onCharDataChange }: StepHeritageProps) {
  const [heritages, setHeritages] = useState<any[]>([]);
  const { validateHeritage, getValidationResult } = useValidateHeritage();
  const [validatingHeritageId, setValidatingHeritageId] = useState<number | null>(null);

  useEffect(() => {
    // TODO: Remplacer par la procédure tRPC
    setHeritages([
      { id: 1, name: "+1 Dons", xpCost: 10, extraDons: 1 },
      { id: 2, name: "+1 Compétence", xpCost: 10, extraCompetences: 1 },
      { id: 3, name: "+1 Capacité bonus", xpCost: 15, extraAbilitiesLevel1: 1 },
      { id: 4, name: "+2 Points de caractéristiques", xpCost: 20, extraStatsPoints: 2 },
    ]);
  }, []);

  const addHeritage = async (heritageId: number) => {
    setValidatingHeritageId(heritageId);
    try {
      const result = await validateHeritage(heritageId, {
        raceId: charData.raceId,
        classId: charData.classId,
        selectedHeritages: charData.heritageAvantages.map((h: any) => h.id),
        showToasts: true,
      });

      if (result.isValid) {
        const existing = charData.heritageAvantages.find((h: any) => h.id === heritageId);
        if (existing) {
          onCharDataChange({
            ...charData,
            heritageAvantages: charData.heritageAvantages.map((h: any) =>
              h.id === heritageId ? { ...h, times: h.times + 1 } : h
            ),
          });
        } else {
          onCharDataChange({
            ...charData,
            heritageAvantages: [...charData.heritageAvantages, { id: heritageId, times: 1 }],
          });
        }
      }
    } finally {
      setValidatingHeritageId(null);
    }
  };

  const removeHeritage = (heritageId: number) => {
    const existing = charData.heritageAvantages.find((h: any) => h.id === heritageId);
    if (existing && existing.times > 1) {
      onCharDataChange({
        ...charData,
        heritageAvantages: charData.heritageAvantages.map((h: any) =>
          h.id === heritageId ? { ...h, times: h.times - 1 } : h
        ),
      });
    } else {
      onCharDataChange({
        ...charData,
        heritageAvantages: charData.heritageAvantages.filter((h: any) => h.id !== heritageId),
      });
    }
  };

  return (
    <div className="space-y-6">
      <p className="text-sm text-muted-foreground">
        Sélectionnez les héritages pour améliorer votre personnage (optionnel)
      </p>

      <div className="space-y-3">
        {heritages.map((heritage: any) => {
          const selected = charData.heritageAvantages.find((h: any) => h.id === heritage.id);
          const count = selected?.times || 0;

          return (
            <div
              key={heritage.id}
              className="p-4 rounded-lg border border-border flex items-center justify-between"
            >
              <div className="flex-1">
                <h4 className="font-semibold">{heritage.name}</h4>
                <p className="text-xs text-muted-foreground">Coût: {heritage.xpCost} XP</p>
                {getValidationResult(heritage.id)?.errors.length ? (
                  <div className="flex items-center gap-1 mt-2 text-xs text-red-600">
                    <AlertCircle className="w-3 h-3" />
                    <span>{getValidationResult(heritage.id)?.errors[0]}</span>
                  </div>
                ) : null}
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeHeritage(heritage.id)}
                  disabled={count === 0}
                >
                  <Minus className="w-4 h-4" />
                </Button>

                <span className="w-8 text-center font-semibold">{count}</span>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addHeritage(heritage.id)}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Résumé des bonus */}
      {charData.heritageAvantages.length > 0 && (
        <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
          <h4 className="font-semibold text-amber-900 mb-2">Bonus d'Héritage actifs :</h4>
          <ul className="text-sm text-amber-800 space-y-1">
            {charData.heritageAvantages.map((h: any) => {
              const heritage = heritages.find((hr) => hr.id === h.id);
              return (
                <li key={h.id}>
                  • {heritage?.name} x{h.times}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
