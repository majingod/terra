import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface TerraMortisCardProps {
  children: ReactNode;
  className?: string;
  faction?: "Sanctum" | "Légion";
  elevated?: boolean;
  hover?: boolean;
}

export function TerraMortisCard({
  children,
  className,
  faction,
  elevated = false,
  hover = true,
}: TerraMortisCardProps) {
  const baseClasses = "terra-card";
  const factionClasses = faction
    ? faction === "Sanctum"
      ? "faction-sanctum"
      : "faction-legion"
    : "";
  const elevatedClasses = elevated ? "card-elevated" : "";
  const hoverClasses = hover ? "card-hover" : "";

  return (
    <div className={cn(baseClasses, factionClasses, elevatedClasses, hoverClasses, className)}>
      {children}
    </div>
  );
}
