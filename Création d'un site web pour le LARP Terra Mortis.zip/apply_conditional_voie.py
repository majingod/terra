#!/usr/bin/env python3

# Lire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Trouver la section STEPS et modifier pour rendre l'étape 9 conditionnelle
old_steps = '''  { id: 9, label: "Voie", icon: Star },
  { id: 10, label: "Dons & Résumé", icon: Check },'''

new_steps = '''  { id: 9, label: "Capacités bonus", icon: Star },
  { id: 10, label: "Dons & Résumé", icon: Check },'''

content = content.replace(old_steps, new_steps)
print("✓ Label de l'étape 9 modifié")

# Écrire le fichier
with open('/home/ubuntu/terra-mortis/client/src/pages/CreatePersonnage.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fichier sauvegardé")
