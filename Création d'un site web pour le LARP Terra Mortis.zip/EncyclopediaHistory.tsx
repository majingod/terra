import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, Calendar, User, BookOpen, RotateCcw } from "lucide-react";

export default function EncyclopediaHistory() {
  const [selectedEntryId, setSelectedEntryId] = useState<string>("");
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [sortBy, setSortBy] = useState<"recent" | "oldest">("recent");

  // Récupérer l'historique des modifications
  const { data: recentChanges, isLoading: isLoadingChanges } = trpc.encyclopedia.history.getRecentChanges.useQuery(
    { limit: 50 },
    { enabled: true }
  );

  // Récupérer les statistiques de modification
  const { data: changeStats, isLoading: isLoadingStats } = trpc.encyclopedia.history.getChangeStats.useQuery(
    {},
    { enabled: true }
  );

  // Récupérer l'historique d'une entrée spécifique
  const { data: entryHistory, isLoading: isLoadingEntry } = trpc.encyclopedia.history.getEntryHistory.useQuery(
    { entryId: selectedEntryId },
    { enabled: !!selectedEntryId }
  );

  // Récupérer les modifications d'un utilisateur
  const { data: userChanges, isLoading: isLoadingUser } = trpc.encyclopedia.history.getChangesByUser.useQuery(
    { userId: selectedUser },
    { enabled: !!selectedUser }
  );

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString("fr-FR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getChangeTypeBadge = (changeType: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      create: "default",
      update: "secondary",
      delete: "destructive",
      restore: "outline",
    };
    return variants[changeType] || "default";
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Historique des Modifications</h1>
        <p className="text-muted-foreground">Consultez l'historique des modifications de l'Encyclopédie</p>
      </div>

      <Tabs defaultValue="recent" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recent">Modifications Récentes</TabsTrigger>
          <TabsTrigger value="entry">Par Entrée</TabsTrigger>
          <TabsTrigger value="user">Par Utilisateur</TabsTrigger>
        </TabsList>

        {/* Onglet : Modifications Récentes */}
        <TabsContent value="recent" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Modifications Récentes</CardTitle>
              <CardDescription>Les 50 dernières modifications de l'Encyclopédie</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingChanges ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-20" />
                  ))}
                </div>
              ) : !recentChanges || recentChanges.length === 0 ? (
                <div className="flex items-center justify-center py-8 text-muted-foreground">
                  <AlertCircle className="mr-2 h-5 w-5" />
                  <span>Aucune modification trouvée</span>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentChanges.map((change: any) => (
                    <div key={change.id} className="border rounded-lg p-4 hover:bg-accent transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={getChangeTypeBadge(change.changeType)}>
                            {change.changeType.toUpperCase()}
                          </Badge>
                          <span className="font-semibold">{change.entryTitle}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">{formatDate(change.timestamp)}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          <span>{change.userName || "Utilisateur inconnu"}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <BookOpen className="h-4 w-4" />
                          <span>{change.category}</span>
                        </div>
                      </div>
                      {change.description && (
                        <p className="mt-2 text-sm text-muted-foreground italic">{change.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Onglet : Par Entrée */}
        <TabsContent value="entry" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Historique d'une Entrée</CardTitle>
              <CardDescription>Consultez toutes les modifications d'une entrée spécifique</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Sélectionner une entrée</label>
                <Input
                  placeholder="ID de l'entrée..."
                  value={selectedEntryId}
                  onChange={(e) => setSelectedEntryId(e.target.value)}
                />
              </div>

              {selectedEntryId && (
                <>
                  {isLoadingEntry ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-20" />
                      ))}
                    </div>
                  ) : !entryHistory || entryHistory.length === 0 ? (
                    <div className="flex items-center justify-center py-8 text-muted-foreground">
                      <AlertCircle className="mr-2 h-5 w-5" />
                      <span>Aucun historique trouvé pour cette entrée</span>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {entryHistory.map((change: any, index: number) => (
                        <div
                          key={change.id}
                          className="border rounded-lg p-4 hover:bg-accent transition-colors relative"
                        >
                          {index < entryHistory.length - 1 && (
                            <div className="absolute left-8 top-full h-4 w-0.5 bg-border"></div>
                          )}
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant={getChangeTypeBadge(change.changeType)}>
                                {change.changeType.toUpperCase()}
                              </Badge>
                              <span className="font-semibold">Version {entryHistory.length - index}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">{formatDate(change.timestamp)}</span>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                            <div className="flex items-center gap-1">
                              <User className="h-4 w-4" />
                              <span>{change.userName || "Utilisateur inconnu"}</span>
                            </div>
                          </div>
                          {change.description && (
                            <p className="text-sm text-muted-foreground italic">{change.description}</p>
                          )}
                          {index < entryHistory.length - 1 && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2"
                              onClick={() => {
                                // Restaurer cette version
                                console.log("Restaurer version", change.id);
                              }}
                            >
                              <RotateCcw className="h-4 w-4 mr-2" />
                              Restaurer cette version
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Onglet : Par Utilisateur */}
        <TabsContent value="user" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Modifications par Utilisateur</CardTitle>
              <CardDescription>Consultez les modifications d'un utilisateur spécifique</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Sélectionner un utilisateur</label>
                <Input
                  placeholder="ID de l'utilisateur..."
                  value={selectedUser}
                  onChange={(e) => setSelectedUser(e.target.value)}
                />
              </div>

              {selectedUser && (
                <>
                  {isLoadingUser ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <Skeleton key={i} className="h-20" />
                      ))}
                    </div>
                  ) : !userChanges || userChanges.length === 0 ? (
                    <div className="flex items-center justify-center py-8 text-muted-foreground">
                      <AlertCircle className="mr-2 h-5 w-5" />
                      <span>Aucune modification trouvée pour cet utilisateur</span>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {userChanges.map((change: any) => (
                        <div key={change.id} className="border rounded-lg p-4 hover:bg-accent transition-colors">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant={getChangeTypeBadge(change.changeType)}>
                                {change.changeType.toUpperCase()}
                              </Badge>
                              <span className="font-semibold">{change.entryTitle}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">{formatDate(change.timestamp)}</span>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <BookOpen className="h-4 w-4" />
                              <span>{change.category}</span>
                            </div>
                          </div>
                          {change.description && (
                            <p className="mt-2 text-sm text-muted-foreground italic">{change.description}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Statistiques */}
      {changeStats && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Statistiques</CardTitle>
            <CardDescription>Vue d'ensemble des modifications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="border rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-primary">{changeStats.totalChanges || 0}</div>
                <div className="text-sm text-muted-foreground">Modifications totales</div>
              </div>
              <div className="border rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-green-600">{changeStats.creates || 0}</div>
                <div className="text-sm text-muted-foreground">Créées</div>
              </div>
              <div className="border rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-blue-600">{changeStats.updates || 0}</div>
                <div className="text-sm text-muted-foreground">Modifiées</div>
              </div>
              <div className="border rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-red-600">{changeStats.deletes || 0}</div>
                <div className="text-sm text-muted-foreground">Supprimées</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
