import { trpc } from "@/lib/trpc";
import type { Class } from "../../../../drizzle/schema";
import { ChevronDown, ChevronRight, Loader2, Shield, Skull } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import Breadcrumbs from "@/components/Breadcrumbs";

const factionColor = (faction: string) => {
  if (faction === "Sanctum") return "oklch(0.55 0.18 240)";
  if (faction === "Légion") return "oklch(0.5 0.22 25)";
  return "oklch(0.65 0.18 45)";
};

const asStrArr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);
const asAbilities = (v: unknown): { name: string; description: string }[] =>
  Array.isArray(v) ? (v as { name: string; description: string }[]) : [];

interface ClassAbility {
  id: number;
  classId: number;
  pathId: number | null;
  level: number;
  name: string;
  description: string;
  manaCost?: number | null;
  pvCost?: number | null;
  usesPerCombat?: number | null;
  usesPerHour?: number | null;
  usesPerDay?: number | null;
  isBuff?: boolean;
  isSign?: boolean;
  isIncantation?: boolean;
  abilityType?: string | null;
  createdAt: Date;
  updatedAt: Date;
}

interface ClassPath {
  id: number;
  classId: number;
  name: string;
  description?: string | null;
  createdAt: Date;
  abilities?: ClassAbility[];
}

interface ClassWithPaths extends Class {
  paths?: ClassPath[];
}

function ClassDetail({ cls }: { cls: ClassWithPaths }) {
  const { data: fullClass } = trpc.rules.classWithPathsAndAbilities.useQuery({ id: cls.id });
  const [expandedPaths, setExpandedPaths] = useState<Set<number>>(new Set());

  const abilities = asAbilities(cls.baseAbilities);
  const specialRules = asStrArr(cls.specialRules);
  const code = asStrArr(cls.code);

  const togglePath = (pathId: number) => {
    const newSet = new Set(expandedPaths);
    if (newSet.has(pathId)) {
      newSet.delete(pathId);
    } else {
      newSet.add(pathId);
    }
    setExpandedPaths(newSet);
  };

  const paths = fullClass?.paths || [];

  return (
    <div className="p-6 rounded-xl border border-border/50 bg-card/30 sticky top-20 overflow-y-auto max-h-[80vh]">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-3xl font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>
            {cls.name}
          </h2>
          <span
            className="text-sm px-3 py-1 rounded-full mt-2 inline-block font-heading"
            style={{
              background: `${factionColor(cls.faction)}20`,
              color: factionColor(cls.faction),
              border: `1px solid ${factionColor(cls.faction)}40`,
            }}
          >
            {cls.faction}
          </span>
        </div>
      </div>

      {/* Base stats */}
      <div className="flex flex-wrap gap-2 mb-6">
        <div
          className="px-3 py-1.5 rounded-lg text-sm font-heading"
          style={{ background: "oklch(0.45 0.15 140 / 0.2)", color: "oklch(0.65 0.2 140)", border: "1px solid oklch(0.45 0.15 140 / 0.4)" }}
        >
          {cls.basePv} PV de base
        </div>
        {cls.baseMana > 0 && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.55 0.18 240 / 0.2)", color: "oklch(0.65 0.2 240)", border: "1px solid oklch(0.55 0.18 240 / 0.4)" }}
          >
            {cls.baseMana} Mana de base
          </div>
        )}
        {cls.requiresWeapon && (
          <div
            className="px-3 py-1.5 rounded-lg text-sm font-heading"
            style={{ background: "oklch(0.65 0.18 45 / 0.2)", color: "oklch(0.82 0.2 85)", border: "1px solid oklch(0.65 0.18 45 / 0.4)" }}
          >
            Bâton/Baguette requis
          </div>
        )}
      </div>

      {/* Description */}
      <div className="mb-6">
        <h3 className="font-heading font-semibold mb-2 text-foreground">Description</h3>
        <p className="text-foreground/80 leading-relaxed text-sm">{cls.description}</p>
      </div>

      {/* Code of conduct */}
      {code.length > 0 && (
        <div className="mb-6 p-4 rounded-lg border" style={{ background: "oklch(0.65 0.18 45 / 0.05)", borderColor: "oklch(0.65 0.18 45 / 0.3)" }}>
          <h3 className="font-heading font-semibold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>Code de conduite</h3>
          <ul className="space-y-1">
            {code.map((c, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "oklch(0.82 0.2 85)" }} />
                {c}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Base Abilities */}
      {abilities.length > 0 && (
        <div className="mb-6">
          <h3 className="font-heading font-semibold mb-3 text-foreground">Capacités de base</h3>
          <div className="space-y-3">
            {abilities.map((ability, i) => (
              <div key={i} className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                <h4 className="font-heading font-semibold text-sm mb-1" style={{ color: "oklch(0.82 0.2 85)" }}>
                  {ability.name}
                </h4>
                <p className="text-xs text-foreground/75 leading-relaxed">{ability.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Special rules */}
      {specialRules.length > 0 && (
        <div className="mb-6">
          <h3 className="font-heading font-semibold mb-2 text-foreground">Règles spéciales</h3>
          <ul className="space-y-1">
            {specialRules.map((r, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "oklch(0.65 0.18 45)" }} />
                {r}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Paths with Abilities */}
      {paths.length > 0 && (
        <div>
          <h3 className="font-heading font-semibold mb-3 text-foreground">Voies disponibles</h3>
          <div className="space-y-3">
            {paths.map((path) => (
              <div key={path.id} className="rounded-lg border border-border/40 bg-secondary/20 overflow-hidden">
                {/* Path Header */}
                <button
                  onClick={() => togglePath(path.id)}
                  className="w-full p-4 flex items-start justify-between hover:bg-secondary/30 transition-colors"
                >
                  <div className="flex-1 text-left">
                    <h4 className="font-heading font-semibold" style={{ color: "oklch(0.82 0.2 85)" }}>
                      {path.name}
                    </h4>
                    {path.description && (
                      <p className="text-xs text-foreground/70 mt-1">{path.description}</p>
                    )}
                  </div>
                  {expandedPaths.has(path.id) ? (
                    <ChevronDown className="w-5 h-5 flex-shrink-0 ml-2" style={{ color: "oklch(0.82 0.2 85)" }} />
                  ) : (
                    <ChevronRight className="w-5 h-5 flex-shrink-0 ml-2" style={{ color: "oklch(0.82 0.2 85)" }} />
                  )}
                </button>

                {/* Path Abilities */}
                {expandedPaths.has(path.id) && path.abilities && path.abilities.length > 0 && (
                  <div className="border-t border-border/20 p-4 bg-secondary/10">
                    <div className="space-y-3">
                      {path.abilities.map((ability) => (
                        <div key={ability.id} className="p-3 rounded-lg bg-background/50 border border-border/20">
                          <div className="flex items-start justify-between mb-1">
                            <h5 className="font-heading font-semibold text-sm" style={{ color: "oklch(0.82 0.2 85)" }}>
                              Niveau {ability.level}: {ability.name}
                            </h5>
                            {ability.manaCost !== null && ability.manaCost !== undefined && ability.manaCost > 0 && (
                              <span className="text-xs px-2 py-1 rounded bg-blue-900/30 text-blue-300">
                                {ability.manaCost} Mana
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-foreground/75 leading-relaxed">{ability.description}</p>
                          {(ability.usesPerCombat || ability.usesPerHour || ability.usesPerDay) && (
                            <div className="mt-2 text-xs text-foreground/60 space-y-1">
                              {ability.usesPerCombat && <p>Utilisations par combat: {ability.usesPerCombat}</p>}
                              {ability.usesPerHour && <p>Utilisations par heure: {ability.usesPerHour}</p>}
                              {ability.usesPerDay && <p>Utilisations par jour: {ability.usesPerDay}</p>}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Classes() {
  const { data: classes, isLoading } = trpc.rules.classes.useQuery();
  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const [filterFaction, setFilterFaction] = useState<string>("Tous");

  const filtered = classes?.filter((c) => filterFaction === "Tous" || c.faction === filterFaction) || [];
  const selected = filtered.find((c) => c.id === selectedClass);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.82 0.2 85)" }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12">
      <Breadcrumbs items={[{ label: "Règles", href: "/regles" }, { label: "Classes" }]} />

      <div className="container mx-auto px-4 mt-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-heading font-bold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
            Classes
          </h1>
          <p className="text-foreground/70">Explorez les 6 classes disponibles et leurs 3 voies d'évolution</p>
        </div>

        {/* Faction Filter */}
        <div className="flex gap-2 mb-8">
          {["Tous", "Sanctum", "Légion"].map((faction) => (
            <button
              key={faction}
              onClick={() => setFilterFaction(faction)}
              className={`px-4 py-2 rounded-lg font-heading transition-all ${
                filterFaction === faction
                  ? "text-white"
                  : "text-foreground/70 hover:text-foreground"
              }`}
              style={{
                background: filterFaction === faction ? `${factionColor(faction)}40` : "transparent",
                border: `1px solid ${filterFaction === faction ? factionColor(faction) : "transparent"}`,
              }}
            >
              {faction}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Classes List */}
          <div className="lg:col-span-1">
            <div className="space-y-2">
              {filtered.map((cls) => (
                <button
                  key={cls.id}
                  onClick={() => setSelectedClass(cls.id)}
                  className={`w-full text-left p-4 rounded-lg transition-all border ${
                    selectedClass === cls.id
                      ? "border-yellow-600/50 bg-yellow-900/20"
                      : "border-border/30 bg-secondary/10 hover:bg-secondary/20"
                  }`}
                >
                  <h3 className="font-heading font-semibold" style={{ color: selectedClass === cls.id ? "oklch(0.82 0.2 85)" : "inherit" }}>
                    {cls.name}
                  </h3>
                  <p className="text-xs text-foreground/60 mt-1">{cls.faction}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Class Detail */}
          <div className="lg:col-span-2">
            {selected ? (
              <ClassDetail cls={selected} />
            ) : (
              <div className="p-8 rounded-xl border border-border/30 bg-card/20 text-center">
                <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p className="text-foreground/60">Sélectionnez une classe pour voir les détails</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
