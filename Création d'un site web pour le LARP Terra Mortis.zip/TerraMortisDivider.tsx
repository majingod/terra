import { cn } from "@/lib/utils";

interface TerraMortisDividerProps {
  className?: string;
  decorative?: boolean;
}

export function TerraMortisDivider({ className, decorative = false }: TerraMortisDividerProps) {
  if (decorative) {
    return (
      <div className={cn("flex items-center justify-center gap-4 my-8", className)}>
        <div className="terra-divider flex-1" />
        <span className="text-primary/50 text-2xl">✦</span>
        <div className="terra-divider flex-1" />
      </div>
    );
  }

  return <div className={cn("terra-divider my-6", className)} />;
}
