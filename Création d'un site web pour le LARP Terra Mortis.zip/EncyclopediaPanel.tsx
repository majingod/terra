import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface EncyclopediaPanelProps {
  title?: string;
  description?: string;
  image?: string;
  bonus?: string[];
  prerequisites?: string[];
  type?: "race" | "class" | "capacity" | "don";
  isLoading?: boolean;
}

/**
 * Panneau latéral affichant les détails Encyclopédie
 * Réutilisable pour races, classes, capacités, dons
 */
export function EncyclopediaPanel({
  title,
  description,
  image,
  bonus,
  prerequisites,
  type = "race",
  isLoading = false,
}: EncyclopediaPanelProps) {
  if (isLoading) {
    return (
      <Card className="w-full h-full">
        <CardHeader>
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-48 mt-2" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </CardContent>
      </Card>
    );
  }

  if (!title) {
    return (
      <Card className="w-full h-full flex items-center justify-center">
        <CardContent className="text-center text-muted-foreground">
          Sélectionnez une option pour voir les détails
        </CardContent>
      </Card>
    );
  }

  const typeColors = {
    race: "bg-blue-100 text-blue-800",
    class: "bg-purple-100 text-purple-800",
    capacity: "bg-green-100 text-green-800",
    don: "bg-orange-100 text-orange-800",
  };

  return (
    <Card className="w-full h-full overflow-y-auto">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="text-2xl">{title}</CardTitle>
            <Badge className={`mt-2 ${typeColors[type]}`}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Image */}
        {image && (
          <div className="w-full h-48 bg-muted rounded-lg overflow-hidden">
            <img
              src={image}
              alt={title}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
          </div>
        )}

        {/* Description */}
        {description && (
          <div>
            <h3 className="font-semibold mb-2">Description</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
          </div>
        )}

        {/* Bonus */}
        {bonus && bonus.length > 0 && (
          <div>
            <h3 className="font-semibold mb-2">Bonus</h3>
            <ul className="space-y-1">
              {bonus.map((b, idx) => (
                <li key={idx} className="text-sm text-green-700 flex items-start gap-2">
                  <span className="text-green-600 font-bold">+</span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Prérequis */}
        {prerequisites && prerequisites.length > 0 && (
          <div>
            <h3 className="font-semibold mb-2">Prérequis</h3>
            <ul className="space-y-1">
              {prerequisites.map((p, idx) => (
                <li key={idx} className="text-sm text-amber-700 flex items-start gap-2">
                  <span className="text-amber-600 font-bold">•</span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
