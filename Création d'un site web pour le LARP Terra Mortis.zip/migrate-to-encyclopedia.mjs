#!/usr/bin/env node

/**
 * Script de migration des données existantes vers l'Encyclopédie
 * Transforme les tables existantes (races, classes, dons, etc.) en entrées d'Encyclopédie
 * 
 * Usage: node scripts/migrate-to-encyclopedia.mjs
 */

import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "terra_mortis",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function migrateRaces() {
  console.log("📦 Migration des races...");
  const connection = await pool.getConnection();

  try {
    // Récupérer toutes les races
    const [races] = await connection.query("SELECT * FROM races WHERE deletedAt IS NULL");

    for (const race of races) {
      const proprietes = {
        faction: race.faction,
        pv_bonus: race.pvBonus || 0,
        pv_malus: race.pvMalus || 0,
        mana_bonus: race.manaBonus || 0,
        lutte_bonus: race.luteBonus || 0,
        bonuses: race.bonuses ? JSON.parse(race.bonuses) : [],
        maluses: race.maluses ? JSON.parse(race.maluses) : [],
        capacites_raciales: race.abilities ? JSON.parse(race.abilities) : [],
        description_physique: race.physicalDescription || "",
        langues: race.startingLanguages ? JSON.parse(race.startingLanguages) : ["Commun"],
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, factionRequise, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [race.name, "races", race.description, JSON.stringify(proprietes), race.faction]
      );
    }

    console.log(`✅ ${races.length} races migrées`);
  } finally {
    connection.release();
  }
}

async function migrateClasses() {
  console.log("📦 Migration des classes...");
  const connection = await pool.getConnection();

  try {
    const [classes] = await connection.query("SELECT * FROM classes WHERE deletedAt IS NULL");

    for (const cls of classes) {
      const proprietes = {
        faction: cls.faction,
        pv_base: cls.basePv || 6,
        mana_base: cls.baseMana || 1,
        base_abilities: cls.baseAbilities ? JSON.parse(cls.baseAbilities) : [],
        special_rules: cls.specialRules ? JSON.parse(cls.specialRules) : [],
        requires_weapon: cls.requiresWeapon || false,
        code_conduite: cls.code ? JSON.parse(cls.code) : null,
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, factionRequise, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [cls.name, "classes", cls.description, JSON.stringify(proprietes), cls.faction]
      );
    }

    console.log(`✅ ${classes.length} classes migrées`);
  } finally {
    connection.release();
  }
}

async function migrateDons() {
  console.log("📦 Migration des dons...");
  const connection = await pool.getConnection();

  try {
    const [dons] = await connection.query("SELECT * FROM dons WHERE deletedAt IS NULL");

    for (const don of dons) {
      const proprietes = {
        effet: don.effect || "",
        cumulable: don.cumulable || false,
        max_fois: don.maxTimes || null,
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [don.name, "dons", don.description || "", JSON.stringify(proprietes)]
      );
    }

    console.log(`✅ ${dons.length} dons migrés`);
  } finally {
    connection.release();
  }
}

async function migrateCompetences() {
  console.log("📦 Migration des compétences...");
  const connection = await pool.getConnection();

  try {
    const [competences] = await connection.query("SELECT * FROM competences WHERE deletedAt IS NULL");

    for (const comp of competences) {
      const proprietes = {
        type: comp.type || "Simple",
        avantage_base: comp.baseAdvantage || "",
        avantage_avance: comp.advancedAdvantage || "",
        interdit_enfants: comp.forbiddenForChildren || false,
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [comp.name, "competences", comp.description || "", JSON.stringify(proprietes)]
      );
    }

    console.log(`✅ ${competences.length} compétences migrées`);
  } finally {
    connection.release();
  }
}

async function migrateHeritageAvantages() {
  console.log("📦 Migration des avantages d'héritage...");
  const connection = await pool.getConnection();

  try {
    const [avantages] = await connection.query("SELECT * FROM heritage_avantages WHERE deletedAt IS NULL");

    for (const avantage of avantages) {
      const proprietes = {
        xp_cost: avantage.xpCost || 0,
        max_times: avantage.maxTimes || 1,
        effet: avantage.effect || "",
        debloque: avantage.unlocks || null,
        extraAbilitiesLevel1: avantage.extraAbilitiesLevel1 || 0,
        extraAbilitiesLevel2: avantage.extraAbilitiesLevel2 || 0,
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [avantage.name, "heritage_avantages", avantage.description || "", JSON.stringify(proprietes)]
      );
    }

    console.log(`✅ ${avantages.length} avantages d'héritage migrés`);
  } finally {
    connection.release();
  }
}

async function migrateHeritageDesavantages() {
  console.log("📦 Migration des désavantages d'héritage...");
  const connection = await pool.getConnection();

  try {
    const [desavantages] = await connection.query("SELECT * FROM desavantages WHERE deletedAt IS NULL");

    for (const desavantage of desavantages) {
      const proprietes = {
        xp_gain: desavantage.xpGain || 0,
        effet: desavantage.effect || "",
        restrictions: desavantage.restrictions ? JSON.parse(desavantage.restrictions) : [],
      };

      await connection.query(
        `INSERT INTO encyclopedia_entries 
        (nom, categorie, description, proprietes, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        description = VALUES(description), 
        proprietes = VALUES(proprietes)`,
        [desavantage.name, "heritage_desavantages", desavantage.description || "", JSON.stringify(proprietes)]
      );
    }

    console.log(`✅ ${desavantages.length} désavantages d'héritage migrés`);
  } finally {
    connection.release();
  }
}

async function main() {
  console.log("🚀 Démarrage de la migration vers l'Encyclopédie...\n");

  try {
    await migrateRaces();
    await migrateClasses();
    await migrateDons();
    await migrateCompetences();
    await migrateHeritageAvantages();
    await migrateHeritageDesavantages();

    console.log("\n✅ Migration complétée avec succès !");
  } catch (error) {
    console.error("\n❌ Erreur lors de la migration:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();
