import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { EncyclopediaPanel } from "../EncyclopediaPanel";

interface StepClassProps {
  charData: any;
  onCharDataChange: (data: any) => void;
  heritageBonus?: any;
}

export function StepClass({ charData, onCharDataChange }: StepClassProps) {
  const [classes, setClasses] = useState<any[]>([]);
  const [paths, setPaths] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedClassData, setSelectedClassData] = useState<any>(null);
  const [selectedPathData, setSelectedPathData] = useState<any>(null);

  useEffect(() => {
    // TODO: Remplacer par la procédure tRPC
    setTimeout(() => {
      setClasses([
        {
          id: 1,
          name: "Guerrier",
          description: "Maître du combat rapproché et de la défense",
          bonus: ["+2 Puissance", "+1 Lutte"],
          prerequisites: ["Aucun"],
        },
        {
          id: 2,
          name: "Mage",
          description: "Maître de la magie et des arcanes",
          bonus: ["+2 Esprit", "+1 Capacité magique"],
          prerequisites: ["Aucun"],
        },
        {
          id: 3,
          name: "Voleur",
          description: "Maître de la discrétion et de la précision",
          bonus: ["+2 Agilité", "+1 Esquive"],
          prerequisites: ["Aucun"],
        },
      ]);
      setPaths([
        {
          id: 1,
          classId: 1,
          name: "Barbare",
          description: "Force brute et rage guerrière",
          bonus: ["+3 Puissance", "+1 Résistance"],
          prerequisites: ["Guerrier"],
        },
        {
          id: 2,
          classId: 1,
          name: "Chevalier",
          description: "Défense et honneur",
          bonus: ["+2 Résistance", "+1 Armure"],
          prerequisites: ["Guerrier"],
        },
        {
          id: 3,
          classId: 2,
          name: "Sorcier",
          description: "Magie destructive et puissante",
          bonus: ["+3 Esprit", "+2 Dégâts magiques"],
          prerequisites: ["Mage"],
        },
        {
          id: 4,
          classId: 2,
          name: "Prêtre",
          description: "Magie curative et protection",
          bonus: ["+2 Esprit", "+2 Soin"],
          prerequisites: ["Mage"],
        },
      ]);
      setIsLoading(false);
    }, 300);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const selectedClass = classes.find((c) => c.id === charData.classId);
  const availablePaths = paths.filter((p) => p.classId === charData.classId);

  const handleClassSelect = (cls: any) => {
    setSelectedClassData(cls);
    setSelectedPathData(null);
    onCharDataChange({
      ...charData,
      classId: cls.id,
      classPathId: null,
    });
  };

  const handlePathSelect = (path: any) => {
    setSelectedPathData(path);
    onCharDataChange({
      ...charData,
      classPathId: path.id,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Sélection de la classe */}
          <div>
            <h3 className="font-semibold mb-3">Classe</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {classes.map((cls: any) => (
                <div
                  key={cls.id}
                  onClick={() => handleClassSelect(cls)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    charData.classId === cls.id
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <h4 className="font-bold mb-1">{cls.name}</h4>
                  <p className="text-xs text-muted-foreground">{cls.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Sélection de la voie */}
          {selectedClass && (
            <div>
              <h3 className="font-semibold mb-3">Voie ({selectedClass.name})</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availablePaths.map((path: any) => (
                  <div
                    key={path.id}
                    onClick={() => handlePathSelect(path)}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      charData.classPathId === path.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <h4 className="font-bold mb-1">{path.name}</h4>
                    <p className="text-xs text-muted-foreground">{path.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Panneau Encyclopédie */}
        <div className="lg:col-span-1">
          <div className="sticky top-4">
            <EncyclopediaPanel
              title={selectedPathData?.name || selectedClassData?.name}
              description={selectedPathData?.description || selectedClassData?.description}
              bonus={selectedPathData?.bonus || selectedClassData?.bonus}
              prerequisites={selectedPathData?.prerequisites || selectedClassData?.prerequisites}
              type={selectedPathData ? "class" : "class"}
              isLoading={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
