import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState } from "react";
import { Link } from "wouter";
import {
  Loader2, Lock, ChevronRight, Users, Shield, Sword, Star, Gem, TrendingDown,
  Edit2, Trash2, Plus, Check, X, BookOpen, Settings
} from "lucide-react";

type AdminTab = "races" | "classes" | "dons" | "competences" | "heritage" | "desavantages" | "users" | "personnages";

function EditableField({ value, onSave, multiline = false }: { value: string; onSave: (v: string) => void; multiline?: boolean }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  if (!editing) {
    return (
      <div className="flex items-start gap-2 group">
        <span className="text-sm text-foreground/80 flex-1">{value || "—"}</span>
        <button onClick={() => { setDraft(value); setEditing(true); }} className="opacity-0 group-hover:opacity-100 transition-opacity">
          <Edit2 className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground" />
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-2">
      {multiline ? (
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          rows={3}
          className="flex-1 px-2 py-1 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none resize-none"
          autoFocus
        />
      ) : (
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          className="flex-1 px-2 py-1 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none"
          autoFocus
        />
      )}
      <button onClick={() => { onSave(draft); setEditing(false); }} className="text-green-400 hover:text-green-300">
        <Check className="w-4 h-4" />
      </button>
      <button onClick={() => setEditing(false)} className="text-red-400 hover:text-red-300">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

function RacesAdmin() {
  const { data: races, refetch } = trpc.rules.races.useQuery();
  const updateMutation = trpc.admin.updateRace.useMutation({ onSuccess: () => { toast.success("Race mise à jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteRace.useMutation({ onSuccess: () => { toast.success("Race supprimée."); refetch(); } });
  const createMutation = trpc.admin.createRace.useMutation({ onSuccess: () => { toast.success("Race créée."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Races ({races?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom de la race" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, faction: "Tous", description: "", bonuses: [], maluses: [], abilities: [], physicalDescription: "", startingLanguages: [], pvBonus: 0, manaBonus: 0, luteBonus: 0, pvMalus: 0 })} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Créer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {races?.map((race) => (
          <div key={race.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={race.name} onSave={(v) => updateMutation.mutate({ id: race.id, data: { name: v } })} />
              </div>
              <div className="flex gap-1 ml-2">
                <select
                  value={race.faction}
                  onChange={(e) => updateMutation.mutate({ id: race.id, data: { faction: e.target.value as any } })}
                  className="text-xs px-2 py-1 rounded bg-secondary/30 border border-border/40 text-foreground"
                >
                  <option value="Tous">Tous</option>
                  <option value="Sanctum">Sanctum</option>
                  <option value="Légion">Légion</option>
                </select>
                <button onClick={() => deleteMutation.mutate({ id: race.id })} className="p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <EditableField value={race.description as string} onSave={(v) => updateMutation.mutate({ id: race.id, data: { description: v } })} multiline />
            <div className="flex gap-3 mt-2">
              {[
                { label: "PV+", field: "pvBonus", value: race.pvBonus },
                { label: "Mana+", field: "manaBonus", value: race.manaBonus },
                { label: "Lutte+", field: "luteBonus", value: race.luteBonus },
                { label: "PV-", field: "pvMalus", value: race.pvMalus },
              ].map((stat) => (
                <div key={stat.field} className="flex items-center gap-1">
                  <span className="text-xs text-muted-foreground">{stat.label}:</span>
                  <input
                    type="number"
                    defaultValue={stat.value}
                    onBlur={(e) => updateMutation.mutate({ id: race.id, data: { [stat.field]: parseInt(e.target.value) || 0 } })}
                    className="w-12 px-1 py-0.5 rounded bg-secondary/30 border border-border/40 text-xs text-foreground text-center focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ClassesAdmin() {
  const { data: classes, refetch } = trpc.rules.classes.useQuery();
  const updateMutation = trpc.admin.updateClass.useMutation({ onSuccess: () => { toast.success("Classe mise à jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteClass.useMutation({ onSuccess: () => { toast.success("Classe supprimée."); refetch(); } });
  const createMutation = trpc.admin.createClass.useMutation({ onSuccess: () => { toast.success("Classe créée."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Classes ({classes?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom de la classe" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, faction: "Tous", description: "", basePv: 10, baseMana: 0, baseAbilities: [], specialRules: [], requiresWeapon: false } as any)} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Creer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {classes?.map((classe) => (
          <div key={classe.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={classe.name} onSave={(v) => updateMutation.mutate({ id: classe.id, data: { name: v } })} />
              </div>
              <div className="flex gap-1 ml-2">
                <select
                  value={classe.faction || "Tous"}
                  onChange={(e) => updateMutation.mutate({ id: classe.id, data: { faction: e.target.value } } as any)}
                  className="text-xs px-2 py-1 rounded bg-secondary/30 border border-border/40 text-foreground"
                >
                  <option value="Tous">Tous</option>
                  <option value="Sanctum">Sanctum</option>
                  <option value="Legion">Legion</option>
                </select>
                <button onClick={() => deleteMutation.mutate({ id: classe.id })} className="p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <EditableField value={classe.description} onSave={(v) => updateMutation.mutate({ id: classe.id, data: { description: v } })} multiline />
            <div className="flex gap-3 mt-2">
              {[
                { label: "PV de base", field: "basePv", value: classe.basePv ?? 10 },
                { label: "Mana de base", field: "baseMana", value: classe.baseMana ?? 0 },
              ].map((stat) => (
                <div key={stat.field} className="flex items-center gap-1">
                  <span className="text-xs text-muted-foreground">{stat.label}:</span>
                  <input
                    type="number"
                    defaultValue={stat.value}
                    onBlur={(e) => updateMutation.mutate({ id: classe.id, data: { [stat.field]: parseInt(e.target.value) || 0 } })}
                    className="w-12 px-1 py-0.5 rounded bg-secondary/30 border border-border/40 text-xs text-foreground text-center focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CompetencesAdmin() {
  const { data: competences, refetch } = trpc.rules.competences.useQuery();
  const updateMutation = trpc.admin.updateCompetence.useMutation({ onSuccess: () => { toast.success("Compétence mise à jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteCompetence.useMutation({ onSuccess: () => { toast.success("Compétence supprimée."); refetch(); } });
  const createMutation = trpc.admin.createCompetence.useMutation({ onSuccess: () => { toast.success("Compétence créée."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Compétences ({competences?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom de la compétence" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, category: "simple", description: "", baseAdvantage: "", advancedAdvantage: "", requiredMaterial: "", isAdultOnly: false })} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Creer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {competences?.map((competence) => (
          <div key={competence.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={competence.name} onSave={(v) => updateMutation.mutate({ id: competence.id, data: { name: v } })} />
              </div>
              <div className="flex gap-1 ml-2">
                <select
                  value={competence.category}
                  onChange={(e) => updateMutation.mutate({ id: competence.id, data: { description: competence.description } } as any)}
                  className="text-xs px-2 py-1 rounded bg-secondary/30 border border-border/40 text-foreground"
                >
                  <option value="simple">Simple</option>
                  <option value="artisanat">Artisanat</option>
                </select>
                <button onClick={() => deleteMutation.mutate({ id: competence.id })} className="p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <EditableField value={competence.description} onSave={(v) => updateMutation.mutate({ id: competence.id, data: { description: v } })} multiline />
            <div className="mt-3 space-y-2">
              <div>
                <span className="text-xs text-muted-foreground">Avantage de base:</span>
                <EditableField value={competence.baseAdvantage} onSave={(v) => updateMutation.mutate({ id: competence.id, data: { baseAdvantage: v } })} multiline />
              </div>
              {competence.advancedAdvantage && (
                <div>
                  <span className="text-xs text-muted-foreground">Avantage avancé:</span>
                  <EditableField value={competence.advancedAdvantage} onSave={(v) => updateMutation.mutate({ id: competence.id, data: { advancedAdvantage: v } })} multiline />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function HeritageAdmin() {
  const { data: heritage, refetch } = trpc.rules.heritageAvantages.useQuery();
  const updateMutation = trpc.admin.updateHeritageAvantage.useMutation({ onSuccess: () => { toast.success("Heritage mis a jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteHeritage.useMutation({ onSuccess: () => { toast.success("Heritage supprime."); refetch(); } });
  const createMutation = trpc.admin.createHeritage.useMutation({ onSuccess: () => { toast.success("Heritage cree."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Héritage ({heritage?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom de l'héritage" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, description: "", xpCost: 0, maxTimes: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 })} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Créer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {heritage?.map((item: any) => (
          <div key={item.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={item.name} onSave={(v) => updateMutation.mutate({ id: item.id, data: { name: v } })} />
              </div>
              <button onClick={() => deleteMutation.mutate({ id: item.id })} className="p-1 text-red-400 hover:text-red-300 ml-2">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <EditableField value={item.description} onSave={(v) => updateMutation.mutate({ id: item.id, data: { description: v } })} multiline />
            <div className="flex gap-3 mt-2">
              {[
                { label: "XP", field: "xpCost", value: item.xpCost ?? 0 },
                { label: "PV+", field: "pvBonus", value: item.pvBonus ?? 0 },
                { label: "Mana+", field: "manaBonus", value: item.manaBonus ?? 0 },
                { label: "Lutte+", field: "luteBonus", value: item.luteBonus ?? 0 },
              ].map((stat) => (
                <div key={stat.field} className="flex items-center gap-1">
                  <span className="text-xs text-muted-foreground">{stat.label}:</span>
                  <input
                    type="number"
                    defaultValue={stat.value}
                    onBlur={(e) => updateMutation.mutate({ id: item.id, data: { [stat.field]: parseInt(e.target.value) || 0 } })}
                    className="w-12 px-1 py-0.5 rounded bg-secondary/30 border border-border/40 text-xs text-foreground text-center focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DesavantagesAdmin() {
  const { data: desavantages, refetch } = trpc.rules.desavantages.useQuery();
  const updateMutation = trpc.admin.updateDesavantage.useMutation({ onSuccess: () => { toast.success("Désavantage mis à jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteDesavantage.useMutation({ onSuccess: () => { toast.success("Désavantage supprimé."); refetch(); } });
  const createMutation = trpc.admin.createDesavantage.useMutation({ onSuccess: () => { toast.success("Désavantage créé."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Désavantages ({desavantages?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom du désavantage" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, description: "", xpGain: 0, xpType: "permanent" as any })} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Creer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {desavantages?.map((item: any) => (
          <div key={item.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={item.name} onSave={(v) => updateMutation.mutate({ id: item.id, data: { name: v } })} />
              </div>
              <div className="flex gap-1 ml-2">
                <select
                  value={item.xpType}
                  onChange={(e) => updateMutation.mutate({ id: item.id, data: { xpGain: item.xpGain } })}
                  className="text-xs px-2 py-1 rounded bg-secondary/30 border border-border/40 text-foreground"
                >
                  <option value="permanent">Permanent</option>
                  <option value="temporaire">Temporaire</option>
                </select>
                <button onClick={() => deleteMutation.mutate({ id: item.id })} className="p-1 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <EditableField value={item.description} onSave={(v) => updateMutation.mutate({ id: item.id, data: { description: v } })} multiline />
            <div className="flex gap-3 mt-2">
              <div className="flex items-center gap-1">
                <span className="text-xs text-muted-foreground">XP:</span>
                <input
                  type="number"
                  defaultValue={item.xpGain ?? 0}
                  onBlur={(e) => updateMutation.mutate({ id: item.id, data: { xpGain: parseInt(e.target.value) || 0 } })}
                  className="w-12 px-1 py-0.5 rounded bg-secondary/30 border border-border/40 text-xs text-foreground text-center focus:outline-none"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DonsAdmin() {
  const { data: dons, refetch } = trpc.rules.dons.useQuery();
  const updateMutation = trpc.admin.updateDon.useMutation({ onSuccess: () => { toast.success("Don mis à jour."); refetch(); } });
  const deleteMutation = trpc.admin.deleteDon.useMutation({ onSuccess: () => { toast.success("Don supprimé."); refetch(); } });
  const createMutation = trpc.admin.createDon.useMutation({ onSuccess: () => { toast.success("Don créé."); refetch(); setShowCreate(false); setNewName(""); } });
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg text-foreground">Dons ({dons?.length ?? 0})</h2>
        <Button size="sm" onClick={() => setShowCreate(!showCreate)} className="font-heading text-xs" style={{ background: "oklch(0.65 0.18 45)", color: "oklch(0.12 0.02 260)" }}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Ajouter
        </Button>
      </div>
      {showCreate && (
        <div className="p-4 rounded-lg border border-border/40 bg-card/30 mb-4 flex gap-2">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom du don" className="flex-1 px-3 py-2 rounded bg-secondary/30 border border-border/40 text-sm text-foreground focus:outline-none" />
          <Button size="sm" onClick={() => createMutation.mutate({ name: newName, description: "Description à compléter.", canStack: false, maxStacks: 1, pvBonus: 0, manaBonus: 0, luteBonus: 0 })} disabled={!newName.trim()} className="font-heading text-xs" style={{ background: "oklch(0.45 0.15 140)", color: "white" }}>
            Créer
          </Button>
        </div>
      )}
      <div className="space-y-3">
        {dons?.map((don) => (
          <div key={don.id} className="p-4 rounded-xl border border-border/40 bg-card/30">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <EditableField value={don.name} onSave={(v) => updateMutation.mutate({ id: don.id, data: { name: v } })} />
              </div>
              <button onClick={() => deleteMutation.mutate({ id: don.id })} className="p-1 text-red-400 hover:text-red-300 ml-2">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <EditableField value={don.description} onSave={(v) => updateMutation.mutate({ id: don.id, data: { description: v } })} multiline />
            <div className="flex gap-3 mt-2">
              {[
                { label: "PV+", field: "pvBonus", value: don.pvBonus ?? 0 },
                { label: "Mana+", field: "manaBonus", value: don.manaBonus ?? 0 },
                { label: "Lutte+", field: "luteBonus", value: don.luteBonus ?? 0 },
              ].map((stat) => (
                <div key={stat.field} className="flex items-center gap-1">
                  <span className="text-xs text-muted-foreground">{stat.label}:</span>
                  <input
                    type="number"
                    defaultValue={stat.value}
                    onBlur={(e) => updateMutation.mutate({ id: don.id, data: { [stat.field]: parseInt(e.target.value) || 0 } })}
                    className="w-12 px-1 py-0.5 rounded bg-secondary/30 border border-border/40 text-xs text-foreground text-center focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function UsersAdmin() {
  const { data: users, refetch } = trpc.admin.getAllUsers.useQuery();
  const updateRoleMutation = trpc.admin.updateUserRole.useMutation({ onSuccess: () => { toast.success("Rôle mis à jour."); refetch(); } });

  return (
    <div>
      <h2 className="font-heading font-semibold text-lg text-foreground mb-4">Utilisateurs ({users?.length ?? 0})</h2>
      <div className="space-y-3">
        {users?.map((user) => (
          <div key={user.id} className="p-4 rounded-xl border border-border/40 bg-card/30 flex items-center justify-between">
            <div>
              <p className="font-heading font-semibold text-foreground">{user.name ?? "Anonyme"}</p>
              <p className="text-xs text-muted-foreground">{user.email ?? user.openId}</p>
            </div>
            <select
              value={user.role}
              onChange={(e) => updateRoleMutation.mutate({ userId: user.id, role: e.target.value as any })}
              className="text-sm px-3 py-1.5 rounded bg-secondary/30 border border-border/40 text-foreground"
            >
              <option value="user">Joueur</option>
              <option value="organizer">Organisateur</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}

function PersonnagesAdmin() {
  const { data: personnages } = trpc.admin.getAllPersonnages.useQuery();

  return (
    <div>
      <h2 className="font-heading font-semibold text-lg text-foreground mb-4">Tous les personnages ({personnages?.length ?? 0})</h2>
      <div className="space-y-3">
        {personnages?.map((p) => (
          <div key={p.id} className="p-4 rounded-xl border border-border/40 bg-card/30 flex items-center justify-between">
            <div>
              <p className="font-heading font-semibold text-foreground">{p.name}</p>
              <div className="flex gap-2 mt-1">
                <span className="text-xs text-muted-foreground">{p.faction}</span>
                <span className="text-xs text-muted-foreground">Niv. {p.level}</span>
                <span className="text-xs text-green-400">{p.maxPv} PV</span>
                {p.maxMana > 0 && <span className="text-xs text-blue-400">{p.maxMana} Mana</span>}
              </div>
            </div>
            <Link href={`/personnage/${p.id}`}>
              <Button variant="outline" size="sm" className="font-heading text-xs">Voir</Button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Admin() {
  const { user, isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>("races");

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: "oklch(0.65 0.18 45)" }} />
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== "admin" && user?.role !== "organizer")) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: "oklch(0.55 0.22 25 / 0.15)", border: "2px solid oklch(0.55 0.22 25 / 0.4)" }}>
            <Lock className="w-8 h-8" style={{ color: "oklch(0.65 0.22 25)" }} />
          </div>
          <h2 className="text-2xl font-heading font-bold mb-2" style={{ color: "oklch(0.82 0.2 85)" }}>
            Accès restreint
          </h2>
          <p className="text-muted-foreground mb-6">Cette section est réservée aux organisateurs.</p>
          <Link href="/">
            <Button variant="outline" className="font-heading">Retour à l'accueil</Button>
          </Link>
        </div>
      </div>
    );
  }

  const tabs: { id: AdminTab; label: string; icon: any }[] = [
    { id: "races", label: "Races", icon: Users },
    { id: "classes", label: "Classes", icon: Shield },
    { id: "dons", label: "Dons", icon: Star },
    { id: "competences", label: "Compétences", icon: BookOpen },
    { id: "heritage", label: "Héritage", icon: Gem },
    { id: "desavantages", label: "Désavantages", icon: TrendingDown },
    { id: "personnages", label: "Personnages", icon: Sword },
    ...(user?.role === "admin" ? [{ id: "users" as AdminTab, label: "Utilisateurs", icon: Settings }] : []),
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-6xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-foreground transition-colors">Accueil</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Administration</span>
        </nav>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-heading font-bold" style={{ color: "oklch(0.82 0.2 85)" }}>
            Panneau d'administration
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Gérez le contenu du GN Terra Mortis — {user?.role === "admin" ? "Administrateur" : "Organisateur"}
          </p>
        </div>

        <div className="flex gap-6">
          {/* Sidebar */}
          <div className="w-48 flex-shrink-0">
            <nav className="space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-heading transition-all text-left"
                    style={{
                      background: activeTab === tab.id ? "oklch(0.65 0.18 45 / 0.15)" : "transparent",
                      color: activeTab === tab.id ? "oklch(0.82 0.2 85)" : "oklch(0.55 0.02 60)",
                      borderLeft: activeTab === tab.id ? "2px solid oklch(0.65 0.18 45)" : "2px solid transparent",
                    }}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {activeTab === "races" && <RacesAdmin />}
            {activeTab === "classes" && <ClassesAdmin />}
            {activeTab === "dons" && <DonsAdmin />}
            {activeTab === "competences" && <CompetencesAdmin />}
            {activeTab === "heritage" && <HeritageAdmin />}
            {activeTab === "desavantages" && <DesavantagesAdmin />}
            {activeTab === "users" && user?.role === "admin" && <UsersAdmin />}
            {activeTab === "personnages" && <PersonnagesAdmin />}
          </div>
        </div>
      </div>
    </div>
  );
}
