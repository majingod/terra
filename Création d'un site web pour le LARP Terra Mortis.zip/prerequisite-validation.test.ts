import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { dons, competences, heritageAvantages, desavantages, classes } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import {
  validateDon,
  validateCompetence,
  validateHeritage,
  validateDesavantage,
  validateCompleteSelection,
} from "./prerequisite-validation";

describe("Prerequisite Validation", () => {
  let db: any;
  let testDonId: number;
  let testCompetenceId: number;
  let testHeritageId: number;
  let testDesavantageId: number;
  let testClassId: number;

  beforeAll(async () => {
    db = await getDb();

    // Create test data
    const timestamp = Date.now();

    // Create a test don
    const donResult = await db
      .insert(dons)
      .values({
        name: `Test Don Validation ${timestamp}`,
        description: "Test don for validation",
        canStack: false,
        maxStacks: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
      });
    testDonId = donResult[0].insertId || 1;

    // Create a test competence
    const competenceResult = await db
      .insert(competences)
      .values({
        name: `Test Competence Validation ${timestamp}`,
        category: "simple",
        description: "Test competence for validation",
        baseAdvantage: "Base",
        advancedAdvantage: null,
        requiredMaterial: null,
        isAdultOnly: false,
      });
    testCompetenceId = competenceResult[0].insertId || 1;

    // Create a test heritage
    const heritageResult = await db
      .insert(heritageAvantages)
      .values({
        name: `Test Heritage Validation ${timestamp}`,
        description: "Test heritage for validation",
        xpCost: 5,
        maxTimes: 1,
        pvBonus: 0,
        manaBonus: 0,
        luteBonus: 0,
        paBonus: 0,
        poBonus: 0,
      });
    testHeritageId = heritageResult[0].insertId || 1;

    // Create a test desavantage
    const desavantageResult = await db
      .insert(desavantages)
      .values({
        name: `Test Desavantage Validation ${timestamp}`,
        description: "Test desavantage for validation",
        xpGain: 5,
        xpType: "temporaire",
        forbiddenClasses: [],
      });
    testDesavantageId = desavantageResult[0].insertId || 1;

    // Get a test class
    const classResult = await db.select().from(classes).limit(1);
    testClassId = classResult[0]?.id || 1;
  });

  describe("validateDon", () => {
    it("should validate a don successfully", async () => {
      const result = await validateDon(testDonId, {});
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should return error for non-existent don", async () => {
      const result = await validateDon(99999, {});
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("non trouvé");
    });

    it("should prevent stacking non-stackable don", async () => {
      const result = await validateDon(testDonId, {
        selectedDons: [testDonId],
      });
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("ne peut pas être sélectionné plusieurs fois");
    });
  });

  describe("validateCompetence", () => {
    it("should validate a competence successfully", async () => {
      const result = await validateCompetence(testCompetenceId, {});
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should return error for non-existent competence", async () => {
      const result = await validateCompetence(99999, {});
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("non trouvée");
    });

    it("should prevent duplicate competence selection", async () => {
      const result = await validateCompetence(testCompetenceId, {
        selectedCompetences: [testCompetenceId],
      });
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("déjà sélectionnée");
    });
  });

  describe("validateHeritage", () => {
    it("should validate a heritage successfully", async () => {
      const result = await validateHeritage(testHeritageId, {});
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should return error for non-existent heritage", async () => {
      const result = await validateHeritage(99999, {});
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("non trouvé");
    });

    it("should prevent duplicate heritage selection when maxTimes is 1", async () => {
      const result = await validateHeritage(testHeritageId, {
        selectedHeritages: [testHeritageId],
      });
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("ne peut être sélectionné qu'une seule fois");
    });
  });

  describe("validateDesavantage", () => {
    it("should validate a desavantage successfully", async () => {
      const result = await validateDesavantage(testDesavantageId, {});
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should return error for non-existent desavantage", async () => {
      const result = await validateDesavantage(99999, {});
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("non trouvé");
    });

    it("should prevent duplicate desavantage selection", async () => {
      const result = await validateDesavantage(testDesavantageId, {
        selectedDesavantages: [testDesavantageId],
      });
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain("déjà sélectionné");
    });
  });

  describe("validateCompleteSelection", () => {
    it("should validate a complete selection successfully", async () => {
      const result = await validateCompleteSelection({
        selectedDons: [testDonId],
        selectedCompetences: [testCompetenceId],
        selectedHeritages: [testHeritageId],
        selectedDesavantages: [testDesavantageId],
      });
      expect(result).toBeDefined();
      expect(result.errors).toBeDefined();
      expect(result.warnings).toBeDefined();
      expect(Array.isArray(result.errors)).toBe(true);
      expect(Array.isArray(result.warnings)).toBe(true);
    });

    it("should return errors for invalid selections", async () => {
      const result = await validateCompleteSelection({
        selectedDons: [testDonId, testDonId], // Duplicate non-stackable don
        selectedCompetences: [testCompetenceId, testCompetenceId], // Duplicate competence
      });
      expect(result.isValid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it("should handle empty selection", async () => {
      const result = await validateCompleteSelection({});
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });
});
